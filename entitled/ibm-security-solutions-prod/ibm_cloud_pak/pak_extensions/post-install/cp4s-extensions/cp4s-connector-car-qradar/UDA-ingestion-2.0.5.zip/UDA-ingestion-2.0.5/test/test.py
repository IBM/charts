import sys, os, unittest

test_dir = os.path.dirname(os.path.realpath(__file__))
code_dir = os.path.split(test_dir)[0]

sys.path.insert(0, test_dir)
sys.path.insert(0, code_dir)

import testdata
import core
import util
from microservice import Microservice
from config import Config

class TestContext:

    def __init__(self, data_size, test_dir, test_data_func, collection_callback=None, edge_callback=None):
        self.data_size = data_size
        self.logger = util.get_logger(test_dir)
        self.working_dir = test_dir
        self.updates_dir = self.working_dir + '/updates'
        if not os.path.exists(self.updates_dir):
            os.mkdir(self.updates_dir)
        self.config_file = self.working_dir + '/updates.conf'
        self.test_data_func = test_data_func
        self.collection_callback = collection_callback
        self.edge_callback = edge_callback
        self.url = 'test-url'
        self.apikey = 'test-apikey'
        self.version = 'test-version'
        self.exporter_version = 'exporter_version'
        self.source = 'source'
        self.source_name = 'source_name'

        self.config = Config(self)
    
    def execute(self, query, params=None):
        return self.test_data_func(self.data_size)

    def save_vertices(self, data):
        if len(data) == 2:
            return
        self.collection_callback(data)

    def save_edges(self, data):
        self.edge_callback(data)


class Response:
    def __init__(self, sc, data={}):
        self.status_code = sc
        self.data = data

    def json(self):
        return self.data

class TestCoreFunctions(unittest.TestCase):

    def check_source_report(self, data):
        self.assertTrue(data['report'])
        self.assertTrue(data['source'])


    def test_vuln(self):
        count = [0]
        def verify(data):
            self.check_source_report(data)
            count[0] += len(data['vulnerability'])
        context = TestContext(3000, test_dir, testdata.gen_vuln, collection_callback=verify)
        core.export_source_report(context)
        core.export_vuln(context)
        self.assertEquals([3000], count)

    def test_ip_vuln(self):
        count = [0]
        def verify(data):
            self.check_source_report(data)
            count[0] += len(data['ipaddress_vulnerability'])
        context = TestContext(3000, test_dir, testdata.gen_ip_vuln, edge_callback=verify)
        core.export_source_report(context)
        core.export_ip_vuln(context)
        self.assertEquals([8 * 3000], count)

    def test_application(self):
        
        collection_count = [0]
        def verify_collection(data):
            self.check_source_report(data)
            collection_count[0] += len(data['application'])

        edge_count = [0]
        def verify_edges(data):
            self.check_source_report(data)
            edge_count[0] += len(data['report_application'])

        context = TestContext(3000, test_dir, testdata.gen_app, collection_callback=verify_collection, edge_callback=verify_edges)
        core.export_source_report(context)
        core.export_asset_application(context)
        self.assertEquals([3000], collection_count)
        self.assertEquals([0], edge_count)

    def test_app_port(self):
        count = [0]
        def verify(data):
            self.check_source_report(data)
            count[0] += len(data['application_port'])
        context = TestContext(3000, test_dir, testdata.gen_app_port, edge_callback=verify)
        core.export_source_report(context)
        core.export_application_port(context)
        self.assertEquals([3000], count)

    def test_app_vuln(self):
        count = [0]
        def verify(data):
            self.check_source_report(data)
            count[0] += len(data['application_vulnerability'])
        context = TestContext(3000, test_dir, testdata.gen_app_vuln, edge_callback=verify)
        core.export_source_report(context)
        core.export_application_vuln(context)
        self.assertEquals([8 * 3000], count)

    def test_user(self):
        
        collection_count = [0]
        def verify_collection(data):
            self.check_source_report(data)
            if data.get('user'):
                collection_count[0] += len(data['user'])
            if data.get('account'):
                collection_count[0] += len(data['account'])

        edge_count = [0]
        def verify_edges(data):
            self.check_source_report(data)
            if data.get('asset_account'):
                edge_count[0] += len(data['asset_account'])
            if data.get('user_account'):
                edge_count[0] += len(data['user_account'])

        context = TestContext(3000, test_dir, testdata.gen_user, collection_callback=verify_collection, edge_callback=verify_edges)
        core.export_source_report(context)
        core.export_user(context)
        self.assertEquals([6000], collection_count)
        self.assertEquals([6000], edge_count)

    def test_hostname(self):
        
        collection_count = [0]
        def verify_collection(data):
            self.check_source_report(data)
            collection_count[0] += len(data['hostname'])

        edge_count = [0]
        def verify_edges(data):
            self.check_source_report(data)
            edge_count[0] += len(data['asset_hostname'])

        context = TestContext(3000, test_dir, testdata.gen_hostname, collection_callback=verify_collection, edge_callback=verify_edges)
        core.export_source_report(context)
        core.export_hostname(context)
        self.assertEquals([3000], collection_count)
        self.assertEquals([3000], edge_count)

    def test_ip_hostname_user_rels(self):
        
        edge_count = [0]
        def verify(data):
            self.check_source_report(data)
            if data.get('ipaddress_hostname'):
                edge_count[0] += len(data['ipaddress_hostname'])
            if data.get('account_ipaddress'):
                edge_count[0] += len(data['account_ipaddress'])
            if data.get('account_hostname'):
                edge_count[0] += len(data['account_hostname'])

        context = TestContext(3000, test_dir, testdata.gen_ip_hostname_user_rels, edge_callback=verify)
        core.export_source_report(context)
        core.export_ip_hostname_user_rels(context, isUpdate=True)
        self.assertEquals([3 * 3000], edge_count)

    def test_port(self):
        count = [0]
        def verify(data):
            self.check_source_report(data)
            count[0] += len(data['port'])
        context = TestContext(3000, test_dir, testdata.gen_port, collection_callback=verify)
        core.export_source_report(context)
        core.export_port(context)
        self.assertEquals([3000], count)

    def test_ip_port(self):
        count = [0]
        def verify(data):
            self.check_source_report(data)
            count[0] += len(data['ipaddress_port'])
        context = TestContext(3000, test_dir, testdata.gen_ip_port, edge_callback=verify)
        core.export_source_report(context)
        core.export_ip_port(context)
        self.assertEquals([3000], count)

    def test_asset(self):
        
        collection_count = [0]
        def verify_collection(data):
            self.check_source_report(data)
            collection_count[0] += len(data['asset'])

        edge_count = [0]
        def verify_edges(data):
            self.check_source_report(data)

        context = TestContext(3000, test_dir, testdata.gen_asset, collection_callback=verify_collection, edge_callback=verify_edges)
        core.export_source_report(context)
        core.export_asset(context)
        self.assertEquals([3000], collection_count)
        self.assertEquals([0], edge_count)

    def test_asset_mac(self):
        count = [0]
        def verify(data):
            self.check_source_report(data)
            count[0] += len(data['asset_macaddress'])
        context = TestContext(3000, test_dir, testdata.gen_asset_mac, edge_callback=verify)
        core.export_source_report(context)
        core.export_asset_mac(context)
        self.assertEquals([3000], count)

    def test_asset_ip(self):
        count = [0]
        def verify(data):
            self.check_source_report(data)
            count[0] += len(data['asset_ipaddress'])
        context = TestContext(3000, test_dir, testdata.gen_asset_ip, edge_callback=verify)
        core.export_source_report(context)
        core.export_asset_ipaddress(context)
        self.assertEquals([3000], count)

    def test_asset_vuln(self):
        count = [0]
        def verify(data):
            self.check_source_report(data)
            count[0] += len(data['asset_vulnerability'])
        context = TestContext(3000, test_dir, testdata.gen_asset_vuln, edge_callback=verify)
        core.export_source_report(context)
        core.export_asset_vulnerability(context)
        self.assertEquals([3000], count)

    def test_ip(self):
        
        collection_count = [0]
        def verify_collection(data):
            self.check_source_report(data)
            collection_count[0] += len(data['ipaddress'])

        edge_count = [0]
        def verify_edges(data):
            self.check_source_report(data)

        context = TestContext(3000, test_dir, testdata.gen_ip, collection_callback=verify_collection, edge_callback=verify_edges)
        core.export_source_report(context)
        core.export_ip(context)
        self.assertEquals([3000], collection_count)
        self.assertEquals([0], edge_count)

    def test_mac(self):
        count = [0]
        def verify(data):
            self.check_source_report(data)
            count[0] += len(data['macaddress'])
        context = TestContext(3000, test_dir, testdata.gen_mac, collection_callback=verify)
        core.export_source_report(context)
        core.export_mac(context)
        self.assertEquals([3000], count)

    def test_ip_mac(self):
        count = [0]
        def verify(data):
            self.check_source_report(data)
            count[0] += len(data['ipaddress_macaddress'])
        context = TestContext(3000, test_dir, testdata.gen_ip_mac, edge_callback=verify)
        core.export_source_report(context)
        core.export_ip_mac(context)
        self.assertEquals([3000], count)

class TestMicroserviceConnector(unittest.TestCase):

    def test_microservice(self):

        class Communicator(object):
            
            # Make files 10, 20, 30 fail and the others succeed
            def send_post_request(self, url, **args):
                file = args['data']
                file_number = int(filter(str.isdigit, file))
                if file_number in (10, 20):
                    return Response(500)
                if file_number == 30:
                    raise Exception('Error') # Pretend something wrong happened
                return Response(200, {'id' : 'job-id-%d' % file_number})

            # Make files 11 and 12 fail and the others succeed
            def send_get_request(self, url, **args):
                params = args['params']
                ids = params['ids'].split(',')
                errors = ('job-id-11' in ids) and [{'id' : 'job-id-11', 'error': 'Error', 'statusCode': 400}, {'id' : 'job-id-12', 'error': 'Error', 'statusCode': 400}] or []
                ids = filter(lambda id: id not in ('job-id-11','job-id-12'), ids)
                ids = ids[1:]
                data = {'error_imports' : errors, 'incomplete_imports' : map(lambda id: {'id': id}, ids)}
                return Response(200, data)

        import microservice
        microservice.max_wait_time = 1
        m = Microservice(util.get_logger(test_dir), Communicator(), 'test-base-url', 'test-source', '.')
        statuses = []
        for i in range(50):
            file = 'file-to-import-%d' % i
            statuses.append(m.import_file(file, file))
        m.check_import_status(statuses)
        self.assertEquals(50, len(statuses))
        for s in statuses:
            if s.file in ['file-to-import-10','file-to-import-20','file-to-import-30','file-to-import-11','file-to-import-12']:
                self.assertTrue(s.status == util.FAILURE)
            else:
                self.assertTrue(s.status == util.SUCCESS)


from test_real_db import Import_121_Assets, Update_121_Assets, Tracker_Test
from test_commands import TestCommandQueue

if __name__ == '__main__':
    suite = unittest.TestSuite()
    suite.addTest(unittest.TestLoader().loadTestsFromTestCase(TestCoreFunctions))
    suite.addTest(unittest.TestLoader().loadTestsFromTestCase(TestMicroserviceConnector))
    suite.addTest(unittest.TestLoader().loadTestsFromTestCase(Import_121_Assets))
    suite.addTest(unittest.TestLoader().loadTestsFromTestCase(Update_121_Assets))
    suite.addTest(unittest.TestLoader().loadTestsFromTestCase(Tracker_Test))
    suite.addTest(unittest.TestLoader().loadTestsFromTestCase(TestCommandQueue))
    unittest.TextTestRunner(verbosity=2).run(suite)
