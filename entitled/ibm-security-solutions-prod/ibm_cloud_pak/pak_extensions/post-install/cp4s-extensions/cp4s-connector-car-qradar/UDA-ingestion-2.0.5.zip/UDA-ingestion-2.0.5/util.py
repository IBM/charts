import os, re, math, time, base64
from os.path import join, dirname, realpath
import datetime 
import logging
import subprocess


def get_logger(working_dir, debug = False):
    now = datetime.datetime.now()
    logfile = 'assets-'+str(now).replace(' ', '-').replace(':', '-')+'.log'
    # create logger
    logger = logging.getLogger(logfile)
    logger.setLevel(debug and logging.DEBUG or logging.INFO)

    # create console handler and set level to debug
    ch = logging.StreamHandler()
    ch.setLevel(debug and logging.DEBUG or logging.INFO)

    # Create fileHandler
    # check if the ./logs folder exists, if it doesn't create it
    if not os.path.exists('{}/logs/'.format(working_dir)):
        os.makedirs('{}/logs/'.format(working_dir))
    fdlr = logging.FileHandler(working_dir + '/logs/' + logfile)
    fdlr.setLevel(debug and logging.DEBUG or logging.INFO)

    # create formatter
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')

    # add formatter to ch
    ch.setFormatter(formatter)
    fdlr.setFormatter(formatter)

    # add ch to logger
    logger.addHandler(fdlr) 
    logger.addHandler(ch)
    return logger

def get_json(response):
    try: return response.json()
    except: return {}

def get_report_time_utc():
    delta = datetime.datetime.utcnow() - datetime.datetime(1970, 1, 1)
    milliseconds = delta.total_seconds()*1000
    return milliseconds

def delete_file(logger, path):
    for i in range(10):
        try: 
            if os.path.exists(path):
                os.remove(path)
            return
        except Exception as e:
            logger.error('Error occured when deleting file: ' + path)
            logger.exception(e)
            time.sleep(0.5)

def get_report_date():
    return datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3] + 'Z'

def measure_time(logger, message, func):
    logger.info(message + ' ...')
    start_time = math.ceil(time.time())
    res = func()
    logger.info(message + ' done')
    logger.info('%s took: %s' % (message, math.ceil(time.time()) - start_time))
    return res

def generate_apikey(key, password):
    base64string = base64.encodestring('%s:%s' % (key, password)).replace('\n', '')
    return base64string

def recoverable_failure_status_code(status_code):
    return status_code in (401, 403, 408, 503, 504)

FAILURE = 0
SUCCESS = 1

def run_command(logger, cmd, inputData=None):
    # logger.info("Running command '%s' in '%s'" % (' '.join(cmd), os.getcwd()))
    p = subprocess.Popen(cmd, stdin = subprocess.PIPE, stdout = subprocess.PIPE, stderr = subprocess.PIPE, shell = True)
    out, err = p.communicate(inputData)
    rc = p.wait()
    if (rc != 0):
        logger.error('External command execution error: {}'.format(cmd))
    return (rc, out, err)

class Status(dict):
    def __init__(self, file=None):
        self['status'] = 'FAILURE'
        self['status_code'] = 0
        self['file'] = file

    @property
    def status(self):
        return self['status'] == 'SUCCESS' and SUCCESS or FAILURE

    @status.setter
    def status(self, value):
        self['status'] = value == SUCCESS and 'SUCCESS' or 'FAILURE'

    @property
    def status_code(self):
        return self.get('status_code')

    @status_code.setter
    def status_code(self, value):
        self['status_code'] = value

    @property
    def file(self):
        return self.get('file')

    @file.setter
    def file(self, value):
        self['file'] = value

    @property
    def error(self):
        return self.get('error')

    @error.setter
    def error(self, value):
        self['error'] = value

class CommandId(object):

    def __init__(self):
        self.fname = join(dirname(realpath(__file__)), 'command.id')

    def next(self):
        try:
            with open(self.fname) as f:
                id = int(f.read().strip())
        except:
            id = 0
        id += 1
        with open(self.fname, 'w') as f:
            f.write('%d' % id)
        return id

class RecoverableFailure(Exception):
    def __init__(self, message):
        self.message = message
class UnrecoverableFailure(Exception):
    callback = None
    def __init__(self, message):
        self.message = message
        if UnrecoverableFailure.callback:
            UnrecoverableFailure.callback(self, message)
