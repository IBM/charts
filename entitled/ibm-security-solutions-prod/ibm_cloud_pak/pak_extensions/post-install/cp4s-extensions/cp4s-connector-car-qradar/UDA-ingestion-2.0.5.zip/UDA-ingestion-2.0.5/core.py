import os, datetime
from distutils.version import LooseVersion
from util import get_report_time_utc

save_json_array_size = 2000

source = {}
report = {}
source_report = {}
source_report_obj = {}
ipaddress_keys = {}
users_keys = {}
accounts_keys = {}
hostname_keys = {}

class DataConsumer(object):

    def __init__(self, context, name):
        self.context = context
        self.name = name

    def copy(self, obj, target):
        pass

    def create_envelope(self):
        self.result = []
        self.envelope = {}
        self.envelope[self.name] = self.result
        add_source_report_info(self.envelope)

    def save(self):
        if self.result:
            self.context.save_vertices(self.envelope)

class EdgeDataConsumer(DataConsumer):
    def save(self):
        if self.result:
            self.context.save_edges(self.envelope)

class QueryProcessor(object):

    def __init__(self, context, query, *consumers):
        self.context = context
        self.query = query
        self.consumers = consumers

    def process(self):
        for consumer in self.consumers:
            consumer.create_envelope()
        with self.context.execute(self.query) as cursor:
            for obj in cursor:
                for consumer in self.consumers:
                    consumer.consume(obj, {})
                    if len(consumer.result) == save_json_array_size:
                        # create new file
                        consumer.save()
                        consumer.create_envelope()
            for consumer in self.consumers:
                consumer.save()
        return self.consumers[0].result

# def build_collections_vuln_edges(edgeName, collection, key, vulnids, risks, timestamp):
def build_collections_vuln_edges(edge_name, collection, obj, key, timestamp, source_key, report_key, active, app_vuln_id = None):
    edge_array = []
    vulnids = str(obj['vulnid']).split(",")
    # risks = str(obj['risks']).split(",")
    vulninstanceids = app_vuln_id.split(",") if app_vuln_id is not None else str(obj['vulninstanceid']).split(",") 
    # assetid = obj['assetid']
    for vuln, vid in zip(vulnids, vulninstanceids):
        edge_name = {}
        # TODO _key of the edge is the vulninstanceid
        # edge_name['_key'] = str(vid) + '|' + collection + '/' + str(key) + 'vulnerability/' + str(vuln)
        edge_name['active'] = active
        edge_name['report'] = report_key
        edge_name['source'] = str(source_key)
        edge_name['timestamp'] = timestamp
        edge_name['external_id'] = str(vid)
        # edge_name['q_assetid'] = assetid
        if collection == 'ipaddress':
            edge_name['_from'] = collection+'/'+str(key)
        else:
            edge_name['_from_external_id'] = str(key)
        edge_name['_to_external_id'] = str(vuln)
        # edge_name['risk'] = float(risk)
        edge_array.append(edge_name)
    return edge_array

def is_cleanedup(value, data):
    if(data.get(value) == '1'):
        return False
    return True
    
def get_operating_system(context, propertyvalue):
    operating_system = None
    query = "select distinct getosvariantname(%s) as operating_system from asset.assetproductvariantxref as assetproductvariantxref"
    with context.execute(query, (propertyvalue, )) as cursor:
        for obj in cursor:
            operating_system = obj['operating_system']
    return operating_system

def add_asset_prop(context, target, srcobj):
    if srcobj['assetpropertytypeid'] is not None:
        assetpropertytypeids = srcobj['assetpropertytypeid'].split(',')
        propertyvalues = srcobj['propertyvalue'].split(',')
        name = None
        for assetpropertytypeid, propertyvalue in zip(assetpropertytypeids, propertyvalues):
            if assetpropertytypeid == '1002':
                name = propertyvalue
                target['name'] = name # unified name
            elif assetpropertytypeid == '1001' and name is not None:
                target['name'] = propertyvalue # given name
            elif assetpropertytypeid == '1003': # weight
                target['business_value'] = float(propertyvalue)
            elif assetpropertytypeid == '1004':  # description
                target['description'] = propertyvalue
            elif assetpropertytypeid == '1005':  # description
                target['business_owner'] = propertyvalue
            elif assetpropertytypeid == '1007':  # description
                target['technical_owner'] = propertyvalue
            elif assetpropertytypeid == '1026':  # description
                target['asset_type'] = propertyvalue
            # TODO delete the following when you know if operating_system is in application
            elif srcobj['assetpropertytypeid'] == '1033':  # operating_system
                primary_os = get_operating_system(context, propertyvalue)
                if primary_os is not None:
                    target['primary_os'] = primary_os

def export_ip(context, whereclause=""):
    if LooseVersion(context.version) > LooseVersion('7.3.0.0'):
        query = "select interface.assetid, interface.id as interfaceid, ipaddress.id as ipid, ipaddress.ipaddress, interface.macaddress from asset.ipaddress as ipaddress INNER JOIN asset.interface as interface on ipaddress.interfaceid = interface.id {} ".format(whereclause)
    else:
        # 7.2.8 system
        query = "select interface.assetid, interface.id as interfaceid, ipaddress.id as ipid, case when ipaddress.ipv4address is not null then ip2address(ipaddress.ipv4address) else ipaddress.ipv6address end as ipaddress, interface.macaddress from asset.ipaddress as ipaddress INNER JOIN asset.interface as interface on ipaddress.interfaceid = interface.id {} ".format(whereclause)

    class IpaddressConsumer(DataConsumer):
        duplicates = {}
        def consume(self, obj, ipaddress):
            if obj['ipaddress'] and obj['ipaddress'] != '::1' and self.duplicates.get(obj['ipaddress'], 0) == 0:
                self.duplicates[obj['ipaddress']] = 1
                ipaddress['_key'] = obj['ipaddress']
                ipaddress['assetid'] = str(obj['assetid'])
                ipaddress_keys[obj['ipaddress']] = 1
                self.result.append(ipaddress)

    ip_address_consumer = IpaddressConsumer(context, 'ipaddress')
    QueryProcessor(context, query, ip_address_consumer).process()
    return ip_address_consumer.result

def export_mac(context, whereclause = ""):
    query = "select interface.assetid, interface.id as interfaceid, interface.macaddress from asset.interface as interface {} ".format(whereclause)

    class MacConsumer(DataConsumer):
        duplicates = {}
        def consume(self, obj, macaddress):
            if obj['macaddress'] and self.duplicates.get(obj['macaddress'], 0) == 0:
                self.duplicates[obj['macaddress']] = 1
                macaddress['_key'] = obj['macaddress']
                macaddress['assetid'] = str(obj['assetid'])
                self.result.append(macaddress)

    return QueryProcessor(context, query, MacConsumer(context, 'macaddress')).process()

def export_ip_mac(context, whereclause="", active = True):
    if LooseVersion(context.version) > LooseVersion('7.3.0.0'):
        query = "select interface.assetid, interface.id as interfaceid, ipaddress.id as ipid, assetproperty.id as assetpropertyid, ipaddress.ipaddress, interface.macaddress, assetproperty.assetpropertytypeid AS assetpropertytypeid, assetproperty.propertyvalue AS propertyvalue  from asset.ipaddress as ipaddress INNER JOIN asset.interface as interface on ipaddress.interfaceid = interface.id LEFT JOIN asset.assetproperty as assetproperty on assetproperty.assetid = interface.assetid and assetproperty.assetpropertytypeid in ( 1003, 1004, 1033) {} ".format(whereclause)
    else:
        # 7.2.8 system
        query = "select interface.assetid, interface.id as interfaceid, ipaddress.id as ipid, assetproperty.id as assetpropertyid, case when ipaddress.ipv4address is not null then ip2address(ipaddress.ipv4address) else ipaddress.ipv6address end as ipaddress, interface.macaddress, assetproperty.assetpropertytypeid AS assetpropertytypeid, assetproperty.propertyvalue AS propertyvalue  from asset.ipaddress as ipaddress INNER JOIN asset.interface as interface on ipaddress.interfaceid = interface.id LEFT JOIN asset.assetproperty as assetprop on assetproperty.assetid = interface.assetid and assetproperty.assetpropertytypeid in ( 1003, 1004, 1033) {} ".format(whereclause)

    class IpaddressMacConsumer(EdgeDataConsumer):
        def consume(self, obj, ipaddress_macaddress):
            if obj['ipaddress'] and obj['macaddress']:
                ipaddress_macaddress = {}
                # ipaddress_macaddress['_key'] = str(obj['ipaddress']) + '-' + str(obj['macaddress'])
                ipaddress_macaddress['_from'] = 'ipaddress/' + obj['ipaddress']
                ipaddress_macaddress['_to'] = 'macaddress/' + obj['macaddress']
                ipaddress_macaddress['report'] = report['_key']
                ipaddress_macaddress['source'] = source['_key']
                ipaddress_macaddress['q_assetid'] = obj['assetid']
                ipaddress_macaddress['external_id'] = str(obj['interfaceid'])
                ipaddress_macaddress['active'] = active
                ipaddress_macaddress['timestamp'] = report['timestamp']
                self.result.append(ipaddress_macaddress)

    return QueryProcessor(context, query, IpaddressMacConsumer(context, 'ipaddress_macaddress')).process()

def add_xref_properties(vulnerability, extreftypeids, extreftypenames, refvalues):
    if extreftypeids is not None:
        extreftypeidarray = extreftypeids.split(',')
        extreftypenamearray = extreftypenames.split(',')
        refvaluearray = refvalues.split(',')
        properties =  []
        for extreftypeid, extreftypename, refvalue in zip(extreftypeidarray, extreftypenamearray, refvaluearray):
            property_vuln = {}
            property_vuln['q_extref_typeid'] = str(extreftypeid)
            property_vuln['extref_typename'] = str(extreftypename)
            property_vuln['extref_value'] = str(refvalue)
            properties.append(property_vuln)
        return properties

# TODO there is an idea about importing just the vulnid and risk for the vulnerability collection in each account and an other master database that conatins the details of vulnerabilities, needs to confirm when and how this will work
def export_vuln(context, whereclause = ""):
    # tables: vuln, q_catalog.vulncvssbasemetrics, extref, extrefvalue, extreftype
    # I made DISTINCT vulncvssbasemetrics.vulncvssbasemetricsid because it should be onlu one value, same logic applied to vulncvssbasemetrics.base_score
    query = "select vuln.vulnid, string_agg(extreftype.extreftypeid::text, ',') as extreftypeid, string_agg(extreftype.typename::text, ',') as extreftypename , string_agg(extrefvalue.refvalue::text, ',') as refvalue, string_agg(DISTINCT vulncvssbasemetrics.vulncvssbasemetricsid::text, ',') as vcvssbmid, string_agg(DISTINCT vulncvssbasemetrics.base_score::text, ',') as base_score, vuln.osvdbid, vuln.osvdbtitle as name, vuln.osvdbcreatedate, EXTRACT(EPOCH FROM vuln.lastmodifieddate) * 1000 as updated_on, EXTRACT(EPOCH FROM vuln.exploitpublishdate) * 1000 as published_on, EXTRACT(EPOCH FROM vuln.disclosuredate) * 1000 as disclosed_on, vuln.discoverydate from vuln as vuln LEFT JOIN extref on vuln.vulnid = extref.vulnid LEFT JOIN extrefvalue as extrefvalue on extrefvalue.extrefvalueid = extref.extrefvalueid LEFT JOIN extreftype as extreftype on extreftype.extreftypeid = extrefvalue.extreftypeid LEFT JOIN q_catalog.vulncvssbasemetrics as vulncvssbasemetrics on vulncvssbasemetrics.vulnid = vuln.vulnid {} group by vuln.vulnid ".format(whereclause)

    class VulnConsumer(DataConsumer):
        duplicates = {}
        def consume(self, obj, vulnerability):
            if self.duplicates.get(obj['vulnid'], 0) == 0:
                self.duplicates[obj['vulnid']] = 1
                vulnerability['external_id'] = str(obj['vulnid'])
                
                # need to add vcvssbmid because when delete triggered in vulncvssbasemetrics, the only info we can get from replication files are just the `id`
                vulnerability['vcvssbmid'] = obj['vcvssbmid']
                vulnerability['name'] = obj['name']
                if obj['base_score']:
                    vulnerability['base_score'] = float(obj['base_score'])
                vulnerability['xref_properties'] = add_xref_properties(vulnerability, obj['extreftypeid'], obj['extreftypename'], obj['refvalue'])
                vulnerability['disclosed_on'] = int(obj['disclosed_on'])
                vulnerability['published_on'] = int(obj['published_on'])
                vulnerability['updated_on'] = int(obj['updated_on'])
                self.result.append(vulnerability)

    return QueryProcessor(context, query, VulnConsumer(context, 'vulnerability')).process()

def export_ip_vuln(context, whereclause = "", active = True):
    if LooseVersion(context.version) > LooseVersion('7.3.0.0'):
        query = "select string_agg(vulninstance.id::text, ',') AS vulninstanceid, vulninstance.assetid, ipaddress.ipaddress,  string_agg(vulninstance.vulnid::text, ',') AS vulnid from asset.ipaddress as ipaddress INNER JOIN asset.interface as interface on ipaddress.interfaceid = interface.id INNER JOIN asset.vulninstance as vulninstance on vulninstance.assetid = interface.assetid INNER JOIN vuln as vuln on vuln.vulnid = vulninstance.vulnid {} group by vulninstance.assetid, ipaddress.id ".format(whereclause)
    else:
        # 7.2.8 system
        query = "select string_agg(vulninstance.id::text, ',') AS vulninstanceid, vulninstance.assetid , case when ipaddress.ipv4address is not null then ip2address(ipaddress.ipv4address) else ipaddress.ipv6address end as ip, string_agg(vulninstance.vulnid::text, ',') AS vulnid from asset.ipaddress as ipaddress INNER JOIN asset.interface as interface on ipaddress.interfaceid = interface.id INNER JOIN asset.vulninstance as vulninstance on vulninstance.assetid = interface.assetid INNER JOIN vuln as vuln on vuln.vulnid = vulninstance.vulnid {} group by vulninstance.assetid, ipid ".format(whereclause)

    class IpVulnConsumer(EdgeDataConsumer):
        def consume(self, obj, ip_vuln):
            # if whereclause is empty then this call is for the initial_import
            # I don't think we need the ipaddressarray if it is incremental update, since this is triggered when vulnerability has been dropped of an asset. I.E, when this is called for initial import, it is better to pre-compute the risk and send an update to arangodb, when it is incremental update, the risk will be recomputed at ingestion service level
            # UPDATE the risk will be computed in arangodb side
            if (obj['ipaddress'] is not None) and (obj['vulnid'] is not None) and (obj['ipaddress'] != '::1'):
                edges = build_collections_vuln_edges('ipaddress_vulnerability', 'ipaddress', obj, obj['ipaddress'], report['timestamp'], source['_key'], report['_key'], active)
            self.result.extend(edges)

    return QueryProcessor(context, query, IpVulnConsumer(context, 'ipaddress_vulnerability')).process()

def export_asset_application(context, whereclause = "", active = True):
    query = "SELECT assetproductvariantxref.assetid, assetproductvariantxref.id as id, os.weight, os.id as osid, assetproductvariantxref.productvariantid AS productid, CASE WHEN assetproductvariantxref.productvariantid = 1 THEN 'Unknown' ELSE getosvariantname(assetproductvariantxref.productvariantid) END AS product FROM asset.assetproductvariantxref as assetproductvariantxref LEFT JOIN asset.os as os on os.assetproductvariantxrefid = assetproductvariantxref.id {} ".format(whereclause)

    class AppConsumer(DataConsumer):
        duplicates = {}
        def consume(self, obj, application):
            if self.duplicates.get(obj['id'], 0) == 0:
                self.duplicates[obj['id']] = 1
                application['external_id'] = str(obj['id'])
                application['assetid'] = str(obj['assetid'])
                application['name'] = obj['product']
                self.result.append(application)

    class AssetAppConsumer(EdgeDataConsumer):
        def consume(self, obj, asset_application):
            # dont know for now the assetid in arangodb
            # the asset_external_id and application_external_id will not be saved into arangodb but it will be used to determine the _from and _to values
            asset_application['_from_external_id'] = str(obj['assetid'])
            asset_application['_to_external_id'] = str(obj['productid'])
            asset_application['timestamp'] = report['timestamp']
            asset_application['source'] = source['_key']
            asset_application['report'] = report['_key']
            asset_application['active'] = active
            asset_application['external_id'] = str(obj['id'])

            # last_modified will be null if it is an insert and will be the report timesatmp if it an update
            # asset_application['last_modified'] = report['timestamp']
            if obj['osid']:
                asset_application['is_os'] = True
                asset_application['weight'] = obj['weight']
            self.result.append(asset_application)

        # TODO: for some reason the results are not saved. Need to double check if this is by intention
        def save(self):
            pass

    app_consumer = AppConsumer(context, 'application')
    asset_app_consumer = AssetAppConsumer(context, 'not-used')

    QueryProcessor(context, query, app_consumer, asset_app_consumer).process()
    return app_consumer.result, asset_app_consumer.result

def export_application_port(context, whereclause = "", active = True):
    query = "SELECT portassetproductvariantxrefxref.id as id, assetproductvariantxref.id AS productid, port.id AS portid FROM asset.assetproductvariantxref as assetproductvariantxref INNER JOIN asset.portassetproductvariantxrefxref as portassetproductvariantxrefxref ON portassetproductvariantxrefxref.assetproductvariantxrefid = assetproductvariantxref.id INNER JOIN asset.port as port ON port.id = portassetproductvariantxrefxref.portid {} ".format(whereclause)

    class AppPortConsumer(EdgeDataConsumer):
        def consume(self, obj, application_port):
            if obj['portid']:
                # the below application_external_id and port_external_id values will not be saved in arangodb but they will be used to determine the keys of _from and _to attributes 
                application_port['_from_external_id'] = str(obj['productid'])
                application_port['_to_external_id'] = str(obj['portid'])
                application_port['report'] = str(report['_key'])
                application_port['active'] = active
                application_port['timestamp'] = report['timestamp']
                application_port['source'] = str(source['_key'])
                application_port['external_id'] = str(obj['id'])
                self.result.append(application_port)

    return QueryProcessor(context, query, AppPortConsumer(context, 'application_port')).process()

def export_application_vuln(context, whereclause = "", active = True):
    query = "SELECT string_agg(assetproductvulnxref.id::text, ',') AS app_vuln_id, string_agg(vulninstance.id::text, ',') AS vulninstanceid, vulninstance.assetid, assetproductvariantxref.id as appid, assetproductvariantxref.productvariantid AS productid, CASE WHEN assetproductvariantxref.productvariantid = 1 THEN 'Unknown' ELSE getosvariantname(assetproductvariantxref.productvariantid) END AS product, string_agg(vulninstance.vulnid::text, ',') AS vulnid FROM asset.assetproductvariantxref assetproductvariantxref INNER JOIN asset.assetproductvulnxref assetproductvulnxref ON assetproductvulnxref.assetproductvariantxrefid = assetproductvariantxref.id INNER JOIN asset.vulninstance as vulninstance ON vulninstance.id = assetproductvulnxref.vulninstanceid INNER JOIN public.vuln ON public.vuln.vulnid = vulninstance.vulnid {} group by vulninstance.assetid, assetproductvariantxref.id ".format(whereclause)

    class AppVulnConsumer(EdgeDataConsumer):
        # application_external_id will not be saved into arangodb but it will be used to determine the _key value of the application
        # application['name'] = str(obj['product'])

        # if whereclause is empty then this call is for the initial_import
        # I don't think we need the applicationarray if it is incremental update, since this is triggered when vulnerability has been dropped of an asset. I.E, when this is called for initial import, it is better to pre-compute the risk and send an update to arangodb, when it is incremental update, the risk will be recomputed at ingestion service level
        
        # UPDATE application does not have risk anymore, the risk is only on the asset
        def consume(self, obj, app_vuln):
            edges = build_collections_vuln_edges('application_vulnerability', 'application', obj, str(obj['appid']), report['timestamp'], source['_key'], report['_key'], active, str(obj['app_vuln_id']))
            self.result.extend(edges)

    return QueryProcessor(context, query, AppVulnConsumer(context, 'application_vulnerability')).process()

def export_user(context, whereclause = "", active = True):
    query = "select DISTINCT physicaluser.username, usr.assetid, physicaluser.groupname from asset.user as usr INNER JOIN asset.physicaluser as physicaluser on physicaluser.id = usr.physicaluserid {} ".format(whereclause)

    class UserConsumer(DataConsumer):
        def consume(self, obj, user):
            if obj['username'] is not None and users_keys.get(obj['username'], 0) == 0:
                user['external_id'] = obj['username']
                users_keys[obj['username']] = 1
                user['username'] = obj['username']
                user['group'] = obj['groupname']
                self.result.append(user)
    
    class AccountConsumer(DataConsumer):
        def consume(self, obj, account):
            if obj['username'] is not None and accounts_keys.get(obj['username'], 0) == 0:
                account['external_id'] = obj['username']
                accounts_keys[obj['username']] = 1
                account['name'] = obj['username']
                self.result.append(account)

    class UserAccountConsumer(EdgeDataConsumer):
        def consume(self, obj, user_account):
            if obj['username'] is not None:
                user_account['_from_external_id'] = obj['username']
                user_account['_to_external_id'] = obj['username']
                user_account['timestamp'] = report['timestamp']
                user_account['active'] = active
                user_account['source'] = source['_key']
                user_account['report'] = report['_key']
                user_account['external_id'] = obj['username']
                self.result.append(user_account)

    class AssetAccountConsumer(EdgeDataConsumer):
        def consume(self, obj, asset_account):
            if obj['username'] is not None:
                asset_account['_from_external_id'] = str(obj['assetid'])
                asset_account['_to_external_id'] = obj['username']
                asset_account['timestamp'] = report['timestamp']
                asset_account['active'] = active
                asset_account['source'] = source['_key']
                asset_account['report'] = report['_key']
                self.result.append(asset_account)

    account_consumer = AccountConsumer(context, 'account')
    asset_account_consumer = AssetAccountConsumer(context, 'asset_account')
    user_consumer = UserConsumer(context, 'user')
    user_account_consumer = UserAccountConsumer(context, 'user_account')

    QueryProcessor(context, query, user_consumer, asset_account_consumer, account_consumer, user_account_consumer).process()
    return user_consumer.result, asset_account_consumer.result, account_consumer.result, user_account_consumer.result

def export_hostname(context, whereclause = "", active = True):
    query = "select distinct on (hostname.hostname) hostname.assetid, hostname.hostname, hostname.id as hostid from asset.hostname as hostname {} ".format(whereclause)

    class HostnameConsumer(DataConsumer):
        duplicates = {}
        def consume(self, obj, hostname):
            if obj['hostname'] and self.duplicates.get(obj['hostname'], 0) == 0:
                self.duplicates[obj['hostname']] = 1
                hostname['_key'] = obj['hostname']
                hostname['assetid'] = str(obj['assetid'])
                hostname_keys[obj['hostname']] = 1
                self.result.append(hostname)

    class AssetHostnameConsumer(EdgeDataConsumer):
        def consume(self, obj, asset_hostname):
            if obj['hostname']:
                asset_hostname['_from_external_id'] = str(obj['assetid'])
                asset_hostname['_to'] = 'hostname/' + str(obj['hostname'])
                asset_hostname['timestamp'] = report['timestamp']
                asset_hostname['active'] = active
                asset_hostname['report'] = report['_key']
                asset_hostname['source'] = source['_key']
                asset_hostname['external_id'] = str(obj['hostid'])
                self.result.append(asset_hostname)

    hostname_consumer = HostnameConsumer(context, 'hostname')
    asset_hostname_consumer = AssetHostnameConsumer(context, 'asset_hostname')
    QueryProcessor(context, query, hostname_consumer, asset_hostname_consumer).process()
    return hostname_consumer.result, asset_hostname_consumer.result

def export_ip_hostname_user_rels(context, whereclause = "", isUpdate = False, active = True):
    if LooseVersion(context.version) >= LooseVersion('7.4.0.0'):
        query = "select id, assetid, identity_ipaddress as ipaddress, macaddress AS macaddress, hostname AS hostname,  machinename AS machinename, username AS username, groupname AS groupname from asset.identitybyip {} ".format(whereclause)
    else:
        # 7.3.0 system
        query = "select id, assetid, ip2address(ipaddress) as ipaddress, macaddress AS macaddress, hostname AS hostname,  machinename AS machinename, username AS username, groupname AS groupname from asset.identitybyip {} ".format(whereclause)
    class IpHostnameConsumer(EdgeDataConsumer):
        def consume(self, obj, ipaddress_hostname):
            if isUpdate:
                ipaddress_hostname_exp = obj['ipaddress'] and obj['hostname']
            else:
                is_ip_cleanedup = is_cleanedup(obj['ipaddress'], ipaddress_keys)
                is_host_cleanedup = is_cleanedup(obj['hostname'], hostname_keys)
                ipaddress_hostname_exp = obj['ipaddress'] and obj['hostname'] and not is_ip_cleanedup and not is_host_cleanedup
                
            if ipaddress_hostname_exp:
                # ipaddress_hostname['_key'] = str(obj['ipaddress']) + '-' + str(obj['hostname'])
                ipaddress_hostname['_from'] = 'ipaddress/'+obj['ipaddress']
                ipaddress_hostname['_to'] = 'hostname/'+obj['hostname']
                ipaddress_hostname['active'] = active
                ipaddress_hostname['report'] = report['_key']
                ipaddress_hostname['source'] = source['_key']
                ipaddress_hostname['timestamp'] = report['timestamp']
                ipaddress_hostname['external_id'] = str(obj['id'])
                self.result.append(ipaddress_hostname)

    class AccountIpConsumer(EdgeDataConsumer):
        def consume(self, obj, account_ipaddress):
            if isUpdate:
                ipaddress_username_exp = obj['ipaddress'] and obj['username']
            else:
                is_ip_cleanedup = is_cleanedup(obj['ipaddress'], ipaddress_keys)
                is_user_cleanedup = is_cleanedup(obj['username'], users_keys)
                ipaddress_username_exp = obj['ipaddress'] and obj['username'] and not is_ip_cleanedup and not is_user_cleanedup
                
            if ipaddress_username_exp:
                account_ipaddress['_from_external_id'] = obj['username']
                account_ipaddress['_to'] = 'ipaddress/'+obj['ipaddress']
                account_ipaddress['active'] = active
                account_ipaddress['report'] = report['_key']
                account_ipaddress['source'] = source['_key']
                account_ipaddress['timestamp'] = report['timestamp']
                self.result.append(account_ipaddress)

    class AccountHostnameConsumer(EdgeDataConsumer):
        def consume(self, obj, account_hostname):
            if isUpdate:
                hostname_username_exp = obj['hostname'] and obj['username']
            else:
                is_host_cleanedup = is_cleanedup(obj['hostname'], hostname_keys)
                is_user_cleanedup = is_cleanedup(obj['username'], users_keys)
                hostname_username_exp = obj['hostname'] and obj['username'] and not is_host_cleanedup and not is_user_cleanedup
            
            if hostname_username_exp:
                account_hostname['_from_external_id'] = obj['username']
                account_hostname['_to'] = 'hostname/' + obj['hostname']
                account_hostname['active'] = active
                account_hostname['report'] = report['_key']
                account_hostname['source'] = source['_key']
                account_hostname['timestamp'] = report['timestamp']
                self.result.append(account_hostname)

    ip_hostname_consumer = IpHostnameConsumer(context, 'ipaddress_hostname')
    account_ip_consumer = AccountIpConsumer(context, 'account_ipaddress')
    account_hostname_consumer = AccountHostnameConsumer(context, 'account_hostname')
    QueryProcessor(context, query, ip_hostname_consumer, account_ip_consumer, account_hostname_consumer).process()
    return ip_hostname_consumer.result, account_ip_consumer.result, account_hostname_consumer.result

def export_port(context, whereclause = ""):
    query = "select interface.assetid, port.id, port.portnumber, l4p.protocol, l4p.normalizestoid, lay7a.displaystring from asset.port as port INNER JOIN asset.interface as interface on interface.id = port.interfaceid LEFT JOIN asset.portlayer4protocolxref as portlayer4protocolxref on port.id = portlayer4protocolxref.portid LEFT JOIN q_catalog.layer4protocol as l4p on l4p.id = portlayer4protocolxref.layer4protocolid Left JOIN q_catalog.layer7applicationvariant as layer7applicationvariant on layer7applicationvariant.id = port.layer7applicationvariantid Left JOIN q_catalog.layer7application as lay7a on lay7a.id = layer7applicationvariant.layer7applicationid {} ".format(whereclause)

    class PortConsumer(DataConsumer):
        duplicates = {}
        def consume(self, obj, port):
            if self.duplicates.get(obj['id'], 0) == 0:
                self.duplicates[obj['id']] = 1
                port['external_id'] = str(obj['id'])
                port['assetid'] = str(obj['assetid'])
                port['port_number'] = obj['portnumber']
                port['protocol'] = str(obj['protocol'])
                if obj['displaystring']:
                    port['layer7application'] = obj['displaystring'][18:] # delete the "layer7application"
                # port['status'] = obj[''] # not available or not sure how to get it
                # port['description'] = obj[''] # not available
                self.result.append(port)

    return QueryProcessor(context, query, PortConsumer(context, 'port')).process()

def export_ip_port(context, whereclause = "", active = True):
    if LooseVersion(context.version) > LooseVersion('7.3.0.0'):
        query = "select interface.id as interfaceid, port.portnumber, port.id, ipaddress.ipaddress from asset.port as port INNER JOIN asset.interface as interface on port.interfaceid = interface.id INNER JOIN asset.ipaddress as ipaddress on ipaddress.interfaceid = interface.id {} ".format(whereclause)
    else:
        query = "select interface.id as interfaceid, port.portnumber, port.id, case when ipaddress.ipv4address is not null then ip2address(ipaddress.ipv4address) else ipaddress.ipv6address end from asset.port as port INNER JOIN asset.interface as interface on port.interfaceid = interface.id INNER JOIN asset.ipaddress as ipaddress on ipaddress.interfaceid = interface.id {} ".format(whereclause)

    class IpPortConsumer(EdgeDataConsumer):
        def consume(self, obj, ipaddress_port):
            ipaddress_port['_from'] = 'ipaddress/'+str(obj['ipaddress'])
            # external_port_id will not be saved to arangodb but it will be used to determine the _to value attribute
            ipaddress_port['_to_external_id'] = str(obj['id'])
            ipaddress_port['report'] = report['_key']
            ipaddress_port['active'] = active
            ipaddress_port['source'] = str(source['_key'])
            ipaddress_port['timestamp'] = report['timestamp'] 
            ipaddress_port['external_id'] = str(obj['interfaceid'])
            self.result.append(ipaddress_port)

    return QueryProcessor(context, query, IpPortConsumer(context, 'ipaddress_port')).process()

def export_asset(context, whereclause = "", active = True):
    # logger = context.logger
    query = "select asset.id as assetid, string_agg(assetproperty.id::text, ',') as assetpropertyid, string_agg(assetproperty.assetpropertytypeid::text, ',') as assetpropertytypeid, string_agg(assetproperty.propertyvalue::text, ',') as propertyvalue from asset.asset as asset LEFT JOIN asset.assetproperty as assetproperty on assetproperty.assetid = asset.id and assetproperty.assetpropertytypeid in ( 1001, 1002, 1003, 1004, 1005, 1007, 1026, 1033 ) {} group by asset.id ".format(whereclause)

    class AssetConsumer(DataConsumer):
        duplicates = {}
        def consume(self, obj, asset):
            if self.duplicates.get(obj['assetid'], 0) == 0:
                self.duplicates[obj['assetid']] = 1
                asset['external_id'] = str(obj['assetid'])
                asset['assetid'] = str(obj['assetid'])
                asset['name'] = ""
                # add asset properties
                add_asset_prop(context, asset, obj)
                
                # the risk will be computed on arangodb side, because we might have multiple source to the same assetid
                # asset_macaddress['risk'] = source['_key']
                self.result.append(asset)

    asset_consumer = AssetConsumer(context, 'asset')
    QueryProcessor(context, query, asset_consumer).process()
    return asset_consumer.result

def export_asset_mac(context, whereclause = "", active = True):
    query = "select asset.id as assetid, interface.id as interfaceid, interface.macaddress from asset.asset as asset INNER JOIN asset.interface as interface on asset.id = interface.assetid {} ".format(whereclause)

    class AssetMacConsumer(EdgeDataConsumer):
        def consume(self, obj, asset_macaddress):
            if obj['assetid'] and obj['macaddress']:
                # TODO as of now we don't know the key of the asset 
                asset_macaddress['_from_external_id'] = str(obj['assetid'])
                asset_macaddress['_to'] = 'macaddress/' + str(obj['macaddress'])
                asset_macaddress['report'] = report['_key']
                asset_macaddress['source'] = source['_key']
                asset_macaddress['external_id'] = str(obj['interfaceid'])
                asset_macaddress['active'] = active
                asset_macaddress['timestamp'] = report['timestamp']
                self.result.append(asset_macaddress)

    return QueryProcessor(context, query, AssetMacConsumer(context, 'asset_macaddress')).process()

def export_asset_ipaddress(context, whereclause = "", active = True):
    if LooseVersion(context.version) > LooseVersion('7.3.0.0'):
        query = "select interface.assetid, ipaddress.ipaddress from asset.interface as interface INNER JOIN asset.ipaddress as ipaddress on ipaddress.interfaceid = interface.id  {} ".format(whereclause)
    else:
        # 7.2.8 system
        query = "select interface.assetid, case when ipaddress.ipv4address is not null then ip2address(ipaddress.ipv4address) else ipaddress.ipv6address end as ipaddress from asset.interface as interface INNER JOIN asset.ipaddress as ipaddress on ipaddress.interfaceid = interface.id {} ".format(whereclause)

    class AssetIpaddressConsumer(EdgeDataConsumer):
        def consume(self, obj, asset_ipaddress):
            asset_ipaddress['_from_external_id'] = str(obj['assetid'])
            asset_ipaddress['_to'] = 'ipaddress/' + str(obj['ipaddress'])
            asset_ipaddress['active'] = active
            asset_ipaddress['timestamp'] = report['timestamp']
            asset_ipaddress['report'] = report['_key']
            asset_ipaddress['source'] = source['_key']
            self.result.append(asset_ipaddress)

    return QueryProcessor(context, query, AssetIpaddressConsumer(context, 'asset_ipaddress')).process()

def export_asset_vulnerability(context, whereclause = "", active = True):
    query = "select vulninstance.id as vid, vulninstance.assetid, vulninstance.vulnid as vulnid, vulninstance.osid from asset.vulninstance as vulninstance {} ".format(whereclause)

    class AssetVulnerabilityConsumer(EdgeDataConsumer):
        def __init__(self, context, name):
            self.os = set()
            return super(AssetVulnerabilityConsumer, self).__init__(context, name)

        def consume(self, obj, asset_vulnerability):
            if obj['osid'] is not None:
                self.os.add(obj['osid'])
            asset_vulnerability['_from_external_id'] = str(obj['assetid'])
            asset_vulnerability['_to_external_id'] = str(obj['vulnid'])
            asset_vulnerability['report'] = str(report['_key'])
            asset_vulnerability['source'] = source['_key']
            asset_vulnerability['external_id'] = str(obj['vid'])
            asset_vulnerability['active'] = active
            asset_vulnerability['timestamp'] = report['timestamp']
            self.result.append(asset_vulnerability)

    consumer = AssetVulnerabilityConsumer(context, 'asset_vulnerability')
    return QueryProcessor(context, query, consumer).process(), consumer.os

def export_source_report(context):
    utc_now = get_report_time_utc()
    source['_key'] = context.source
    source['name'] = context.source_name
    source['description'] = 'reports coming from source ' + context.source
    assets = {}
    assets['source'] = source
    # the report key is today in seconds
    report['_key'] = str(utc_now)
    report['timestamp'] = utc_now
    report['type'] = 'Qradar API'
    # report['paramaters'] = ''
    # report['value']  = ''
    report['description'] = 'Qradar imports'
    
    source_report_obj['report'] = report
    source_report_obj['source'] = source
    context.save_vertices(source_report_obj)

def add_source_report_info(obj):
    obj['report'] = source_report_obj['report']
    obj['source'] = source_report_obj['source']

