import sys, os, glob, json, copy, urllib, socket, struct
from zipfile import ZipFile
from datetime import datetime

BATCH_SIZE = 2000

test_dir = os.path.dirname(os.path.realpath(__file__))
code_dir = os.path.split(test_dir)[0]
updates_dir = test_dir + '/updates'

zips_dir = test_dir + '/zips'
if not os.path.exists(zips_dir):
    os.makedirs(zips_dir)

for f in glob.glob(updates_dir + '/*'):
    if os.path.isfile(f): os.remove(f)

template = json.loads('''
{"report": {"_key": "1.56960467391e+12", "timestamp": 1569604673910.0, "type": "Qradar API", "description": "Qradar imports"}, 
"source": {"_key": "73da35acc9b94fa68273e5124e7fc143", "name": "alex112.canlab.ibm.com", "description": "reports coming from source 73da35acc9b94fa68273e5124e7fc143"}, 
"source_report": [{"active": true, "timestamp": 1569604673910.0, "_from": "source/73da35acc9b94fa68273e5124e7fc143", "_to": "report/1.56960467391e+12"}]}
''')

class Generator:
    def __init__(self):
        self.vertices = 1244
        self.counter = 1342


    def get_vuln(self):
        if not os.path.exists(zips_dir + '/updates.zip'):
            urllib.urlretrieve('http://gleb-isc1.fyre.ibm.com/assets/vuln.zip', zips_dir + '/updates.zip')
        with ZipFile(zips_dir + '/updates.zip', 'r') as zipObj:
            zipObj.extractall(updates_dir)


    def gen_assets(self, data, start, size):
        for i in range(start, start + size):
            data.append({"assetid": str(i + 1001), "external_id": str(i + 1001), "name": "%d.q1labs.lab" % (i + 1001), "asset_type": "Other"})

    def gen_mac(self, data, start, size):
        for i in range(start, start + size):
            self.mac_int += 1
            mac_hex = "{:012x}".format(self.mac_int)
            mac_str = ":".join(mac_hex[i:i+2] for i in range(0, len(mac_hex), 2))
            data.append({"_key": mac_str, "assetid": str(i + 1001)})

    def gen_ip(self, data, start, size):
        for i in range(start, start + size):
            self.ip_int += 1
            data.append({"_key": socket.inet_ntoa(struct.pack('!L', self.ip_int)), "assetid": str(i + 1001)})

    def gen_host(self, data, start, size):
        for i in range(start, start + size):
            data.append({"_key": "%d.q1labs.lab" % (i + 1001), "assetid": str(i + 1001)})
            
    def gen_app(self, data, start, size):
        for i in range(start, start + size):
            data.append({"assetid": str(i + 1001), "external_id": str(i + 1001), "name": "Linux Linux 3.X"})
            
    def gen_port(self, data, start, size):
        for i in range(start, start + size):
            for p in range(1, 3):
                data.append({"assetid": str(i + 1001), "port_number": 8009, "external_id": "%d-%d" % (i + 1001, p), "layer7application": "UnknownApplication", "protocol": "tcp"})
            
    def gen_asset_macaddress(self, data, start, size):
        for i in range(start, start + size):
            self.mac_int += 1
            mac_hex = "{:012x}".format(self.mac_int)
            mac_str = ":".join(mac_hex[i:i+2] for i in range(0, len(mac_hex), 2))
            data.append({"timestamp": 1569604673910.0, "_from_external_id": str(i + 1001), "source": "73da35acc9b94fa68273e5124e7fc143", "_to": "macaddress/" + mac_str, "report": "1.56960467391e+12", "external_id": str(i + 1001), "active": True})
            
    def gen_asset_ipaddress(self, data, start, size):
        for i in range(start, start + size):
            self.ip_int += 1
            data.append({"source": "73da35acc9b94fa68273e5124e7fc143", "timestamp": 1569604673910.0, "_from_external_id": str(i + 1001), "report": "1.56960467391e+12", "_to": "ipaddress/" + socket.inet_ntoa(struct.pack('!L', self.ip_int)), "active": True})

    def gen_asset_vulnerability(self, data, start, size):
        for i in range(start, start + size):
            data.append({"source": "73da35acc9b94fa68273e5124e7fc143", "timestamp": 1569604673910.0, "_from_external_id": str(i + 1001), "active": True, "report": "1.56960467391e+12", "external_id": str(i + 1001) + "-1", "_to_external_id": "137402"})
            data.append({"source": "73da35acc9b94fa68273e5124e7fc143", "timestamp": 1569604673910.0, "_from_external_id": str(i + 1001), "active": True, "report": "1.56960467391e+12", "external_id": str(i + 1001) + "-2", "_to_external_id": "97305"})

    def gen_ipaddress_macaddress(self, data, start, size):
        for i in range(start, start + size):
            self.ip_int += 1
            self.mac_int += 1
            mac_hex = "{:012x}".format(self.mac_int)
            mac_str = ":".join(mac_hex[i:i+2] for i in range(0, len(mac_hex), 2))
            data.append({"q_assetid": i + 1001, "timestamp": 1569604673910.0, "source": "73da35acc9b94fa68273e5124e7fc143", "_to": "macaddress/" + mac_str, "report": "1.56960467391e+12", "_from": "ipaddress/" + socket.inet_ntoa(struct.pack('!L', self.ip_int)), "external_id": str(i + 1001), "active": True})
            
    def gen_ipaddress_vulnerability(self, data, start, size):
        for i in range(start, start + size):
            self.ip_int += 1
            data.append({"source": "73da35acc9b94fa68273e5124e7fc143", "timestamp": 1569604673910.0, "_from": "ipaddress/" + socket.inet_ntoa(struct.pack('!L', self.ip_int)), "active": True, "report": "1.56960467391e+12", "external_id": str(i + 1001) + "-1", "_to_external_id": "137402"})
            data.append({"source": "73da35acc9b94fa68273e5124e7fc143", "timestamp": 1569604673910.0, "_from": "ipaddress/" + socket.inet_ntoa(struct.pack('!L', self.ip_int)), "active": True, "report": "1.56960467391e+12", "external_id": str(i + 1001) + "-2", "_to_external_id": "97305"})

    def gen_asset_hostname(self, data, start, size):
        for i in range(start, start + size):
            data.append({"source": "73da35acc9b94fa68273e5124e7fc143", "timestamp": 1569604673910.0, "_from_external_id": str(i + 1001), "active": True, "_to": "hostname/" + "%d.q1labs.lab" % (i + 1001), "report": "1.56960467391e+12", "external_id": str(i + 1001)})
            
    def gen_application_port(self, data, start, size):
        for i in range(start, start + size):
            for p in range(1, 3):
                data.append({"external_id": "%d-%d" % (i + 1001, p), "timestamp": 1569604673910.0, "_from_external_id": str(i + 1001), "source": "73da35acc9b94fa68273e5124e7fc143", "report": "1.56960467391e+12", "active": True, "_to_external_id": "%d-%d" % (i + 1001, p)})
            
    def gen_application_vulnerability(self, data, start, size):
        for i in range(start, start + size):
            data.append({"source": "73da35acc9b94fa68273e5124e7fc143", "timestamp": 1569604673910.0, "_from_external_id": str(i + 1001), "report": "1.56960467391e+12", "active": True, "external_id": str(i + 1001), "_to_external_id": "117469"})
            
    def gen_ipaddress_port(self, data, start, size):
        for i in range(start, start + size):
            self.ip_int += 1
            for p in range(1, 3):
                data.append({"external_id": "%d-%d" % (i + 1001, p), "timestamp": 1569604673910.0, "_from": "ipaddress/" + socket.inet_ntoa(struct.pack('!L', self.ip_int)), "source": "73da35acc9b94fa68273e5124e7fc143", "report": "1.56960467391e+12", "active": True, "_to_external_id": "%d-%d" % (i + 1001, p)})

    def gen(self, name, worker):
        print 'generating %s ...' % name
        self.mac_int = int('00:50:56:A6:E2:1D'.replace(':', ''), 16)
        self.ip_int = 168430090

        start = 0
        while True:
            data = []
            if start >= self.total: break
            size = BATCH_SIZE
            if start + size > self.total:
                size = self.total - start
            worker(data, start, size)
            start += size

            res = copy.deepcopy(template)
            res[name] = data
            file = open(updates_dir + '/data-%d.json' % self.counter, 'w')
            json.dump(res, file)
            self.counter += 1

    def gen_queue(self):
        f = open(updates_dir + '/import.queue', 'w')
        i = 1
        f.write('%d ENTER_FULL_IMPORT_IN_PROGRESS_STATE \n' % i)
        for file_index in range(self.vertices, self.counter):
            if file_index == self.start_edges:
                i += 1
                f.write('%d WAIT \n' % i)
            i += 1
            f.write('%d SEND_DATA data-%d.json\n' % (i, file_index))

        i += 1
        f.write('%d WAIT \n' % i)
        i += 1
        f.write('%d EXIT_FULL_IMPORT_IN_PROGRESS_STATE \n' % i)

    def make(self, total):
        self.total = total
        self.get_vuln()
        self.gen('asset', self.gen_assets)
        self.gen('macaddress', self.gen_mac)
        self.gen('ipaddress', self.gen_ip)
        self.gen('hostname', self.gen_host)
        self.gen('application', self.gen_app)
        self.gen('port', self.gen_port)

        self.start_edges = self.counter

        self.gen('asset_macaddress', self.gen_asset_macaddress)
        self.gen('asset_ipaddress', self.gen_asset_ipaddress)
        self.gen('asset_vulnerability', self.gen_asset_vulnerability)
        self.gen('ipaddress_macaddress', self.gen_ipaddress_macaddress)
        self.gen('ipaddress_vulnerability', self.gen_ipaddress_vulnerability)
        self.gen('asset_hostname', self.gen_asset_hostname)
        self.gen('application_port', self.gen_application_port)
        self.gen('application_vulnerability', self.gen_application_vulnerability)
        self.gen('ipaddress_port', self.gen_ipaddress_port)

        self.gen_queue()



