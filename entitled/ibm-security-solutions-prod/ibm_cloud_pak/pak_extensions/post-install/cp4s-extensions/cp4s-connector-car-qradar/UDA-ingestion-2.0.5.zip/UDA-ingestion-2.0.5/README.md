# Qradar Asset Exporter
## Steps to run the Assets script

1. Download a tar archive of the [latest release](https://github.ibm.com/CAR/UDA-ingestion/releases) of the UDA-ingestion project.
2. SSH into your QRadar box.
3. On your QRadar box, create a directory called `car` under `/transient/`.
4. Unzip the archive into the `car` folder created in the previous step.
5. Navigate to the new `car` directory (`cd /transient/car`).
6. The archive contains the `assets.py` script which will require the following arguments: 

| Argument     | Optional  | Default value if omitted | Description       |
| -----------  | --------- | -----------              | ------------       |
| url          |           |                          | URL for the CAR ingestion service |
| database     | *         | qradar                   | Database to extract assets from |
| dbuser       | *         | qradar                   | Database user                  |
| dbpassword   | *         |                          | Database password                  |
| key          |           |                          | CAR API key                 |
| pass         |           |                          | CAR Secret API key                   |
| u            | *         | false                    | option to enable incremental update |

The URL for the CAR ingestion service is a combination of the CP4S cluster and the API path of the CAR server: 

`https://<host name of CP4S cluster>/api/car/v2`

7. To run the initial import which is the full dump of the asset database, run the following command:
   ```
   python assets.py -url <'url'> -key <'api key'> -pass <'secret api key'> -database <'database'> -dbuser <'db user'> -dbpassword <'db password'>
   ```
8. To run the incremental update, run the following command:
   ```
   python assets.py -url <'url'> -key <'api key'> -pass <'secret api key'> -database <'database'> -dbuser <'db user'> -dbpassword <'db password'> -u true
   ```
   This will create a cronjob that runs every 15 minutes. Note that the command for incremental update is the same as the initial import, just with the added `-u true` argument.

