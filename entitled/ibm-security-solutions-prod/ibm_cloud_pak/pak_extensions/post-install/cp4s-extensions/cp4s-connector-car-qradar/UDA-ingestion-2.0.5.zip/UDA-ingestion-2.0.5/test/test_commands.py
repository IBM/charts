import os, unittest
from import_queue import CommandQueue, Command

test_dir = os.path.dirname(os.path.realpath(__file__))

class TestCommandQueue(unittest.TestCase):
    def test_command_queue(self):

        cq = CommandQueue(test_dir + '/updates')
        c1 = Command.new('POST', 'stuff1', 'smuff1')
        c2 = Command.new('POST', 'stuff2', 'smuff2')
        c3 = Command.new('POST', 'stuff3', 'smuff3')
        c4 = Command.new('POST', 'stuff4', 'smuff4')
        cq.push(c1)
        cq.push(c2)
        cq.push(c3)
        cq.push(c4)

        c11 = cq.peek()
        self.assertEquals(c1.id, c11.id)
        cq.remove(c1)
        c12 = cq.peek()
        self.assertEquals(c2.id, c12.id)
        c13 = cq.peek()
        self.assertEquals(c3.id, c13.id)
        cq.remove(c3)
        cq.remove(c2)
        c14 = cq.peek()
        self.assertEquals(c4.id, c14.id)
        cq.remove(c4)
