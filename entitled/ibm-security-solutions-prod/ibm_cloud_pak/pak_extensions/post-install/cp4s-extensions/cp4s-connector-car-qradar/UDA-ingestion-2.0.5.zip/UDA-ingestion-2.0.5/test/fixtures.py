import sys, os, glob, argparse, ConfigParser
import urllib
from zipfile import ZipFile
import requests
from datetime import datetime

MICROSERVICE_URI = 'http://9.28.239.135:3000/car/api'

test_dir = os.path.dirname(os.path.realpath(__file__))
code_dir = os.path.split(test_dir)[0]
updates_dir = test_dir + '/updates'
zips_dir = test_dir + '/zips'
if not os.path.exists(zips_dir):
    os.makedirs(zips_dir)

sys.path.insert(0, test_dir)
sys.path.insert(0, code_dir)

from util import get_logger
from context import Context
from update_tracker import AssetModelUpdateTracker

parser = argparse.ArgumentParser()
parser.add_argument('-keep', dest='keep', action='store_true')
parser.add_argument('-target', dest='target', type=str)
parser.add_argument('-postgres', dest='postgres', type=str)
parser.add_argument('-json-zip', dest='json_zip', type=str)
parser.add_argument('-generate', dest='generate', type=str)
args = parser.parse_args()

config = ConfigParser.RawConfigParser()
config.read(os.path.join(test_dir, 'env.prop'))
url = config.get(args.target, 'CAR-URL');
api_key = config.get(args.target, 'API-KEY')

logger = get_logger(test_dir)

def cleanup_updates_dir():
    for f in glob.glob(updates_dir + '/*'):
        if os.path.isfile(f): os.remove(f)

cleanup_updates_dir()

###############################################################################################

def stress_test():
    count = 1
    while True:
        with open(os.path.join(test_dir, '__stress_test__'), 'a') as file:
            file.write('%s : %d\n' % (datetime.now().strftime("%m/%d/%Y - %H:%M:%S"), count))
        delete_db()
        import_from_json_files('121')
        count += 1

if sys.argv[1] == 'stress_test':
    stress_test()
    sys.exit()
        
###############################################################################################

class Tracker(AssetModelUpdateTracker):
    def __init__(self, context):
        return super(Tracker, self).__init__(context)

    def get_updates(self, context, table_list):
        input_file_name = test_dir + '/updates/repl.sql'
        try:
            with open(input_file_name, 'a') as repl:
                with open(test_dir + '/assets-deleted.sql') as input: repl.write(input.read())
                with open(test_dir + '/assets-modified.sql') as input: repl.write(input.read())
                with open(test_dir + '/assets-created.sql') as input: repl.write(input.read())
            return self.parse_replication_file(input_file_name, table_list)
        finally:
            if os.path.exists(input_file_name): os.remove(input_file_name)

def update_with_existing_replication_file():
    context = Context(test_dir, logger, MICROSERVICE_URI, '', '7.3.1', '2.2.5', '73da35acc9b94fa68273e5124e7fc143', 'alex112.canlab.ibm.com', 'qradar_731_scan_modified_121_assets', 
        'qradar', 'qradar.1', dbhost='gleb-isc1.fyre.ibm.com')
    context.tracker = Tracker(context)
    from inc_export import run_incremental_export
    run_incremental_export(context)
    from assets import run_importer
    run_importer(context)

if sys.argv[1] == 'update_with_existing_replication_file':
    update_with_existing_replication_file()
    sys.exit()

##############################################################################################

def cleanup():
    if args.keep: return
    r = requests.delete(url + '/databases', headers={'Authorization': 'Basic ' + api_key})
    print 'Deleting the database: %s' % r.status_code

def export_json():
    if args.postgres:
        context = Context(test_dir, logger, url, api_key, '7.3.1', '2.2.5', '73da35acc9b94fa68273e5124e7fc143', 'alex112.canlab.ibm.com', args.postgres, 
            'qradar', 'qradar.1', dbhost='gleb-isc1.fyre.ibm.com')
        from full_export import run_full_export
        run_full_export(context)

    if args.json_zip:
        json_zip = '%s/%s' % (zips_dir, args.json_zip)
        print json_zip
        if not os.path.exists(json_zip):
            print 'Retrieving json files...'
            urllib.urlretrieve('http://gleb-isc1.fyre.ibm.com/assets/%s' % args.json_zip, json_zip)
        with ZipFile(json_zip, 'r') as zipObj:
            zipObj.extractall(updates_dir)

    if args.generate:
        print 'Generating json files...'
        size = args.generate
        thousands = 'K' in size
        size = size.replace('K', '')
        size = int(size)
        if thousands: size *= 1000
        from gen_model import Generator
        Generator().make(size)

def import_json():
    context = Context(test_dir, logger, url, api_key, '7.3.1', '2.2.5', '73da35acc9b94fa68273e5124e7fc143', 'alex112.canlab.ibm.com', None, 
        None, None, None)
    from assets import run_importer
    run_importer(context)

cleanup()
export_json()
import_json()
