from util import Status, SUCCESS, FAILURE
from util import recoverable_failure_status_code, RecoverableFailure, UnrecoverableFailure, get_json
import time, json, os
from flock import Lock

IMPORT_RESOURCE = '/imports'
STATUS_RESOURCE = '/importstatus'
DATABASE_RESOURCE = '/databases'
JOBSTATUS_RESOURCE = '/jobstatus'
FULL_IMPORT_IN_PROGRESS_ENDPOINT = '/full-import-in-progress'
batch_call_size = 20
max_wait_time = 60

class Microservice(object):

    DB_FAILURE = 0
    DB_READY = 1
    DB_NEW = 2


    def __init__(self, logger, communicator, base_url, source, updates_dir):
        self.logger = logger
        self.communicator = communicator
        self.base_url = base_url
        self.source = source
        self.import_url = base_url + IMPORT_RESOURCE
        self.status_url = base_url + STATUS_RESOURCE
        self.updates_dir = updates_dir


    def import_file(self, file, data):
        status = Status(file=file)
        self.logger.info('importing file %s ...' % file)
        try:
            r = self.communicator.send_post_request(self.import_url, data=data, timeout=None)
            status.status_code = r.status_code
            json = get_json(r)
            if 'id' in json:
                status.job_id = json['id']
                status.status = SUCCESS
            else:
                status.status = FAILURE
                status.error = str(json)
            return status

        except Exception as e:
            self.logger.error(e)
            status.status = FAILURE
            status.error = str(e)
            return status


    def check_import_status(self, statuses):
        # for SUCCESS statuses create a map: id -> status
        jobs_to_check = dict(map(lambda s: (s.job_id, s), filter(lambda s: s.status is SUCCESS, statuses)))
        
        wait_time = 1
        try:
            while True:
                if not jobs_to_check: return
                params = ','.join(jobs_to_check.keys())
                r = self.communicator.send_get_request(self.status_url, params={'ids': params})
                data = get_json(r)
                if 'error_imports' in data:
                    for err in data['error_imports']:
                        id = err['id']
                        jobs_to_check[id].status = FAILURE
                        jobs_to_check[id].error = err.get('error')
                        jobs_to_check[id].status_code = err.get('statusCode')
                        jobs_to_check.pop(id, None)

                incomplete_ids = []
                if 'incomplete_imports' in data:
                    incomplete = data['incomplete_imports']
                    if incomplete:
                        self.logger.info('The following imports are still in progress:')
                        incomplete_ids = map(lambda item: item['id'], incomplete)
                        for id in incomplete_ids:
                            self.logger.info('id: %s, file: %s' % (id, jobs_to_check[id].file))

                done = filter(lambda id: id not in incomplete_ids, jobs_to_check.keys())
                for id in done:
                    del jobs_to_check[id]

                if not jobs_to_check: return
                time.sleep(wait_time)
                if wait_time < max_wait_time: wait_time *= 2
                if wait_time > max_wait_time: wait_time = max_wait_time

        except Exception as e:
            # mark all remaining statuses as failed
            for s in jobs_to_check.values():
                s.status = FAILURE
                s.error = str(e)
        

    def delete(self, resource, ids):
        url = '%s/source/%s/%s?external_ids=%s' % (self.base_url, self.source, resource, ids)
        r = self.communicator.send_delete_request(url)
        return r.status_code


    def get_db_status(self):
        with Lock('dbstatus.lock', blocking = True) as lock:
            return self._get_db_status()


    '''
    algorithm:
        1. Call GET /databases endpoint and check if Database exist with the checks of all the collections, indexes, etc
            - Yes: move on and start importing
            - No: Call the endpoint POST /databases, the function should wait here untill the database, graph, indexes are created, this will take more than 10 minutes
    '''
    def _get_db_status(self):
        logger = self.logger
        logger.info('checking if the database is set up ...')
        db_url = self.base_url + DATABASE_RESOURCE
        r = self.communicator.send_get_request(db_url)
        status_code = r.status_code
        
        if status_code == 400:
            # the database is not setup yet, create it
            logger.info('setting up the database')
            r = self.communicator.send_post_request(db_url, timeout=None)
            job_id = get_json(r)['job_id']
            logger.debug('job_id: {}'.format(job_id))
            status = self.wait_until_done(job_id)
            # status could be either COMPLETE or ERROR
            if status == 'COMPLETE':
                logger.info('database is ready')
                return Microservice.DB_NEW
            else:
                # work around, arangodb timing out within the cluster, as a work around check again the database, create missing indexes 
                # call 5 recursive times _get_db_status every 10 seconds
                for x in range(5):
                    logger.info('Check# {}, the database is not ready Yet, checking again ...'.format(x))
                    if self._get_db_status() == Microservice.DB_READY:
                        return Microservice.DB_NEW
                    time.sleep(10)
                return Microservice.DB_FAILURE
        
        elif status_code == 200:
            r_json = get_json(r)
            databases = r_json['databases']
            if databases[0]['is_ready'] == True:
                # database is ready to accept imports
                logger.info('database is ready')
                return Microservice.DB_READY
            elif databases[0]['graph_name'] == "":
                # create the graph
                logger.info('creating the graph')
                payload = json.dumps({ 'graph_name': 'assets'})
                r = self.communicator.send_patch_request(db_url, data=payload, timeout=None)
                job_id = get_json(r)['job_id']
                status = self.wait_until_done(job_id)
                # status could be either COMPLETE or ERROR
                if status == 'COMPLETE':
                    logger.info('database is ready')
                    return Microservice.DB_NEW
                else:
                    return Microservice.DB_FAILURE
            elif len(databases[0]['collections_without_indexes']) > 0:
                # create indexes
                logger.info('creating missing indexes')
                payload = json.dumps({ 'collections_without_indexes': databases[0]['collections_without_indexes']})
                r = self.communicator.send_patch_request(db_url, data=payload, timeout=None)
                job_id = get_json(r)['job_id']
                status = self.wait_until_done(job_id)
                # status could be either COMPLETE or ERROR
                if status == 'COMPLETE':
                    logger.info('database is ready')
                    return Microservice.DB_READY
                else:
                    return Microservice.DB_FAILURE
        
        elif recoverable_failure_status_code(status_code):
            raise RecoverableFailure('Getting the following status code when accessing ISC CAR service: %d' % status_code)
        else:
            raise UnrecoverableFailure('Getting the following status code when accessing ISC CAR service: %d' % status_code)

    def wait_until_done(self, job_id):
        jobstatus_url = self.base_url + JOBSTATUS_RESOURCE
        job_complete = False
        status = 'INPROGRESS'
        while not job_complete:
            r = self.communicator.send_get_request(jobstatus_url+"/{}".format(job_id))
            if r.status_code == 200:
                status = get_json(r)['status']
                if status == 'COMPLETE' or status == 'ERROR':
                    job_complete = True
            else:
                return 'ERROR'

        return status


    def enter_full_import_in_progress_state(self):
        logger = self.logger
        self.logger.info('Entering "Full import in progress" state. Source: %s' % self.source)
        endpoint = '%s/source/%s%s' % (self.base_url, self.source, FULL_IMPORT_IN_PROGRESS_ENDPOINT)
        r = self.communicator.send_post_request(endpoint, timeout=None)
        job_id = get_json(r)['job_id']
        logger.debug('job_id: {}'.format(job_id))
        status = self.wait_until_done(job_id)
        return r.status_code


    def exit_full_import_in_progress_state(self):
        logger = self.logger
        self.logger.info('Exiting "Full import in progress" state. Source: %s' % self.source)
        endpoint = '%s/source/%s%s' % (self.base_url, self.source, FULL_IMPORT_IN_PROGRESS_ENDPOINT)
        r = self.communicator.send_delete_request(endpoint, timeout=None)
        job_id = get_json(r)['job_id']
        logger.debug('job_id: {}'.format(job_id))
        status = self.wait_until_done(job_id)
        return r.status_code

