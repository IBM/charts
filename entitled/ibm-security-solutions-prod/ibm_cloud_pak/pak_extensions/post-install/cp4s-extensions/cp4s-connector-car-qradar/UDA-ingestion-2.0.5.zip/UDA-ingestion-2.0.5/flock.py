import os
from os.path import join, dirname, realpath

try:
    if os.name != 'nt':
        import posixfile, fcntl
        fake = False
    else:
        fake = True
except:
    fake = True

class Lock(object):

    def __init__(self, name, blocking):
        self.name = name
        self.blocking = blocking
        self.locked = False

    # In 'non-blocking' mode returns True if aquires the lock.
    # In 'blocking' mode can only return True.
    def lock(self):
        if fake: self.locked = True; return True
        self.file = posixfile.open(join(dirname(realpath(__file__)), self.name), 'w')
        try:
            self.file.lock(self.blocking and 'w|' or 'w')
            self.locked = True
            return True
        except IOError as e:
            if e.errno == 11: return False
            raise e

    def unlock(self):
        if fake: self.locked = False; return
        if self.locked:
            self.file.lock('u')
        self.file.close()

    def __enter__(self):
        self.lock()
        return self

    def __exit__(self, type, value, traceback):
        self.unlock()
