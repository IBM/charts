import os, unittest, util
import psycopg2, psycopg2.extras, re, json, sys
import ConfigParser
from config import Config
from update_tracker import AssetModelUpdateTracker
import full_export, inc_export


test_dir = os.path.dirname(os.path.realpath(__file__))


expected_results = {'asset': 121, 'asset_macaddress': 95, 'asset_ipaddress': 122, 'asset_vulnerability': 228, 'macaddress': 95, 'ipaddress': 122,
                    'ipaddress_macaddress': 96, 'ipaddress_vulnerability': 231, 'hostname': 122, 'asset_hostname': 122, 'application': 178,
                    'application_port': 118, 'application_vulnerability': 125, 'port': 243, 'ipaddress_port': 243, 'vulnerability': 192831}
results = {}

update_data = {}
delete_data = {}

class Response:
    def __init__(self, sc, data={}):
        self.status_code = sc
        self.data = data

    def json(self):
        return self.data


class MockedMicroservice():
    DB_READY = 1

    def get_db_status(self):
        return DB_READY

    def import_files(self, files):
        return []

    def delete(self, resource, ids):
        global delete_data
        delete_data[resource] = ids

    def enter_full_import_in_progress_state(self):
        pass

    def exit_full_import_in_progress_state(self):
        pass

class MockedQueue:
    def push(self, command):
        if command.name == 'DELETE':
            delete_data[command.args[0]] = command.args[1].split(',')

class MockedContext():

    def __init__(self, test_db):
        self.test_db = test_db
        self.logger = util.get_logger(test_dir)
        self.working_dir = test_dir
        self.updates_dir = self.working_dir + '/updates'
        if not os.path.exists(self.updates_dir):
            os.mkdir(self.updates_dir)
        self.config_file = self.working_dir + '/updates.conf'
        self.url = 'test-url'
        self.apikey = 'test-apikey'
        self.version = '7.3.1'
        self.exporter_version = 'exporter_version'
        self.source = 'source'
        self.source_name = 'source_name'
        self.microservice = MockedMicroservice()
        self.collection_files = ()
        self.edge_files = ()
        self.config = Config(self)
        self.tracker = MockedUpdateTracker()
        self.queue = MockedQueue()
        self.cleanup_actions = []
        
    def save_error(self, p1, p2):
        pass
    
    def _connect(self):
        connection = psycopg2.connect(host='gleb-isc1.fyre.ibm.com', database=self.test_db, user='qradar', password='qradar.1')
        cursor = connection.cursor(cursor_factory=psycopg2.extras.DictCursor)
        return cursor

    def execute(self, query, params=None):
        cursor = self._connect()
        cursor.execute(query, params)
        return cursor

    def send_get_request(self, url, **args):
        if url.endswith('/databases'):
            return Response(200, {'databases' : [{'is_ready' : True}]})
        raise 'Valid response needed here'

    def save_vertices(self, data):
        if len(data) == 3 and 'source_report' in data:
            return

        for coll_name in data:
            if coll_name not in ('report', 'source', 'source_report'):
                num = results.get(coll_name) or 0
                coll = data[coll_name]
                num += len(coll)
                results[coll_name] = num
                print coll_name, num

    def save_edges(self, data):
        self.save_vertices(data)

    def import_saved_data(self):
        pass

    def cleanup_updates_dir(self):
        pass        

class MockedUpdateTracker:
    def is_full_import_required(self):
        return False

    def get_updates(self, context, table_list):
        # Existing IDs: 1001, 1002, 1003, ...
        # Non-existing IDs: 2001, 2002, 2003, ...
        ids = []
        for i in range(1001, 1001 + 50): ids.append(str(i))
        for i in range(2001, 2001 + 50): ids.append(str(i))
        return { 'rep.asset_asset_activity' : ids }

    def set_next_baseline(self):
        pass

    def persist(self):
        pass

class TestUpdateTracker(AssetModelUpdateTracker):
    def __init__(self, context, filename):
        self.filename = filename
        return super(TestUpdateTracker, self).__init__(context)

    def _get_replication_file(self, replicationurl):
        return os.path.join(test_dir, self.filename)

class Import_121_Assets(unittest.TestCase):
    def test_import(self):
        global results
        results = {}
        context = MockedContext('qradar_731_scan_121_assets')
        full_export.run_full_export(context)
        
        for name, num in expected_results.items():
            self.assertEquals(num, results.get(name), '%s size should be %d' % (name, num))
            

class Update_121_Assets(unittest.TestCase):
    def test_update(self):
        global results
        results = {}
        context = MockedContext('qradar_731_scan_121_assets')
        inc_export.run_incremental_export(context)
        
        self.assertEquals(50, results['asset'])


class Tracker_Test(unittest.TestCase):
    def test_assets_deleted(self):
        global delete_data
        delete_data = {}
        context = MockedContext('qradar_731_scan_modified_121_assets')
        context.tracker = TestUpdateTracker(context, 'assets-deleted.sql')
        inc_export.run_incremental_export(context)
        self.assertEquals(62, len(delete_data['application']))
        self.assertEquals(90, len(delete_data['ipaddress_vulnerability']))
        self.assertEquals(90, len(delete_data['asset_vulnerability']))
        self.assertEquals(21, len(delete_data['macaddress']))
        self.assertEquals(30, len(delete_data['hostname']))
        self.assertEquals(21, len(delete_data['ipaddress']))
        self.assertEquals(83, len(delete_data['port']))
        self.assertEquals(44, len(delete_data['application_port']))
        self.assertEquals(21, len(delete_data['asset']))        

    def test_assets_modified(self):
        global results
        results = {}
        context = MockedContext('qradar_731_scan_modified_121_assets')
        context.tracker = TestUpdateTracker(context, 'assets-modified.sql')
        inc_export.run_incremental_export(context)
        self.assertEquals(1, results['asset'])
        self.assertEquals(1, results['ipaddress'])
        self.assertEquals(1, results['ipaddress_macaddress'])
        self.assertEquals(3, results['ipaddress_vulnerability'])
        self.assertEquals(3, results['ipaddress_port'])
        self.assertEquals(1, results['asset_ipaddress'])

    def test_assets_created(self):
        global results
        results = {}
        context = MockedContext('qradar_731_scan_modified_121_assets')
        context.tracker = TestUpdateTracker(context, 'assets-created.sql')
        inc_export.run_incremental_export(context)
        self.assertEquals(1, results['ipaddress'])
        self.assertEquals(1, results['asset_ipaddress'])
        self.assertEquals(2, results['asset'])
