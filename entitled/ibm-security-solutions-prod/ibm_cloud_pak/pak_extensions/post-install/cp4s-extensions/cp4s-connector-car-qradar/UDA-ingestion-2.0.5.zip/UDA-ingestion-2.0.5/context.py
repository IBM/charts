import os, json, sys, shutil, glob, uuid
from os.path import join
from microservice import Microservice
from communicator import Communicator
from update_tracker import AssetModelUpdateTracker
import ConfigParser
from config import Config
from util import measure_time, SUCCESS, FAILURE, delete_file, UnrecoverableFailure
from import_queue import CommandQueue, Command
from datetime import datetime

class Context:

    def __init__(self, working_dir, logger, url, apikey, version, exporter_version, source, source_name, database, dbuser, dbpassword, dbhost=None):
        if database is None: database = 'qradar'
        if dbuser is None: dbuser = 'qradar'
        if dbpassword is None: dbpassword = ''

        self.cleanup_actions = []
        self.working_dir = working_dir
        self.logger = logger
        self.url = url
        self.apikey = apikey
        self.version = version
        self.exporter_version = exporter_version
        self.source = source
        self.source_name = source_name
        self.dbhost = dbhost
        self.database = database
        self.dbuser = dbuser
        self.dbpassword = dbpassword

        self.vertices = []
        self.edges = []

        self.config_file = join(os.path.dirname(os.path.realpath(__file__)), 'updates.conf')

        # create required folders if they don't exist
        self.logs_dir = join(working_dir, 'logs')
        self.errors_dir = join(working_dir, 'errors')
        self.updates_dir = join(working_dir, 'updates')
        if not os.path.exists(self.logs_dir):
            os.makedirs(self.logs_dir)
        if not os.path.exists(self.errors_dir):
            os.makedirs(self.errors_dir)
        if not os.path.exists(self.updates_dir):
            os.makedirs(self.updates_dir)

        communicator = Communicator(logger, {'Accept' : 'application/json', 'Content-Type' : 'application/json', 'Authorization': 'Basic ' + apikey, 'User-Agent': exporter_version})
        self.microservice = Microservice(logger, communicator, url, source, self.updates_dir)
        self.config = Config(self)
        self.tracker = AssetModelUpdateTracker(self)
        self.queue = CommandQueue(self.updates_dir)

        def log_unrecoverable_failures(exc, message):
            with open(join(join(working_dir, 'logs'), 'failures.log'), 'a') as file:
                file.write('%s %s\n' % (datetime.now().strftime("%m/%d/%Y - %H:%M:%S"), message))
        UnrecoverableFailure.callback = log_unrecoverable_failures
    

    def cleanup_updates_dir(self):
        for f in glob.glob(self.updates_dir + '/*'):
            if os.path.isfile(f):
                delete_file(self, f)


    def _connect(self):
        import psycopg2, psycopg2.extras
        connection = psycopg2.connect(host=self.dbhost, database=self.database, user=self.dbuser, password=self.dbpassword)
        cursor = connection.cursor(cursor_factory=psycopg2.extras.DictCursor)
        return cursor


    def execute(self, query, params=None):
        cursor = self._connect()
        cursor.execute(query, params)
        return cursor


    def _save(self, data):
        filename = '%s.json' % uuid.uuid4()
        with open(join(self.updates_dir, filename), 'w') as outfile:
            json.dump(data, outfile)
        self.cleanup_actions.append(lambda: delete_file(self.logger, join(self.updates_dir, filename)))
        return filename
    
    
    def save_vertices(self, data):
        self.vertices.append(self._save(data))


    def save_edges(self, data):
        self.edges.append(self._save(data))


    def _create_import_commands(self, files):
        for filename in files:
            command = Command.new('SEND_DATA')
            file = 'data-%d.json' % command.id
            os.rename(join(self.updates_dir, filename), join(self.updates_dir, file))
            command.args.append(file)
            self.queue.push(command)

    
    def import_saved_data(self):
        self._create_import_commands(self.vertices)
        self.queue.push(Command.new('WAIT'))
        self._create_import_commands(self.edges)
        self.queue.push(Command.new('WAIT'))
