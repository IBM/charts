import subprocess, os, re
from os.path import dirname, realpath


def run(cmd, input=None):
    if input is not None:
        p = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            close_fds=True, preexec_fn=os.setsid)
    else:
        p = subprocess.Popen(cmd, shell=True,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            close_fds=True, preexec_fn=os.setsid)

    out, err = p.communicate(input)
    return p.returncode, err, out


def hide(arg, s):
    m = re.search(r"-%s\s+(\S+)" % arg, s)
    if m:
        s = s.replace(m.group(1), '<%s>' % arg)
    return s


def hide_passwords(s):
    s = hide('key', s)
    s = hide('pass', s)
    s = hide('dbuser', s)
    s = hide('dbpassword', s)
    return s


def add_job(args, context):
    if args.cron:
        context.logger.info('Running as a cron job. No need to change the crontab.')
        return

    context.logger.info('Trying to add CP4S CAR connector to crontab.')

    new_job = "*/15 * * * * cd '%s' && python assets.py -cron -key '%s' -pass '%s' -url '%s'" % (dirname(realpath(__file__)), args.key, args.password, args.url)
    if args.database:
        new_job += " -database '%s'" % args.database
    if args.dbuser:
        new_job += " -dbuser '%s'" % args.dbuser
    if args.dbpassword:
        new_job += " -dbpassword '%s'" % args.dbpassword

    rc, err, contents = run('crontab -l')
    if rc != 0 and 'no crontab for' not in err:
        context.logger.error('Failed to add cron job: %s' % err)
        return

    jobs = contents and contents.split('\n') or []
    for job in jobs:
        if 'assets.py' in job:
            context.logger.info('Leaving existing crontab in place because the following job is already there:')
            context.logger.info(hide_passwords(job))
            return

    jobs.append('# Run CP4S CAR connector every 15 minutes.')
    jobs.append(new_job)
    rc, err, out = run('crontab', '\n'.join(jobs) + '\n')
    if rc != 0:
        context.logger.error('Failed to add cron job: %s' % err)
        return

    context.logger.info('The following cron job added:')
    context.logger.info(hide_passwords(new_job))
