import core, traceback
from util import measure_time
from import_queue import Command
from appstatus import ApplicationStatus, EXPORTER

def export(context, delegate, message):
    context.logger.info(message + ' ...')
    delegate(context)
    context.logger.info(message + ' done.')

def run(context):
        # before building all the necessary objects, remember the rep_next_trans value which will be used when calling incremental updates
        context.tracker.set_next_baseline()
        context.cleanup_updates_dir()

        context.queue.push(Command.new('ENTER_FULL_IMPORT_IN_PROGRESS_STATE'))

        # source, report, source_report
        core.export_source_report(context)

        # vulnerability
        export(context, core.export_vuln, 'building JSON document vulnerabily catalog')

        # asset
        export(context, core.export_asset, 'building JSON document asset catalog')
        export(context, core.export_asset_mac, 'building JSON document asset_mac catalog')
        export(context, core.export_asset_ipaddress, 'building JSON document asset_ipaddress catalog')
        export(context, core.export_asset_vulnerability, 'building JSON document asset_vulnerability catalog')
        
        # macaddress
        export(context, core.export_mac, 'building JSON document macaddress')

        # ipaddress, report_ipaddress
        export(context, core.export_ip, 'building JSON document ipaddresses')

        # macaddress, ipaddress_macaddress
        export(context, core.export_ip_mac, 'building JSON document macaddresses and ipaddress_macaddress relations')

        # ipaddress_vulnerability
        export(context, core.export_ip_vuln, 'building JSON document ipaddress_vulnerability relations')

        # user, asset_account, report_user
        export(context, core.export_user, 'building JSON document user')

        # hostname, asset_hostname
        export(context, core.export_hostname, 'building JSON document hostnames')
        
        # ipaddress_hostname, account_ipaddress, account_hostname 
        export(context, core.export_ip_hostname_user_rels, 'building JSON document ipaddress_hostname, account_ipaddress, account_hostname')
               
        # application, report_application, asset_application
        export(context, core.export_asset_application, 'building JSON document application')

        # application_port
        export(context, core.export_application_port, 'building JSON document application_port relations')

        # application_vulnerability
        export(context, core.export_application_vuln, 'building JSON document application_vulnerability relations')

        # assets['application'] = applicationarray

        # port
        export(context, core.export_port, 'building JSON document port')
        
        # ipaddress_port edge
        export(context, core.export_ip_port, 'building JSON document ipaddress_port relations')

        context.import_saved_data()
        context.queue.push(Command.new('EXIT_FULL_IMPORT_IN_PROGRESS_STATE'))

        # save the new config in the very end
        context.tracker.persist()

        ApplicationStatus(context.logger).set_status(EXPORTER, 'OK')


def run_full_export(context):
    try:
        ApplicationStatus(context.logger).set_status(EXPORTER, 'Running full export')
        measure_time(context.logger, 'Running queries and building json objects', lambda: run(context))
    except Exception as e:
        context.logger.error('Unexpected error occured while running full export')
        traceback.print_exc()
        context.logger.exception(e)
