import os, json, shutil
from util import SUCCESS, FAILURE, delete_file
from util import UnrecoverableFailure, RecoverableFailure, recoverable_failure_status_code
from os.path import join

BATCH_SIZE = 20
MAX_NUMBER_OF_ATTEMPTS = 5

class ImportProcessor(object):


    def __init__(self, context):
        self.context = context
        self.import_statuses = []
        self.import_commands = {}
        self.attempts = {}


    def process(self):
        while True:
            command = self.context.queue.peek()
            if not command:
                return

            exec('self.%s(command)' % command.name)


    def check_if_unrecoverable_failure(self, status):
        if recoverable_failure_status_code(status.status_code):
            return
        with open(join(self.context.errors_dir, status.file.replace('.json', '.error')), 'w') as outfile:
            json.dump(status, outfile, sort_keys=True, indent=4)
        self.context.logger.info('moving file to errors folder: ' + status.file)
        try: shutil.move(join(self.context.updates_dir, status.file), self.context.errors_dir)
        except: pass
        raise UnrecoverableFailure(status.error)


    def check_if_recoverable_failure(self, command, status):
        if recoverable_failure_status_code(status.status_code):
            attempt = (self.attempts.get(status.file) or 0) + 1
            if attempt < MAX_NUMBER_OF_ATTEMPTS:
                self.context.logger.info('Getting status code %d when sending %s. Re-sending ...' % (status.status_code, status.file))
                self.attempts[status.file] = attempt
                self.import_statuses.remove(status)
                self.send_data(command)
            else:
                self.context.logger.info('Getting status code %d after attempting to send %s %d times. Failing ...' % (status.status_code, status.file, attempt))
                raise RecoverableFailure('Getting the following status code when accessing ISC CAR service: %d' % status.status_code)


    def fail(self, status_code):
        if recoverable_failure_status_code(status_code):
            raise RecoverableFailure('Getting the following status code when accessing ISC CAR service: %d' % status_code)
        else:
            raise UnrecoverableFailure('Getting the following status code when accessing ISC CAR service: %d' % status_code)

    
    def ENTER_FULL_IMPORT_IN_PROGRESS_STATE(self, command):
        status_code = self.context.microservice.enter_full_import_in_progress_state()
        if status_code == 200:
            self.context.queue.remove(command)
        else:
            self.fail(status_code)


    def EXIT_FULL_IMPORT_IN_PROGRESS_STATE(self, command):
        status_code = self.context.microservice.exit_full_import_in_progress_state()
        if status_code == 200:
            self.context.queue.remove(command)
        else:
            self.fail(status_code)


    def SEND_DATA(self, command):
        self.send_data(command)
        if len(self.import_statuses) >= BATCH_SIZE:
            self.WAIT(None)


    def send_data(self, command):
        filename = command.args[0]
        try:
            with open(os.path.join(self.context.updates_dir, filename)) as file:
                data = file.read()
        except:
            # Ignore the missing file: Exporter deleted the file by cleaning up update dir before running full import
            self.context.queue.remove(command)
            return

        status = self.context.microservice.import_file(filename, data)
        self.import_statuses.append(status)
        self.import_commands[filename] = command


    def WAIT(self, command):
        self.context.logger.info('Waiting for completion of import jobs ...')
        while self.import_statuses:
            self.context.microservice.check_import_status(self.import_statuses)

            for status in self.import_statuses:
                if status.status == SUCCESS:
                    self.context.queue.remove(self.import_commands[status.file])
                    delete_file(self.context, os.path.join(self.context.updates_dir, status.file))

            self.import_statuses = filter(lambda status: status.status == FAILURE, self.import_statuses)

            for status in self.import_statuses:
                self.check_if_unrecoverable_failure(status)

            for status in self.import_statuses:
                self.check_if_recoverable_failure(self.import_commands[status.file], status)

        self.context.logger.info('All import jobs are completed')
        if command:
            self.context.queue.remove(command)


    def DELETE(self, command):
        self.context.logger.info('Sending DELETE request. Resource: %s, IDs: %s' % (command.args[0], command.args[1]))
        status_code = self.context.microservice.delete(command.args[0], command.args[1])
        if status_code == 200:
            self.context.queue.remove(command)
        else:
            self.fail(status_code)

