import os
from flock import Lock
from util import CommandId

LOCK = 'import_queue.lock'
COMM_QUEUE = 'import.queue'

class CommandQueue(object):

    def __init__(self, dir):
        self.dir = dir
        self.fname = os.path.join(dir, COMM_QUEUE)
        self.last_id = None

    def push(self, command):
        with Lock(LOCK, blocking = True) as lock:
            with open(self.fname, 'a') as f:
                f.write(command.serialize() + '\n')

    def _peek(self, contents, index):
        command = Command.deserialize(contents[index])
        self.last_id = command.id
        return command
    
    def peek(self):
        with Lock(LOCK, blocking = True) as lock:
            try:
                with open(self.fname, 'r') as f:
                    contents = f.readlines()
                    if not contents:
                        return None

                    if not self.last_id:
                        return self._peek(contents, 0)

                    for i in range(len(contents)):
                        command = Command.deserialize(contents[i])
                        if command.id > self.last_id:
                            return self._peek(contents, i)
                        
                    return None

                    return Command.deserialize(contents[0])
            except:
                return None

    def remove(self, command):
        with Lock(LOCK, blocking = True) as lock:
            try:
                with open(self.fname, 'r') as f:
                    contents = f.readlines()
                    for i in range(len(contents)):
                        c = Command.deserialize(contents[i])
                        if c.id == command.id:
                            del contents[i]
                            break
                with open(self.fname, 'w') as f:
                    f.writelines(contents)
            except:
                return


class Command(object):
    
    def __init__(self, name, *args):
        self.name = name
        self.args = list(args)

    def serialize(self):
        return '%s %s %s' % (self.id, self.name, ' '.join(self.args))

    @classmethod
    def new(cls, name, *args):
        c = Command(name, *args)
        c.id = CommandId().next()
        return c

    @classmethod
    def deserialize(cls, s):
        parts = s.strip().split(' ')
        c = Command(parts[1], *parts[2:])
        c.id = int(parts[0])
        return c

    def __str__(self):
        return 'Command: id=%s, name=%s, args=%s' % (self.id, self.name, self.args)

