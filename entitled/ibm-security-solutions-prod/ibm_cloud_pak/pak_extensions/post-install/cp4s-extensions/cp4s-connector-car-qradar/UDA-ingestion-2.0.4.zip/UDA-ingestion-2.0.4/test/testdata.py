import os


class Cursor():
    def __init__(self, iterable):
        self.iterable = iterable
    def __enter__(self):
        return self.iterable
    def __exit__(self, exc_type, exc_val, exc_tb):
        pass


class Row(dict):
    def __missing__(self, key):
        return ''


def gen_data(size, fields):
    rows = []
    for i in range(size):
        row = Row()
        rows.append(row)
        for f in fields.keys():
            v = v = fields[f]
            if '%d' in v: v = v % (i + 1)
            if '+' in v or '*' in v: v = str(eval(v))
            row[f] = v
    return Cursor(rows)


def gen_vuln(size):
    return gen_data(size, {'vulnid' : '%d', 'vcvssbmid' : '1000 + %d', 'name' : 'vuln-name-%d', 'base_score' : '0.001 * %d', 'disclosed_on' : '926035200000', 'published_on' : '938476800000', 'updated_on' : '1430922986000'})

def gen_ip_vuln(size):
    return gen_data(size, {'ipaddress' : '10.10.10.%d', 'vulnid' : '1,2,3,4,5,6,7,8', 'vulninstanceid' : '10,11,12,13,14,15,16,17,18'})

def gen_app(size):
    return gen_data(size, {'id' : '%d', 'assetid' : '%d', 'product' : 'Stuff', 'productid' : '%d'})

def gen_app_port(size):
    return gen_data(size, {'id' : '%d', 'productid' : '%d', 'portid' : '%d'})

def gen_app_vuln(size):
    return gen_data(size, {'appid' : '%d', 'vulnid' : '1,2,3,4,5,6,7,8', 'app_vuln_id' : '10,11,12,13,14,15,16,17,18'})

def gen_user(size):
    return gen_data(size, {'username' : 'user-%d', 'id' : '%d', 'assetid' : '%d', 'groupname' : 'group-%d'})

def gen_hostname(size):
    return gen_data(size, {'hostname' : 'host-%d', 'hostid' : '10000 + %d', 'assetid' : '%d', 'groupname' : 'group-%d'})

def gen_ip_hostname_user_rels(size):
    return gen_data(size, {'hostname' : 'host-%d', 'ipaddress' : '10.10.10.%d', 'id' : '%d', 'username' : 'user-%d'})

def gen_port(size):
    return gen_data(size, {'assetid' : '%d', 'protocol' : 'Protocol-%d', 'id' : '%d', 'portnumber' : '80', 'displaystring' : 'layer7application stuff'})

def gen_ip_port(size):
    return gen_data(size, {'ipaddress' : '10.10.10.%d', 'interfaceid' : '%d', 'id' : '%d'})

def gen_asset(size):
    return gen_data(size, {'assetid' : '%d', 'assetpropertytypeid' : '1002,1003,1004,1005,1026', 'propertyvalue' : 'Some Name,0.5,Some Description,Some Owner,Workstation'})

def gen_asset_mac(size):
    return gen_data(size, {'assetid' : '%d', 'macaddress' : '"22-79-18-D6-1D-" + str(%d / 100)', 'interfaceid' : '%d'})

def gen_asset_ip(size):
    return gen_data(size, {'assetid' : '%d', 'ipaddress' : '10.10.10.%d'})

def gen_asset_vuln(size):
    return gen_data(size, {'assetid' : '%d', 'osid' : '%d', 'vulnid' : '%d', 'vid' : '%d'})

def gen_ip(size):
    return gen_data(size, {'ipaddress' : '10.10.10.%d', 'ipid' : '%d', 'assetid' : '%d', 'vulnid' : '%d', 'vid' : '%d'})

def gen_mac(size):
    return gen_data(size, {'macaddress' : '"22-79-18-D6-1D-" + str(%d / 100)', 'interfaceid' : '%d', 'assetid' : '%d'})

def gen_ip_mac(size):
    return gen_data(size, {'ipaddress' : '10.10.10.%d', 'macaddress' : '"22-79-18-D6-1D-" + str(%d / 100)', 'interfaceid' : '%d', 'assetid' : '%d'})
