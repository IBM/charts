import ConfigParser, os, sys

SECTION = 'metainfo'

class Config(object):


    def __init__(self, context):
        self.context = context
        self.config = ConfigParser.RawConfigParser()
        if os.path.exists(self.context.config_file):
            self.config.read(self.context.config_file)
        else:
            self.config.add_section(SECTION)
            self.config.set(SECTION, 'rep_next_trans', '0')


    def get_value(self, key):
        return self.config.get(SECTION, key)


    def set_value(self, key, value):
        self.config.set(SECTION, key, value)
        with open(self.context.config_file, 'w') as configfile:
            self.config.write(configfile)
