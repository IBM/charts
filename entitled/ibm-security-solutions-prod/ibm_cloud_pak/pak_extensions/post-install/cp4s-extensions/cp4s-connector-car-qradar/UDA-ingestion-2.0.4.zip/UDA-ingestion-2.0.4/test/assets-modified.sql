-- Replication Profile : default profile
-- Mon Jul 29 11:43:20 2019
-- Incremental Transaction 0000000000000001303

COPY rep.public_jmsmailbox_activity FROM stdin;
1357
1358
1359
1360
\.

COPY rep.public_jmsmailbox FROM stdin;
1358	ID:243-172.18.131.157(f8:28:be:47:a6:a5)-33270-1564411376572	\\254\\355\\000\\005sr\\000\\021java.util.HashMap\\005\\007\\332\\301\\303\\026`\\321\\003\\000\\002F\\000\\012loadFactorI\\000\\011thresholdxp?@\\000\\000\\000\\000\\000\\000w\\010\\000\\000\\000\\020\\000\\000\\000\\000x	\N	2	AssetCacheUpdateNotificationTopic	2	0	4	f	\N	0	1564411376572	\N	3	\\254\\355\\000\\005sr\\000\\022gnu.trove.THashSet\\000\\000\\000\\000\\000\\000\\000\\001\\014\\000\\000xr\\000\\025gnu.trove.TObjectHash\\317\\367\\250y\\253\\235\\2761\\002\\000\\001L\\000\\020_hashingStrategyt\\000"Lgnu/trove/TObjectHashingStrategy;xpw\\005\\000\\000\\000\\000\\002sr\\000:com.q1labs.core.assetprofile.utils.AssetCacheUpdateContext\\000\\000\\000\\000\\000\\000\\000\\001\\002\\000\\005J\\000\\007assetIdI\\000\\010domainIdL\\000\\006actiont\\000SLcom/q1labs/core/assetprofile/utils/AssetCacheUpdateContext$AssetCacheUpdateAction;L\\000\\002ipt\\000\\022Ljava/lang/String;L\\000\\004nameq\\000~\\000\\006xp\\000\\000\\000\\000\\000\\000\\004\\007\\000\\000\\000\\000~r\\000Qcom.q1labs.core.assetprofile.utils.AssetCacheUpdateContext$AssetCacheUpdateAction\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006INSERTt\\000\\01310.10.10.10psq\\000~\\000\\004\\000\\000\\000\\000\\000\\000\\004\\007\\000\\000\\000\\000~q\\000~\\000\\010t\\000\\006UPDATEpt\\000\\012Test Assetx	1303
1359	ID:246-172.18.131.157(f8:28:be:47:a6:a5)-33270-1564411392694	\\254\\355\\000\\005sr\\000\\021java.util.HashMap\\005\\007\\332\\301\\303\\026`\\321\\003\\000\\002F\\000\\012loadFactorI\\000\\011thresholdxp?@\\000\\000\\000\\000\\000\\014w\\010\\000\\000\\000\\020\\000\\000\\000\\001t\\000\\024FRAMEWORKS_SESION_IDt\\000$6b74c948-f34d-49c1-83d3-d9c157d761f6x	\N	2	HostAssetUpdateNotificationTopic	2	0	4	f	\N	0	1564411392694	\N	3	\\254\\355\\000\\005sr\\000:com.q1labs.core.assetprofile.services.DomainAssetUpdateMap\\000\\000\\000\\000\\000\\000\\000\\001\\002\\000\\004I\\000\\016deletedIpCountI\\000\\017insertedIpCountI\\000\\022totalUpdateIpCountI\\000\\016updatedIpCountxr\\000\\021java.util.HashMap\\005\\007\\332\\301\\303\\026`\\321\\003\\000\\002F\\000\\012loadFactorI\\000\\011thresholdxp?@\\000\\000\\000\\000\\000\\014w\\010\\000\\000\\000\\020\\000\\000\\000\\001sr\\000\\021java.lang.Integer\\022\\342\\240\\244\\367\\201\\2078\\002\\000\\001I\\000\\005valuexr\\000\\020java.lang.Number\\206\\254\\225\\035\\013\\224\\340\\213\\002\\000\\000xp\\000\\000\\000\\000sr\\0007com.q1labs.core.assetprofile.services.DomainAssetUpdate\\000\\000\\000\\000\\000\\000\\000\\001\\002\\000\\003L\\000\\007deletedt\\000\\036Lcom/q1labs/core/util/IPV4Set;L\\000\\010insertedq\\000~\\000\\007L\\000\\007updatedq\\000~\\000\\007xpsr\\0000com.q1labs.core.util.IPV4Set$SynchronizedIPV4Set\\000\\000\\000\\000\\000\\000\\000\\001\\002\\000\\000xr\\000\\034com.q1labs.core.util.IPV4Set\\000\\000\\000\\000\\000\\000\\000\\000\\002\\000\\005J\\000\\010hitCountJ\\000\\011missCountJ\\000\\004sizeL\\000\\007addresst\\000\\027Lgnu/trove/TIntHashSet;L\\000\\004namet\\000\\022Ljava/lang/String;xp\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000sr\\000\\025gnu.trove.TIntHashSet\\000\\000\\000\\000\\000\\000\\000\\001\\014\\000\\000xr\\000\\022gnu.trove.TIntHashI;v\\237\\372c\\037'\\002\\000\\001L\\000\\020_hashingStrategyt\\000\\037Lgnu/trove/TIntHashingStrategy;xpw\\005\\000\\000\\000\\000\\000xt\\000$d4b5eb74-4638-4515-8d10-55878e35e87asq\\000~\\000\\011\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\001\\000\\000\\000\\000\\000\\000\\000\\001sq\\000~\\000\\016w\\011\\000\\000\\000\\000\\001\\012\\012\\012\\012xt\\000$59856cb7-5162-4d44-8bcc-425b488c2c90sq\\000~\\000\\011\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\001\\000\\000\\000\\000\\000\\000\\000\\001sq\\000~\\000\\016w\\011\\000\\000\\000\\000\\001\\254\\022\\202Qxt\\000$87843c12-e87a-4c80-9254-5163080c5406x\\000\\000\\000\\000\\000\\000\\000\\001\\000\\000\\000\\002\\000\\000\\000\\001	1303
1360	ID:247-172.18.131.157(f8:28:be:47:a6:a5)-33270-1564411392699	\\254\\355\\000\\005sr\\000\\021java.util.HashMap\\005\\007\\332\\301\\303\\026`\\321\\003\\000\\002F\\000\\012loadFactorI\\000\\011thresholdxp?@\\000\\000\\000\\000\\000\\014w\\010\\000\\000\\000\\020\\000\\000\\000\\001t\\000\\024FRAMEWORKS_SESION_IDt\\000$2cf344bb-a946-4d59-8cc3-fffc696e2c34x	\N	2	AssetUpdateNotificationTopic	2	0	4	f	\N	0	1564411392699	\N	3	\\254\\355\\000\\005sr\\000:com.q1labs.core.assetprofile.services.DomainAssetUpdateMap\\000\\000\\000\\000\\000\\000\\000\\001\\002\\000\\004I\\000\\016deletedIpCountI\\000\\017insertedIpCountI\\000\\022totalUpdateIpCountI\\000\\016updatedIpCountxr\\000\\021java.util.HashMap\\005\\007\\332\\301\\303\\026`\\321\\003\\000\\002F\\000\\012loadFactorI\\000\\011thresholdxp?@\\000\\000\\000\\000\\000\\014w\\010\\000\\000\\000\\020\\000\\000\\000\\001sr\\000\\021java.lang.Integer\\022\\342\\240\\244\\367\\201\\2078\\002\\000\\001I\\000\\005valuexr\\000\\020java.lang.Number\\206\\254\\225\\035\\013\\224\\340\\213\\002\\000\\000xp\\000\\000\\000\\000sr\\0007com.q1labs.core.assetprofile.services.DomainAssetUpdate\\000\\000\\000\\000\\000\\000\\000\\001\\002\\000\\003L\\000\\007deletedt\\000\\036Lcom/q1labs/core/util/IPV4Set;L\\000\\010insertedq\\000~\\000\\007L\\000\\007updatedq\\000~\\000\\007xpsr\\0000com.q1labs.core.util.IPV4Set$SynchronizedIPV4Set\\000\\000\\000\\000\\000\\000\\000\\001\\002\\000\\000xr\\000\\034com.q1labs.core.util.IPV4Set\\000\\000\\000\\000\\000\\000\\000\\000\\002\\000\\005J\\000\\010hitCountJ\\000\\011missCountJ\\000\\004sizeL\\000\\007addresst\\000\\027Lgnu/trove/TIntHashSet;L\\000\\004namet\\000\\022Ljava/lang/String;xp\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000sr\\000\\025gnu.trove.TIntHashSet\\000\\000\\000\\000\\000\\000\\000\\001\\014\\000\\000xr\\000\\022gnu.trove.TIntHashI;v\\237\\372c\\037'\\002\\000\\001L\\000\\020_hashingStrategyt\\000\\037Lgnu/trove/TIntHashingStrategy;xpw\\005\\000\\000\\000\\000\\000xt\\000$f195beed-d983-4c98-8645-7d39d311dd48sq\\000~\\000\\011\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\001\\000\\000\\000\\000\\000\\000\\000\\001sq\\000~\\000\\016w\\011\\000\\000\\000\\000\\001\\012\\012\\012\\012xt\\000$672aa6b4-d9ff-49d7-83db-3d673ccc8f9fsq\\000~\\000\\011\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\000\\001\\000\\000\\000\\000\\000\\000\\000\\001sq\\000~\\000\\016w\\011\\000\\000\\000\\000\\001\\254\\022\\202Qxt\\000$b40f897d-3fee-414d-9731-ebffc27c5b0ex\\000\\000\\000\\000\\000\\000\\000\\001\\000\\000\\000\\002\\000\\000\\000\\001	1303
1357	ID:2659-172.18.131.157(e0:2e:64:46:8f:83)-60142-1564411373149	\\254\\355\\000\\005sr\\000\\021java.util.HashMap\\005\\007\\332\\301\\303\\026`\\321\\003\\000\\002F\\000\\012loadFactorI\\000\\011thresholdxp?@\\000\\000\\000\\000\\000\\000w\\010\\000\\000\\000\\020\\000\\000\\000\\000x	\N	2	AssetProfilerAPI	2	0	4	f	\N	0	1564411373149	\N	3	\\254\\355\\000\\005sr\\000\\023java.util.ArrayListx\\201\\322\\035\\231\\307a\\235\\003\\000\\001I\\000\\004sizexp\\000\\000\\000\\001w\\004\\000\\000\\000\\001sr\\000Gcom.q1labs.assetprofile.api.updates.targeted.AssetProfileTargetedUpdate\\000\\000\\000\\000\\000\\000\\000\\001\\002\\000\\023I\\000\\010domainIdL\\000\\023assetDataSourceNamet\\000\\022Ljava/lang/String;L\\000\\023assetDataSourceTypet\\0009Lcom/q1labs/assetprofile/persistence/AssetDataSourceType;L\\000\\013catalogTypet\\0001Lcom/q1labs/assetprofile/util/ProductCatalogType;L\\000\\022clientApplicationst\\000\\025Ljava/util/ArrayList;L\\000\\005flagst\\000\\020Ljava/util/List;L\\000\\011hostnamesq\\000~\\000\\006L\\000\\012interfacesq\\000~\\000\\006L\\000\\015netBiosGroupsq\\000~\\000\\006L\\000\\020operatingSystemsq\\000~\\000\\006L\\000\\011patchScant\\000FLcom/q1labs/assetprofile/api/updates/targeted/PatchScanTargetedUpdate;L\\000\\015policyAnswersq\\000~\\000\\006L\\000\\010portScant\\000ELcom/q1labs/assetprofile/api/updates/targeted/PortScanTargetedUpdate;L\\000\\020portlessProductsq\\000~\\000\\006L\\000\\005portsq\\000~\\000\\006L\\000\\012propertiesq\\000~\\000\\006L\\000\\011timestampt\\000\\020Ljava/lang/Long;L\\000\\005usersq\\000~\\000\\006L\\000\\005vulnsq\\000~\\000\\006xr\\000Hcom.q1labs.assetprofile.api.updates.targeted.AssetComponentPendingUpdate<\\326\\023+C\\332\\240z\\002\\000\\002L\\000\\017parentPendingIdq\\000~\\000\\012L\\000\\017pendingUpdateIdq\\000~\\000\\012xr\\000Icom.q1labs.assetprofile.api.updates.targeted.AssetComponentTargetedUpdate\\351[D\\\\\\365m\\373\\263\\002\\000\\002L\\000\\006actiont\\000ZLcom/q1labs/assetprofile/api/updates/targeted/AssetComponentTargetedUpdate$TargetedAction;L\\000\\002idq\\000~\\000\\012xp~r\\000Xcom.q1labs.assetprofile.api.updates.targeted.AssetComponentTargetedUpdate$TargetedAction\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xr\\000\\016java.lang.Enum\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xpt\\000\\006UPDATEsr\\000\\016java.lang.Long;\\213\\344\\220\\314\\217#\\337\\002\\000\\001J\\000\\005valuexr\\000\\020java.lang.Number\\206\\254\\225\\035\\013\\224\\340\\213\\002\\000\\000xp\\000\\000\\000\\000\\000\\000\\004\\007psq\\000~\\000\\023\\000\\000\\000\\000\\000\\000\\000\\026\\000\\000\\000\\000t\\000\\005admin~r\\0007com.q1labs.assetprofile.persistence.AssetDataSourceType\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xq\\000~\\000\\020t\\000\\004USERppppsq\\000~\\000\\000\\000\\000\\000\\001w\\004\\000\\000\\000\\001sr\\000Dcom.q1labs.assetprofile.api.updates.targeted.InterfaceTargetedUpdate< \\2639\\377:5\\031\\002\\000\\002L\\000\\013ipAddressesq\\000~\\000\\006L\\000\\012macAddressq\\000~\\000\\003xq\\000~\\000\\013~q\\000~\\000\\017t\\000\\010NOACTIONsq\\000~\\000\\023\\000\\000\\000\\000\\000\\000\\004\\007q\\000~\\000\\026sq\\000~\\000\\023\\000\\000\\000\\000\\000\\000\\000\\001sq\\000~\\000\\000\\000\\000\\000\\001w\\004\\000\\000\\000\\001sr\\000=com.q1labs.assetprofile.api.updates.targeted.IpTargetedUpdatek\\0247\\375\\314\\002{\\367\\002\\000\\003L\\000\\011ipaddressq\\000~\\000\\003L\\000\\005netIdq\\000~\\000\\012L\\000\\007versiont\\000(Lcom/q1labs/assetprofile/util/IPVersion;xq\\000~\\000\\013~q\\000~\\000\\017t\\000\\006INSERTpq\\000~\\000!q\\000~\\000!t\\000\\01310.10.10.10p~r\\000&com.q1labs.assetprofile.util.IPVersion\\000\\000\\000\\000\\000\\000\\000\\000\\022\\000\\000xq\\000~\\000\\020t\\000\\002V4xpxpppppppsq\\000~\\000\\000\\000\\000\\000\\003w\\004\\000\\000\\000\\003sr\\000Hcom.q1labs.assetprofile.api.updates.targeted.AssetPropertyTargetedUpdate\\242=E\\316e\\337\\224g\\002\\000\\002L\\000\\014propertyTypeq\\000~\\000\\012L\\000\\015propertyValueq\\000~\\000\\003xq\\000~\\000\\013q\\000~\\000&pq\\000~\\000\\026q\\000~\\000!sq\\000~\\000\\023\\000\\000\\000\\000\\000\\000\\003\\351t\\000\\012Test Assetsq\\000~\\000-q\\000~\\000&pq\\000~\\000\\026sq\\000~\\000\\023\\000\\000\\000\\000\\000\\000\\000\\002sq\\000~\\000\\023\\000\\000\\000\\000\\000\\000\\003\\361t\\000\\006Ottawasq\\000~\\000-q\\000~\\000&pq\\000~\\000\\026sq\\000~\\000\\023\\000\\000\\000\\000\\000\\000\\000\\003sq\\000~\\000\\023\\000\\000\\000\\000\\000\\000\\003\\373t\\000\\016root@localhostxsq\\000~\\000\\023\\000\\000\\001l>/&*ppx	1303
\.
SELECT replicate_restore_dump('jmsmailbox', 'public');
DELETE FROM rep.replicate_verify WHERE relname = 'jmsmailbox' AND schemaname = 'public';

COPY rep.public_serverhost_activity FROM stdin;
51
\.

COPY rep.public_serverhost FROM stdin;
51	172.18.131.157	ip-131-157.q1labs.lab	0	2019-07-10 13:44:00.34	2019-07-29 11:43:17.69	7.3.1	53	ens192	VMware-42 26 d0 da 49 f5 57 48-20 94 6f f5 93 f5 9b 5c
\.
SELECT replicate_restore_dump('serverhost', 'public');
DELETE FROM rep.replicate_verify WHERE relname = 'serverhost' AND schemaname = 'public';

COPY rep.public_saf_history_activity FROM stdin;
101
\.

COPY rep.public_saf_history FROM stdin;
101	7		2		611523	0	0	1	135	133	1564406805446	1564411395367
\.
SELECT replicate_restore_dump('saf_history', 'public');
DELETE FROM rep.replicate_verify WHERE relname = 'saf_history' AND schemaname = 'public';

COPY rep.asset_asset_activity FROM stdin;
\.

COPY rep.asset_asset FROM stdin;
\.
SELECT replicate_restore_dump('asset', 'asset');
DELETE FROM rep.replicate_verify WHERE relname = 'asset' AND schemaname = 'asset';

COPY rep.asset_assetproductvariantxref_activity FROM stdin;
\.

COPY rep.asset_assetproductvariantxref FROM stdin;
\.
SELECT replicate_restore_dump('assetproductvariantxref', 'asset');
DELETE FROM rep.replicate_verify WHERE relname = 'assetproductvariantxref' AND schemaname = 'asset';

COPY rep.asset_assetproperty_activity FROM stdin;
1302
1303
1078
1304
\.

COPY rep.asset_assetproperty FROM stdin;
1302	1031	1001	Test Asset	t	USER:admin	2019-07-29 14:42:53.098
1303	1031	1019	root@localhost	t	USER:admin	2019-07-29 14:42:53.098
1078	1031	1002	Test Asset	t	USER:admin	2019-07-29 14:42:53.935
1304	1031	1009	Ottawa	t	USER:admin	2019-07-29 14:42:53.098
\.
SELECT replicate_restore_dump('assetproperty', 'asset');
DELETE FROM rep.replicate_verify WHERE relname = 'assetproperty' AND schemaname = 'asset';

COPY rep.asset_hostname_activity FROM stdin;
\.

COPY rep.asset_hostname FROM stdin;
\.
SELECT replicate_restore_dump('hostname', 'asset');
DELETE FROM rep.replicate_verify WHERE relname = 'hostname' AND schemaname = 'asset';

COPY rep.asset_interface_activity FROM stdin;
\.

COPY rep.asset_interface FROM stdin;
\.
SELECT replicate_restore_dump('interface', 'asset');
DELETE FROM rep.replicate_verify WHERE relname = 'interface' AND schemaname = 'asset';

COPY rep.asset_ipaddress_activity FROM stdin;
1123
\.

COPY rep.asset_ipaddress FROM stdin;
1123	1031	2	t	2019-07-29 14:42:53.098	\N	\N	\N	\N	0	10.10.10.10
\.
SELECT replicate_restore_dump('ipaddress', 'asset');
DELETE FROM rep.replicate_verify WHERE relname = 'ipaddress' AND schemaname = 'asset';

COPY rep.asset_pendingassetupdate_activity FROM stdin;
22
\.

COPY rep.asset_pendingassetupdate FROM stdin;
\.
SELECT replicate_restore_dump('pendingassetupdate', 'asset');
DELETE FROM rep.replicate_verify WHERE relname = 'pendingassetupdate' AND schemaname = 'asset';

COPY rep.asset_pendingipaddressupdate_activity FROM stdin;
1
\.

COPY rep.asset_pendingipaddressupdate FROM stdin;
\.
SELECT replicate_restore_dump('pendingipaddressupdate', 'asset');
DELETE FROM rep.replicate_verify WHERE relname = 'pendingipaddressupdate' AND schemaname = 'asset';

COPY rep.asset_pendinginterfaceupdate_activity FROM stdin;
1
\.

COPY rep.asset_pendinginterfaceupdate FROM stdin;
\.
SELECT replicate_restore_dump('pendinginterfaceupdate', 'asset');
DELETE FROM rep.replicate_verify WHERE relname = 'pendinginterfaceupdate' AND schemaname = 'asset';

COPY rep.asset_pendingassetpropertyupdate_activity FROM stdin;
1
2
3
\.

COPY rep.asset_pendingassetpropertyupdate FROM stdin;
\.
SELECT replicate_restore_dump('pendingassetpropertyupdate', 'asset');
DELETE FROM rep.replicate_verify WHERE relname = 'pendingassetpropertyupdate' AND schemaname = 'asset';

COPY rep.asset_port_activity FROM stdin;
\.

COPY rep.asset_port FROM stdin;
\.
SELECT replicate_restore_dump('port', 'asset');
DELETE FROM rep.replicate_verify WHERE relname = 'port' AND schemaname = 'asset';

COPY rep.asset_portvulnxref_activity FROM stdin;
\.

COPY rep.asset_portvulnxref FROM stdin;
\.
SELECT replicate_restore_dump('portvulnxref', 'asset');
DELETE FROM rep.replicate_verify WHERE relname = 'portvulnxref' AND schemaname = 'asset';

COPY rep.asset_user_activity FROM stdin;
\.

COPY rep.asset_user FROM stdin;
\.
SELECT replicate_restore_dump('user', 'asset');
DELETE FROM rep.replicate_verify WHERE relname = 'user' AND schemaname = 'asset';

COPY rep.asset_vulninstance_activity FROM stdin;
\.

COPY rep.asset_vulninstance FROM stdin;
\.
SELECT replicate_restore_dump('vulninstance', 'asset');
DELETE FROM rep.replicate_verify WHERE relname = 'vulninstance' AND schemaname = 'asset';

COPY rep.asset_assetview_activity FROM stdin;
1031
\.

COPY rep.asset_assetview FROM stdin;
1031	-1408073135	\N	Test Asset	\N	\N	\N	\N	0
\.
SELECT replicate_restore_dump('assetview', 'asset');
DELETE FROM rep.replicate_verify WHERE relname = 'assetview' AND schemaname = 'asset';

COPY rep.asset_os_activity FROM stdin;
\.

COPY rep.asset_os FROM stdin;
\.
SELECT replicate_restore_dump('os', 'asset');
DELETE FROM rep.replicate_verify WHERE relname = 'os' AND schemaname = 'asset';

COPY rep.asset_physicaluser_activity FROM stdin;
\.

COPY rep.asset_physicaluser FROM stdin;
\.
SELECT replicate_restore_dump('physicaluser', 'asset');
DELETE FROM rep.replicate_verify WHERE relname = 'physicaluser' AND schemaname = 'asset';

COPY rep.asset_useralias_activity FROM stdin;
\.

COPY rep.asset_useralias FROM stdin;
\.
SELECT replicate_restore_dump('useralias', 'asset');
DELETE FROM rep.replicate_verify WHERE relname = 'useralias' AND schemaname = 'asset';

COPY rep.asset_portlayer4protocolxref_activity FROM stdin;
\.

COPY rep.asset_portlayer4protocolxref FROM stdin;
\.
SELECT replicate_restore_dump('portlayer4protocolxref', 'asset');
DELETE FROM rep.replicate_verify WHERE relname = 'portlayer4protocolxref' AND schemaname = 'asset';

COPY rep.asset_clientapplication_activity FROM stdin;
\.

COPY rep.asset_clientapplication FROM stdin;
\.
SELECT replicate_restore_dump('clientapplication', 'asset');
DELETE FROM rep.replicate_verify WHERE relname = 'clientapplication' AND schemaname = 'asset';

COPY rep.asset_portassetproductvariantxrefxref_activity FROM stdin;
\.

COPY rep.asset_portassetproductvariantxrefxref FROM stdin;
\.
SELECT replicate_restore_dump('portassetproductvariantxrefxref', 'asset');
DELETE FROM rep.replicate_verify WHERE relname = 'portassetproductvariantxrefxref' AND schemaname = 'asset';

COPY rep.q_catalog_layer7applicationvariant_activity FROM stdin;
\.

COPY rep.q_catalog_layer7applicationvariant FROM stdin;
\.
SELECT replicate_restore_dump('layer7applicationvariant', 'q_catalog');
DELETE FROM rep.replicate_verify WHERE relname = 'layer7applicationvariant' AND schemaname = 'q_catalog';

COPY rep.q_catalog_layer7application_activity FROM stdin;
\.

COPY rep.q_catalog_layer7application FROM stdin;
\.
SELECT replicate_restore_dump('layer7application', 'q_catalog');
DELETE FROM rep.replicate_verify WHERE relname = 'layer7application' AND schemaname = 'q_catalog';

COPY rep.q_catalog_layer7applicationsource_activity FROM stdin;
\.

COPY rep.q_catalog_layer7applicationsource FROM stdin;
\.
SELECT replicate_restore_dump('layer7applicationsource', 'q_catalog');
DELETE FROM rep.replicate_verify WHERE relname = 'layer7applicationsource' AND schemaname = 'q_catalog';

COPY rep.q_catalog_product_activity FROM stdin;
\.

COPY rep.q_catalog_product FROM stdin;
\.
SELECT replicate_restore_dump('product', 'q_catalog');
DELETE FROM rep.replicate_verify WHERE relname = 'product' AND schemaname = 'q_catalog';

COPY rep.q_catalog_productvendor_activity FROM stdin;
\.

COPY rep.q_catalog_productvendor FROM stdin;
\.
SELECT replicate_restore_dump('productvendor', 'q_catalog');
DELETE FROM rep.replicate_verify WHERE relname = 'productvendor' AND schemaname = 'q_catalog';

COPY rep.q_catalog_productname_activity FROM stdin;
\.

COPY rep.q_catalog_productname FROM stdin;
\.
SELECT replicate_restore_dump('productname', 'q_catalog');
DELETE FROM rep.replicate_verify WHERE relname = 'productname' AND schemaname = 'q_catalog';

COPY rep.q_catalog_productversion_activity FROM stdin;
\.

COPY rep.q_catalog_productversion FROM stdin;
\.
SELECT replicate_restore_dump('productversion', 'q_catalog');
DELETE FROM rep.replicate_verify WHERE relname = 'productversion' AND schemaname = 'q_catalog';

COPY rep.q_catalog_productvariant_activity FROM stdin;
\.

COPY rep.q_catalog_productvariant FROM stdin;
\.
SELECT replicate_restore_dump('productvariant', 'q_catalog');
DELETE FROM rep.replicate_verify WHERE relname = 'productvariant' AND schemaname = 'q_catalog';

COPY rep.q_catalog_productvendorvariant_activity FROM stdin;
\.

COPY rep.q_catalog_productvendorvariant FROM stdin;
\.
SELECT replicate_restore_dump('productvendorvariant', 'q_catalog');
DELETE FROM rep.replicate_verify WHERE relname = 'productvendorvariant' AND schemaname = 'q_catalog';

COPY rep.q_catalog_productnamevariant_activity FROM stdin;
\.

COPY rep.q_catalog_productnamevariant FROM stdin;
\.
SELECT replicate_restore_dump('productnamevariant', 'q_catalog');
DELETE FROM rep.replicate_verify WHERE relname = 'productnamevariant' AND schemaname = 'q_catalog';

COPY rep.q_catalog_productversionvariant_activity FROM stdin;
\.

COPY rep.q_catalog_productversionvariant FROM stdin;
\.
SELECT replicate_restore_dump('productversionvariant', 'q_catalog');
DELETE FROM rep.replicate_verify WHERE relname = 'productversionvariant' AND schemaname = 'q_catalog';

COPY rep.q_catalog_producttype_activity FROM stdin;
\.

COPY rep.q_catalog_producttype FROM stdin;
\.
SELECT replicate_restore_dump('producttype', 'q_catalog');
DELETE FROM rep.replicate_verify WHERE relname = 'producttype' AND schemaname = 'q_catalog';

COPY rep.q_catalog_productproducttypexref_activity FROM stdin;
\.

COPY rep.q_catalog_productproducttypexref FROM stdin;
\.
SELECT replicate_restore_dump('productproducttypexref', 'q_catalog');
DELETE FROM rep.replicate_verify WHERE relname = 'productproducttypexref' AND schemaname = 'q_catalog';

COPY rep.q_catalog_osproductindex_activity FROM stdin;
\.

COPY rep.q_catalog_osproductindex FROM stdin;
\.
SELECT replicate_restore_dump('osproductindex', 'q_catalog');
DELETE FROM rep.replicate_verify WHERE relname = 'osproductindex' AND schemaname = 'q_catalog';


-- Truncate and populate the rep.replicate table
DELETE FROM rep.public_replicate; 
COPY rep.public_replicate FROM stdin;
7	jmsmailbox	00:00:00	2019-07-29 11:43:17.679708	12	9	9	id	{}	public
37	serverhost	00:00:00	2019-07-29 11:43:17.679708	0	80	0	id	{}	public
86	saf_history	00:00:00	2019-07-29 11:43:17.679708	1	149	3	id	{}	public
102	asset	00:00:00	2019-07-29 11:43:17.679708	0	0	21	id	{}	asset
103	assetproductvariantxref	00:00:00	2019-07-29 11:43:17.679708	0	0	62	id	{}	asset
104	assetproperty	00:00:00	2019-07-29 11:43:17.679708	3	1	60	id	{assetid,assetpropertytypeid,propertyvalue,isuservalue,lastreportedby}	asset
108	hostname	00:00:00	2019-07-29 11:43:17.679708	0	0	30	id	{}	asset
110	interface	00:00:00	2019-07-29 11:43:17.679708	0	0	21	id	{assetid,macaddress,isuservalue,created,domainid}	asset
111	ipaddress	00:08:00	2019-07-29 11:43:17.679708	1	0	21	id	{interfaceid,netid,isuservalue,created,lastseenscanner,domainid,ipaddress}	asset
113	pendingassetupdate	00:00:00	2019-07-29 11:43:17.679708	22	0	22	id	{}	asset
114	pendingipaddressupdate	00:00:00	2019-07-29 11:43:17.679708	1	0	1	id	{}	asset
115	pendinginterfaceupdate	00:00:00	2019-07-29 11:43:17.679708	1	0	1	id	{}	asset
117	pendingassetpropertyupdate	00:00:00	2019-07-29 11:43:17.679708	3	0	3	id	{}	asset
119	port	00:00:00	2019-07-29 11:43:17.679708	0	0	83	id	{}	asset
120	portvulnxref	00:00:00	2019-07-29 11:43:17.679708	0	0	68	id	{}	asset
124	user	00:08:00	2019-07-29 11:43:17.679708	0	0	0	id	{assetid,physicaluserid,lastknownlogin,lastknownlogout}	asset
125	vulninstance	00:00:00	2019-07-29 11:43:17.679708	0	0	90	id	{}	asset
127	assetview	00:00:00	2019-07-29 11:43:17.679708	22	0	0	id	{}	asset
128	os	00:00:00	2019-07-29 11:43:17.679708	0	0	18	id	{}	asset
131	physicaluser	00:00:00	2019-07-29 11:43:17.679708	0	0	0	id	{}	asset
132	useralias	00:00:00	2019-07-29 11:43:17.679708	0	0	0	id	{}	asset
133	portlayer4protocolxref	00:00:00	2019-07-29 11:43:17.679708	0	0	86	id	{}	asset
134	clientapplication	00:00:00	2019-07-29 11:43:17.679708	0	0	0	id	{assetid,layer7applicationvariantid,lastseenport,lastreportedbytesin,lastreportedbytesout}	asset
135	portassetproductvariantxrefxref	00:00:00	2019-07-29 11:43:17.679708	0	0	44	id	{}	asset
142	layer7applicationvariant	00:00:00	2019-07-29 11:43:17.679708	0	0	0	id	{}	q_catalog
143	layer7application	00:00:00	2019-07-29 11:43:17.679708	0	0	0	id	{}	q_catalog
144	layer7applicationsource	00:00:00	2019-07-29 11:43:17.679708	0	0	0	id	{}	q_catalog
145	product	00:00:00	2019-07-29 11:43:17.679708	0	0	0	id	{}	q_catalog
146	productvendor	00:00:00	2019-07-29 11:43:17.679708	0	0	0	id	{}	q_catalog
147	productname	00:00:00	2019-07-29 11:43:17.679708	0	0	0	id	{}	q_catalog
148	productversion	00:00:00	2019-07-29 11:43:17.679708	0	0	0	id	{}	q_catalog
149	productvariant	00:00:00	2019-07-29 11:43:17.679708	0	0	0	id	{}	q_catalog
150	productvendorvariant	00:00:00	2019-07-29 11:43:17.679708	0	0	0	id	{}	q_catalog
151	productnamevariant	00:00:00	2019-07-29 11:43:17.679708	0	0	0	id	{}	q_catalog
152	productversionvariant	00:00:00	2019-07-29 11:43:17.679708	0	0	0	id	{}	q_catalog
153	producttype	00:00:00	2019-07-29 11:43:17.679708	0	0	0	id	{}	q_catalog
154	productproducttypexref	00:00:00	2019-07-29 11:43:17.679708	0	0	0	id	{}	q_catalog
155	osproductindex	00:00:00	2019-07-29 11:43:17.679708	0	0	0	id	{}	q_catalog
\.

-- Populate the rep.replicate_verify table
COPY rep.replicate_verify FROM stdin;
jmsmailbox	public	4
serverhost	public	1
saf_history	public	1
asset	asset	100
assetproductvariantxref	asset	116
assetproperty	asset	245
hostname	asset	134
interface	asset	100
ipaddress	asset	102
pendingassetupdate	asset	0
pendingipaddressupdate	asset	0
pendinginterfaceupdate	asset	0
pendingassetpropertyupdate	asset	0
port	asset	157
portvulnxref	asset	69
user	asset	0
vulninstance	asset	138
assetview	asset	22
os	asset	42
physicaluser	asset	0
useralias	asset	0
portlayer4protocolxref	asset	157
clientapplication	asset	0
portassetproductvariantxrefxref	asset	74
layer7applicationvariant	q_catalog	2239
layer7application	q_catalog	1921
layer7applicationsource	q_catalog	2
product	q_catalog	73676
productvendor	q_catalog	8879
productname	q_catalog	16214
productversion	q_catalog	28864
productvariant	q_catalog	97017
productvendorvariant	q_catalog	9052
productnamevariant	q_catalog	16397
productversionvariant	q_catalog	84821
producttype	q_catalog	7
productproducttypexref	q_catalog	7394
osproductindex	q_catalog	7518
\.
UPDATE replication_info SET value = '0000000000000001303' WHERE key = 'rep_last_trans';
