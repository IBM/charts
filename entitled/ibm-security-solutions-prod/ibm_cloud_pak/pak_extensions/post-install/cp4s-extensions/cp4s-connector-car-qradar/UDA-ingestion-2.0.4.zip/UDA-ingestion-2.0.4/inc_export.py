import traceback
import core
from appstatus import ApplicationStatus, EXPORTER
from import_queue import Command


def get_where_clause(table, identifier, value):
    if table and 'q_catalog_' in table:
        table = table[14:-9]
    elif table and 'asset_' in table:
        table = table[10:-9]
    if table:
        whereclause = "where {}.{} {}".format(table, identifier, value)
    else:
        whereclause = "where {} {}".format(identifier, value)
    return str(whereclause)


# is it a delete or an update
def updates_deletes(context, ids, query, identifier = 'id'):
    updates = []
    query = query % ','.join(ids)
    with context.execute(query) as cursor:
        for obj in cursor:
            id = str(obj[identifier])
            updates.append(id)
                
    deleted = filter(lambda id: id not in updates, ids)
    context.logger.info('Created/modified: %d, Deleted: %d' % (len(updates), len(deleted)))
    return updates, deleted


def delete(context, resource, ids):
    context.queue.push(Command.new('DELETE', resource, ','.join(ids)))


def build_asset_related_objects(context, data):
    table = 'asset'
    query = "select id from asset.asset where id in (%s)"
    updates, deletes = updates_deletes(context, data, query)

    if updates:
        value = ' in (%s)' % ','.join(updates)
        whereclause = get_where_clause(table, 'id', value)
        core.export_asset(context, whereclause)
    if deletes:
        delete(context, 'asset', deletes)


# ipaddress, macaddress, asset_ipaddress, ipaddress_macaddress, ipaddress_vulnerability, report_ipaddress, ipaddress_port edge
def build_ip_related_objects(context, data):
    table = 'ipaddress'
    query = "select id from asset.ipaddress where id in (%s)"
    updates, deletes = updates_deletes(context, data, query)
        
    if updates:
        value = ' in (%s)' % ','.join(updates)
        whereclause = get_where_clause(table, 'id', value)
        core.export_ip(context, whereclause)
        core.export_ip_mac(context, whereclause)
        core.export_ip_vuln(context, whereclause)
        core.export_ip_port(context, whereclause)
        core.export_asset_ipaddress(context, whereclause)
    if deletes:
        delete(context, 'ipaddress', deletes)


#       Column       |            Type             |                           Modifiers                            
# -------------------+-----------------------------+----------------------------------------------------------------
#  id                | bigint                      | not null default nextval('asset.interface_sequence'::regclass)
#  assetid           | bigint                      | not null
#  macaddress        | character varying           | 
#  isuservalue       | boolean                     | default false
#  created           | timestamp without time zone | 
#  firstseenscanner  | timestamp without time zone | 
#  lastseenscanner   | timestamp without time zone | 
#  firstseenprofiler | timestamp without time zone | 
#  lastseenprofiler  | timestamp without time zone | 
#  domainid          | integer                     | default 0

def build_interface_related_objects(context, data):
    table = 'interface'
    query = "select id from asset.interface where id in (%s)"
    updates, deletes = updates_deletes(context, data, query)
    if updates:
        # INSERT: asset, macaddress, asset_macaddress
        # UPDATE: asset, macaddress, asset_macaddress
        value = ' in (%s)' % ','.join(updates)
        whereclause = get_where_clause(table, 'id', value)
        core.export_mac(context, whereclause)
        # assetarray = core.export_asset(context, whereclause)
        core.export_asset_mac(context, whereclause)
    if deletes:
        delete(context, 'macaddress', deletes)


# I think this function will be used only when a record has been deleted, becuase we are basically looking for the vulnerability and compute the score 
# using asset.assetstatistics table. 
# We dont care about the other fields if they have changed.  
# the deleted IDs are in rep.asset_<relationname>_activity
# Collections that could be influenced by these updates are: ipaddress, application, edge application_vuln, ipaddress_vuln
def build_vulninstance_related_objects(context, data):
    # id              | not null default nextval('asset.vulninstance_sequence'::regclass)
    # assetid         | not null
    # osid            | 
    # vulnid          | not null
    # vulntypeid      | not null
    # isearlywarning  | default false

    # cases to consider are: 
    # 1) new record inserted 
    # 2) if osid, vulnid, vulntypeid, assetid have changed
    # 3) an entry has been deleted
    updates = []
    deletes = []
    query = "select id from asset.vulninstance where id in (%s)"
    # note about deletes, I'm not sure if this is the best approach, since the assetid is the link between (ipaddress, vulnerability) and (application, vulnerability). I will add `id` of vulninstance (since when a row is deleted, `id` is the only information I could get) and `assetid` in the edge that links between ipaddress_vulnerability, application_vulnerability. Then if a vulnerability has been dropped from an asset, I will delete the edges that has that assetId and the vulnid
    updates, deletes = updates_deletes(context, data, query)
    
    if updates:
        # this is an insert/update
        # if osid, vulnid, vulntypeid, assetid have changed

        # osid is taking care of by assetproperty, I'm not sure what use of the osid here, is it the same one in assetprorty?
        # vulnId, assetId
        value = ' in (%s)' % ','.join(updates)
        table = 'vulninstance'
        whereclause = get_where_clause(table, 'id', value)

        core.export_ip_vuln(context, whereclause)
        
        # TODO asset_vulnerability
        asset_vulnerabilityarray, os = core.export_asset_vulnerability(context, whereclause)
        
        # osid, asset_application
        # I have added is_os field to the asset_application edge in order to tell if the linked application is an os, I have added the field to the edge because it is faster and easier to filter to get the list of OSes for an asset 
        
        # UPDATE 
        # The asset model schema is messed up, the os is an application so there is direct relation between an asset and application (assetproductvariantexref), but also there is a relation between an asset and os tables, just to say that the application associated to the asset is an operating system. This information is taking care by the import_asset_application() function which, when importing the application it checks if the application is an os, if so it add the information to the edge asset_application (is_os = True)

        # application_vulnerability
        core.export_application_vuln(context, whereclause)
        # no need to update these collections: applicationarray, report_applicationarray because application should be already in arangodb (foreign key in asset.vulninstance table)
        
    if deletes:
        delete(context, 'ipaddress_vulnerability', deletes)
        delete(context, 'asset_vulnerability', deletes)
        delete(context, 'application_vulnerability', deletes)


# this is might be not necessary
#  vulnid             | bigint                      | not null
#  osvdbid            | bigint                      | 
#  osvdbtitle         | character varying(255)      | not null
#  osvdbcreatedate    | timestamp without time zone | 
#  lastmodifieddate   | timestamp without time zone | 
#  exploitpublishdate | timestamp without time zone | 
#  disclosuredate     | timestamp without time zone | 
#  discoverydate      | timestamp without time zone | 

def build_vuln_related_objects(context, data):
    #TODO this is a catalog table so I assume no delete should happen in this table, need to check after but for now I'm considering just the update/insert
    identifier = 'vulnid'
    value = ' in (' + ','.join(data) +') ' 
    whereclause = get_where_clause("vuln", identifier, value)
    core.export_vuln(context, whereclause)


def build_vulncvssbasemetrics_related_objects(context, data):
    # Commenting out this code since I have explained the main program why changes to this table should be ignored
    pass


def  build_assetstatistics_related_objects(context, data):
    # This table is only used in initial imports which compute the risk of the asset, 
    # in incremental updates, the risk will be computed in the ingestion service 

    # UPDATE: no need for this table anymore, since the risk will be always computed in arangodb side
    pass


def build_assetproperty_related_objects(context, data):
    query = "select id from asset.assetproperty where id in (%s)"
    updates, deletes = updates_deletes(context, data, query)

    if updates:
        value = ' in (%s)' % ','.join(updates)
        whereclause = get_where_clause('assetproperty', 'id', value)
        # asset 
        core.export_asset(context, whereclause)
    return deletes


def  build_user_related_objects(context, data):
    table = 'usr'
    query = "select id from asset.user where id in (%s)"
    updates, deletes = updates_deletes(context, data, query)

    if updates:
        value = ' in (%s)' % ','.join(updates)
        whereclause = get_where_clause(table, 'id', value)
        core.export_user(context, whereclause)
    if deletes:
        delete(context, 'user', deletes)
        delete(context, 'account', deletes)
        delete(context, 'user_account', deletes)
    return deletes


def build_hostname_related_objects(context, data):
    # hostname, if the update is about changing "hostname.hostname" then we need to make sure that arango knows that this is an update and not a new hostname object (the key in arango is hostname value)
    query = "select id from asset.hostname where id in (%s)"
    updates, deletes = updates_deletes(context, data, query)
    if updates:
        value = ' in (%s)' % ','.join(updates)
        whereclause = get_where_clause('hostname', 'id', value)
        core.export_hostname(context, whereclause)
    if deletes:
        delete(context, 'hostname', deletes)


def build_identitybyip_related_objects(context, data):
    # ipaddress_hostname, account_ipaddress, account_hostname
    # is it an update or a delete
    query = "select id from asset.identitybyip where id in (%s)"
    updates, deletes = updates_deletes(context, data, query)
    if updates:
        value = ' in (%s)' % ','.join(updates)
        whereclause = get_where_clause(None, 'id', value)
        isUpdate = False
        core.export_ip_hostname_user_rels(context, whereclause, isUpdate)
    if deletes:
        delete(context, 'ipaddress_hostname', deletes)
        delete(context, 'account_ipaddress', deletes)
        delete(context, 'account_hostname', deletes)


def build_assetproductvariantxref_related_objects(context, data):
    query = "select id from asset.assetproductvariantxref where id in (%s)"
    updates, deletes = updates_deletes(context, data, query)
    
    if updates:
        value = ' in (%s)' % ','.join(updates)
        whereclause = get_where_clause("assetproductvariantxref", 'id', value)
        core.export_asset_application(context, whereclause)
        core.export_application_port(context, whereclause)
    if deletes:
        delete(context, 'application', deletes)


def build_portassetproductvariantxrefxref_related_objects(context, data):
    query = "select id from asset.portassetproductvariantxrefxref where id in (%s)"
    updates, deletes = updates_deletes(context, data, query)
    if updates:
        value = ' in (%s)' % ','.join(updates)
        whereclause = get_where_clause("portassetproductvariantxrefxref", 'id', value)
        core.export_application_port(context, whereclause)
    if deletes:
        delete(context, 'application_port', deletes)


def build_port_related_objects(context, data):
    query = "select id from asset.port where id in (%s)"
    updates, deletes = updates_deletes(context, data, query)
    if updates:
        value = ' in (%s)' % ','.join(updates)
        whereclause = get_where_clause("port", 'id', value)
        core.export_port(context, whereclause)
        core.export_ip_port(context, whereclause)
        core.export_application_port(context, whereclause)
    if deletes:
        delete(context, 'port', deletes)


def build_assetproductvulnxref_related_objects(context, data):
    query = "select id from asset.assetproductvulnxref where id in (%s)"
    updates, deletes = updates_deletes(context, data, query)
    if updates:
        value = ' in (%s)' % ','.join(updates)
        whereclause = get_where_clause("assetproductvulnxref", 'id', value)
        core.export_application_vuln(context, whereclause)
    if deletes:
        delete(context, 'application_vulnerability', deletes)


def build_portlayer4protocolxref_related_objects(context, data):
    query = "select id from asset.portlayer4protocolxref where id in (%s)"
    updates, deletes = updates_deletes(context, data, query)
    if updates:
        value = ' in (%s)' % ','.join(updates)
        whereclause = get_where_clause("portlayer4protocolxref", 'id', value)
        core.export_port(context, whereclause)
    return deletes


def build_layer4protocol_related_objects(context, data):
    print('TODO')


def build_layer7applicationvariant_related_objects(context, data):
    query = "select id from q_catalog.layer7applicationvariant where id in (%s)"
    updates, deletes = updates_deletes(context, data, query)
    if updates:
        value = ' in (%s)' % ','.join(updates)
        whereclause = get_where_clause("layer7applicationvariant", 'id', value)
        core.export_port(context, whereclause)
    return deletes


def build_layer7application_related_objects(context, data):
    query = "select id from q_catalog.layer7application where id in (%s)"
    updates, deletes = updates_deletes(context, data, query)
    if updates:
        value = ' in (%s)' % ','.join(updates)
        whereclause = get_where_clause("layer7application", 'id', value)
        core.export_port(context, whereclause)
    return deletes


def build_extref_related_objects(context, data):
    query = "select extrefid from extref where extrefid in (%s)"
    updates, deletes = updates_deletes(context, data, query, "extrefid")
    if updates:
        identifier = 'extrefid'
        value = ' in (%s)' % ','.join(updates)
        whereclause = get_where_clause("extref", identifier, value)
        core.export_vuln(context, whereclause)
    if deletes:
        # No deletion should happen for now, only updates 
        pass


# TODO: This function is not used. Should be deleted?
def build_extreftype_related_objects(context, data):
    query = "select extreftypeid from extreftype where extreftypeid in (%s)"
    updates, deletes = updates_deletes(context, data, query, "extreftypeid")
    if updates:
        identifier = 'extreftypeid'
        value = ' in (%s)' % ','.join(updates)
        whereclause = get_where_clause("extreftype", identifier, value)
        core.export_vuln(context, whereclause)
    return deletes


def build_extrefvalue_related_objects(context, data):
    query = "select extrefvalueid from extrefvalue where extrefvalueid in (%s)"
    updates, deletes = updates_deletes(context, data, query, "extrefvalueid")
    if updates:
        identifier = 'extrefvalueid'
        value = ' in (%s)' % ','.join(updates)
        whereclause = get_where_clause("extrefvalue", identifier, value)
        core.export_vuln(context, whereclause)
    if deletes:
        # NO deletion should happen for now, only updates
        pass

    
# if table is any of: asset.ipaddress, asset.interface, asset.vulninstance, vuln, q_catalog.vulncvssbasemetrics, asset.assetstatistics, 
# asset.assetproperty, assetprop.assetpropertytypeid
# Run build ipadrressRelated()

# ####################### VARIABLE DECLARATION ################################
# TODO I have mentioned here what should be deleted by blindly report what qradar deletes but I think we shouldn't do this 
# to keep historically informations and to answer questions such as what is the hostname of this ip: x.x.x.x at this time zzz or on which port was it connected or which users connect to it at this time zzz, etc?

# ####################### END VARIABLE DECLARATION ################################
# all the functions calls below do the following:
# 1) update if the record in question is an update or insert
# 2) return the IDs if it is delete operation


# rep.q_catalog_vulncvssbasemetrics_activity:
# updates means the base_score might be modified, so need to update the new value in arango, more specefic update the base_score to the associated vulnerability
# vcbm_updates dict has this form: updates[obj['vulnid']] = obj['base_score']
# deletes means that a record has been deleted from vulncvssbasemetrics table which means that there were a vulnerability without defined base_score, update the base_score of the related vulnerability (which is unknown at this point, we will use the vulncvssbasemetricsid to do the deletion) to None
# TODO double confirm with brad and JK the following
# Talked to JK if the cvss base_score get ever updated and he said no, cvss base_score of a vulnerability is always the same. Howeve QradarVulnerabilityManager can decide that the vulnerability should have a different score value, in which case the score value will be on the edge and will override the base_score in the vulnerability vertex. I.E ignore changes to this table


# rep.asset_assetproperty_activity'
# deletes_assetprop are list of id of assetproperty table 
# delete of an assetproperty will result in deleting the business value, operating system, description of an ip or hostname collection using the assetpropertyid, that's why we saved the assetpropertyid in the collection as q_assetpropertyid
# TODO


# if table == 'rep.asset_physicaluser_activity'
# NO need for this, we care about user, not about the physical user


# if table == 'rep.asset_assetproductvariantxref_activity': 
# deletes_application are the list of assetproductvariantxref id which are the keys of the application collection


# if table == 'rep.asset_portassetproductvariantxrefxref_activity'): 
# deletes_application_port 


# if table == 'rep.asset_portlayer4protocolxref_activity':
# TODO not sure if this is needed ?????
# I commented out the code, need to discuss this with JK and brad before
# deletes_portlayer4protocolxref = build_portlayer4protocolxref_related_objects(context, updates[table], table)


# if table == 'rep.asset_layer4protocol': 
# this table does not get replicated


# if table == 'rep.q_catalog_layer7applicationvariant_activity':
# TODO not sure if this is needed ?????
# I commented out the code, need to discuss this with JK and brad before 
# deletes_layer7applicationvariant = build_layer7applicationvariant_related_objects(context, updates[table], table) 


# if table == 'rep.public_extref_activity') and len(updates[table]) > 0: 
# TODO since a master database will be created and hold a common vuln db for all accounts, more works needs to be done here


# if table == 'rep.public_extreftype_activity': 
# TODO extreftype is a catalog table that contains the diffrent sources of the vulnerability, no need to do anything if the table changed


# if table == 'rep.public_extrefvalue_activity': 
# TODO since a master database will be created and hold a common vuln db for all accounts, more works needs to be done here
    
    
table_handlers = {
    'asset_asset_activity': build_asset_related_objects,                        'asset_ipaddress_activity': build_ip_related_objects,                   'asset_interface_activity': build_interface_related_objects,
    'asset_vulninstance_activity': build_vulninstance_related_objects,          'vuln_activity': build_vuln_related_objects,                            'q_catalog_vulncvssbasemetrics_activity': None,
    'asset_assetstatistics_activity': build_assetstatistics_related_objects,    'asset_assetproperty_activity': build_assetproperty_related_objects,    'asset_user_activity': build_user_related_objects,
    'asset_hostname_activity': build_hostname_related_objects,                  'asset_identitybyip_activity': build_identitybyip_related_objects,      'asset_assetproductvariantxref_activity': build_assetproductvariantxref_related_objects,
    'asset_portlayer4protocolxref_activity': None,                              'q_catalog_layer7applicationvariant_activity': None,                    'q_catalog_layer7application_activity': None,
    'public_extref_activity': build_extref_related_objects,                     'public_extreftype_activity': None,                                     'public_extrefvalue_activity': build_extrefvalue_related_objects,
    'asset_portassetproductvariantxrefxref_activity': build_portassetproductvariantxrefxref_related_objects, 'asset_port_activity': build_port_related_objects, 'asset_assetproductvulnxref_activity': build_assetproductvulnxref_related_objects,
    'q_catalog_vulncvssbasemetrics_activity': None,
    }


def build_assets(context, updates):
    for table in updates:
        data = updates[table]
        handler = table_handlers.get(table.replace('rep.', ''))
        if data and handler:
            context.logger.info('Changes detected in table ' + table.replace('rep.', '').replace('_activity', ''))
            handler(context, data)
    

def run_incremental_export(context):
    try:
        logger = context.logger
        context.queue.push(Command.new('WAIT')) # wait first to avoid race conditions

        # before building all the necessary objects, remember the rep_next_trans value which will be used when calling incremental updates
        context.tracker.set_next_baseline()
        
        # source, report, source_report
        core.export_source_report(context)
        updates = context.tracker.get_updates(map(lambda s: 'rep.' + s, table_handlers.keys()))
        logger.debug('printing updates: ')
        logger.debug(updates)
        
        # loop through the dictionary and build the objects
        build_assets(context, updates)

        # call the ingestion service and start exporting assets to the cloud
        context.import_saved_data()

        # save the new config in the very end
        context.tracker.persist()

        ApplicationStatus(context.logger).set_status(EXPORTER, 'OK')

    except Exception as e:
        logger.error('Unexpected error occured while running incremental update')
        traceback.print_exc()
        logger.exception(e)
