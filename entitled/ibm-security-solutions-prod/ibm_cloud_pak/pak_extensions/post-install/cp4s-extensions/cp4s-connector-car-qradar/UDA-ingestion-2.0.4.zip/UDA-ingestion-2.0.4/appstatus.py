from os.path import join, dirname, realpath
from datetime import datetime
from flock import Lock

FILENAME = '___STATUS___'
LOCK = 'status.lock'

IMPORTER = 'Importer'
EXPORTER = 'Exporter'

ORDER = {EXPORTER : 1, IMPORTER : 2}

ERROR = 'Error'

class ApplicationStatus(object):


    def __init__(self, logger):
        self.logger = logger
        self.fpath = join(dirname(realpath(__file__)), FILENAME)


    def get_status(self, entity):
        with Lock(LOCK, blocking = True) as lock:
            self._parse()
            parts = self.contents.get(entity)
            if not parts:
                return None
            return self._parse_status(parts[1])[1]

    
    def set_status(self, entity, status, details=None):
        self.logger.info('Setting status: %s: %s, Details: %s' % (entity, status, details))
        with Lock(LOCK, blocking = True) as lock:
            self._parse()
            self.contents[entity] = [datetime.now().strftime("%m/%d/%Y - %H:%M:%S"), '%s: %s' % (entity, status)]
            if details:
                self.contents[entity].append('Details: %s' % details)

            with open(self.fpath, 'w') as f:
                for entity in sorted(self.contents.keys(), key = lambda entity: ORDER.get(entity)):
                    parts = self.contents[entity]
                    f.write(', '.join(parts) + '\n')


    def _parse_status(self, status):
        return map(lambda s: s.strip(), status.split(':'))
    

    def _parse(self):
        self.contents = {}
        try:
            with open(self.fpath) as f:
                for line in f.readlines():
                    try:
                        parts = map(lambda s: s.strip(), line.split(','))
                        entity, status = self._parse_status(parts[1])
                        self.contents[entity] = parts
                    except:
                        pass
        except:
            pass
