import argparse
import time
import math
import full_export
import inc_export
import os, sys, traceback
from context import Context
from util import get_logger, measure_time, generate_apikey, RecoverableFailure, UnrecoverableFailure, run_command
from flock import Lock
from import_processor import ImportProcessor
from appstatus import ApplicationStatus, IMPORTER, EXPORTER, ERROR
import crontab

exporter_version = '1.0.9'

# This is for remote debugging in VSCode
# import ptvsd
# ptvsd.enable_attach()
# ptvsd.wait_for_attach()

def run_exporter(context):
    try:
        with Lock('exporter.lock', blocking = False) as lock:
            if not lock.locked:
                context.logger.info('Another exporter instance is detected. Exiting ...')
                return

            db_status = measure_time(context.logger, 'checking the database status +- creating database', context.microservice.get_db_status)
            if db_status == context.microservice.DB_FAILURE:
                context.logger.error('database is not healthy, exiting the process ...')
                return

            # if we are forced to run full import do so

            if db_status == context.microservice.DB_NEW:
                context.logger.info('New database detected. Running full import ...')
                full_export.run_full_export(context)
                return

            if int(context.config.get_value('rep_next_trans')) == 0:
                context.logger.info('Full import was never performed. Running full import ...')
                full_export.run_full_export(context)
                return

            if ApplicationStatus(context.logger).get_status(IMPORTER) == ERROR:
                context.logger.info('Importer has failed. Recovering by running full import ...')
                full_export.run_full_export(context)
                return

            if context.tracker.is_full_import_required():
                context.logger.info('Update tracker requests full import. Running full import ...')
                full_export.run_full_export(context)
                return

            context.logger.info('Running incremental import ...')
            inc_export.run_incremental_export(context)

    except RecoverableFailure as e:
        ApplicationStatus(context.logger).set_status(EXPORTER, 'Recovering', e.message)

    except UnrecoverableFailure as e:
        ApplicationStatus(context.logger).set_status(EXPORTER, ERROR, e.message)

    except Exception as e:
        context.logger.error('Unexpected error occured: ' + str(e))
        traceback.print_exc()
        context.logger.exception(e)
        ApplicationStatus(context.logger).set_status(EXPORTER, ERROR, str(e))


def run_importer(context):
    context.logger.info('Running importer ...')
    try:
        with Lock('importer.lock', blocking = False) as lock:
            if not lock.locked:
                context.logger.info('Another importer instance is detected. Exiting ...')
                return

            db_status = measure_time(context.logger, 'checking the database status +- creating database', context.microservice.get_db_status)
            if db_status == context.microservice.DB_FAILURE:
                context.logger.error('database is not healthy, exiting ...')
                return

            ApplicationStatus(context.logger).set_status(IMPORTER, 'Working')
            ImportProcessor(context).process()
            ApplicationStatus(context.logger).set_status(IMPORTER, 'OK')

    except RecoverableFailure as e:
        ApplicationStatus(context.logger).set_status(IMPORTER, 'Recovering', e.message)

    except UnrecoverableFailure as e:
        ApplicationStatus(context.logger).set_status(IMPORTER, ERROR, e.message)

    except Exception as e:
        context.logger.error('Unexpected error occured: ' + str(e))
        traceback.print_exc()
        context.logger.exception(e)
        ApplicationStatus(context.logger).set_status(IMPORTER, ERROR, str(e))


def main():
    try:
        parser = argparse.ArgumentParser(description='script used to extract assets from Qradar and send it to the ingestion microservice', version=exporter_version)
        parser.add_argument('-pass', dest='password', type=str, required=True, help='pass')
        parser.add_argument('-key', dest='key', type=str, required=True, help='key')
        parser.add_argument('-database', dest='database', type=str, required=False, help='database')
        parser.add_argument('-dbuser', dest='dbuser', type=str, required=False, help='database user')
        parser.add_argument('-dbpassword', dest='dbpassword', type=str, required=False, help='database password')
        parser.add_argument('-url', dest='url', type=str, required=True, help='The url of the ingestion service')
        parser.add_argument('-u', dest='update', type=str, required=False, help='This option is obsolete')
        parser.add_argument('-d', dest='debug', action='store_true', help='Enables DEBUG level logging')

        # hidden options
        parser.add_argument('-working_dir', dest='working_dir', type=str, required=False, help=argparse.SUPPRESS)
        parser.add_argument('-dbhost', dest='dbhost', type=str, required=False, help=argparse.SUPPRESS)
        parser.add_argument('-version', dest='version', type=str, required=False, help=argparse.SUPPRESS)
        parser.add_argument('-source', dest='source', type=str, required=False, help=argparse.SUPPRESS)
        parser.add_argument('-source_name', dest='source_name', type=str, required=False, help=argparse.SUPPRESS)
        parser.add_argument('-cron', dest='cron', action='store_true', required=False, help=argparse.SUPPRESS)

        args = parser.parse_args()

        working_dir = args.working_dir or os.path.dirname(os.path.realpath(__file__))
        if not os.path.exists(working_dir):
            os.makedirs(working_dir)

        logger = get_logger(working_dir)
        
        password = args.password
        key = args.key
        database = args.database
        dbhost = args.dbhost
        dbuser = args.dbuser
        dbpassword = args.dbpassword
        url = args.url

        version = args.version
        if not version:
            # Get the console version
            cmd = '/opt/qradar/bin/myver'
            rc, out, err = run_command(logger, cmd)
            if rc != 0:
                logger.error("Could not determine system version return code ({0})".format(rc))
                version = '7.3.1'
            version = out.rstrip()
            logger.info('Qradar version is {}'.format(version))

        source = args.source
        if not source:
            cmd = 'cat /etc/machine-id'
            rc, out, err = run_command(logger, cmd)
            if rc != 0:
                logger.error("Could not determine system id return code ({0})".format(rc))
            source = out.rstrip()
            logger.info('source is: {}'.format(source))

        source_name = args.source_name
        if not source_name:
            cmd = 'hostname'
            rc, out, err = run_command(logger, cmd)
            if rc != 0:
                logger.error("Could not determine system hostname return code ({0})".format(rc))
            source_name = out.rstrip()
            logger.info('source_name is: {}'.format(source_name))

        try:
            apikey = generate_apikey(key, password)
            context = Context(working_dir, logger, url, apikey, version, exporter_version, source, source_name, database, dbuser, dbpassword, dbhost=dbhost)

            run_exporter(context)
            run_importer(context)

            # if we have a successful import session then arguments are sane and we can use them for crontab job
            crontab.add_job(args, context)
        finally:
            for action in context.cleanup_actions:
                action()

    except Exception as e:
        logger.error('Unexpected error occured: ' + str(e))
        traceback.print_exc()
        logger.exception(e)


if __name__ == '__main__':
    main()
