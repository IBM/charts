import requests
from requests.exceptions import ConnectionError, ConnectTimeout
from util import get_json

class EmulatedResponse(object):
    def __init__(self, sc, data):
        self.status_code = sc
        self.data = data

    def json(self):
        return self.data


class Communicator(object):
    def __init__(self, logger, headers):
        self.logger = logger
        self.headers = headers

    def send_request(self, req, func, url, **args):
        try:
            resp = func(url, verify=False, headers=self.headers, **args)
            self.logger.debug('%s %s, status code: %d, response data: %s' % (req, url, resp.status_code, get_json(resp)))
            if resp.status_code != 200:
                self.logger.warn('%s %s, status code: %d, response data: %s' % (req, url, resp.status_code, get_json(resp)))
            return resp
        except (ConnectionError, ConnectTimeout) as e:
            self.logger.error('Error while sending %s request: %s' % (req, str(e)))
            return EmulatedResponse(503, {'error' : str(e)})
    
    def send_post_request(self, url, **args):
        return self.send_request('POST', requests.post, url, **args)

    def send_get_request(self, url, **args):
        return self.send_request('GET', requests.get, url, **args)

    def send_patch_request(self, url, **args):
        return self.send_request('PATCH', requests.patch, url, **args)

    def send_delete_request(self, url, **args):
        return self.send_request('DELETE', requests.delete, url, **args)
