import datetime, tarfile, os, codecs, sys, requests
from re import search
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
from util import delete_file, run_command
from distutils.version import LooseVersion


class AssetModelUpdateTracker(object):


    def __init__(self, context):
        self.context = context
        self.next_baseline_Tx = None
        self.last_handled_Tx = int(self.context.config.get_value('rep_next_trans')) - 1


    def _get_rep_next_trans_from_db(self):
        rep_next_trans_from_db = 0
        with self.context.execute("select key, value from replication_info where key = 'rep_next_trans'") as cursor:
            for obj in cursor:
                return int(obj['value'])


    # A better way of knowing if incremental TXs are available is directly checking the TX files in /store/replication.
    # But when we switch to '2 processes' architecture we should be able to easily keep up with updates so leaving this method in place is not a big deal.
    def _is_in_timewindow(self):
        rep_next_trans_from_db = self._get_rep_next_trans_from_db()
        # multiply by 60 to get the time in seconds
        delta = (rep_next_trans_from_db - self.last_handled_Tx) * 60
        self.context.logger.debug('time delta = %s' % delta)
        with self.context.execute("select key, override_value from nva_conf where id = 37") as cursor:
            for obj in cursor:
                self.context.logger.debug('TX files retention time = %s'  % obj['override_value'])
                if delta < int(obj['override_value']):
                    return True
        return False


    def _get_sec(self):
        with open('/opt/qradar/conf/host.token', 'r') as f:
            return f.readline()
    
    def _get_replication_file(self, replicationurl):
        logger = self.context.logger
        # 7.3.3 FP2 is 2019.14.2 in new versioning
        SEC_TOKEN_ENCRYPT_VERSION = '2019.14.2'
        # As of Qradar 7.3.3 FP2, the SEC token is encrypted, so we need to check the Qradar version in order to know if the SEC is encrypted/decrypted
        # Also versioning in Qradar has been changed in 7.3.3
        sec = token = self._get_sec()
        if LooseVersion(self.context.version) >= SEC_TOKEN_ENCRYPT_VERSION:
            cmd = "java -jar /opt/qradar/jars/ibm-si-mks.jar decrypt {}".format(sec)
            rc, token, err = run_command(logger, cmd)
        headers = {'SEC': token.strip()}
        local_filename = 'assets-replication-' + str(datetime.datetime.now()).replace(' ', '-').replace(':', '-') + '.tgz'
        logger.debug('downloading the replication file')
        r = requests.get(replicationurl, headers=headers, verify=False)
        logger.debug(r.status_code)
        
        if 'content-type' in r.headers:
            path = os.path.join(self.context.updates_dir, local_filename)
            self.context.cleanup_actions.append(lambda: delete_file(self.context.logger, path))
            with open(path, 'wb') as f:
                f.write(r.content)

            # extract from tar in "working dir"
            dir = os.getcwd()
            try:
                os.chdir(self.context.updates_dir)
                with tarfile.open(local_filename) as tar:
                    tar.extractall()
                    for tarinfo in tar:
                        return os.path.join(self.context.updates_dir, tarinfo.name)
            finally:
                os.chdir(dir)
        else:
            return None
        

    def set_next_baseline(self):
        self.next_baseline_Tx = self._get_rep_next_trans_from_db()


    def is_full_import_required(self):
        return not self._is_in_timewindow()


    def persist(self):
        self.context.config.set_value('rep_next_trans', self.next_baseline_Tx)


    # from the downloaded replication file, extract the assets tables with its data and write it to a dictionary  
    def get_updates(self, table_list):
        host = 'ISC-CAR-Asset-Exporter'
        # we use different version every time to avoid 'getting in the corner'. See ReplicationHostTracker.update logic related to 'timeout' for details (in QRadar code base)
        version = str(datetime.datetime.now()).replace(' ', '-').replace(':', '-')

        # call the replication to get an sql file containing the data since last TX we handled
        replicationurl = 'https://127.0.0.1/console/replicationData?lastTxID=%d&host=%s&version=%s' % (self.last_handled_Tx, host, version)
        self.context.logger.debug('replicationurl: ' + replicationurl)
        
        # replication file
        sql_file = self._get_replication_file(replicationurl)
        if sql_file:
            self.context.cleanup_actions.append(lambda: delete_file(self.context.logger, sql_file))
            return self.parse_replication_file(sql_file, table_list)
        else:
            return []


    def parse_replication_file(self, sql_file, table_list):
        start_copy = False
        # Use dict where the key is the table name and the values are the ids that has been changed in the interesting tables
        updates = {}
        key = None
        with codecs.open(sql_file, "r", encoding="utf-8") as infile:
            for line in infile:
                if (not start_copy) and search('^COPY', line) and table_list:
                    for table in table_list:
                        key = table.strip()
                        if search(''.join(['^COPY ', key, ' ']), line):
                            start_copy = True
                            if key not in updates:
                                updates[key] = set()
                            break
                elif start_copy and search('^\\\.', line):
                    start_copy = False
                elif start_copy:
                    updates[key].add(line.strip())

        return updates
