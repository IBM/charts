import os

HOST = 'gleb-isc1.fyre.ibm.com'
USER = 'qradar' # The user must be 'qradar'
PASSWORD = 'qradar.1'

def psql(command, db):
    os.system('PGPASSWORD="%s" psql -h %s -U %s -d %s -c "%s"' % (PASSWORD, HOST, USER, db, command))

def create_user(user, db):
    psql('CREATE USER %s WITH PASSWORD \'qradar.1\';' % user, db)
    psql('ALTER USER %s WITH SUPERUSER;' % user, db)
    psql('GRANT ALL PRIVILEGES ON DATABASE %s to %s;' % (db, user), db)

def create_db(db, zip, contents):
    try:
        psql('DROP DATABASE IF EXISTS %s;' % db, 'postgres')
        os.system('PGPASSWORD="%s" createdb -h %s -U %s %s' % (PASSWORD, HOST, USER, db))
        create_user('qvmuser', db)
        create_user('vis', db)
        os.system('wget gleb-isc1.fyre.ibm.com/assets/' + zip)
        os.system('unzip ' + zip)
        os.system('psql -U %s %s < %s > /dev/null' % (USER, db, contents))
    finally:
        if os.path.exists(zip):
            os.remove(zip)
        if os.path.exists(contents):
            os.remove(contents)

create_db('qradar_731_scan_121_assets', '731-scan-121.zip', '731-scan-121.pgsql')
create_db('qradar_731_scan_modified_121_assets', '121-scan-modified.zip', '121-scan-modified.pgsql')
create_db('qradar_731_gen_500_assets', '731-gen-500.zip', '731-gen-500.pgsql')
create_db('qradar_731_gen_5000_assets', '731-gen-5000.zip', '731-gen-5000.pgsql')
create_db('qradar_731_gen_20000_assets', '731-gen-20000.zip', '731-gen-20000.pgsql')
create_db('qradar_731_gen_50000_assets', '731-gen-50000.zip', '731-gen-50000.pgsql')
