#!/bin/bash

openssl req -x509 -nodes -days 365 -newkey rsa:2048 -keyout ./oc.key -out ./oc.crt -subj "/CN=cpq.oc.ext.ibm.com.apps.blurs.os.fyre.ibm.com/O=cpq.oc.ext.ibm.com.apps.blurs.os.fyre.ibm.com"
