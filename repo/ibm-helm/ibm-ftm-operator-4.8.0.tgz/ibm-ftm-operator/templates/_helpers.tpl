{{/*
Expand the name of the chart.
*/}}
{{- define "ibm-ftm-operator.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "ibm-ftm-operator.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "ibm-ftm-operator.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "ibm-ftm-operator.labels" -}}
helm.sh/chart: {{ include "ibm-ftm-operator.chart" . }}
{{ include "ibm-ftm-operator.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "ibm-ftm-operator.selectorLabels" -}}
app.kubernetes.io/name: {{ include "ibm-ftm-operator.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "ibm-ftm-operator.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "ibm-ftm-operator.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

# image: "{{ .Values.operator.deployment.repository }}/{{ .Values.operator.deployment.image }}@{{ .Values.operator.deployment.sha }}"
{{/*
ibm-ftm.image
Return the ibm-ftm operator image
*/}}
{{- define "ibm-ftm.image" -}}
{{- if .Values.operator.deployment.sha -}}
{{ .Values.operator.deployment.repository }}/{{ .Values.operator.deployment.image }}@{{ .Values.operator.deployment.sha }}
{{- else if .Values.operator.deployment.tag -}}
{{ .Values.operator.deployment.repository }}/{{ .Values.operator.deployment.image }}:{{ .Values.operator.deployment.tag }}
{{- end -}}
{{- end -}}