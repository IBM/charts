#!/bin/bash

#
# Generate list of images used by DevOps Loop.  For each image, skopeo copy
# the image to the destination image registry.
#

# Process args
usage() {
    printf "Usage: $0 -r HELM_CHART_ROOT_DIR -d DEST_REGISTRY_SPEC [ -s SRC_REGISTRY_SPEC] [-h] [-l] [-y] [-x save|load] [-c SKOPEO_COPY_ARGS]\n" 1>&2
    echo "When running this script, the following is assumed."
    echo "1) The DevOps Loop helm chart has been downloaded and expanded.  The -r option specifies the directory path to the chart directory."
    echo "2) You have successfully run 'skopeo login...' to the source and destination image registries."
    printf "\nWhen specifying '-x save', the -d argument is directory to write save dirs to."
    echo "When specifying '-x load', the -s argument is directory holding save dirs, and is required."
}

while getopts "r:d:s:c:x:hly" opt; do
    case "${opt}" in
        r)
            ROOT_DIR=${OPTARG}
            ;;
        d)
            DEST_REGISTRY=${OPTARG}
            ;;
        s)
            SRC_REGISTRY=${OPTARG}
            ;;
        c)
            SKOPEO_COPY_ARGS=${OPTARG}
            ;;
        l)
            LIST_FILES=true
            ;;
        x)
            SAVE_LOAD_ARG=$(echo ${OPTARG} | tr '[:upper:]' '[:lower:]')
            ;;
        y)
            ASSUME_YES=true
            ;;
        h)
            usage
            exit 0
            ;;
        *)
            usage
            exit 1
            ;;
    esac
done
shift $((OPTIND-1))

if [ -z "${ROOT_DIR}" ] || [ -z "${DEST_REGISTRY}" ] || [ $# -gt 0 ]
then
    usage
    exit 1
fi

if [ "${SAVE_LOAD_ARG}" ] && [ "${SAVE_LOAD_ARG}" != "save" ] && [ "${SAVE_LOAD_ARG}" != "load" ]
then
    usage
    exit 1
fi

#
# Default args for 'skopeo copy...' command.
# We only want the amd64/linux images by default
SKOPEO_COPY_ARGS="${SKOPEO_COPY_ARGS} --override-arch amd64 --override-os linux"

#
# Set the source image registry by looking at the helm chart name
CHART_NAME=$(basename "${ROOT_DIR}")
if [[ "${CHART_NAME}" == "ibm-devops-loop" ]]
then
    SRC_REGISTRY="${SRC_REGISTRY:-cp.icr.io/cp}"
elif [[ "${CHART_NAME}" == "hcl-devops-loop" ]]
then
    SRC_REGISTRY="${SRC_REGISTRY:-hclcr.io}"
else
    echo "Invalid ROOT_DIR: ${ROOT_DIR}"
    exit 1
fi

# Values needed to successfully run 'helm template...' below
DOMAIN=loop.example.com
PASSWORD_SEED=random

HELM_OPTIONS="${HELM_OPTIONS:-} \
--set global.domain=${DOMAIN} \
--set-literal global.passwordSeed=${PASSWORD_SEED} \
--set license=true \
--set harbor.runningAirgapScript=true \
--set harbor.enabled=false \
--set harbor.externalURL=https://harbor.${DOMAIN} \
--set harbor.serviceAccountName=harbor
"

# To successfully run the Loop helm install with Harbor enabled,
# and pull images from the airgap repo, customers will need to set the
# following helm values.
#
# Assuming global.externalImageRegistry=airgapregistry.com/devops-loop
#
# --set harbor.nginx.image.repository=airgapregistry.com/devops-loop/nginx-photon
# --set harbor.portal.image.repository=airgapregistry.com/devops-loop/harbor-portal
# --set harbor.core.image.repository=airgapregistry.com/devops-loop/harbor-core
# --set harbor.jobservice.image.repository=airgapregistry.com/devops-loop/harbor-jobservice
# --set harbor.registry.registry.image.repository=airgapregistry.com/devops-loop/registry-photon
# --set harbor.registry.controller.image.repository=airgapregistry.com/devops-loop/harbor-registryctl
# --set harbor.trivy.image.repository=airgapregistry.com/devops-loop/trivy-adapter-photon
# --set harbor.exporter.image.repository=airgapregistry.com/devops-loop/harbor-exporter
# --set harbor.database.internal.image.repository=airgapregistry.com/devops-loop/harbor-db
#
# --set harbor.imagePullSecrets[0].name=secretName
# --set harbor.expose.tls.certSource=secret
# --set harbor.expose.tls.secret.secretName=secretName

# We only want to set global.imageRegistry if a SRC_REGISTRY other than the
# default values are specified.
if [ "${SRC_REGISTRY}" != "cp.icr.io/cp" ] && [ "${SRC_REGISTRY}" != "hclcr.io" ]
then
    HELM_OPTIONS="${HELM_OPTIONS} --set global.imageRegistry=${SRC_REGISTRY}"
fi

# Get a list of all images listed in template files
# Sort and remove non-unique image lines
# Remove any lines that begin with a comment (#)
# Remove any comments from within a line to the end of the line
# Remove the leading image: from the line
# Remove any leading and trailing quotes
# Remove any leading whitespace characters
getLoopImageList() {

    # Put awk program in a file so it can be referenced below.
    AWK_FILE=/tmp/listImages$$.awk
    cat >${AWK_FILE} <<-'EOF'
#
# Search for lines that include 'image:'. Some will have the image name
# on the next line, so we need to handle that.
#
/image:/ {
    if ($NF == "image:") {
        getline nextLine
        print $0 nextLine
    }
    else {
        print $0
    }
}
EOF

    TEMPLATE_FILE=/tmp/template$$.out
    helm template airgaptest ${ROOT_DIR} ${HELM_OPTIONS} | tee ${TEMPLATE_FILE} | awk -f ${AWK_FILE} | grep -v '^[ \t]*#' | grep -v '#.*$' | sed -e 's/^.*image://' -e "s/^[ \t]*'//" -e "s/'[ \t]*$//" -e 's/^[ \t]*"//' -e 's/"[ \t]*$//' -e 's/^[ \t]*//' | sort -u -b

    # Add Loop, Velocity plugin and Code images not referenced in the rendered yamls.
    # Since the images are different between IBM and HCL versions
    # we need to determine which product version we are dealing with.
    if [[ "${CHART_NAME}" == "ibm-devops-loop" ]]
    then
        # Learning loop backend application image
        BACKENDAPP_IMAGE=$(grep "image: ibm-devops-loop-learning-app-backend" ${ROOT_DIR}/values.yaml | sed -e 's/^.*image://' -e 's/^[ \t]*//' -e 's/[ \t]*$//' )
        echo "${SRC_REGISTRY}/${BACKENDAPP_IMAGE}"

        # Velocity plugin images
        grep "urbancode/ucv-ext-compass:" ${ROOT_DIR}/values.yaml | sed -e 's/^.*image://' -e 's/^[ \t]*//' -e 's/[ \t]*$//'
        grep "urbancode/ucv-ext-control:" ${ROOT_DIR}/values.yaml | sed -e 's/^.*image://' -e 's/^[ \t]*//' -e 's/[ \t]*$//'
        grep "urbancode/ucv-ext-onetest-server:" ${ROOT_DIR}/values.yaml | sed -e 's/^.*image://' -e 's/^[ \t]*//' -e 's/[ \t]*$//'
        grep "urbancode/ucv-ext-ucd:" ${ROOT_DIR}/values.yaml | sed -e 's/^.*image://' -e 's/^[ \t]*//' -e 's/[ \t]*$//'
        grep "urbancode/ucv-ext-build:" ${ROOT_DIR}/values.yaml | sed -e 's/^.*image://' -e 's/^[ \t]*//' -e 's/[ \t]*$//'
        grep "urbancode/ucv-ext-yaml-executor:" ${ROOT_DIR}/values.yaml | sed -e 's/^.*image://' -e 's/^[ \t]*//' -e 's/[ \t]*$//'
        grep "urbancode/ucv-ext-handlebars-reporter:" ${ROOT_DIR}/values.yaml | sed -e 's/^.*image://' -e 's/^[ \t]*//' -e 's/[ \t]*$//'

        # Code image(s).  These tags will need to be updated each release.
        echo "${SRC_REGISTRY}/ibm-devops-automation-code-minimal:2.0.201"
        echo "${SRC_REGISTRY}/ibm-devops-automation-code-copilot:2.0.201"
        echo "${SRC_REGISTRY}/ibm-devops-automation-trivy:1.0.9"
    else
        grep "hclcr.io/accelerate/ucv-ext-compass:" ${ROOT_DIR}/values.yaml | sed -e 's/^.*image://' -e 's/^[ \t]*//' -e 's/[ \t]*$//'
        grep "hclcr.io/accelerate/ucv-ext-control:" ${ROOT_DIR}/values.yaml | sed -e 's/^.*image://' -e 's/^[ \t]*//' -e 's/[ \t]*$//'
        grep "hclcr.io/accelerate/ucv-ext-onetest-server:" ${ROOT_DIR}/values.yaml | sed -e 's/^.*image://' -e 's/^[ \t]*//' -e 's/[ \t]*$//'
        grep "hclcr.io/accelerate/ucv-ext-launch:" ${ROOT_DIR}/values.yaml | sed -e 's/^.*image://' -e 's/^[ \t]*//' -e 's/[ \t]*$//'
        grep "hclcr.io/accelerate/ucv-ext-build:" ${ROOT_DIR}/values.yaml | sed -e 's/^.*image://' -e 's/^[ \t]*//' -e 's/[ \t]*$//'
        grep "hclcr.io/accelerate/ucv-ext-yaml-executor:" ${ROOT_DIR}/values.yaml | sed -e 's/^.*image://' -e 's/^[ \t]*//' -e 's/[ \t]*$//'
        grep "hclcr.io/accelerate/ucv-ext-handlebars-reporter:" ${ROOT_DIR}/values.yaml | sed -e 's/^.*image://' -e 's/^[ \t]*//' -e 's/[ \t]*$//'

        # Learning loop backend and Code image(s).  These tags will need to be updated each release.
        if [ "${SRC_REGISTRY}" = "hclcr.io" ]
        then
            BACKENDAPP_IMAGE=$(grep "image: hcl-devops-loop-learning-app-backend" ${ROOT_DIR}/values.yaml | sed -e 's/^.*image://' -e 's/^[ \t]*//' -e 's/[ \t]*$//' )
            echo "${SRC_REGISTRY}/devops-automation/${BACKENDAPP_IMAGE}"

            echo "${SRC_REGISTRY}/devops-automation/hcl-devops-automation-code-minimal:2.0.201"
            echo "${SRC_REGISTRY}/devops-automation/hcl-devops-automation-code-copilot:2.0.201"
            echo "${SRC_REGISTRY}/devops-automation/hcl-devops-automation-trivy:1.0.9"
        else
            BACKENDAPP_IMAGE=$(grep "image: hcl-devops-loop-learning-app-backend" ${ROOT_DIR}/values.yaml | sed -e 's/^.*image://' -e 's/^[ \t]*//' -e 's/[ \t]*$//' )
            echo "${SRC_REGISTRY}/${BACKENDAPP_IMAGE}"

            echo "${SRC_REGISTRY}/hcl-devops-automation-code-minimal:2.0.201"
            echo "${SRC_REGISTRY}/hcl-devops-automation-code-copilot:2.0.201"
            echo "${SRC_REGISTRY}/hcl-devops-automation-trivy:1.0.9"
        fi
    fi

    # Add the Mongodb server image to the list since it's not part of the
    # DevOps Loop helm chart.
    echo "docker.io/bitnamilegacy/mongodb:6.0"

    # These DevOps Code images are the same for IBM and HCL
    echo "docker.io/alpine:3"
    echo "baravich/devcontainer-bob:2.0.200"
    echo "baravich/devcontainer-cpp:2.0.200"
    echo "baravich/devcontainer-java:2.0.200"
    echo "baravich/devcontainer-node:2.0.200"
    echo "baravich/devcontainer-python:2.0.200"
    echo "baravich/devcontainer-rtcpp:2.0.200"
    echo "baravich/devcontainer-watsonx:2.0.200"

    # Cleanup
    rm -f ${AWK_FILE} ${TEMPLATE_FILE}
}

# Given an image specification that includes a digest value, output a string
# that has the same image name, but uses a tag with the first 12 chars of the
# digest value instead.
digest2tag() {
    local imageSpec=$1
    local delimiter="@sha256:"
    local temp_text="${imageSpec//$delimiter/@}" # Replace @sha256: with @
    local imageName=""
    local digest=""

    IFS='@' read -r imageName digest <<< "${temp_text}"
    echo "${imageName}:sha256-${digest:0:12}"
}

IMAGES_WITH_FAILURES=/tmp/failedImages.$$

# Create $HOME/.config/containers/registries.d directory if it doesn't
# already exist.  This directory is needed to allow skopeo to process any
# image signatures it might encounter while copying images.  If this directory
# doesn't exist, skopeo will attempt to update /etc/containers/registries.d
# which will likely fail if this script is run by a non-root user.
mkdir -p $HOME/.config/containers/registries.d

# If we are in a save/load case, we need to check if the destination or
# source directory exists.
if [ "${SAVE_LOAD_ARG}" = "save" ] && [ ! -d ${DEST_REGISTRY} ]
then
    if [ "${ASSUME_YES}" = "true" ]
    then
        echo "Directory ${DEST_REGISTRY} does not exist. Creating because -y was specified."
    else
        read -p "Directory ${DEST_REGISTRY} does not exist. Create? (y/n): " -n 1 -r
        echo
        if [[ ! ${REPLY} =~ ^[Yy]$ ]]; then
            echo "Directory to hold image saves does not exist, exiting."
            exit 1
        fi
    fi
    mkdir -p ${DEST_REGISTRY}
elif [ "${SAVE_LOAD_ARG}" = "load" ] && [ ! -d "${SRC_REGISTRY}" ]
then
    echo "Directory ${SRC_REGISTRY} does not exist. Exiting."
    exit 1
fi

# If loading images from the filesystem, we use the directory names in the
# source directory.  Otherwise we need the list of images from the helm chart
if [ "${SAVE_LOAD_ARG}" = "load" ]
then
    ABSOLUTE_SRC_PATH=$(cd -- "${SRC_REGISTRY}" && pwd)
    for dir in "${ABSOLUTE_SRC_PATH}"/*/
    do
        if [ -d "${dir}" ]
        then
            echo "Loading image from ${dir}"

            # If the image is specified with a digest, copy it using a tag.
            # We will still be able to reference it using the digest value.
            # This is required when copying to image registries like the
            # internal OpenShift image registry.
            image="$(basename ${dir})"
            if [[ "${image}" =~ "sha256:" ]]
            then
                image="$(digest2tag $image)"
            fi
            skopeo copy ${SKOPEO_COPY_ARGS} dir:/${dir} docker://${DEST_REGISTRY}/${image}
            if [ $? -ne 0 ]
            then
                echo ${dir} >> ${IMAGES_WITH_FAILURES}
            fi
        fi
    done
else
    getLoopImageList | while read imageName
    do
        if [ -n "${LIST_FILES}" ]
        then
            echo "${imageName}"
            continue
        fi

        if [ "${SAVE_LOAD_ARG}" = "save" ]; then
            ABSOLUTE_DEST_PATH=$(cd -- "${DEST_REGISTRY}" && pwd)
            # Create a "save" directory for the image
            echo "Creating save directory for ${imageName}"
            skopeo copy ${SKOPEO_COPY_ARGS} docker://${imageName} dir:/${ABSOLUTE_DEST_PATH}/$(basename ${imageName})
            if [ $? -ne 0 ]
            then
                echo ${imageName} >> ${IMAGES_WITH_FAILURES}
            fi
        else
            printf "\nCopying image $imageName\n"

            # If the image is specified with a digest, copy it using a tag.
            # We will still be able to reference it using the digest value.
            # This is required when copying to image registries like the
            # internal OpenShift image registry.
            image="$(basename ${imageName})"
            if [[ "${image}" =~ "sha256:" ]]
            then
                image="$(digest2tag $image)"
            fi

            skopeo copy ${SKOPEO_COPY_ARGS} docker://${imageName} docker://${DEST_REGISTRY}/${image}
            if [ $? -ne 0 ]
            then
                echo ${imageName} >> ${IMAGES_WITH_FAILURES}
            fi
        fi
    done
fi

if [ -f "${IMAGES_WITH_FAILURES}" ]
then
    printf "\n**** The following images had issues being copied to the destination registry. ****\n"
    cat ${IMAGES_WITH_FAILURES}
fi

rm -f ${IMAGES_WITH_FAILURES}
