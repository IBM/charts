#!/usr/bin/env bash
set -euo pipefail

DOMAIN=""
NAMESPACE=""
SECRET_NAME=""
CERT_DIR=""

usage() {
  echo "Usage: $0 --domain <domain> --namespace <namespace> --secret-name <secret-name> --cert-dir <cert-dir>" >&2
}

require_value() {
  local name="$1"
  local value="$2"

  if [ -z "${value}" ]; then
    echo "Error: ${name} is required." >&2
    usage
    exit 1
  fi
}

require_command() {
  local command_name="$1"

  if ! command -v "${command_name}" >/dev/null 2>&1; then
    echo "Error: '${command_name}' is required." >&2
    exit 1
  fi
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --domain)
      if [ "$#" -lt 2 ]; then
        echo "Error: --domain requires a value." >&2
        usage
        exit 1
      fi
      DOMAIN="${2:-}"
      shift 2
      ;;
    --namespace)
      if [ "$#" -lt 2 ]; then
        echo "Error: --namespace requires a value." >&2
        usage
        exit 1
      fi
      NAMESPACE="${2:-}"
      shift 2
      ;;
    --secret-name)
      if [ "$#" -lt 2 ]; then
        echo "Error: --secret-name requires a value." >&2
        usage
        exit 1
      fi
      SECRET_NAME="${2:-}"
      shift 2
      ;;
    --cert-dir)
      if [ "$#" -lt 2 ]; then
        echo "Error: --cert-dir requires a value." >&2
        usage
        exit 1
      fi
      CERT_DIR="${2:-}"
      shift 2
      ;;
    --help|-h)
      usage
      exit 0
      ;;
    *)
      echo "Error: Unknown argument '$1'." >&2
      usage
      exit 1
      ;;
  esac
done

require_value "--domain" "${DOMAIN}"
require_value "--namespace" "${NAMESPACE}"
require_value "--secret-name" "${SECRET_NAME}"
require_value "--cert-dir" "${CERT_DIR}"

require_command openssl
require_command kubectl

mkdir -p "${CERT_DIR}"

ROOT_CA_KEY="${CERT_DIR}/loop-root-ca.key"
ROOT_CA_CERT="${CERT_DIR}/loop-root-ca.crt"
SERVER_KEY="${CERT_DIR}/key.pem"
SERVER_CERT="${CERT_DIR}/cert.pem"
SERVER_CSR="${CERT_DIR}/loop-server.csr"
SERVER_EXT="${CERT_DIR}/loop-server.ext"
SERIAL_FILE="${CERT_DIR}/loop-root-ca.srl"

cleanup() {
  rm -f "${SERVER_CSR}" "${SERVER_EXT}" "${SERIAL_FILE}"
}
trap cleanup EXIT

if [ -f "${ROOT_CA_KEY}" ] && [ -f "${ROOT_CA_CERT}" ]; then
  echo "Reusing existing Root CA: ${ROOT_CA_CERT}"
elif [ ! -f "${ROOT_CA_KEY}" ] && [ ! -f "${ROOT_CA_CERT}" ]; then
  echo "Generating Root CA: ${ROOT_CA_CERT}"
  openssl genrsa -out "${ROOT_CA_KEY}" 4096
  openssl req -x509 -new -nodes \
    -key "${ROOT_CA_KEY}" \
    -sha256 \
    -days 3650 \
    -out "${ROOT_CA_CERT}" \
    -subj "/CN=DevOps Loop Root CA" \
    -addext "basicConstraints = critical, CA:TRUE" \
    -addext "keyUsage = critical, keyCertSign, cRLSign"
else
  echo "Error: Root CA files are incomplete in ${CERT_DIR}. Preserve or remove both loop-root-ca.crt and loop-root-ca.key." >&2
  exit 1
fi

echo "Generating Loop server certificate for ${DOMAIN}"
openssl genrsa -out "${SERVER_KEY}" 2048
openssl req -new \
  -key "${SERVER_KEY}" \
  -out "${SERVER_CSR}" \
  -subj "/CN=${DOMAIN}"

cat > "${SERVER_EXT}" <<EOF
basicConstraints = CA:FALSE
keyUsage = critical, digitalSignature, keyEncipherment
extendedKeyUsage = serverAuth
subjectAltName = DNS:${DOMAIN},DNS:*.${DOMAIN}
EOF

openssl x509 -req \
  -in "${SERVER_CSR}" \
  -CA "${ROOT_CA_CERT}" \
  -CAkey "${ROOT_CA_KEY}" \
  -CAcreateserial \
  -CAserial "${SERIAL_FILE}" \
  -out "${SERVER_CERT}" \
  -days 365 \
  -sha256 \
  -extfile "${SERVER_EXT}"

kubectl create secret generic "${SECRET_NAME}" \
  --type=kubernetes.io/tls \
  --from-file=ca.crt="${ROOT_CA_CERT}" \
  --from-file=tls.crt="${SERVER_CERT}" \
  --from-file=tls.key="${SERVER_KEY}" \
  --namespace "${NAMESPACE}" \
  --dry-run=client \
  -o yaml | kubectl apply -f -

echo "Root CA for AppScan OIDC trust: ${CERT_DIR}/loop-root-ca.crt"
echo "Kubernetes secret updated: ${NAMESPACE}/${SECRET_NAME}"
