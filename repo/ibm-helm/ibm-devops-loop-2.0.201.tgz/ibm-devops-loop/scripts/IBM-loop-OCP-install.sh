#Pull ibm helm charts
LOOP_CHART_VERSION=2.0.201
helm repo add ibm-helm https://raw.githubusercontent.com/IBM/charts/master/repo/ibm-helm --force-update
helm pull --untar ibm-helm/ibm-devops-loop --version ${LOOP_CHART_VERSION}
#
#Required
#External fully qualified domain name of the cluster
#
# Note: The default configuration inherits the default domain when you created
# your Openshift cluster.  You may also choose to further customize the
# domain such as adding a prefix, for instance devops-loop.$(oc get....),
# using an altnernative ingress controller, or directly specifying a fully
# qualified name associated with your cluster.
#
#See Installation of DevOps Loop documentation for more details:
#https://www.ibm.com/docs/en/devops-loop/2.0.2?topic=administration-installation-devops-loop
DOMAIN=$(oc get -n openshift-ingress-operator ingresscontroller default -o jsonpath='{.status.domain}')

#Required
#Set value to 'true' to accept the license.
ACCEPT_LICENSE=

#Required
#Hostname of IBM Rational license server
LICENSE_SERVER=

#Required
#SMTP Server configuration
EMAIL_SERVER_HOST=
EMAIL_SERVER_PORT=
EMAIL_FROM_ADDRESS=

#Optional
#Additional SMTP Server configuration
EMAIL_SERVER_USERNAME=""
EMAIL_SERVER_PASSWORD=""
EMAIL_SERVER_STARTTLS=false
EMAIL_SERVER_SMTPS=false

#Required
#Secure seed required to generate passwords
#A random string
#Unrecoverable so keep it safe
PASSWORD_SEED=

#Specify the TLS secret name in your namespace as necessary.
#
#See Installation of DevOps Loop documentation for more details:
#https://www.ibm.com/docs/en/devops-loop/2.0.2?topic=administration-installation-devops-loop
TLS_CERT_SECRET_NAME=

#Set SELF_SIGNED=true to generate and use a self-signed certificate for the
#installation of DevOps Loop
SELF_SIGNED=

#Alternative RWX storage class
#See Storage
#For example: ibmc-file-gold-gid
RWX_STORAGE_CLASS=

#Alternative RWO storage class
#See Storage
#For example: ibmc-block-gold
RWO_STORAGE_CLASS=

#Required
NAMESPACE=devops-loop
HELM_NAME=devops-loop

#Optional Additional Helm options
ADDITIONAL_HELM_OPTIONS=""

# Optional Appscan integration
APP_SCAN_ENABLED=false
# Required only when APP_SCAN_ENABLED=true
# External URL for AppScan (e.g. https://cloud.appscan.com)
APPSCAN_EXTERNAL_URL=

# Optional Harbor integration
HARBOR_ENABLED=false

# Required only when HARBOR_ENABLED=true
HARBOR_S3_BUCKET=
HARBOR_S3_REGION=
HARBOR_S3_ENDPOINT=

# Harbor Trivy cache storage class
#See Storage
#For example: ibmc-file-gold-gid
HARBOR_TRIVY_STORAGE_CLASS=

# Harbor OIDC admin group in Keycloak
# Users in this group become Harbor system administrators.
HARBOR_OIDC_ADMIN_GROUP=

# Optional Harbor external URL. Leave empty unless a fixed external Harbor URL
# must be passed to the Harbor chart.
HARBOR_EXTERNAL_URL=

# OpenShift SCC preflight values for optional Harbor integration.
# The SCC is intentionally not created by this installer.
HARBOR_SERVICE_ACCOUNT="${HARBOR_SERVICE_ACCOUNT:-harbor}"
HARBOR_SCC_NAME="${HARBOR_SCC_NAME:-harbor-uid-10000-${NAMESPACE}}"

ROOT_DIR=./ibm-devops-loop

wait_for_secret() {
  local secret_name="$1"
  local timeout_seconds="${2:-900}"
  local waited=0

  echo "Waiting for secret ${secret_name} in namespace ${NAMESPACE}..."

  until oc get secret "${secret_name}" -n "${NAMESPACE}" >/dev/null 2>&1; do
    if [ "${waited}" -ge "${timeout_seconds}" ]; then
      echo "Timed out waiting for secret ${secret_name}"
      return 1
    fi
    sleep 10
    waited=$((waited + 10))
  done

  echo "Secret ${secret_name} is available."
}

validate_harbor_openshift_scc() {
  local service_account_subject="system:serviceaccount:${NAMESPACE}:${HARBOR_SERVICE_ACCOUNT}"
  local scc_users
  local run_as_user_type
  local run_as_user_uid
  local fs_group_type
  local fs_group_min
  local fs_group_max
  local supplemental_groups_type
  local supplemental_groups_min
  local supplemental_groups_max

  echo "Validating Harbor OpenShift SCC ${HARBOR_SCC_NAME}..."

  if ! oc get scc "${HARBOR_SCC_NAME}" >/dev/null 2>&1; then
    echo "Required SCC ${HARBOR_SCC_NAME} was not found."
    echo "Ask a cluster administrator to apply scripts/harbor/openshift/harbor-scc.yaml using:"
    echo "  NAMESPACE=${NAMESPACE} HARBOR_SERVICE_ACCOUNT=${HARBOR_SERVICE_ACCOUNT} HARBOR_SCC_NAME=${HARBOR_SCC_NAME} scripts/harbor/openshift/apply-harbor-scc.sh --yes"
    return 1
  fi

  scc_users=$(oc get scc "${HARBOR_SCC_NAME}" -o jsonpath='{.users[*]}')
  if ! printf '%s\n' "${scc_users}" | tr ' ' '\n' | grep -Fx "${service_account_subject}" >/dev/null 2>&1; then
    echo "Required SCC ${HARBOR_SCC_NAME} is not bound to ${service_account_subject}."
    echo "Ask a cluster administrator to bind only this dedicated Harbor ServiceAccount using:"
    echo "  NAMESPACE=${NAMESPACE} HARBOR_SERVICE_ACCOUNT=${HARBOR_SERVICE_ACCOUNT} HARBOR_SCC_NAME=${HARBOR_SCC_NAME} scripts/harbor/openshift/apply-harbor-scc.sh --yes"
    return 1
  fi

  run_as_user_type=$(oc get scc "${HARBOR_SCC_NAME}" -o jsonpath='{.runAsUser.type}')
  run_as_user_uid=$(oc get scc "${HARBOR_SCC_NAME}" -o jsonpath='{.runAsUser.uid}')
  fs_group_type=$(oc get scc "${HARBOR_SCC_NAME}" -o jsonpath='{.fsGroup.type}')
  fs_group_min=$(oc get scc "${HARBOR_SCC_NAME}" -o jsonpath='{.fsGroup.ranges[0].min}')
  fs_group_max=$(oc get scc "${HARBOR_SCC_NAME}" -o jsonpath='{.fsGroup.ranges[0].max}')
  supplemental_groups_type=$(oc get scc "${HARBOR_SCC_NAME}" -o jsonpath='{.supplementalGroups.type}')
  supplemental_groups_min=$(oc get scc "${HARBOR_SCC_NAME}" -o jsonpath='{.supplementalGroups.ranges[0].min}')
  supplemental_groups_max=$(oc get scc "${HARBOR_SCC_NAME}" -o jsonpath='{.supplementalGroups.ranges[0].max}')

  if [ "${run_as_user_type}" != "MustRunAs" ] || [ "${run_as_user_uid}" != "10000" ]; then
    echo "SCC ${HARBOR_SCC_NAME} must set runAsUser.type=MustRunAs and runAsUser.uid=10000."
    return 1
  fi

  if [ "${fs_group_type}" != "MustRunAs" ] || [ "${fs_group_min}" != "10000" ] || [ "${fs_group_max}" != "10000" ]; then
    echo "SCC ${HARBOR_SCC_NAME} must set fsGroup.type=MustRunAs with range 10000-10000."
    return 1
  fi

  if [ "${supplemental_groups_type}" != "MustRunAs" ] || [ "${supplemental_groups_min}" != "10000" ] || [ "${supplemental_groups_max}" != "10000" ]; then
    echo "SCC ${HARBOR_SCC_NAME} must set supplementalGroups.type=MustRunAs with range 10000-10000."
    return 1
  fi

  echo "Harbor OpenShift SCC preflight passed for ${service_account_subject}."
}

run_install() {

  if ! oc get namespace ${NAMESPACE} > /dev/null 2>&1; then
    oc create namespace ${NAMESPACE} || { echo "Failed to create namespace"; return 1; }
  fi

  if ! oc get secret mongodb-url-secret --namespace ${NAMESPACE} > /dev/null 2>&1; then

    MONGO_CHART_VERSION="${MONGO_CHART_VERSION:-14.13.0}"
    MONGO_IMAGE_TAG="${MONGO_IMAGE_TAG:-6.0}"
    MONGO_IMAGE_REPO="${MONGO_IMAGE_REPO:-bitnamilegacy/mongodb}"
    MONGO_HELM_RELEASE_NAME="${MONGO_HELM_RELEASE_NAME:-devops-loop-mongo}"
    MONGO_NAMESPACE="${MONGO_NAMESPACE:-${NAMESPACE}}"
    MONGO_PVC_SIZE=${MONGO_PVC_SIZE:-20Gi}

    helm repo add bitnami https://charts.bitnami.com/bitnami --force-update 1> /dev/null

    MONGO_INSTALL_OPTIONS="\
      --set image.repository=${MONGO_IMAGE_REPO} \
      --set image.tag=${MONGO_IMAGE_TAG} \
      --set persistence.size=${MONGO_PVC_SIZE} \
      --set global.compatibility.openshift.adaptSecurityContext=auto
    "

    if [ -n "${RWO_STORAGE_CLASS}" ]; then
      MONGO_INSTALL_OPTIONS="${MONGO_INSTALL_OPTIONS} --set persistence.storageClass=${RWO_STORAGE_CLASS}"
    fi

    if [ -n "${MONGO_ADDITIONAL_INSTALL_OPTIONS:-}" ]; then
      MONGO_INSTALL_OPTIONS="${MONGO_INSTALL_OPTIONS} ${MONGO_ADDITIONAL_INSTALL_OPTIONS}"
    fi

    helm upgrade --install ${MONGO_HELM_RELEASE_NAME} \
      --version ${MONGO_CHART_VERSION} \
      ${MONGO_INSTALL_OPTIONS} \
      --namespace=${MONGO_NAMESPACE} \
      --create-namespace \
      bitnami/mongodb 1> /dev/null || { echo "Failed to install MongoDB"; return 1; }

    MONGODB_ROOT_PASSWORD=$(oc get secret --namespace ${NAMESPACE} ${MONGO_HELM_RELEASE_NAME}-mongodb -o jsonpath="{.data.mongodb-root-password}" | base64 -d)

    MONGO_URL="mongodb://root:${MONGODB_ROOT_PASSWORD}@${MONGO_HELM_RELEASE_NAME}-mongodb:27017/admin"

    oc create secret generic mongodb-url-secret --namespace ${NAMESPACE} --from-literal=password="${MONGO_URL}" 1> /dev/null || { echo "Failed to create MongoDB secret"; return 1; }

  fi

  if [ "${SELF_SIGNED}" = "true" ]; then
    export TLS_CERT_SECRET_NAME=devops-loop-tls-secret
    openssl genrsa -out key.pem 2048
    openssl req -new -x509 -key key.pem -out cert.pem -days 365 \
            -subj "/CN=${DOMAIN}" -addext "subjectAltName = DNS:${DOMAIN},DNS:*.${DOMAIN}" \
            -addext "certificatePolicies = 1.2.3.4"

    oc create secret generic ${TLS_CERT_SECRET_NAME} \
      --type=kubernetes.io/tls \
      --from-file=ca.crt=./cert.pem \
      --from-file=tls.crt=./cert.pem \
      --from-file=tls.key=./key.pem \
      --namespace ${NAMESPACE}
  fi

  HELM_OPTIONS="${HELM_OPTIONS:-} \
--set global.domain=${DOMAIN} \
--set-literal global.passwordSeed=${PASSWORD_SEED} \
--set global.platform.smtp.sender=${EMAIL_FROM_ADDRESS} \
--set global.platform.smtp.host=${EMAIL_SERVER_HOST} \
--set global.platform.smtp.port=${EMAIL_SERVER_PORT} \
--set global.platform.smtp.username=${EMAIL_SERVER_USERNAME} \
--set global.platform.smtp.password=${EMAIL_SERVER_PASSWORD} \
--set global.platform.smtp.startTLS=${EMAIL_SERVER_STARTTLS} \
--set global.platform.smtp.smtps=${EMAIL_SERVER_SMTPS} \
--set global.ibmCertSecretName=${TLS_CERT_SECRET_NAME} \
--set license=${ACCEPT_LICENSE} \
--set platform.appscan.enabled=${APP_SCAN_ENABLED}
"
  if [ "${APP_SCAN_ENABLED}" = "true" ] && [ -n "${APPSCAN_EXTERNAL_URL}" ]; then
    HELM_OPTIONS="${HELM_OPTIONS} --set-string platform.appscan.externalURL=${APPSCAN_EXTERNAL_URL}"
  fi																	 

  if [ "${SELF_SIGNED}" = "true" ]; then
     HELM_OPTIONS="${HELM_OPTIONS} --set global.privateCaBundleSecretName=${TLS_CERT_SECRET_NAME}"
     HELM_OPTIONS="${HELM_OPTIONS} --set ibm-devops-prod.ingress.cert.selfSigned=true"
  fi

  if [ -n "${LICENSE_SERVER}" ]; then
    HELM_OPTIONS="${HELM_OPTIONS} --set global.rationalLicenseKeyServer=@${LICENSE_SERVER}"
  fi

  if [ -n "${RWX_STORAGE_CLASS}" ]; then
    HELM_OPTIONS="${HELM_OPTIONS} --set global.persistence.rwxStorageClass=${RWX_STORAGE_CLASS}"
  fi

  if [ -n "${RWO_STORAGE_CLASS}" ]; then
    HELM_OPTIONS="${HELM_OPTIONS} --set global.persistence.rwoStorageClass=${RWO_STORAGE_CLASS}"
  fi

  HELM_OPTIONS="${HELM_OPTIONS} ${ADDITIONAL_HELM_OPTIONS}"

  echo "Installing DevOps Loop..."

  helm upgrade --install ${HELM_NAME} ${ROOT_DIR} ${HELM_OPTIONS} \
    --set harbor.enabled=false \
    -n ${NAMESPACE} -f ${ROOT_DIR}/values-openshift.yaml || return 1

  if [ "${HARBOR_ENABLED}" != "true" ]; then
    echo "Harbor is disabled. DevOps Loop installation completed."
    return 0
  fi

  echo "Waiting for release jobs to complete before enabling Harbor..."
  for job in $(kubectl get jobs -n "${NAMESPACE}" \
    -l "app.kubernetes.io/instance=${HELM_NAME}" \
    -o jsonpath='{range .items[*]}{.metadata.name}{"\n"}{end}'); do
    kubectl get job "${job}" -n "${NAMESPACE}" >/dev/null 2>&1 || continue
    kubectl wait --for=condition=complete "job/${job}" -n "${NAMESPACE}" --timeout=900s 2>/dev/null || \
    { kubectl get job "${job}" -n "${NAMESPACE}" >/dev/null 2>&1 && return 1 || continue; }
  done

  echo "Validating Harbor prerequisites..."

  if [ -z "${HARBOR_S3_BUCKET}" ]; then
    echo "HARBOR_S3_BUCKET is required when HARBOR_ENABLED=true"
    return 1
  fi

  if [ -z "${HARBOR_S3_REGION}" ]; then
    echo "HARBOR_S3_REGION is required when HARBOR_ENABLED=true"
    return 1
  fi

  if [ -z "${HARBOR_S3_ENDPOINT}" ]; then
    echo "HARBOR_S3_ENDPOINT is required when HARBOR_ENABLED=true"
    return 1
  fi

  if ! oc get secret harbor-s3-secret -n "${NAMESPACE}" >/dev/null 2>&1; then
    echo "harbor-s3-secret is required when HARBOR_ENABLED=true"
    echo "Create it before install:"
    echo "oc create secret generic harbor-s3-secret -n ${NAMESPACE} --from-literal=accesskey='<ACCESS_KEY>' --from-literal=secretkey='<SECRET_KEY>'"
    return 1
  fi

  if [ -z "${HARBOR_TRIVY_STORAGE_CLASS}" ] && [ -z "${RWX_STORAGE_CLASS}" ]; then
    echo "Either HARBOR_TRIVY_STORAGE_CLASS or RWX_STORAGE_CLASS is required when HARBOR_ENABLED=true"
    return 1
  fi

  HARBOR_EFFECTIVE_TRIVY_STORAGE_CLASS="${HARBOR_TRIVY_STORAGE_CLASS:-${RWX_STORAGE_CLASS}}"

  if ! oc get storageclass "${HARBOR_EFFECTIVE_TRIVY_STORAGE_CLASS}" >/dev/null 2>&1; then
    echo "StorageClass ${HARBOR_EFFECTIVE_TRIVY_STORAGE_CLASS} does not exist"
    return 1
  fi

  echo "Using Harbor Trivy storage class: ${HARBOR_EFFECTIVE_TRIVY_STORAGE_CLASS}"

  validate_harbor_openshift_scc || return 1

  echo "Waiting for Harbor dependency secrets"

  for secret in devops-loop-valkey devops-loop-postgresql; do
    if ! wait_for_secret "${secret}" 1200; then
      echo "WARNING: Required Harbor dependency secret ${secret} was not available within timeout period."
      echo "Skipping Harbor installation/upgrade. DevOps Loop base installation completed successfully."
      echo "After ${secret} is available, rerun this script to enable Harbor."
      return 0
    fi
  done

  REDIS_PASSWORD=$(oc get secret devops-loop-valkey \
    -n "${NAMESPACE}" \
    -o jsonpath="{.data.valkey-password}" | base64 -d)

  S3_ACCESS_KEY=$(oc get secret harbor-s3-secret \
    -n "${NAMESPACE}" \
    -o jsonpath="{.data.accesskey}" | base64 -d)

  S3_SECRET_KEY=$(oc get secret harbor-s3-secret \
    -n "${NAMESPACE}" \
    -o jsonpath="{.data.secretkey}" | base64 -d)

  if [ -z "${HARBOR_OIDC_ADMIN_GROUP}" ]; then
    HARBOR_OIDC_ADMIN_GROUP=harbor-admins
  fi

  echo "Using Harbor OIDC admin group: ${HARBOR_OIDC_ADMIN_GROUP}"
  HARBOR_URL="${HARBOR_EXTERNAL_URL:-https://harbor.${DOMAIN}}"

  HARBOR_HELM_OPTIONS="${HELM_OPTIONS} \
--set harbor.enabled=true \
--set platform.harbor.enabled=true \
--set-string harbor.serviceAccountName=${HARBOR_SERVICE_ACCOUNT} \
--set-string harbor.nginx.serviceAccountName=${HARBOR_SERVICE_ACCOUNT} \
--set-string harbor.portal.serviceAccountName=${HARBOR_SERVICE_ACCOUNT} \
--set-string harbor.core.serviceAccountName=${HARBOR_SERVICE_ACCOUNT} \
--set-string harbor.jobservice.serviceAccountName=${HARBOR_SERVICE_ACCOUNT} \
--set-string harbor.registry.serviceAccountName=${HARBOR_SERVICE_ACCOUNT} \
--set-string harbor.trivy.serviceAccountName=${HARBOR_SERVICE_ACCOUNT} \
--set-string harbor.exporter.serviceAccountName=${HARBOR_SERVICE_ACCOUNT} \
--set-string harbor.externalURL=${HARBOR_URL} \
--set-string harbor.oidc.adminGroup=${HARBOR_OIDC_ADMIN_GROUP} \
--set-string harbor.redis.external.password=${REDIS_PASSWORD} \
--set-string harbor.trivy.externalRedis.password=${REDIS_PASSWORD} \
--set-string harbor.persistence.imageChartStorage.s3.bucket=${HARBOR_S3_BUCKET} \
--set-string harbor.persistence.imageChartStorage.s3.region=${HARBOR_S3_REGION} \
--set-string harbor.persistence.imageChartStorage.s3.regionendpoint=${HARBOR_S3_ENDPOINT} \
--set-string harbor.persistence.imageChartStorage.s3.accesskey=${S3_ACCESS_KEY} \
--set-string harbor.persistence.imageChartStorage.s3.secretkey=${S3_SECRET_KEY} \
--set-string harbor.trivy.persistence.storageClass=${HARBOR_EFFECTIVE_TRIVY_STORAGE_CLASS}
"

  echo "Installing optional Harbor integration..."
  
  HARBOR_HELM_OPTIONS="${HARBOR_HELM_OPTIONS} ${ADDITIONAL_HELM_OPTIONS}"
  helm upgrade --install "${HELM_NAME}" "${ROOT_DIR}" ${HARBOR_HELM_OPTIONS} \
  --hide-notes \
  --timeout 30m \
  -n "${NAMESPACE}" -f "${ROOT_DIR}/values-openshift.yaml" || return 1

  echo "DevOps Loop + Harbor installation completed."
  echo ""
  echo "Harbor is available from the DevOps Loop application switcher."
  echo ""
  echo "Monitor Harbor pods:"
  echo "  oc get pods -n ${NAMESPACE} | grep harbor"
  echo ""
  echo "Bootstrap Harbor images:"
  echo "  1. Update scripts/harbor/bootstrap-images.txt"
  echo "  2. Run:"
  echo "     DOMAIN=${DOMAIN} NAMESPACE=${NAMESPACE} RELEASE=${HELM_NAME} scripts/harbor/bootstrap-images.sh"

}

run_install
