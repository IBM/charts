#!/usr/bin/env bash

set -e

SCRIPT_DIR="$(dirname "${BASH_SOURCE[0]}")"

refresh_admin_token() {
  . "$SCRIPT_DIR/admin-token.sh"
}

keycloak_request() {
  local method="$1"
  local url="$2"
  local data="${3:-}"

  refresh_admin_token

  if [ -n "$data" ]; then
    curl -s -w "\n%{http_code}" $CAFILE -X "$method" "$url" \
      -H "Authorization: Bearer $ADMIN_TOKEN" \
      -H "Content-Type: application/json" \
      -d "$data"
  else
    curl -s -w "\n%{http_code}" $CAFILE -X "$method" "$url" \
      -H "Authorization: Bearer $ADMIN_TOKEN"
  fi
}

response_body() {
  sed '$d'
}

response_code() {
  tail -n1
}

require_success() {
  local response="$1"
  local action="$2"
  local http_code
  http_code=$(printf '%s\n' "$response" | response_code)

  if [ "$http_code" -ge 300 ]; then
    echo "Failed to ${action}. HTTP response code: $http_code"
    printf '%s\n' "$response" | response_body
    exit 1
  fi
}

trim_trailing_slashes() {
  local value="$1"
  while [ "${value%/}" != "$value" ]; do
    value="${value%/}"
  done
  printf '%s' "$value"
}

CLIENT_ID="${CLIENT_ID:-appscan360}"
APP_SCAN_URL="$(trim_trailing_slashes "${APP_SCAN_URL:-}")"
REDIRECT_URI="${REDIRECT_URI:-}"

if [ -z "$APP_SCAN_URL" ]; then
  echo "APP_SCAN_URL is required when AppScan Keycloak integration is enabled"
  exit 1
fi

if [ -z "$REDIRECT_URI" ]; then
  echo "REDIRECT_URI is required when AppScan Keycloak integration is enabled"
  exit 1
fi

if [ -z "$ADMIN_TOKEN" ]; then
  refresh_admin_token
fi

id=$(. "$SCRIPT_DIR/client-id.sh")

if [ -z "$id" ]; then
  echo "No id found for $CLIENT_ID, so creating a new AppScan OIDC client..."
  payload=$(jq -n \
    --arg clientId "$CLIENT_ID" \
    --arg appScanUrl "$APP_SCAN_URL" \
    --arg redirectUri "$REDIRECT_URI" \
    '{
      clientId: $clientId,
      protocol: "openid-connect",
      enabled: true,
      clientAuthenticatorType: "client-secret",
      standardFlowEnabled: true,
      publicClient: false,
      bearerOnly: false,
      baseUrl: $appScanUrl,
      rootUrl: $appScanUrl,
      redirectUris: [$redirectUri],
      webOrigins: [$appScanUrl],
      attributes: {
        "post.logout.redirect.uris": $appScanUrl,
        "oauth2.device.authorization.grant.enabled": "false"
      }
    }')

  response=$(keycloak_request POST "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients" "$payload")
  require_success "$response" "create AppScan client"

  id=$(. "$SCRIPT_DIR/client-id.sh")
  if [ -z "$id" ]; then
    echo "AppScan client was created, but its Keycloak id could not be resolved"
    exit 1
  fi
else
  echo "Updating existing AppScan OIDC client $CLIENT_ID..."
  response=$(keycloak_request GET "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$id")
  require_success "$response" "read AppScan client"

  existing=$(printf '%s\n' "$response" | response_body)
  payload=$(printf '%s\n' "$existing" | jq \
    --arg appScanUrl "$APP_SCAN_URL" \
    --arg redirectUri "$REDIRECT_URI" \
    '.protocol = "openid-connect"
      | .clientAuthenticatorType = "client-secret"
      | .standardFlowEnabled = true
      | .publicClient = false
      | .bearerOnly = false
      | .baseUrl = $appScanUrl
      | .rootUrl = $appScanUrl
      | .redirectUris = [$redirectUri]
      | .webOrigins = [$appScanUrl]
      | .attributes = (.attributes // {})
      | .attributes."post.logout.redirect.uris" = $appScanUrl')

  response=$(keycloak_request PUT "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$id" "$payload")
  require_success "$response" "update AppScan client"
fi

response=$(keycloak_request GET "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$id/client-secret")
require_success "$response" "read AppScan client secret"

secret=$(printf '%s\n' "$response" | response_body | jq -r '.value // empty')
if [ -n "$secret" ]; then
  echo "AppScan OIDC client secret for ${CLIENT_ID}: ${secret}"
  echo "Configure this secret in the external AppScan SSO settings."
else
  echo "AppScan OIDC client was configured, but the client secret could not be read from the response."
fi
