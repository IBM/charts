#!/bin/bash
echo "Running cleanup step"