#!/bin/bash
echo "Running pre-install step"
