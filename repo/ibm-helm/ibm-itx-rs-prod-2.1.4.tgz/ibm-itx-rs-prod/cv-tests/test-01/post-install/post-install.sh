#!/bin/bash
echo "Running post-install step"