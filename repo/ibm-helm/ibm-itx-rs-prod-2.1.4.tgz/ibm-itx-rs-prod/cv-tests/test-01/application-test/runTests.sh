#!/bin/bash
echo "Running test-01 app test"