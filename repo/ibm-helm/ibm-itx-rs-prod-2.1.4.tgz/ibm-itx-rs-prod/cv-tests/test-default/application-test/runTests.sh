#!/bin/bash
echo "Helm charts tested through operator"
