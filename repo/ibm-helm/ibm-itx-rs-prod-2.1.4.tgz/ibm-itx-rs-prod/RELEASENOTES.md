# Release Notes

This document is release notes for IBM Sterling Transformation Extender for Red Hat OpenShift 10.1.2

## What's new

This container version includes IBM Sterling Transformation Extender 10.1.2. It runs on supported version of Red Hat OpenShift Container Platform (RHOCP).

## Fixes

N/A

## Prerequisites

Please refer to the main `README` document.

## Version History

1.0.x - IBM Sterling Transformation Extender Runtime Server 10.0.3
<br>2.0.x - IBM Sterling Transformation Extender for Red Hat OpenShift 10.1.1
<br>2.1.x - IBM Sterling Transformation Extender for Red Hat OpenShift 10.1.2
* 2.1.0 - 20231130 : The image with ID bc9b60086ca9 includes security patches and fixes applied to IBM Transformation Extender through 10.1.2.0 build 135.
* 2.1.1 - 20241122 : The image with ID 8f9a6470db4f includes security patches and fixes applied to IBM Transformation Extender through 10.1.2.1 build 65.
* 2.1.2 - 20250328 : The image with ID c789036b8c28 includes security patches and fixes applied to IBM Transformation Extender through 10.1.2.1 build 77.
* 2.1.3 - 20251121 : The image with ID 568f81cca561 includes security patches and fixes applied to IBM Transformation Extender through 10.1.2.1 build 108.
* 2.1.4 - 20260320 : The image with ID 0701489c7ca9 includes security patches and fixes applied to IBM Transformation Extender through 10.1.2.2 build 10.

<br>3.0.x - IBM Sterling Transformation Extender for Red Hat OpenShift 11.0.1
<br>3.1.x - IBM Sterling Transformation Extender for Red Hat OpenShift 11.0.2

## Breaking Changes

N/A

## Documentation

For general IBM Sterling Transformation Extender documentation, please refer to the product's [knowledge center](https://www.ibm.com/docs/en/ste/10.1.2).
