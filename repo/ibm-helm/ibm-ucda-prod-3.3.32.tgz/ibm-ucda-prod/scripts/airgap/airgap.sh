#!/bin/bash

#
# Generate list of images used by DevOps Deploy Agent.  For each image, skopeo copy
# the image to the destination image registry.
#

# Process args
usage() {
    echo -e "Usage: $0 -r HELM_CHART_ROOT_DIR -d DEST_REGISTRY_SPEC [ -s SRC_REGISTRY_SPEC] [-h] [-l] [-y] [-x save|load] [-c SKOPEO_COPY_ARGS]\n" 1>&2
    echo "When running this script, the following is assumed."
    echo "1) The DevOps Deploy agent helm chart has been downloaded and expanded.  The -r option specifies the directory path to the chart directory."
    echo "2) You have successfully run 'skopeo login...' to the source and destination image registries."
    echo -e "\nWhen specifying '-x save', the -d argument is directory to write save dirs to."
    echo "When specifying '-x load', the -s argument is directory holding save dirs, and is required."
}

while getopts "r:d:s:c:x:hly" opt; do
    case "${opt}" in
        r)
            ROOT_DIR=${OPTARG}
            ;;
        d)
            DEST_REGISTRY=${OPTARG}
            ;;
        s)
            SRC_REGISTRY=${OPTARG}
            ;;
        c)
            SKOPEO_COPY_ARGS=${OPTARG}
            ;;
        l)
            LIST_FILES=true
            ;;
        x)
            SAVE_LOAD_ARG=$(echo ${OPTARG} | tr '[:upper:]' '[:lower:]')
            ;;
        y)
            ASSUME_YES=true
            ;;
        h)
            usage
            exit 0
            ;;
        *)
            usage
            exit 1
            ;;
    esac
done
shift $((OPTIND-1))

if [ -z "${ROOT_DIR}" ] || [ -z "${DEST_REGISTRY}" ] || [ $# -gt 0 ]
then
    usage
    exit 1
fi

if [ "${SAVE_LOAD_ARG}" ] && [ "${SAVE_LOAD_ARG}" != "save" ] && [ "${SAVE_LOAD_ARG}" != "load" ]
then
    usage
    exit 1
fi

#
# Default args for 'skopeo copy...' command.
# We only want the amd64/linux images by default
SKOPEO_COPY_ARGS=${SKOPEO_COPY_ARGS:-"--override-arch amd64 --override-os linux"}

#
# Set the source image registry by looking at the helm chart name
CHART_NAME=$(basename "${ROOT_DIR}")
if [[ "${CHART_NAME}" == "ibm-ucda-prod" ]]
then
    SRC_REGISTRY="${SRC_REGISTRY:-cp.icr.io/cp}"
elif [[ "${CHART_NAME}" == "hcl-launch-agent-prod" ]]
then
    SRC_REGISTRY="${SRC_REGISTRY:-hclcr.io}"
else
    echo "Invalid ROOT_DIR: ${ROOT_DIR}"
    exit 1
fi

# Values needed to successfully run 'helm template...' below

HELM_OPTIONS="${HELM_OPTIONS:-} \
--set license.accept=true
"

# We only want to set global.imageRegistry if a SRC_REGISTRY other than the
# default values are specified.
if [ "${SRC_REGISTRY}" != "cp.icr.io/cp" ] && [ "${SRC_REGISTRY}" != "hclcr.io" ]
then
    HELM_OPTIONS="${HELM_OPTIONS} --set global.imageRegistry=${SRC_REGISTRY}"
fi

# Get a list of all images listed in template files
# Sort and remove non-unique image lines
# Remove any lines that begin with a comment (#)
# Remove any comments from within a line to the end of the line
# Remove the leading image: from the line
# Remove any leading and trailing quotes
# Remove any leading whitespace characters
function getDeployImageList {

    # Put awk program in a file so it can be referenced below.
    AWK_FILE=/tmp/listImages$$.awk
    cat >${AWK_FILE} <<-'EOF'
#
# Search for lines that include 'image:'. Some will have the image name
# on the next line, so we need to handle that.
#
/image:/ {
    if ($NF == "image:") {
        getline nextLine
        print $0 nextLine
    }
    else {
        print $0
    }
}
EOF

    TEMPLATE_FILE=/tmp/template$$.out
    helm template airgaptest ${ROOT_DIR} ${HELM_OPTIONS} | tee ${TEMPLATE_FILE} | awk -f ${AWK_FILE} | grep -v '^[ \t]*#' | grep -v '#.*$' | sed -e 's/^.*image://' -e "s/^[ \t]*'//" -e "s/'[ \t]*$//" -e 's/^[ \t]*"//' -e 's/"[ \t]*$//' -e 's/^[ \t]*//' | sort -u -b

    rm -f ${AWK_FILE} ${TEMPLATE_FILE}
}

IMAGES_WITH_FAILURES=/tmp/failedImages.$$

# Create $HOME/.config/containers/registries.d directory if it doesn't
# already exist.  This directory is needed to allow skopeo to process any
# image signatures it might encounter while copying images.  If this directory
# doesn't exist, skopeo will attempt to update /etc/containers/registries.d
# which will likely fail if this script is run by a non-root user.
mkdir -p $HOME/.config/containers/registries.d

# If we are in a save/load case, we need to check if the destination or
# source directory exists.
if [ "${SAVE_LOAD_ARG}" = "save" ] && [ ! -d ${DEST_REGISTRY} ]
then
    if [ "${ASSUME_YES}" = "true" ]
    then
        echo "Directory ${DEST_REGISTRY} does not exist. Creating because -y was specified."
    else
        read -p "Directory ${DEST_REGISTRY} does not exist. Create? (y/n): " -n 1 -r
        echo
        if [[ ! ${REPLY} =~ ^[Yy]$ ]]; then
            echo "Directory to hold image saves does not exist, exiting."
            exit 1
        fi
    fi
    mkdir -p ${DEST_REGISTRY}
elif [ "${SAVE_LOAD_ARG}" = "load" ] && [ ! -d "${SRC_REGISTRY}" ]
then
    echo "Directory ${SRC_REGISTRY} does not exist. Exiting."
    exit 1
fi

# If loading images from the filesystem, we use the directory names in the
# source directory.  Otherwise we need the list of images from the helm chart
if [ "${SAVE_LOAD_ARG}" = "load" ]
then
    ABSOLUTE_SRC_PATH=$(cd -- "${SRC_REGISTRY}" && pwd)
    for dir in "${ABSOLUTE_SRC_PATH}"/*/
    do
        if [ -d "${dir}" ]
        then
            echo "Loading image from ${dir}"
            skopeo copy ${SKOPEO_COPY_ARGS} dir:/${dir} docker://${DEST_REGISTRY}/$(basename ${dir})
            if [ $? -ne 0 ]
            then
                echo ${dir} >> ${IMAGES_WITH_FAILURES}
            fi
        fi
    done
else
    getDeployImageList | while read imageName
    do
        if [ -n "${LIST_FILES}" ]
        then
            echo "${imageName}"
            continue
        fi

        if [ "${SAVE_LOAD_ARG}" = "save" ]; then
            ABSOLUTE_DEST_PATH=$(cd -- "${DEST_REGISTRY}" && pwd)
            # Create a "save" directory for the image
            echo "Creating save directory for ${imageName}"
            skopeo copy ${SKOPEO_COPY_ARGS} docker://${imageName} dir:/${ABSOLUTE_DEST_PATH}/$(basename ${imageName})
            if [ $? -ne 0 ]
            then
                echo ${imageName} >> ${IMAGES_WITH_FAILURES}
            fi
        else
            echo -e "\nCopying image $imageName"
            skopeo copy ${SKOPEO_COPY_ARGS} docker://${imageName} docker://${DEST_REGISTRY}/$(basename ${imageName})
            if [ $? -ne 0 ]
            then
                echo ${imageName} >> ${IMAGES_WITH_FAILURES}
            fi
        fi
    done
fi

if [ -f "${IMAGES_WITH_FAILURES}" ]
then
    echo -e "\n**** The following images had issues being copied to the destination registry. ****\n"
    cat ${IMAGES_WITH_FAILURES}
fi

rm -f ${IMAGES_WITH_FAILURES}
