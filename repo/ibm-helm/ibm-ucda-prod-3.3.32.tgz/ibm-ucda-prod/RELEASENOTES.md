# What's new in Chart Version 3.3.32

* Support for DevOps Deploy 8.2.2.0

## Breaking Changes

* None

# Fixes/Updates

# Prerequisites
* See README for prerequisites

# Documentation
* See README for documentation

# Version History

| Chart | Date | Image(s) Supported | Breaking Changes | Details |
| ----- | ---- | ------------------ | ---------------- | ------- | 
| 3.3.32 | June 16th, 2026 | ucda: sha256:766a5bbb69d9d99376138a7e322a3232be31a354d86b57132bebcb244e7883dc | None | Version 8.2.2.0 |
| 3.3.31 | March 24th, 2026 | ucda: sha256:3f99830b9ffcfc0a5d2027619e21b75a60e2bac2a81d49c7ec29511a7d4208a5 | None | Version 8.2.1.0 |
| 3.3.30 | January 20th, 2026 | ucda: sha256:92f17c0231ac7178ecda671f3bd10e06242572c059b502bf6efdbc5a1669de20 | None | Version 8.2.0.1 |
| 3.3.29 | December 9th, 2025 | ucda: sha256:da8fad53bef978cdaa7ed8a565dde33fd37dc70273a5842eb4217775ce3d3faa | None | Version 8.2.0.0 |
| 3.3.28 | October 7th, 2025 | ucda: sha256:971204546f064da267e46afefa1d2b072d29bb2ce1733bed546632fcc3baf6fe | None | Version 8.1.2.3 |
| 3.3.27 | August 26th, 2025 | ucda: sha256:c974cebfa4cd663801048941a7da858232d1912628c500c2778fcc83710b583b | None | Version 8.1.2.2 |
| 3.3.26 | July 15th, 2025 | ucda: sha256:04fba511198bae3844f8f0d9b41e75811c5657f3a79fd377667c80e9e5fc8b53 | None | Version 8.1.2.1 |
| 3.3.25 | June 17th, 2025 | ucda: sha256:36d6b293a26e6f84f5ea53131e107c7f653422e3cb4f6c05c17b768baaf55fd9 | None | Version 8.1.2.0 |
| 3.3.24 | March 25th, 2025 | ucda: sha256:d9ef53f0653e182c847afb5bb3bcbaf1e8f788148e67e2d7baa6261ce3a8d7f6 | None | Version 8.1.1.0 |
| 3.3.23 | January 28th, 2025| ucda: sha256:2e76fa49a4fa4bd35e212180be0a7200cf42d8f8d5fe56e6b2cee52b6356ca22 | None | Version 8.1.0.1 |
| 3.3.22 | November 26th, 2024| ucda: sha256:2777d346c011fe2992185d4f128a9fa1470f1e859863601828e2843c770da83c | None | Version 8.1.0.0 |
| 3.3.21 | June 25th, 2024 | ucda: sha256:bb57fbee54fc77cbc7fb87bd1fdfdcfc5796b4e5d295db00e7b0bde5562d97ba | None | Version 8.0.1.2 |
| 3.3.20 | May 14th, 2024 | ucda: sha256:01ad7a8ab4c119c298a7700579b2467bb9d1c6f7f8c2af17b97cd663930b22f8 | None | Version 8.0.1.1 |
| 3.3.19 | April 2nd, 2024 | ucda: sha256:e39f7a17558de69c79eb57a460e120d56400d4e7a3e95c7fb2876224f7497f6e | None | Version 8.0.1.0 |
| 3.3.18 | January 30th, 2024 | ucda: sha256:46b43b0356d2da49a9cc3e6df7460bd054513476bc990b1ca10add924f196bb2 | None | Version 8.0.0.1 |
| 3.3.17 | December 19th, 2023 | ucda: sha256:c08816c74c87defd714fdae7d371c0c61fd8f83b70ee4bbdb1da389967aeac6e | None | Version 8.0.0.0 |
| 3.3.16 | September 26th, 2023 | ucda: sha256:3082dda74b62e2078fb1f713ec9c6fb8d17c288cb38d985244101f7157d7f062 | None | Version 7.3.2.2 |
| 3.3.15 | August 15th, 2023 | ucda: sha256:079e016417bb08463d6dfba77e607a267e513659614f26411af9cbdb50076f6d | None | Version 7.3.2.1 |
| 3.3.14 | July 13th, 2023 | ucda: sha256:83193cfddb653d82dbcce74ca05caa7cae60fdfd2cca72904a0afc232cc2ff6f | None | Version 7.3.2.0 |
| 3.3.13 | May 2nd, 2023 | ucda: sha256:150c0dbe81dd5b748f5d4948187eefc7ff71265b3fe1f7a87f0d1f5606eed6a4 | None | Version 7.3.1.1 |
| 3.3.12 | April 4th, 2023 | ucda: sha256:d47d186a8b96a60de38491fc4bb08f14c79a6399b840f97712fd631570572cae | None | Version 7.3.1.0 |
| 3.3.11 | December 13th, 2022 | ucda: sha256:24af54f221f11e93b5abc9207d085c75f45a5551e947dc6b1c272ffff9128edb | None | Version 7.3.0.1 |
| 3.3.10 | November 22nd, 2022 | ucda: sha256:ed9ad59e0a4c31f9a08e3364bbfdb14bc3f4d88e49848df20369876e67521d89 | None | Version 7.3.0.0 |
| 3.3.9 | July 26th, 2022 | ucda: sha256:050f2a8df044a87c07758dd8218bef59114ccee7f0ad1aaae56db97e5c4b9944 | None | Version 7.2.3.1 |
| 3.3.8 | June 28th, 2022 | ucda: sha256:e1fa2b9e71432ce94bf7b55b60ba64e95abfaae35cd4812e1ac3f5b66be6e578 | None | Version 7.2.3.0 |
| 3.3.7 | April 19th, 2022 | ucda: sha256:6ce0ed9c560469983be172e9f9e8aaa5d32923b24ef031cf175bfebfb27ff6f4 | None | Version 7.2.2.1 |
| 3.3.6 | March 22nd, 2022 | ucda: sha256:04b58b16d77ad6fa4117e361034d4cb7d2ccc5417ccfe77d9870adb4646c88fa | None | Version 7.2.2.0 |
| 3.3.5 | January 18th, 2022 | ucda: sha256:0f70c7a15b76bebf0fa7211d196fd7243c2968bff8aeb23bb79e1e0f41273a43 | None | Version 7.2.1.2 |
| 3.3.4 | December 14th, 2021 | ucda: sha256:51fa7da8873c3dff180739c3180ff2f5e812fbbac8541c28cfcece1763a9fc31 | None | Version 7.2.1.1 |
| 3.3.3 | November 2nd, 2021 | ucda: sha256:9251f7d9caacd3fadd3fe1fb2ee4a77413ac62083184fcccdaff14de95342e02 | None | Version 7.2.1.0 |
| 3.3.2 | September 7th, 2021 | ucda: sha256:645a21a9668d0cb1b50e5514208224ee193215a6ae46a1f6475c52ec93101da1 | None | Version 7.2.0.2 |
| 3.3.1 | August 3rd, 2021 | ucda: sha256:8ae16aabe832e0cd0ac9a671636bff82cfe6bdb69fedfdc85cc01e03863f61f6 | None | Version 7.2.0.1 |
| 3.3.0 | July 6th, 2021 | ucda: sha256:c26cc9113198194ac4ed59c456652c4bf98f795e8d699a57d22e28f3a81a3c99 | None | Version 7.2.0.0 |
| 3.2.1 | April 20th, 2021 | ucda: sha256:76ddedef53b5b5f6f5f72d1f14068967b133b04ad4018df014b1228f5eb259a3 | None | Version 7.1.2.1 |
| 3.2.0 | March 30th, 2021 | ucda: sha256:366642772a2e84decfcbeda42745494f23a494d24248f838a00e8f2139a122d8 | None | Version 7.1.2.0 |
| 3.1.2 | January 12th, 2021 | ucda: sha256:0bf58dc592ca7127fec75148df8ba92f29a55e072c6b056e534ab1ab0695709c | None | Version 7.1.1.2 |
| 3.1.1 | Nov 24th, 2020 | ucda: sha256:8a3c5815cdfc7852a74fb62ba5c4a954246a17a6947cefc561f29de2181081ae | None | Version 7.1.1.1 |
| 3.1.0 | Nov 3rd, 2020 | ucda: sha256:6b34cf4a0ce9b2f6398ea2bb41e8d614bba7befe8f5cbdce6d06d78c9207042d | None | Version 7.1.1.0 |
| 3.0.4 | September 15th, 2020 | ucda: 7.1.0.3.1069281 | None | Version 7.1.0.3 |
| 3.0.3 | August 18th, 2020 | ucda: 7.1.0.2.1063225 | None | Version 7.1.0.2 |
| 3.0.2 | July 21st, 2020 | ucda: 7.1.0.1.ifix01.1062130 | None | Version 7.1.0.1.ifix01 |
| 3.0.1 | June 23rd, 2020 | ucda: 7.1.0.0.1058690 | None | Version 7.1.0.0 |
| 2.1.9 | March 24th, 2020 | ucda: 7.0.5.2.1050384 | None | Version 7.0.5.2 added user specified PVC containing additional utilties programs the agent can execute |
| 2.1.8 | February 11th, 2020 | ucda: 7.0.5.1.1044461 | None | Version 7.0.5.1 added oc and git CLI utilities |
| 2.1.7 | January 14th, 2020 | ucda: 7.0.5.0.1041488 | None | Version 7.0.5.0  |
| 2.1.6 | December 4th, 2019| ucda: 7.0.4.2.1038002 | None | Version 7.0.4.2  |
| 2.1.5 | November 5th, 2019| ucda: 7.0.4.1.1036185 | None | Support for latest UCD Server Release  |
| 2.1.0 | October 1st, 2019 | ucda: 7.0.4.0.1034011 | None | Support for latest UCD Server Release |
| 2.0.0 | September 3rd, 2019 | ucda: 7.0.3.3.1031820 | None | Support for latest UCD Server Release |
| 1.0.8 | August 6th, 2019 | ucda: 7.0.3.2.1028848 | None | Support for latest UCD Server Release |
| 1.0.7 | July 2nd, 2019 | ucda: 7.0.3.1.1026877 | None | Support for latest UCD Server Release |
| 1.0.6 | June 11th, 2019 | ucda: 7.0.3.0.1025086 | None | Support for latest UCD Server Release |
| 1.0.5 | May 7th, 2019 | ucda: 7.0.2.3.1021487 | None | Support for latest UCD Server Release |
| 1.0.4 | March 12th, 2019| ucda: 7.0.2.2.1017795 | None | Initial Release  |
