{{/*
Return the list of namespaces the operator should watch:
- Always starts with tetheredNamespaces (if any)
- Adds instanceNamespace if set
- Prepends operatorNamespace if set
*/}}
{{- define "db2aaservice.watchNamespaces" -}}
  {{- $watchNamespaces := default (list) .Values.global.tetheredNamespaces -}}

  {{- if .Values.global.instanceNamespace }}
    {{- $watchNamespaces = append $watchNamespaces .Values.global.instanceNamespace }}
  {{- end }}

  {{- if .Values.global.operatorNamespace }}
    {{- $watchNamespaces = prepend $watchNamespaces .Values.global.operatorNamespace }}
  {{- end }}

  {{- $watchNamespaces | toYaml }}
{{- end }}