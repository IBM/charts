{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "ibm-eem-operator.fullname" -}}
{{- $name := default .Chart.Name }}
{{- printf "%s" $name | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "ibm-eem-operator.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "ibm-eem-operator.labels" -}}
{{- if not .Values.olm }}
helm.sh/chart: {{ include "ibm-eem-operator.chart" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}
{{ include "ibm-eem-operator.selectorLabels" . }}
{{- if .Chart.Version }}
app.kubernetes.io/version: {{ .Chart.Version | quote }}
{{- end }}
{{- end }}

{{/*
Common annotations
*/}}
{{- define "ibm-eem-operator.annotations" -}}
productID: "682b6db3fed247a098d85da5ab905b46"
productName: "IBM Event Automation"
productVersion: {{ .Chart.Version | quote }}
productMetric: "FREE"
productChargedContainers: ""
{{- end }}


{{/*
Selector labels
*/}}
{{- define "ibm-eem-operator.selectorLabels" -}}
app.kubernetes.io/name: ibm-event-endpoint-management
app.kubernetes.io/instance: {{ .Chart.Name | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Pod Security Context
*/}}
{{- define "ibm-eem-operator.podSecurityContext" -}}
runAsNonRoot: true
{{- end }}
