{{/*
CDC HELM Chart Helper Templates
These templates provide reusable logic for the CDC chart
*/}}

{{/*
Return the chart name for use in labels.
This is always the chart name (e.g., "cdc-replication").
*/}}
{{- define "cdc.name" -}}
{{- .Chart.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
Uses Release.Name directly as the CDC instance identifier.
Chart name is reflected in labels (app.kubernetes.io/name), not resource names.
This keeps resource names short and user-controlled.
*/}}
{{- define "cdc.fullname" -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "cdc.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Return the CDC instance name.
Fixed container constant - not configurable (must match IBMCDC constant in container runtime).
Single source of truth for all configmap templates.
*/}}
{{- define "cdc.instanceName" -}}
{{- "IBMCDC" -}}
{{- end -}}

{{/*
Return the CDC TCP listener port.
Fixed container constant (11701) - single source of truth for the container port and
all configmap <tcpPort> elements. Independent of service.port.
*/}}
{{- define "cdc.tcpPort" -}}
{{- 11701 -}}
{{- end -}}

{{/*
Return the root base path for external container mounts.
Fixed container constant - matches the CDC mount staging root /opt/ibm/mount.
*/}}
{{- define "cdc.mountBasePath" -}}
{{- "/opt/ibm/mount" -}}
{{- end -}}

{{/*
Return the base path for config file mounts.
Fixed container constant - matches the CDC mount staging layout under /opt/ibm/mount/conf.
*/}}
{{- define "cdc.configFilesBasePath" -}}
{{- printf "%s/conf" (include "cdc.mountBasePath" .) -}}
{{- end -}}

{{/*
Return the base path for secret file mounts.
Fixed container constant - matches the CDC mount staging layout under /opt/ibm/mount/secrets.
*/}}
{{- define "cdc.secretFilesBasePath" -}}
{{- printf "%s/secrets" (include "cdc.mountBasePath" .) -}}
{{- end -}}

{{/*
Return the base path for TLS security mounts.
Fixed container constant - matches the CDC mount staging layout under /opt/ibm/mount/security.
*/}}
{{- define "cdc.securityFilesBasePath" -}}
{{- printf "%s/security" (include "cdc.mountBasePath" .) -}}
{{- end -}}

{{/*
Convert productType to uppercase for CDC internal use
CDC expects UPPERCASE product type constants
*/}}
{{- define "cdc.productTypeUpper" -}}
{{- .Values.productType | upper -}}
{{- end -}}

{{/*
Get product-specific configuration
Returns the entire configuration block for the selected product type
Uses lowercase productType for values.yaml lookup
*/}}
{{- define "cdc.productConfig" -}}
{{- $productType := .Values.productType -}}
{{- $config := index .Values $productType -}}
{{- toYaml $config -}}
{{- end -}}

{{/*
Get the container image for the selected product type
Uses digest if provided, otherwise falls back to tag
Applies imagePullPrefix from values.yaml
Uses lowercase productType for values.yaml lookup
*/}}
{{- define "cdc.image" -}}
{{- $productType := .Values.productType -}}
{{- $config := index .Values $productType -}}
{{- $fullImage := printf "%s/%s" .Values.common.imagePullPrefix $config.image.name -}}
{{- if $config.image.digest -}}
{{- printf "%s@%s" $fullImage $config.image.digest -}}
{{- else -}}
{{- printf "%s:%s" $fullImage $config.image.tag -}}
{{- end -}}
{{- end -}}

{{/*
Get environment variables for the selected product type
Merges common envVars with product-specific envVars
Uses lowercase productType for values.yaml lookup
*/}}
{{- define "cdc.envVars" -}}
{{- $productType := .Values.productType -}}
{{- $config := index .Values $productType -}}
{{- $allEnvVars := concat .Values.common.envVars ($config.envVars | default list) -}}
{{- toYaml $allEnvVars -}}
{{- end -}}

{{/*
Returns the container resource requests/limits block from .Values.resources
*/}}
{{- define "cdc.resources" -}}
{{- toYaml .Values.resources -}}
{{- end -}}

{{/*
Calculate JVM memory in MB based on container memory limit and percentage
Supports both Gi and Mi units
Returns memory in MB as an integer
Usage: {{ include "cdc.calculateMemoryMB" . }}
*/}}
{{- define "cdc.calculateMemoryMB" -}}
{{- $memoryLimit := .Values.resources.limits.memory -}}
{{- $memoryPercentage := .Values.common.memoryPercentage | default 50 -}}
{{- $memoryMB := 0 -}}
{{- if hasSuffix "Gi" $memoryLimit -}}
  {{- $memoryLimitGi := trimSuffix "Gi" $memoryLimit | atoi -}}
  {{- $memoryMB = div (mul (mul $memoryLimitGi 1024) $memoryPercentage) 100 -}}
{{- else if hasSuffix "Mi" $memoryLimit -}}
  {{- $memoryLimitMi := trimSuffix "Mi" $memoryLimit | atoi -}}
  {{- $memoryMB = div (mul $memoryLimitMi $memoryPercentage) 100 -}}
{{- end -}}
{{- $memoryMB -}}
{{- end -}}

{{/*
Calculate staging store disk quota in Gi based on persistent volume size
Returns size in Gi as an integer
Usage: {{ include "cdc.calculateStagingStoreGi" . }}
*/}}
{{- define "cdc.calculateStagingStoreGi" -}}
{{- $pvSize := .Values.persistence.size -}}
{{- if hasSuffix "Gi" $pvSize -}}
{{- trimSuffix "Gi" $pvSize -}}
{{- else if hasSuffix "Ti" $pvSize -}}
{{- mul (trimSuffix "Ti" $pvSize | atoi) 1024 -}}
{{- else if hasSuffix "Mi" $pvSize -}}
{{- div (trimSuffix "Mi" $pvSize | atoi) 1024 -}}
{{- end -}}
{{- end -}}

{{/*
Common labels — applied to all chart resources (StatefulSet, Service, ServiceAccount, etc.)
app.kubernetes.io/component is a fixed tier constant identifying this chart's role.
cdc.ibm.com/product-type carries the runtime product (udb, kafka, postgresql, etc.).
license-accepted is intentionally omitted: cdc.validateLicense fails the install if not
true, so acceptance is guaranteed by the time any resource is created.
*/}}
{{- define "cdc.labels" -}}
app.kubernetes.io/name: {{ include "cdc.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/component: replication-engine
cdc.ibm.com/product-type: {{ .Values.productType }}
cdc.ibm.com/license-type: {{ .Values.license.type | quote }}
{{- end -}}

{{/*
PVC labels — applied to volumeClaimTemplates metadata.
Intentionally omits app.kubernetes.io/version (PVC labels are immutable; version
changes on every release would require PVC deletion to update).
app.kubernetes.io/managed-by is omitted — Helm stamps it automatically.
cdc.ibm.com/license-type is omitted: license type can change on upgrade/renewal and PVC
labels cannot be updated without deleting the PVC, which would destroy replication state.
license-accepted is omitted for the same reason as cdc.labels above.
*/}}
{{- define "cdc.pvcLabels" -}}
app.kubernetes.io/name: {{ include "cdc.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: replication-engine
cdc.ibm.com/product-type: {{ .Values.productType }}
{{- end -}}

{{/*
Selector labels
Uses standard Kubernetes labels for pod selection
*/}}
{{- define "cdc.selectorLabels" -}}
app.kubernetes.io/name: {{ include "cdc.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/*
Create the name of the service account to use
*/}}
{{- define "cdc.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
{{- default (include "cdc.fullname" .) .Values.serviceAccount.name -}}
{{- else -}}
{{- default "default" .Values.serviceAccount.name -}}
{{- end -}}
{{- end -}}
{{/*
=============================================================================
VALIDATION HELPERS
These templates validate configuration and provide user-friendly error messages
=============================================================================
*/}}

{{/*
Validate productType
*/}}
{{- define "cdc.validateProductType" -}}
{{- $validTypes := list "udb" "db2z" "postgresql" "mysql" "mssql" "sybase" "oraredo" "oratrigger" "oraxstream" "ds" "td" "es" "informix" "netezza_cdc" "netezza_rs" "sql92" "kafka" "mariadb" "bigquery" "watsonx" "mongodb" "iceberg" -}}
{{- if not (has .Values.productType $validTypes) -}}
{{- fail (printf "\n\nERROR: Invalid productType '%s'\n\nValid options (lowercase, will be uppercased internally for CDC):\n  Sources: udb, db2z, postgresql, mysql, mssql, sybase, oraredo, oratrigger, oraxstream, informix, mariadb\n  Targets: kafka, bigquery, watsonx, mongodb, iceberg, ds, td, es, sql92, netezza_cdc, netezza_rs\n\nExample:\n  helm install cdc ./cdc-replication --set productType=kafka\n" .Values.productType) -}}
{{- end -}}
{{- end -}}

{{/*
Validate required secrets exist
*/}}
{{- define "cdc.validateSecrets" -}}
{{- /* Guard: secrets: null in an override file wipes all values.yaml defaults. */ -}}
{{- if not .Values.secrets -}}
{{- fail "ERROR: secrets is null. This happens when secrets: or secrets: ~ appears in your values file with no sub-keys. Either remove the secrets: key entirely to use the chart defaults, or provide explicit sub-key configuration. Refer to the chart documentation for supported configuration options." -}}
{{- end -}}
{{- if not .Values.secrets.secretName -}}
{{- fail "\n\nERROR: secrets.secretName is required\n\nCreate a secret first:\n  kubectl create secret generic cdc-db-credentials \\\n    --from-literal=username=cdcuser \\\n    --from-literal=password=yourpassword\n\nThen set in values:\n  secrets:\n    secretName: cdc-db-credentials\n\n  Or via command line:\n  helm install cdc ./cdc-replication \\\n    --set secrets.secretName=cdc-db-credentials\n" -}}
{{- end -}}
{{- end -}}

{{/*
Validate TLS configuration
*/}}
{{- define "cdc.validateTLS" -}}
{{- /* Guard: tls: null in an override file wipes all values.yaml defaults. */ -}}
{{- if not .Values.tls -}}
{{- fail "ERROR: tls is null. This happens when tls: or tls: ~ appears in your values file with no sub-keys. Either remove the tls: key entirely to use the chart defaults, or provide explicit sub-key configuration. Refer to the chart documentation for supported configuration options." -}}
{{- end -}}
{{- if ne .Values.tls.enablement "disabled" -}}
{{- if not .Values.tls.secretName -}}
{{- fail (printf "ERROR: TLS is enabled (tls.enablement=%s) but tls.secretName is not set" .Values.tls.enablement) -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Validate memory configuration.
Normalises both values to Mi before comparing so cross-unit pairs (e.g. 8Gi
requests vs 512Mi limit) are caught correctly.
*/}}
{{- define "cdc.validateMemory" -}}
{{- /* Guard: resources: null in an override file wipes all values.yaml defaults. */ -}}
{{- if not .Values.resources -}}
{{- fail "ERROR: resources is null. This happens when resources: or resources: ~ appears in your values file with no sub-keys. Either remove the resources: key entirely to use the chart defaults, or provide explicit sub-key configuration. Refer to the chart documentation for supported configuration options." -}}
{{- end -}}
{{- $reqRaw := .Values.resources.requests.memory -}}
{{- $limRaw := .Values.resources.limits.memory -}}
{{- $reqMi := 0 -}}
{{- $limMi := 0 -}}
{{- if hasSuffix "Gi" $reqRaw -}}
  {{- $reqMi = mul (trimSuffix "Gi" $reqRaw | atoi) 1024 -}}
{{- else if hasSuffix "Mi" $reqRaw -}}
  {{- $reqMi = trimSuffix "Mi" $reqRaw | atoi -}}
{{- end -}}
{{- if hasSuffix "Gi" $limRaw -}}
  {{- $limMi = mul (trimSuffix "Gi" $limRaw | atoi) 1024 -}}
{{- else if hasSuffix "Mi" $limRaw -}}
  {{- $limMi = trimSuffix "Mi" $limRaw | atoi -}}
{{- end -}}
{{- if and (gt $reqMi 0) (gt $limMi 0) (gt $reqMi $limMi) -}}
{{- fail (printf "ERROR: Memory requests (%s) cannot exceed limits (%s)" $reqRaw $limRaw) -}}
{{- end -}}
{{- end -}}

{{/*
Validate CPU configuration
*/}}
{{- define "cdc.validateCPU" -}}
{{- /* Guard: resources: null — validateMemory fires first but guard here for defence-in-depth. */ -}}
{{- if not .Values.resources -}}
{{- fail "ERROR: resources is null. This happens when resources: or resources: ~ appears in your values file with no sub-keys. Either remove the resources: key entirely to use the chart defaults, or provide explicit sub-key configuration. Refer to the chart documentation for supported configuration options." -}}
{{- end -}}
{{- $requestsCPU := .Values.resources.requests.cpu | trimSuffix "m" | float64 -}}
{{- $limitsCPU := .Values.resources.limits.cpu | trimSuffix "m" | float64 -}}
{{- if gt $requestsCPU $limitsCPU -}}
{{- fail (printf "ERROR: CPU requests (%s) cannot exceed limits (%s)" .Values.resources.requests.cpu .Values.resources.limits.cpu) -}}
{{- end -}}
{{- end -}}

{{/*
Validate license configuration
*/}}
{{- define "cdc.validateLicense" -}}
{{- if not .Values.license.accept -}}
{{- fail "\n\nERROR: License must be accepted before deployment\n\nYou must explicitly accept the license terms:\n  license:\n    accept: true\n    type: IDRAI\n\n  Or via command line:\n  helm install cdc ./cdc-replication \\\n    --set license.accept=true \\\n    --set license.type=IDRAI\n\nReview license terms at:\n  https://www.ibm.com/software/sla/sladb.nsf\n" -}}
{{- end -}}
{{- if not .Values.license.type -}}
{{- fail "\n\nERROR: License type must be specified\n\nValid license types:\n  - IDRAI  (IBM Data Replication AI Edition)\n  - IDRAIZ (IBM Data Replication AI Edition for z/OS)\n\nExample:\n  license:\n    accept: true\n    type: IDRAI\n\n  Or via command line:\n  helm install cdc ./cdc-replication \\\n    --set license.accept=true \\\n    --set license.type=IDRAI\n" -}}
{{- end -}}
{{- $validLicenses := list "IDRAI" "IDRAIZ" -}}
{{- if not (has .Values.license.type $validLicenses) -}}
{{- fail (printf "\n\nERROR: Invalid license type '%s'\n\nValid license types:\n  - IDRAI  (IBM Data Replication AI Edition)\n  - IDRAIZ (IBM Data Replication AI Edition for z/OS)\n\nExample:\n  helm install cdc ./cdc-replication \\\n    --set license.accept=true \\\n    --set license.type=IDRAI\n" .Values.license.type) -}}
{{- end -}}
{{- end -}}

{{/*
Validate persistence configuration
*/}}
{{- define "cdc.validatePersistence" -}}
{{- if not .Values.persistence.blockStorageClass -}}
{{- fail "\n\nERROR: persistence.blockStorageClass is required\n\nCDC requires a block storage class for its data PVC. Specify the storage class:\n  persistence:\n    blockStorageClass: nfs-client\n\n  Or via command line:\n  helm install cdc ./cdc-replication \\\n    --set persistence.blockStorageClass=nfs-client\n\nRun `kubectl get storageclass` to list available classes in your cluster.\n" -}}
{{- end -}}
{{- if not .Values.persistence.size -}}
{{- fail "\n\nERROR: persistence.size is required\n\nPersistent storage is mandatory for CDC. Specify the volume size:\n  persistence:\n    size: 10Gi\n\n  Or via command line:\n  helm install cdc ./cdc-replication \\\n    --set persistence.size=10Gi\n" -}}
{{- end -}}
{{- if not (regexMatch "^[0-9]+(Gi|Mi|Ti)$" .Values.persistence.size) -}}
{{- fail (printf "\n\nERROR: Invalid persistence.size '%s'\n\nSize must be specified with unit (Gi, Mi, or Ti):\n  Valid examples:\n    - 10Gi\n    - 100Gi\n    - 1Ti\n\nExample:\n  helm install cdc ./cdc-replication \\\n    --set persistence.size=10Gi\n" .Values.persistence.size) -}}
{{- end -}}
{{- end -}}

{{/*
=============================================================================
VOLUME AND MOUNT HELPERS
These templates generate volume mounts and volumes based on configuration
=============================================================================
*/}}

{{/*
Generate environment variables from product-specific secrets
Iterates over secrets.keys and creates env vars for keys with asEnvVar set
Usage: {{ include "cdc.secretEnvVars" . | nindent 8 }}
*/}}
{{- define "cdc.secretEnvVars" -}}
{{- $productConfig := index .Values .Values.productType -}}
{{- $secretName := .Values.secrets.secretName -}}
{{- if $secretName -}}
{{- with $productConfig.secrets.keys -}}
{{- range $keyName, $keyConfig := . -}}
{{- if $keyConfig.asEnvVar }}
- name: {{ $keyConfig.asEnvVar }}
  valueFrom:
    secretKeyRef:
      name: {{ $secretName }}
      key: {{ $keyName }}
      optional: true
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Generate extra config files data for ConfigMaps (e.g. kafka, oracle)
Usage: {{- include "cdc.extraConfigFiles" . | nindent 2 }}
*/}}
{{- define "cdc.extraConfigFiles" -}}
{{- with (index .Values .Values.productType).extraConfigFiles }}
{{- range $filename, $content := . }}
{{ $filename }}: |
{{ $content | indent 4 }}
{{- end }}
{{- end }}
{{- end -}}

{{/*
Generate volume mounts for config files
Auto-generates mounts for each file in extraConfigFiles
Usage: {{ include "cdc.configFileMounts" . | nindent 8 }}
*/}}
{{- define "cdc.configFileMounts" -}}
{{- $productConfig := index .Values .Values.productType -}}
{{- with $productConfig.extraConfigFiles -}}
{{- range $filename, $content := . }}
- name: cdc-config
  mountPath: {{ include "cdc.configFilesBasePath" $ }}/{{ $filename }}
  subPath: {{ $filename }}
  readOnly: true
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Generate volume mounts for secret files
Auto-generates mounts for secrets with asFile=true
Usage: {{ include "cdc.secretFileMounts" . | nindent 8 }}
*/}}
{{- define "cdc.secretFileMounts" -}}
{{- $productConfig := index .Values .Values.productType -}}
{{- $secretName := .Values.secrets.secretName -}}
{{- if $secretName -}}
{{- with $productConfig.secrets.keys -}}
{{- range $keyName, $keyConfig := . -}}
{{- if $keyConfig.asFile }}
- name: cdc-secrets
  mountPath: {{ include "cdc.secretFilesBasePath" $ }}/{{ $keyName }}
  subPath: {{ $keyName }}
  readOnly: true
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Generate volumes section
Creates all required volumes including ConfigMaps, Secrets, and product-specific volumes
Usage: {{ include "cdc.volumes" . | nindent 6 }}
*/}}
{{- define "cdc.volumes" -}}
- name: cdc-runtime
  emptyDir: {}
- name: cdc-config
  configMap:
    name: {{ include "cdc.fullname" . }}-{{ .Values.productType }}-config
{{- if ne .Values.tls.enablement "disabled" }}
- name: cdc-tls-keystore
  secret:
    secretName: {{ .Values.tls.secretName }}
    optional: true
    items:
      - key: keystore
        path: keystore
{{- end }}
{{- if .Values.tls.secretName }}
- name: cdc-tls-truststore
  secret:
    secretName: {{ .Values.tls.secretName }}
    optional: true
    items:
      - key: truststore
        path: truststore
{{- end }}
{{- if .Values.secrets.secretName }}
- name: cdc-secrets
  secret:
    secretName: {{ .Values.secrets.secretName }}
{{- end }}
{{- with (index .Values .Values.productType).extraVolumes }}
{{- toYaml . | nindent 0 }}{{/* nindent 0: items must sit at column 0 here; the caller applies | nindent 6 to the whole helper output, supplying the actual indentation */}}
{{- end -}}
{{- end -}}


{{/*
Validate the common section is not null.
common: ~ wipes imagePullPrefix, imagePullPolicy, envVars, and memoryPercentage,
causing nil-pointer panics in cdc.image, cdc.envVars, and cdc.calculateMemoryMB.
common is also added to the schema required array so this guard acts as a
belt-and-suspenders fallback with a better error message than the schema produces.
*/}}
{{- define "cdc.validateCommon" -}}
{{- if not .Values.common -}}
{{- fail "ERROR: common is null. This happens when common: or common: ~ appears in your values file with no sub-keys. Either remove the common: key entirely to use the chart defaults, or provide explicit sub-key configuration. Refer to the chart documentation for supported configuration options." -}}
{{- end -}}
{{- end -}}

{{/*
Validate the instance section is not null.
instance: ~ wipes overrideTargetTables, dbLoginMethod, properties, and all
database connection fields, causing nil-pointer panics in every configmap template.
*/}}
{{- define "cdc.validateInstance" -}}
{{- if not .Values.instance -}}
{{- fail "ERROR: instance is null. This happens when instance: or instance: ~ appears in your values file with no sub-keys. Either remove the instance: key entirely to use the chart defaults, or provide explicit sub-key configuration. Refer to the chart documentation for supported configuration options." -}}
{{- end -}}
{{- if kindIs "invalid" .Values.instance.dbParams -}}
{{- fail "ERROR: instance.dbParams is null. This happens when dbParams: or dbParams: ~ appears in your values file with no sub-keys. Either remove the dbParams: key entirely to use the chart defaults ({}), or provide explicit key-value pairs. Example:\n  instance:\n    dbParams:\n      sslConnection: \"true\"" -}}
{{- end -}}
{{- end -}}

{{/*
Validate the podSpec section is not null.
podSpec: ~ wipes hostNetwork, hostPID, and hostIPC defaults (all false),
causing a nil-pointer panic when the statefulset template accesses these fields.
*/}}
{{- define "cdc.validatePodSpec" -}}
{{- if not .Values.podSpec -}}
{{- fail "ERROR: podSpec is null. This happens when podSpec: or podSpec: ~ appears in your values file with no sub-keys. Either remove the podSpec: key entirely to use the chart defaults, or provide explicit sub-key configuration. Refer to the chart documentation for supported configuration options." -}}
{{- end -}}
{{- end -}}

{{/*
Validate the podSecurityContext section is not null.
podSecurityContext: ~ wipes runAsNonRoot and any configured runAsUser/fsGroup,
causing a nil-pointer panic when the statefulset template accesses these fields.
*/}}
{{- define "cdc.validatePodSecurityContext" -}}
{{- if not .Values.podSecurityContext -}}
{{- fail "ERROR: podSecurityContext is null. This happens when podSecurityContext: or podSecurityContext: ~ appears in your values file with no sub-keys. Either remove the podSecurityContext: key entirely to use the chart defaults, or provide explicit sub-key configuration. Refer to the chart documentation for supported configuration options." -}}
{{- end -}}
{{- end -}}

{{/*
Validate the securityContext section is not null.
securityContext: ~ causes toYaml to render "null" as the container securityContext,
silently dropping all security constraints (privileged: false,
allowPrivilegeEscalation: false, capabilities.drop: ALL) with no error.
*/}}
{{- define "cdc.validateSecurityContext" -}}
{{- if not .Values.securityContext -}}
{{- fail "ERROR: securityContext is null. This happens when securityContext: or securityContext: ~ appears in your values file with no sub-keys. Either remove the securityContext: key entirely to use the chart defaults, or provide explicit sub-key configuration. Refer to the chart documentation for supported configuration options." -}}
{{- end -}}
{{- end -}}

{{/*
Validate the serviceAccount section is not null.
A plain `serviceAccount:` or `serviceAccount: ~` in an override file wipes all
values.yaml defaults, causing .Values.serviceAccount.create to be nil and the
serviceAccountName helper to panic.
*/}}
{{- define "cdc.validateServiceAccount" -}}
{{- /* Guard: serviceAccount: null in an override file wipes all values.yaml defaults. */ -}}
{{- if not .Values.serviceAccount -}}
{{- fail "ERROR: serviceAccount is null. This happens when serviceAccount: or serviceAccount: ~ appears in your values file with no sub-keys. Either remove the serviceAccount: key entirely to use the chart defaults, or provide explicit sub-key configuration. Refer to the chart documentation for supported configuration options." -}}
{{- end -}}
{{- end -}}

{{/*
=============================================================================
MASTER VALIDATION
Orchestrates all validation checks - must be at end since it calls other helpers
=============================================================================
*/}}

{{/*
Master validation - calls all validation helpers
This should be the last helper in the file since it depends on all validation helpers above
Usage: {{- include "cdc.validate" . -}} at the top of templates that need validation
*/}}
{{- define "cdc.validate" -}}
{{- include "cdc.validateLicense" . -}}
{{- include "cdc.validateProductType" . -}}
{{- include "cdc.validateCommon" . -}}
{{- include "cdc.validateSecrets" . -}}
{{- include "cdc.validateTLS" . -}}
{{- include "cdc.validateMemory" . -}}
{{- include "cdc.validateCPU" . -}}
{{- include "cdc.validateInstance" . -}}
{{- include "cdc.validatePodSpec" . -}}
{{- include "cdc.validatePodSecurityContext" . -}}
{{- include "cdc.validateSecurityContext" . -}}
{{- include "cdc.validateServiceAccount" . -}}
{{- include "cdc.validatePersistence" . -}}
{{- end -}}
