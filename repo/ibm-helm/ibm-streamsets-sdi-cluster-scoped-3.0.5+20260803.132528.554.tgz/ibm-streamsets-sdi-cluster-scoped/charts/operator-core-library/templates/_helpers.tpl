{{/*
Common validation for namespace requirements
Usage: {{ include "operator-core-library.validate" . }}
*/}}
{{- define "operator-core-library.validate" -}}
{{- $operatorNs := required "global.operatorNamespace is required" .Values.global.operatorNamespace -}}
{{- $instanceNs := required "global.instanceNamespace is required" .Values.global.instanceNamespace -}}
{{- end -}}

{{/*
Get operator registry prefix
Usage: {{ include "operator-core-library.operatorRegistry" (dict "root" . "config" .Values.streamsets) }}
*/}}
{{- define "operator-core-library.operatorRegistry" -}}
{{- $root := .root -}}
{{- $config := .config -}}
{{- if $config.devImagePullPrefix -}}
{{- $config.devImagePullPrefix -}}
{{- else if eq $root.Values.global.imagePullPrefix "icr.io" -}}
cp.icr.io
{{- else if $root.Values.global.imagePullPrefix -}}
{{- $root.Values.global.imagePullPrefix -}}
{{- else -}}
icr.io
{{- end -}}
{{- end -}}

{{/*
Get operand registry prefix with fallback logic
Usage: {{ include "operator-core-library.operandRegistry" (dict "root" . "config" .Values.streamsets) }}
*/}}
{{- define "operator-core-library.operandRegistry" -}}
{{- $root := .root -}}
{{- $config := .config -}}
{{- if $config.devImagePullPrefix -}}
{{- $config.devImagePullPrefix -}}
{{- else if $config.operandImagePullPrefix -}}
{{- $config.operandImagePullPrefix -}}
{{- else if eq $root.Values.global.imagePullPrefix "icr.io" -}}
cp.icr.io
{{- else if $root.Values.global.imagePullPrefix -}}
{{- $root.Values.global.imagePullPrefix -}}
{{- else -}}
cp.icr.io
{{- end -}}
{{- end -}}

{{/*
Build operator image reference with digest
Usage: {{ include "operator-core-library.operatorImage" (dict "root" . "config" .Values.streamsets) }}
*/}}
{{- define "operator-core-library.operatorImage" -}}
{{- $root := .root -}}
{{- $config := .config -}}
{{- $arch := required "global.arch is required" $root.Values.global.arch -}}
{{- $operatorRegistry := include "operator-core-library.operatorRegistry" . -}}
{{- $digest := index $config.operatorImageDigest $arch -}}
{{- if not $digest -}}
{{- fail (printf "Missing operatorImageDigest.%s" $arch) -}}
{{- end -}}
{{- printf "%s/%s@%s" $operatorRegistry $config.operatorImageName $digest -}}
{{- end -}}

{{/*
Calculate watch namespaces (operator, instance, and tethered)
Usage: {{ include "operator-core-library.watchNamespaces" . }}
*/}}
{{- define "operator-core-library.watchNamespaces" -}}
{{- $operatorNs := .Values.global.operatorNamespace -}}
{{- $instanceNs := .Values.global.instanceNamespace -}}
{{- $tetheredNs := .Values.global.tetheredNamespaces | default (list) -}}
{{- $namespaces := concat (list $operatorNs $instanceNs) $tetheredNs | compact | uniq -}}
{{- toYaml $namespaces -}}
{{- end -}}

{{/*
Build install config image for migration
Usage: {{ include "operator-core-library.installConfigImage" . }}
*/}}
{{- define "operator-core-library.installConfigImage" -}}
{{- $pullPrefix := (.Values.global.installConfigImagePullPrefix | default .Values.global.imagePullPrefix) -}}
{{- $name := .Values.global.installConfigImageName -}}
{{- if .Values.global.installConfigImageDigest -}}
{{- printf "%s/%s@%s" $pullPrefix $name .Values.global.installConfigImageDigest -}}
{{- else -}}
{{- printf "%s/%s:%s" $pullPrefix $name .Values.global.installConfigImageTag -}}
{{- end -}}
{{- end -}}
