{{/*
upgrade.check only runs on upgrade and ensures the chart is upgrading from a supported chart version
*/}}
{{- define "upgrade.check" -}}
{{- if .Release.IsUpgrade -}}
{{- $minimumVersion := "12.3.1" -}}
{{- if not .Values.previousVersion -}}
{{- $setVersionError := printf "\n\nOn upgrade please set 'previousVersion' field using\n\n  --set previousVersion=<previousVersion>\n\nValue can be retrieved by running\n\n  helm list --filter %s -n %s -o json | jq '.[0].app_version'" .Release.Name .Release.Namespace -}}
{{- fail $setVersionError -}}
{{- end -}}
{{- $var := semver .Values.previousVersion | (semver $minimumVersion ).Compare -}}
{{- if eq $var 1 -}}
{{- $oldVersionError := printf "\n\npreviousVersion set to %s, minimal version allowed to upgrade from is %s, ensure you are upgrading to a valid chart version following the upgrade documentation: https://ibm.github.io/event-automation/es/installing/installing-on-kubernetes/" .Values.previousVersion $minimumVersion -}}
{{- fail $oldVersionError -}}
{{- end -}}
{{- end -}}
{{- end -}}