# Breaking Changes

- None

# Whats new in Helm chart v1.3.33 for IBM Connect:Direct for UNIX v6.3.0.7-iFix021-2026-06-17-iFix021-2026-06-16-iFix014-2026-05-22-iFix008-2026-04-21-iFix000-2026-03-17-iFix000-2026-02-23-iFix027-2026-01-14-iFix021-2025-12-15-iFix011-2025-11-14-iFix000-2025-10-03-iFix012-2025-09-15-iFix008-2025-08-21-iFix000-2025-07-29-iFix000-2025-07-29

- UBI upgrade
- Application issues fixes
- PSIRT fixes

# Fixes

- For Application defect fixes, refer [fixlist.txt](./ibm_cloud_pak/fixlist.txt).

# Prerequisites

Please refer prerequisites section from [README.md](README.md)

# Documentation

Please refer to [README.md](README.md) provided with chart for detailed installation instruction.

# Version History

| Chart  | Date         | Kubernetes Required | OpenShift Required       | Image(s) Supported                                    | Details            |
| ------ | ------------ | ------------------- | ------------------------ | ----------------------------------------------------- | ------------------ | 
| 1.3.0  | May 19, 2023 | >= 1.24             | >=4.10 <=4.12            | cdu6.3_certified_container_6.3.0.0:6.3.0.0_ifix000    | C:D Unix 6.3.0.0   |
| 1.3.1  | Aug 21, 2023 | >= 1.23             | >=4.10 <=4.12            | cdu6.3_certified_container_6.3.0.0:6.3.0.0_ifix016    | C:D Unix 6.3.0.0   |
| 1.3.2  | Oct 30, 2023 | >= 1.23             | >=4.10 <=4.13            | cdu6.3_certified_container_6.3.0.1:6.3.0.1_ifix009    | C:D Unix 6.3.0.1   |
| 1.3.3  | Nov 20, 2023 | >= 1.23             | >=4.10 <=4.13            | cdu6.3_certified_container_6.3.0.1:6.3.0.1_ifix012    | C:D Unix 6.3.0.1   |
| 1.3.4  | Dec 21, 2023 | >= 1.23.0 <1.27     | >=4.10 <=4.13            | cdu6.3_certified_container_6.3.0.2:6.3.0.2_ifix002    | C:D Unix 6.3.0.2   |
| 1.3.5  | Jan 30, 2024 | >= 1.24.0 <1.28     | >=4.11 <=4.14            | cdu6.3_certified_container_6.3.0.2:6.3.0.2_ifix009    | C:D Unix 6.3.0.2   |
| 1.3.6  | Mar 20, 2024 | >= 1.24.0 <1.28     | >=4.11 <=4.14            | cdu6.3_certified_container_6.3.0.2:6.3.0.2_ifix018    | C:D Unix 6.3.0.2   |
| 1.3.7  | Apr 08, 2024 | >= 1.24.0 <1.28     | >=4.11 <=4.14            | cdu6.3_certified_container_6.3.0.2:6.3.0.2_ifix021    | C:D Unix 6.3.0.2   |
| 1.3.8  | May 20, 2024 | >= 1.24.0 <1.29     | >=4.11 <=4.15            | cdu6.3_certified_container_6.3.0.3:6.3.0.3_ifix003    | C:D Unix 6.3.0.3   |
| 1.3.9  | Jul 03, 2024 | >= 1.24.0 <1.30     | >=4.11 <=4.16            | cdu6.3_certified_container_6.3.0.3:6.3.0.3_ifix009    | C:D Unix 6.3.0.3   |
| 1.3.10 | Jul 30, 2024 | >= 1.24.0 <1.30     | >=4.11 <=4.16            | cdu6.3_certified_container_6.3.0.3:6.3.0.3_ifix012    | C:D Unix 6.3.0.3   |
| 1.3.11 | Sep 18, 2024 | >= 1.24.0 <1.30     | >=4.11 <=4.16            | cdu6.3_certified_container_6.3.0.3:6.3.0.3_ifix013    | C:D Unix 6.3.0.3   |
| 1.3.12 | Oct 30, 2024 | >= 1.24.0 <1.30     | >=4.11 <=4.16            | cdu6.3_certified_container_6.3.0.3:6.3.0.3_ifix021    | C:D Unix 6.3.0.3   |
| 1.3.13 | Nov 15, 2024 | >= 1.24.0 <1.30     | >=4.11 <=4.16            | cdu6.3_certified_container_6.3.0.3:6.3.0.3_ifix025    | C:D Unix 6.3.0.3   |
| 1.3.14 | Jan 08, 2025 | >= 1.24.0 <1.30     | >=4.11 <=4.16            | cdu6.3_certified_container_6.3.0.4:6.3.0.4_iFix003	 | C:D Unix 6.3.0.4   |
| 1.3.15 | Mar 06, 2025 | >= 1.24.0 <1.30     | >=4.11 <=4.16            | cdu6.3_certified_container_6.3.0.4:6.3.0.4_iFix015	 | C:D Unix 6.3.0.4   |
| 1.3.16 | Apr 24, 2025 | >= 1.27.0 <1.32     | >=4.14 <=4.17            | cdu6.3_certified_container_6.3.0.4:6.3.0.4_iFix025	 | C:D Unix 6.3.0.4   |
| 1.3.17 | May 27, 2025 | >= 1.27.0 <1.32     | >=4.14 <=4.17            | cdu6.3_certified_container_6.3.0.4:6.3.0.4_iFix030	 | C:D Unix 6.3.0.4   |
| 1.3.18 | Jun 19, 2025 | >= 1.27.0 <1.33     | >=4.14 <=4.18            | cdu6.3_certified_container_6.3.0.4:6.3.0.4_iFix035	 | C:D Unix 6.3.0.4   |
| 1.3.19 | Jul 08, 2025 | >= 1.27.0 <1.33     | >=4.14 <=4.18            | cdu6.3_certified_container_6.3.0.5:6.3.0.5_iFix000	 | C:D Unix 6.3.0.5   |
| 1.3.20 | Jul 30, 2025 | >= 1.27.0 <1.34     | >=4.14 <=4.18            | cdu:6.3.0.5-iFix000-2025-07-29	                 | C:D Unix 6.3.0.5-iFix000-2025-07-29   |
| 1.3.21 | Aug 01, 2025 | >= 1.27.0 <1.34     | >=4.14 <=4.18            | cdu:6.3.0.5-iFix000-2025-07-29	                 | C:D Unix 6.3.0.5-iFix000-2025-07-29   |
| 1.3.22 | Aug 21, 2025 | >= 1.28.0 <1.34     | >=4.15 <=4.19            | cdu:6.3.0.5-iFix008-2025-08-21	                 | C:D Unix 6.3.0.5-iFix008-2025-08-21   |
| 1.3.23 | Sep 16, 2025 | >= 1.28.0 <1.34     | >=4.15 <=4.19            | cdu:6.3.0.5-iFix012-2025-09-15	                 | C:D Unix 6.3.0.5-iFix012-2025-09-15   |
| 1.3.24 | Oct 06, 2025 | >= 1.28.0 <1.34     | >=4.15 <=4.19            | cdu:6.3.0.6-iFix000-2025-10-03	                 | C:D Unix 6.3.0.6-iFix000-2025-10-03   |
| 1.3.25 | Nov 17, 2025 | >= 1.28.0 <1.34     | >=4.15 <=4.19            | cdu:6.3.0.6-iFix011-2025-11-14	                 | C:D Unix 6.3.0.6-iFix011-2025-11-14   |
| 1.3.26 | Dec 17, 2025 | >= 1.28.0 <1.34     | >=4.15 <=4.19            | cdu:6.3.0.6-iFix021-2025-12-15	                 | C:D Unix 6.3.0.6-iFix021-2025-12-15   |
| 1.3.27 | Jan 16, 2026 | >= 1.28.0 <1.34     | >=4.15 <=4.19            | cdu:6.3.0.6-iFix027-2026-01-14	                 | C:D Unix 6.3.0.6-iFix027-2026-01-14   |
| 1.3.28 | Feb 25, 2026 | >= 1.28.0 <1.34     | >=4.15 <=4.19            | cdu:6.3.0.7-iFix000-2026-02-23	                 | C:D Unix 6.3.0.7-iFix000-2026-02-23   |
| 1.3.29 | Mar 18, 2026 | >= 1.28.0           | >=4.15                   | cdu:6.3.0.7-iFix000-2026-03-17	                 | C:D Unix 6.3.0.7-iFix000-2026-03-17   |
| 1.3.30 | Apr 22, 2026 | >= 1.28.0           | >=4.15                   | cdu:6.3.0.7-iFix008-2026-04-21	                 | C:D Unix 6.3.0.7-iFix008-2026-04-21   |
| 1.3.31 | May 25, 2026 | >= 1.28.0           | >=4.15                   | cdu:6.3.0.7-iFix014-2026-05-22	                 | C:D Unix 6.3.0.7-iFix014-2026-05-22   |
| 1.3.32 | Jun 17, 2026 | >= 1.28.0           | >=4.15                   | cdu:6.3.0.7-iFix021-2026-06-16	                 | C:D Unix 6.3.0.7-iFix021-2026-06-16   |
| 1.3.33 | Jun 19, 2026 | >= 1.28.0           | >=4.15                   | cdu:6.3.0.7-iFix021-2026-06-17	                 | C:D Unix 6.3.0.7-iFix021-2026-06-17   |

`Note: The images listed here are minimum supported container image for the respective helm chart version.`

