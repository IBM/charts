# What's new in Helm Charts Version 1.0.0 for IBM Sterling B2B Integrator and File Gateway Agents 1.0.0.0


* This chart bundles the deployment for IBM Sterling B2B Integrator and File Gateway Agents which includes the Resolution Agent
* Tech stack support
    Red Hat UBI Python minimal base image version 10.2.x
    Red Hat OpenShift Container Platform 4.19, 4.20, 4.21, 4.22 or later fixes
    Kubernetes versions >=1.32
    Helm version 4.2.3

# Breaking Changes
N/A

# DB Changes (refer Version History section below)
N/A


# Documentation
Check the README file provided with the chart for detailed installation instructions.

# Fixes
N/A

# Prerequisites
Please refer prerequisites section from README.md

# Version History

| Chart | Date | Kubernetes Version Required | Breaking Changes | Details | DB Changes |
| ----- | ---- | --------------------------- | ---------------- | ------- | ---------- |
| 1.0.0  | Oct 23, 2026 | >=1.35  | N | Initial release for IBM Sterling B2B Integrator and File Gateway Agents | N |
