{{/*
Chart name, truncated/sanitized for use in resource names.
*/}}
{{- define "ibm-b2bi-sfg-agents.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Fully qualified release name.
*/}}
{{- define "ibm-b2bi-sfg-agents.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "ibm-b2bi-sfg-agents.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "ibm-b2bi-sfg-agents.namespace" -}}
{{- default .Release.Namespace .Values.global.namespaceOverride -}}
{{- end -}}

{{/*
Common labels / selector labels, shared across all resources.
*/}}
{{- define "ibm-b2bi-sfg-agents.labels" -}}
helm.sh/chart: {{ include "ibm-b2bi-sfg-agents.chart" . }}
{{ include "ibm-b2bi-sfg-agents.selectorLabels" . }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: {{ include "ibm-b2bi-sfg-agents.name" . }}
{{- end -}}

{{- define "ibm-b2bi-sfg-agents.selectorLabels" -}}
app.kubernetes.io/name: {{ include "ibm-b2bi-sfg-agents.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/*
Per-component (agent / mcp-server) name + label helpers.
*/}}
{{- define "ibm-b2bi-sfg-agents.agent.fullname" -}}
{{- printf "%s-agent" (include "ibm-b2bi-sfg-agents.fullname" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "ibm-b2bi-sfg-agents.agent.selectorLabels" -}}
{{ include "ibm-b2bi-sfg-agents.selectorLabels" . }}
app.kubernetes.io/component: agent
{{- end -}}

{{- define "ibm-b2bi-sfg-agents.agent.labels" -}}
{{ include "ibm-b2bi-sfg-agents.labels" . }}
app.kubernetes.io/component: agent
{{- end -}}

{{- define "ibm-b2bi-sfg-agents.mcpServer.fullname" -}}
{{- printf "%s-mcp-server" (include "ibm-b2bi-sfg-agents.fullname" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "ibm-b2bi-sfg-agents.mcpServer.selectorLabels" -}}
{{ include "ibm-b2bi-sfg-agents.selectorLabels" . }}
app.kubernetes.io/component: mcp-server
{{- end -}}

{{- define "ibm-b2bi-sfg-agents.mcpServer.labels" -}}
{{ include "ibm-b2bi-sfg-agents.labels" . }}
app.kubernetes.io/component: mcp-server
{{- end -}}

{{/*
Bundled Valkey (sharedCacheStore.bundled) name + label helpers.
*/}}
{{- define "ibm-b2bi-sfg-agents.valkey.fullname" -}}
{{- printf "%s-valkey" (include "ibm-b2bi-sfg-agents.fullname" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "ibm-b2bi-sfg-agents.valkey.selectorLabels" -}}
{{ include "ibm-b2bi-sfg-agents.selectorLabels" . }}
app.kubernetes.io/component: valkey
{{- end -}}

{{- define "ibm-b2bi-sfg-agents.valkey.labels" -}}
{{ include "ibm-b2bi-sfg-agents.labels" . }}
app.kubernetes.io/component: valkey
{{- end -}}

{{/*
ServiceAccount name — shared by the agent and MCP server pods (spec section
6.6: one least-privilege ServiceAccount per agent, not the default SA).
*/}}
{{- define "ibm-b2bi-sfg-agents.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
{{ default (include "ibm-b2bi-sfg-agents.fullname" .) .Values.serviceAccount.name }}
{{- else -}}
{{ default "default" .Values.serviceAccount.name }}
{{- end -}}
{{- end -}}

{{/*
Resolves the Secret name backing the MCP server's B2BI credentials: an
operator-supplied existingSecretName takes precedence over the chart's own
convenience Secret (see templates/secret-b2bi-credentials.yaml). Renders
empty when neither is configured (e.g. B2BI_AUTH_STRATEGY=relay, which needs
no static credential).
*/}}
{{- define "ibm-b2bi-sfg-agents.mcpServer.b2biSecretName" -}}
{{- if .Values.mcpServer.b2bi.existingSecretName -}}
{{- .Values.mcpServer.b2bi.existingSecretName -}}
{{- else if or .Values.mcpServer.b2bi.username .Values.mcpServer.b2bi.password .Values.mcpServer.b2bi.apiToken -}}
{{- include "ibm-b2bi-sfg-agents.mcpServer.fullname" . }}-b2bi-credentials
{{- end -}}
{{- end -}}

{{/*
Istio sidecar injection annotation — only rendered when istio.enabled=true;
customers managing injection at the namespace level can set
istio.sidecarInjection=false while still leaving istio.enabled=true.
*/}}
{{- define "ibm-b2bi-sfg-agents.istioAnnotations" -}}
{{- if .Values.istio.enabled -}}
sidecar.istio.io/inject: {{ .Values.istio.sidecarInjection | quote }}
{{- end -}}
{{- end -}}

{{/*
Operator acknowledgement gate (spec section 6.1) — only enforced when
istio.enabled=true. This chart does NOT hard-require Istio: set
istio.enabled=false to use the agent's native mTLS fallback instead.
*/}}
{{- define "ibm-b2bi-sfg-agents.istioGate" -}}
{{- if and .Values.istio.enabled (not .Values.istio.installed) -}}
{{ fail "istio.enabled=true requires istio.installed=true to confirm OpenShift Service Mesh is installed and this namespace is enrolled (see README.md). Set istio.enabled=false to use native mTLS instead." }}
{{- end -}}
{{- end -}}

{{/*
License acceptance gate (mirrors the ibm-b2bi-prod chart convention) — a
single standalone flag covering this whole release.
*/}}
{{- define "ibm-b2bi-sfg-agents.licenseGate" -}}
{{- if not .Values.global.license -}}
{{ fail "global.license must be set to true to accept the license terms before installing this chart." }}
{{- end -}}
{{- end -}}

{{/*
Runs both pre-install gates — include once from each always-rendered workload template.
*/}}
{{- define "ibm-b2bi-sfg-agents.gates" -}}
{{ include "ibm-b2bi-sfg-agents.licenseGate" . }}
{{ include "ibm-b2bi-sfg-agents.istioGate" . }}
{{- end -}}
