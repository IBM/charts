{{- define "ibm-databand-migration.validate" -}}
{{- $operatorNs := required "global.operatorNamespace is required" .Values.global.operatorNamespace -}}
{{- $instanceNs := required "global.instanceNamespace is required" .Values.global.instanceNamespace -}}
{{- end -}}

{{- define "ibm-databand-migration.addonId" -}}
{{- .Values.ibmDataband.addonId | default "databand" -}}
{{- end -}}

{{- define "ibm-databand-migration.jobServiceAccountName" -}}
{{- .Values.serviceAccount.name | default "ibm-databand-migration-job" -}}
{{- end -}}

{{- define "ibm-databand-migration.installConfigImage" -}}
{{- $pullPrefix := (.Values.global.installConfigImagePullPrefix | default .Values.global.imagePullPrefix) -}}
{{- $imageName := .Values.global.installConfigImageName -}}
{{- if .Values.global.installConfigImageDigest -}}
{{- printf "%s/%s@%s" $pullPrefix $imageName .Values.global.installConfigImageDigest -}}
{{- else -}}
{{- printf "%s/%s:%s" $pullPrefix $imageName .Values.global.installConfigImageTag -}}
{{- end -}}
{{- end -}}
