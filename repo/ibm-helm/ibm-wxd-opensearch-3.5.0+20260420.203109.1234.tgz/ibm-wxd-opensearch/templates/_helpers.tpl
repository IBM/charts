{{/*
Expand the name of the chart.
Defaults to ibm-wxd-opensearch unless nameOverride is provided.
*/}}
{{- define "opensearch-operator.name" -}}
{{- default "ibm-wxd-opensearch" .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "opensearch-operator.watchNamespaces" -}}
{{- $watchNamespaces := .Values.global.tetheredNamespaces | default list -}}
{{- if .Values.global.instanceNamespace -}}
{{- $watchNamespaces = append $watchNamespaces .Values.global.instanceNamespace -}}
{{- end -}}
{{- $watchNamespaces = prepend $watchNamespaces .Values.global.operatorNamespace }}
{{- uniq $watchNamespaces | join "," | quote }}
{{- end -}}

{{- define "opensearch-operator.watchNamespacesList" -}}
{{- $watchNamespaces := .Values.global.tetheredNamespaces | default list -}}
{{- if .Values.global.instanceNamespace -}}
{{- $watchNamespaces = append $watchNamespaces .Values.global.instanceNamespace -}}
{{- end -}}
{{- $watchNamespaces = prepend $watchNamespaces .Values.global.operatorNamespace }}
{{- uniq $watchNamespaces | toYaml }}
{{- end -}}

{{/*
Operator image pull prefix priority:
1. global.installConfigImagePullPrefix
2. ibmWxdOpensearch.devImagePullPrefix
3. global.imagePullPrefix
4. default: icr.io
*/}}
{{- define "opensearch-operator.operatorImagePullPrefix" -}}
{{- if .Values.global.installConfigImagePullPrefix -}}
{{- .Values.global.installConfigImagePullPrefix -}}
{{- else if .Values.ibmWxdOpensearch.devImagePullPrefix -}}
{{- .Values.ibmWxdOpensearch.devImagePullPrefix -}}
{{- else if .Values.global.imagePullPrefix -}}
{{- .Values.global.imagePullPrefix -}}
{{- else -}}
icr.io
{{- end -}}
{{- end -}}

{{/*
Component image pull prefix priority:
1. global.installConfigImagePullPrefix
2. ibmWxdOpensearch.devImagePullPrefix
3. global.imagePullPrefix
4. default: cp.icr.io

If global.imagePullPrefix is icr.io and no installConfigImagePullPrefix is set,
convert to cp.icr.io for component images.
*/}}
{{- define "opensearch-operator.componentImagePullPrefix" -}}
{{- if .Values.global.installConfigImagePullPrefix -}}
{{- .Values.global.installConfigImagePullPrefix -}}
{{- else if .Values.ibmWxdOpensearch.devImagePullPrefix -}}
{{- .Values.ibmWxdOpensearch.devImagePullPrefix -}}
{{- else if eq .Values.global.imagePullPrefix "icr.io" -}}
cp.icr.io
{{- else if .Values.global.imagePullPrefix -}}
{{- .Values.global.imagePullPrefix -}}
{{- else -}}
cp.icr.io
{{- end -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
Do not derive from Chart.Name or Release.Name because split packaging
may rename the chart (for example, adding -cluster-scoped), while
Kubernetes resource names must remain canonical.
*/}}
{{- define "opensearch-operator.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- include "opensearch-operator.name" . }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "opensearch-operator.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "opensearch-operator.labels" -}}
helm.sh/chart: {{ include "opensearch-operator.chart" . }}
{{ include "opensearch-operator.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "opensearch-operator.selectorLabels" -}}
app.kubernetes.io/name: {{ include "opensearch-operator.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "opensearch-operator.serviceAccountName" -}}
{{- if .Values.ibmWxdOpensearch.serviceAccount.create }}
{{- default (printf "%s-%s" (include "opensearch-operator.fullname" .) "controller-manager") .Values.ibmWxdOpensearch.serviceAccount.name }}
{{- else }}
{{- default "opensearch-operator-controller-manager" .Values.ibmWxdOpensearch.serviceAccount.name }}
{{- end }}
{{- end }}

{{- define "traefik.name" -}}
{{- printf "%s-traefik" (include "opensearch-operator.fullname" .) -}}
{{ end }}

{{- define "traefik.svc-addr-without-port" -}}
{{- printf "%s.%s.svc.cluster.local" (include "traefik.name" .) .Values.global.operatorNamespace -}}
{{- end -}}

{{/*
Create the name of the metrics service with proper truncation
*/}}
{{- define "opensearch-operator.metricsServiceName" -}}
{{- $fullname := include "opensearch-operator.fullname" . -}}
{{- $suffix := "-controller-manager-metrics-service" -}}
{{- $maxLength := int (sub 63 (len $suffix)) -}}
{{- printf "%s%s" ($fullname | trunc $maxLength | trimSuffix "-") $suffix -}}
{{- end }}

{{/*
OS Role Exporter - Expand the name of the chart.
*/}}
{{- define "os-role-exporter.name" -}}
{{- printf "%s-os-role-exporter" (include "opensearch-operator.fullname" .) -}}
{{- end }}

{{/*
OS Role Exporter - Create a default fully qualified app name.
*/}}
{{- define "os-role-exporter.fullname" -}}
{{- printf "%s-os-role-exporter" (include "opensearch-operator.fullname" .) -}}
{{- end }}

{{/*
OS Role Exporter - Create chart name and version as used by the chart label.
*/}}
{{- define "os-role-exporter.chart" -}}
{{- printf "%s-%s" "os-role-exporter" .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
OS Role Exporter - Common labels
*/}}
{{- define "os-role-exporter.labels" -}}
app: os-role-exporter
helm.sh/chart: {{ include "os-role-exporter.chart" . }}
{{ include "os-role-exporter.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
OS Role Exporter - Selector labels
*/}}
{{- define "os-role-exporter.selectorLabels" -}}
app.kubernetes.io/name: {{ include "os-role-exporter.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
OS Role Exporter - Create the name of the service account to use
*/}}
{{- define "os-role-exporter.serviceAccountName" -}}
{{- if .Values.ibmWxdOpensearch.osRoleExporter.serviceAccount.create }}
{{- default (include "os-role-exporter.fullname" .) .Values.ibmWxdOpensearch.osRoleExporter.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.ibmWxdOpensearch.osRoleExporter.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
OS Role Exporter - Environment Variables
*/}}
{{- define "os-role-exporter.envs" -}}
- name: "CACHE_TTL_MINUTES"
  value: {{ .Values.ibmWxdOpensearch.osRoleExporter.config.cacheTtlMinutes | quote }}
- name: "WATCH_NAMESPACE"
  value: {{ .Values.global.instanceNamespace | quote }}
- name: "LOG_LEVEL"
  value: {{ .Values.ibmWxdOpensearch.osRoleExporter.config.logLevel | quote }}
- name: "TLS_ENABLED"
  value: {{ .Values.ibmWxdOpensearch.osRoleExporter.config.tls.enabled | quote }}
- name: "TLS_CERT_FILE"
  value: {{ .Values.ibmWxdOpensearch.osRoleExporter.config.tls.certFile | quote }}
- name: "TLS_KEY_FILE"
  value: {{ .Values.ibmWxdOpensearch.osRoleExporter.config.tls.keyFile | quote }}
- name: "AMS_URL"
  value: "https://lhconsole-ams-svc.{{ .Values.global.instanceNamespace }}.svc.cluster.local:3333"
- name: "LH_CONTEXT"
  value: {{ .Values.ibmWxdOpensearch.osRoleExporter.lh_context | quote }}
{{- end }}

{{- define "traefik.ingress-tls-cert" -}}
{{- printf "%s-ingress-tls" (include "traefik.name" . ) -}}
{{- end -}}
