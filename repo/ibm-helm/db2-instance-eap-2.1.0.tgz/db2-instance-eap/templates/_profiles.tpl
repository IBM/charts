{{/*
Profile lookup table.

Resolves all sizing (cpu, memory, storage, nodes, partitions) from
(profile.workload, profile.size). Templates call "db2-instance.profile"
and use the returned dict instead of reading profile.resources.* and
profile.storage.* directly.

Workload values: oltp | warehouse-smp | warehouse-mpp
Size values:     dev | small | medium | large

This is based on kosta's recommendation; so it requires review

Sizing formulas (all workloads):
  memory = 4 GB/core (OLTP) | 16 GB/core (Warehouse)
  data   = 4.5 × memory
  all volumes = 20% of data each
  activelogs: OLTP only (Warehouse does not use activelogs)

Dev sizes are intentionally undersized for local testing / CI only.
*/}}
{{- define "db2-instance.profile" -}}
{{- $w := .Values.profile.workload -}}
{{- $s := .Values.profile.size -}}

{{- if and (eq $w "oltp") (eq $s "dev") -}}
cpu: "2"
memory: 8Gi
nodes: 1
storage:
  meta: 5Gi
  backup: 10Gi
  archivelogs: 5Gi
  data: 20Gi
  activelogs: 10Gi
  tempts: 10Gi

{{- else if and (eq $w "oltp") (eq $s "small") -}}
cpu: "8"
memory: 32Gi
nodes: 1
storage:
  meta: 29Gi
  backup: 29Gi
  archivelogs: 29Gi
  data: 144Gi
  activelogs: 29Gi
  tempts: 29Gi

{{- else if and (eq $w "oltp") (eq $s "medium") -}}
cpu: "32"
memory: 128Gi
nodes: 1
storage:
  meta: 115Gi
  backup: 115Gi
  archivelogs: 115Gi
  data: 576Gi
  activelogs: 115Gi
  tempts: 115Gi

{{- else if and (eq $w "oltp") (eq $s "large") -}}
cpu: "64"
memory: 256Gi
nodes: 1
storage:
  meta: 230Gi
  backup: 230Gi
  archivelogs: 230Gi
  data: 1152Gi
  activelogs: 230Gi
  tempts: 230Gi

{{- else if and (eq $w "warehouse-smp") (eq $s "dev") -}}
cpu: "4"
memory: 32Gi
nodes: 1
partition:
  dataOnMln0: true
  total: 1
  volumePerPartition: false
storage:
  meta: 5Gi
  backup: 20Gi
  archivelogs: 20Gi
  data: 50Gi
  tempts: 10Gi

{{- else if and (eq $w "warehouse-smp") (eq $s "small") -}}
cpu: "8"
memory: 128Gi
nodes: 1
partition:
  dataOnMln0: true
  total: 1
  volumePerPartition: false
storage:
  meta: 115Gi
  backup: 115Gi
  archivelogs: 115Gi
  data: 576Gi
  tempts: 115Gi

{{- else if and (eq $w "warehouse-smp") (eq $s "medium") -}}
cpu: "32"
memory: 512Gi
nodes: 1
partition:
  dataOnMln0: true
  total: 1
  volumePerPartition: false
storage:
  meta: 461Gi
  backup: 461Gi
  archivelogs: 461Gi
  data: 2304Gi
  tempts: 461Gi

{{- else if and (eq $w "warehouse-smp") (eq $s "large") -}}
cpu: "64"
memory: 1024Gi
nodes: 1
partition:
  dataOnMln0: true
  total: 1
  volumePerPartition: false
storage:
  meta: 922Gi
  backup: 922Gi
  archivelogs: 922Gi
  data: 4608Gi
  tempts: 922Gi

{{- else if and (eq $w "warehouse-mpp") (eq $s "dev") -}}
cpu: "4"
memory: 32Gi
nodes: 3
partition:
  dataOnMln0: true
  total: 3
  volumePerPartition: true
storage:
  meta: 5Gi
  backup: 20Gi
  archivelogs: 20Gi
  data: 50Gi
  tempts: 10Gi

{{- else if and (eq $w "warehouse-mpp") (eq $s "small") -}}
cpu: "8"
memory: 128Gi
nodes: 3
partition:
  dataOnMln0: true
  total: 3
  volumePerPartition: true
storage:
  meta: 115Gi
  backup: 115Gi
  archivelogs: 115Gi
  data: 576Gi
  tempts: 115Gi

{{- else if and (eq $w "warehouse-mpp") (eq $s "medium") -}}
cpu: "32"
memory: 512Gi
nodes: 7
partition:
  dataOnMln0: true
  total: 7
  volumePerPartition: true
storage:
  meta: 461Gi
  backup: 461Gi
  archivelogs: 461Gi
  data: 2304Gi
  tempts: 461Gi

{{- else if and (eq $w "warehouse-mpp") (eq $s "large") -}}
cpu: "64"
memory: 1024Gi
nodes: 9
partition:
  dataOnMln0: true
  total: 9
  volumePerPartition: true
storage:
  meta: 922Gi
  backup: 922Gi
  archivelogs: 922Gi
  data: 4608Gi
  tempts: 922Gi

{{- else -}}
{{- fail (printf "ERROR: Unknown profile workload=%q size=%q. Valid workloads: oltp, warehouse-smp, warehouse-mpp. Valid sizes: dev, small, medium, large." $w $s) -}}
{{- end -}}
{{- end -}}
