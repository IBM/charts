{{- define "db2-instance.image" -}}
{{- $repository := .repository -}}
{{- $tag := .tag -}}
{{- $repositoryName := last (splitList "/" $repository) -}}
{{- $baseSlug := trimSuffix ".eap" .slug -}}
{{- if not (or (eq $repositoryName .slug) (hasPrefix (printf "%s." $baseSlug) $repositoryName) (hasPrefix (printf "%s." .slug) $repositoryName)) -}}
{{- $repository = printf "%s/%s" $repository .slug -}}
{{- end -}}
{{- if not (hasPrefix "v" $tag) -}}
{{- $tag = printf "v%s" $tag -}}
{{- end -}}
{{- printf "%s:%s" $repository $tag -}}
{{- end -}}

{{/*
Validation helper template
*/}}
{{- define "db2-instance.validate" -}}

{{/* Validate profile workload and size */}}
{{- $validWorkloads := list "oltp" "warehouse-smp" "warehouse-mpp" -}}
{{- if not (has .Values.profile.workload $validWorkloads) }}
{{- fail (printf "ERROR: profile.workload=%q is not valid. Must be one of: oltp, warehouse-smp, warehouse-mpp" .Values.profile.workload) }}
{{- end }}
{{- $validSizes := list "dev" "small" "medium" "large" -}}
{{- if not (has .Values.profile.size $validSizes) }}
{{- fail (printf "ERROR: profile.size=%q is not valid. Must be one of: dev, small, medium, large" .Values.profile.size) }}
{{- end }}

{{/* Validate required parameters */}}
{{- if not .Values.image.tag }}
{{- fail "ERROR: image.tag is required. Please specify the DB2 version (e.g., --set image.tag=12.1.6.0)" }}
{{- end }}

{{- if not .Values.storageclassname.rwo }}
{{- fail "ERROR: storageclassname.rwo is required. Please specify ReadWriteOnce storage class (e.g., --set storageclassname.rwo=nfs)" }}
{{- end }}

{{- if not .Values.storageclassname.rwx }}
{{- fail "ERROR: storageclassname.rwx is required. Please specify ReadWriteMany storage class (e.g., --set storageclassname.rwx=nfs)" }}
{{- end }}

{{/* Validate restricted-v2 is not combined with MPP */}}
{{- if .Values.securityContext }}
{{- if eq (.Values.securityContext.sccMode | default "") "restricted-v2" }}
{{- if eq (.Values.profile.workload | default "") "warehouse-mpp" }}
{{- fail "ERROR: restricted-v2 SCC does not support MPP (multi-node) warehouse deployments. Use profile.workload=warehouse-smp instead." }}
{{- end }}
{{- end }}
{{- end }}

{{/* Validate SSL configuration */}}
{{- if .Values.ssl }}
{{- if .Values.ssl.enabled }}
{{- if not .Values.ssl.secretName }}
{{- fail "ERROR: ssl.secretName is required when SSL is enabled. Please specify the secret name containing SSL certificates (e.g., --set ssl.secretName=db2ssl-certs). The secret must contain keys: tls.crt, tls.key, and ca.crt" }}
{{- end }}
{{- end }}
{{- end }}

{{/* Validate LDAP configuration */}}
{{- if .Values.ldap }}
{{- if .Values.ldap.enabled }}
{{- if not .Values.ldap.configMapName }}
{{- fail "ERROR: ldap.configMapName is required when LDAP is enabled. Please specify the ConfigMap name containing LDAP configuration (e.g., --set ldap.configMapName=ldap-config)" }}
{{- end }}
{{- end }}
{{- end }}

{{/* Validate ODF and NCOS are not used with OLTP */}}
{{- if eq (.Values.profile.workload | default "") "oltp" }}
{{- if .Values.odf }}
{{- if .Values.odf.enabled }}
{{- fail "ERROR: odf is not supported with profile.workload=oltp. ODF requires a Warehouse workload (warehouse-smp or warehouse-mpp)." }}
{{- end }}
{{- end }}
{{- if .Values.ncos }}
{{- if .Values.ncos.enabled }}
{{- fail "ERROR: ncos is not supported with profile.workload=oltp. NCOS requires a Warehouse workload (warehouse-smp or warehouse-mpp)." }}
{{- end }}
{{- end }}
{{- end }}

{{/* Validate NCOS configuration */}}
{{- if .Values.ncos }}
{{- if .Values.ncos.enabled }}
{{- if not .Values.ncos.storageSize }}
{{- fail "ERROR: ncos.storageSize is required when NCOS is enabled. Please specify the caching tier storage size (e.g., --set ncos.storageSize=100Gi)" }}
{{- end }}
{{- $validProviders := list "aws" "azure" "self-hosted" "ibmcloud" -}}
{{- if not (has .Values.ncos.cosProvider $validProviders) }}
{{- fail (printf "ERROR: ncos.cosProvider=%q is not valid. Must be one of: aws, azure, self-hosted, ibmcloud" .Values.ncos.cosProvider) }}
{{- end }}
{{- end }}
{{- end }}

{{/* Validate HA configuration */}}
{{- if .Values.ha }}
{{- if .Values.ha.enabled }}
{{- if not .Values.ha.standbyReplicas }}
{{- fail "ERROR: ha.standbyReplicas is required when ha.enabled is true (e.g., --set ha.standbyReplicas=3)" }}
{{- end }}
{{- end }}
{{- end }}

{{- end -}}
