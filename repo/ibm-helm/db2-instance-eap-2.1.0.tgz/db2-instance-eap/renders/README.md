# Renders Directory

Generated Helm manifests are written here for review before applying to a cluster.

## Usage

Always review the generated YAML before running `oc apply`.

### Development

```bash
helm template my-db2 . \
  -f values-dev.yaml \
  --namespace db2u \
  --set image.tag=12.1.6.0 \
  --set storageclassname.rwo=<your-rwo-class> \
  --set storageclassname.rwx=<your-rwx-class> \
  --output-dir renders/dev

oc apply -f renders/dev/db2-instance/templates/
```

### Production — Warehouse MPP (default)

```bash
helm template my-db2 . \
  -f values-prod.yaml \
  --namespace db2u \
  --set profile.size=small \
  --set image.tag=12.1.6.0 \
  --set storageclassname.rwo=<your-rwo-class> \
  --set storageclassname.rwx=<your-rwx-class> \
  --output-dir renders/prod-wh-mpp

oc apply -f renders/prod-wh-mpp/db2-instance/templates/
```

### Production — Warehouse SMP

```bash
helm template my-db2 . \
  -f values-prod.yaml \
  -f examples/prod-wh-smp.yaml \
  --namespace db2u \
  --set profile.size=small \
  --set image.tag=12.1.6.0 \
  --set storageclassname.rwo=<your-rwo-class> \
  --set storageclassname.rwx=<your-rwx-class> \
  --output-dir renders/prod-wh-smp

oc apply -f renders/prod-wh-smp/db2-instance/templates/
```

### Production — OLTP

```bash
helm template my-db2 . \
  -f values-prod.yaml \
  -f examples/prod-oltp.yaml \
  --namespace db2u \
  --set profile.size=small \
  --set image.tag=12.1.6.0 \
  --set storageclassname.rwo=<your-rwo-class> \
  --set storageclassname.rwx=<your-rwx-class> \
  --output-dir renders/prod-oltp

oc apply -f renders/prod-oltp/db2-instance/templates/
```

## Directory Structure

```
renders/
├── dev/           # Development OLTP (values-dev.yaml)
├── prod-wh-mpp/   # Production Warehouse MPP (values-prod.yaml)
├── prod-wh-smp/   # Production Warehouse SMP (values-prod.yaml + prod-wh-smp.yaml)
├── prod-oltp/     # Production OLTP (values-prod.yaml + prod-oltp.yaml)
└── README.md      # This file
```

> This directory is excluded from version control. Generated files are local only.
