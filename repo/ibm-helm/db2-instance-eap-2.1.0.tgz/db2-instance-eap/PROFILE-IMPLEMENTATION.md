# Profile-Based DB2 Instance Deployment — Implementation Reference

## Architecture

### Layered Values System

```
values.yaml                 ← base defaults (do not use directly)
  └── values-dev.yaml       ← workload: oltp, size: dev
  └── values-prod.yaml      ← workload: warehouse-mpp, size: small (default)
        └── examples/prod-oltp.yaml      ← override workload → oltp
        └── examples/prod-wh-smp.yaml    ← override workload → warehouse-smp
        └── examples/<cloud>-*.yaml      ← storage classes only
        └── examples/db2wh-with-*.yaml   ← add-ons (LDAP, NCOS, ODF, SCC)
```

Templates are chosen by `profile.workload`:
- `oltp` → `templates/db2-oltp.yaml`
- `warehouse-smp` / `warehouse-mpp` → `templates/db2-wh.yaml`

Sizing is **never in the values files**. It lives entirely in `templates/_profiles.tpl` and is resolved from `(profile.workload, profile.size)` at render time.

---

## Profile Lookup Table (`templates/_profiles.tpl`)

The `db2-instance.profile` helper maps `(workload, size)` → a YAML dict with keys:
`cpu`, `memory`, `nodes`, `storage.*`, and `partition.*` (warehouse only).

Valid values:
- `profile.workload`: `oltp` | `warehouse-smp` | `warehouse-mpp`
- `profile.size`: `dev` | `small` | `medium` | `large`

### OLTP sizing

memory = 4 GB/core · data = 4.5× memory · all volumes = 20% of data

| size | nodes | cpu | memory | meta | backup | archivelogs | data | activelogs | tempts |
|------|-------|-----|--------|------|--------|-------------|------|------------|--------|
| dev | 1 | 2 | 8Gi | 5Gi | 10Gi | 5Gi | 20Gi | 10Gi | 10Gi |
| small | 1 | 8 | 32Gi | 29Gi | 29Gi | 29Gi | 144Gi | 29Gi | 29Gi |
| medium | 1 | 32 | 128Gi | 115Gi | 115Gi | 115Gi | 576Gi | 115Gi | 115Gi |
| large | 1 | 64 | 256Gi | 230Gi | 230Gi | 230Gi | 1152Gi | 230Gi | 230Gi |

### Warehouse SMP sizing (1 node, volumePerPartition: false)

memory = 16 GB/core · data = 4.5× memory · all volumes = 20% of data

| size | nodes | cpu | memory | meta | backup | archivelogs | data | tempts |
|------|-------|-----|--------|------|--------|-------------|------|--------|
| dev | 1 | 4 | 32Gi | 5Gi | 20Gi | 20Gi | 50Gi | 10Gi |
| small | 1 | 8 | 128Gi | 115Gi | 115Gi | 115Gi | 576Gi | 115Gi |
| medium | 1 | 32 | 512Gi | 461Gi | 461Gi | 461Gi | 2304Gi | 461Gi |
| large | 1 | 64 | 1024Gi | 922Gi | 922Gi | 922Gi | 4608Gi | 922Gi |

### Warehouse MPP sizing (volumePerPartition: true, total = nodes)

memory = 16 GB/core · data = 4.5× memory · all volumes = 20% of data

| size | nodes | cpu/node | memory/node | meta | backup | archivelogs | data/node | tempts/node |
|------|-------|----------|-------------|------|--------|-------------|-----------|-------------|
| dev | 3 | 4 | 32Gi | 5Gi | 20Gi | 20Gi | 50Gi | 10Gi |
| small | 3 | 8 | 128Gi | 115Gi | 115Gi | 115Gi | 576Gi | 115Gi |
| medium | 7 | 32 | 512Gi | 461Gi | 461Gi | 461Gi | 2304Gi | 461Gi |
| large | 9 | 64 | 1024Gi | 922Gi | 922Gi | 922Gi | 4608Gi | 922Gi |

---

## Workload Templates

### OLTP (`templates/db2-oltp.yaml`)

Renders when `profile.workload == "oltp"`.

- `spec.environment.dbType`: `db2oltp`
- `spec.environment.databases[].storage`: `data`, `activelogs` (RWO, per-database)
- `spec.storage` (top-level): `meta`, `backup`, `archivelogs` (RWX, `type: create`), `tempts` (RWO, `type: template`)
- No `partitionConfig`

### Warehouse (`templates/db2-wh.yaml`)

Renders when `profile.workload == "warehouse-smp"` or `"warehouse-mpp"`.

- `spec.environment.dbType`: `db2wh`
- `spec.environment.partitionConfig`: `dataOnMln0`, `total`, `volumePerPartition`
- `spec.storage` (top-level): `meta`, `backup`, `archivelogs` (RWX, `type: create`), `data`, `tempts` (RWO, `type: template`)
- No `activelogs`

---

## Storage Access Modes

| Volume | Access | OLTP placement | WH placement |
|--------|--------|----------------|--------------|
| meta | RWX | `spec.storage` | `spec.storage` |
| backup | RWX | `spec.storage` | `spec.storage` |
| archivelogs | RWX | `spec.storage` | `spec.storage` |
| data | RWO | `databases[].storage` | `spec.storage` |
| activelogs | RWO | `databases[].storage` | — (not used) |
| tempts | RWO | `spec.storage` | `spec.storage` |

---

## Validation (`templates/_validation.tpl`)

Runs on every render before any YAML is emitted. Fails fast with a clear message.

| Check | Error |
|-------|-------|
| `profile.workload` not in valid list | `profile.workload="x" is not valid` |
| `profile.size` not in valid list | `profile.size="x" is not valid` |
| `image.tag` empty | `image.tag is required` |
| `storageclassname.rwo` empty | `storageclassname.rwo is required` |
| `storageclassname.rwx` empty | `storageclassname.rwx is required` |
| `ssl.enabled` but no `ssl.secretName` | `ssl.secretName is required` |
| `ldap.enabled` but no `ldap.configMapName` | `ldap.configMapName is required` |
| `ncos.enabled` but no `ncos.storageSize` | `ncos.storageSize is required` |
| `ncos.cosProvider` not in valid list | `ncos.cosProvider="x" is not valid` |

---

## Template Selection Logic

```
profile.workload == "oltp"
  └─ db2-oltp.yaml renders
  └─ db2-wh.yaml is skipped (condition false)

profile.workload == "warehouse-smp" OR "warehouse-mpp"
  └─ db2-wh.yaml renders
  └─ db2-oltp.yaml is skipped (condition false)
```

Only one template renders per invocation.

---

## Testing

```bash
cd charts/db2-instance

# Dev (OLTP, size:dev)
helm template t . -f values-dev.yaml \
  --namespace db2u --set image.tag=12.1.6.0 \
  --set storageclassname.rwo=nfs --set storageclassname.rwx=nfs \
  --output-dir renders/dev

# Prod MPP small
helm template t . -f values-prod.yaml \
  --namespace db2u --set profile.size=small --set image.tag=12.1.6.0 \
  --set storageclassname.rwo=nfs --set storageclassname.rwx=nfs \
  --output-dir renders/prod-small

# Prod OLTP medium
helm template t . -f values-prod.yaml -f examples/prod-oltp.yaml \
  --namespace db2u --set profile.size=medium --set image.tag=12.1.6.0 \
  --set storageclassname.rwo=nfs --set storageclassname.rwx=nfs \
  --output-dir renders/prod-oltp-medium

# Prod WH-SMP large
helm template t . -f values-prod.yaml -f examples/prod-wh-smp.yaml \
  --namespace db2u --set profile.size=large --set image.tag=12.1.6.0 \
  --set storageclassname.rwo=nfs --set storageclassname.rwx=nfs \
  --output-dir renders/prod-wh-smp-large

# AWS EKS MPP medium
helm template t . -f values-prod.yaml -f examples/aws-eks-db2wh-mpp.yaml \
  --namespace db2u --set profile.size=medium --set image.tag=12.1.6.0 \
  --output-dir renders/aws-mpp-medium

# Error: bad size
helm template t . -f values-prod.yaml \
  --set profile.size=xlarge --set image.tag=12.1.6.0 \
  --set storageclassname.rwo=nfs --set storageclassname.rwx=nfs

# Lint
helm lint .
```
