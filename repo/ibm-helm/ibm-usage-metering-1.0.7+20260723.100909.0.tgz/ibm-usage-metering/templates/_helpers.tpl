{{/*
Returns a comma-separated list of namespaces to watch.
In processor_capacity_enabled mode, instanceNamespace is always prepended so
that it is guaranteed to appear even when the user omits it from watchNamespace.
*/}}
{{- define "ibm-usage-metering.watchNamespaces" -}}
  {{- $instanceNamespace := .Values.global.instanceNamespace | default .Release.Namespace -}}
  {{- $targets := list $instanceNamespace -}}
  {{- range $ns := splitList "," .Values.ibmUsageMetering.watchNamespace -}}
    {{- $trimmed := trim $ns -}}
    {{- if $trimmed -}}{{- $targets = append $targets $trimmed -}}{{- end -}}
  {{- end -}}
  {{- $targets | uniq | join "," -}}
{{- end -}}