# Examples

The examples demonstrate how to use IBM&reg; Sterling Transformation Extender Launcher Container 11.0.3
<br>&copy; Copyright IBM Corporation 2025, 2026 All rights reserved.
<br>Program Number : 5724-Q23 

## Table of Contents
1. [Introduction](#introduction)
2. [Installation](#installation)
3. [Requirements](#requirements)
4. [Configuration](#configuration)
   - [Kubernetes](#kubernetes)
   - [ITX-LS](#itx-ls)
5. [File Listener](#file-listener)
6. [HTTP Listener](#http-listener)
7. [Storage](#storage)
   - [PVC](#pvc)
   - [COS](#cos)
8. [Istio](#istio)

## Introduction

IBM&reg; Sterling Transformation Extender Launcher Server Container (ITX-LS) can be deployed to any [Kubernetes](https://kubernetes.io/) platform via a [Helm](https://helm.sh/docs/) chart installation. The ITX-LS Helm chart defines the necessary ITX containers (or processes) that must be started under Kubernetes. Kubernetes automatically monitors the ITX containers for their readiness to satisfy the most demanding of workloads. 

The current examples target the Minikube implementation of Kubernetes. However, the same set of Helm chart installation steps work with any enterprise version of Kubernetes, particularly Red Hat OpenShift (RHOS). 

Once maps from ITX Design Studio and systems from ITX Integration Flow Designer are deployed to persistent storage or to ephemeral storage via Cloud Object Storage, the ITX-LS deployment is ready to process external client requests and triggered watches from system flows.

## Installation

ITX-LS must first get installed on the Kubernetes platform before any maps or flows are executed there. The ITX-LS Helm chart provides the necessary Kubernetes definitions to accomplish this task in a user-friendly and customized way. The input needed from the user is documented in the "values.yaml" file. Examples are provided to assist with the Helm-based ITX-LS installation. Once installation occurs, all the necessary ITX containers are created on the cluster for map and flow execution.

In order to install the ITX-LS Helm chart, a number of Kubernetes applications are needed. First, RHOS is recommended for production purposes, but Minikube is used in these examples as a lighter alternative that is capable of spinning up all the necessary ITX containers that are defined in the ITX-LS Helm chart. Secondly, the Helm application is needed to actually read the ITX-LS Helm chart and deploy it to the running instance of Kubernetes. Lastly, the Kubernetes command line tool, kubectl, is used to display and control the status of all the deployed ITX containers, which are now running under Minikube after having installed the ITX-LS Helm chart.   

## Requirements
All the necessary software requirements for running the current set of examples are listed in the table below.

| Name                   | Version <sup>1</sup>             | Platform/Package |  URL    |
| ------------------- | ----------------- |------------- |----------|
| `ITX-LS` Helm Chart    | 3.2.0          | Helm | https://github.com/IBM/charts/blob/master/repo/ibm-helm/ibm-itx-ls-prod-3.2.0.tgz |
| `ITX-LS` image         | 11.0.3.0       | Container | https://myibm.ibm.com/products-services/containerlibrary |
| `ITX Design Studio`<sup>2</sup> | 11.0.3.0 | Windows      |https://www.ibm.com/software/passportadvantage/pao_customer.html |
| `Helm`                 | 3.16.1            | Windows      |https://github.com/helm/helm/releases |
| `Kubernetes`           | Minikube 1.34     | Windows      |https://minikube.sigs.k8s.io/docs/start/?arch=%2Fwindows%2Fx86-64%2Fstable%2F.exe+download |
| `Kubernetes API tool`  | kubectl 1.31.1    | Windows      |https://kubernetes.io/docs/tasks/tools/install-kubectl-windows/ |
| `curl`<sup>3</sup>     | 8.9.1             | Windows   |https://curl.se/download.html |

<sup>1</sup> Minimum Version\
<sup>2</sup> Optional if source maps and systems need to be viewed or edited\
<sup>3</sup> Optional if a browser is used

## Configuration
Before running the examples, some preliminary configuration steps are required.   

### Kubernetes
All examples require access to a running version of Kubernetes and to a container registry, which needs to include the ITX-LS image.

1. Start the Kubernetes cluster if not done already.<sup>1</sup>\
`> minikube start`
2. Load the ITX-LS container image into the container registry.\
`> minikube image load ibm-itx-ls_11.0.3.0.20260625.tar.gz`<sup>2</sup>
3. Identify the ITX-LS container image and tag name.\
`> minikube image ls --format=table`
4. Tag the ITX-LS container image with the name, "localhost/ibm-itx-ls:11.0.3", which is referenced in subsequent steps.\
`> minikube image tag < image-name-from-prior-step >:11.0.3.0.20260625 localhost/ibm-itx-ls:11.0.3`
5. [Provision](#pvc) storage.

<sup>1</sup> Run all the minikube commands from an Administrator window.\
<sup>2</sup> Change "ibm-itx-ls_11.0.3.0.20260625.tar.gz" to appropriate image name, if different.

### ITX-LS
An instance of ITX-LS is installed and started on a Kubernetes cluster by using a Helm chart. The ITX-LS Helm chart comes packaged in a compressed tar format - which can be uncompressed and extracted into a local directory. For example, the following command may be used for extracting the ITX-LS Helm chart: `tar -xvzf ibm-itx-ls.3.2.0.tgz -C < your-target-dir >`.
After the ITX-LS Helm chart is extracted to a local directory, each of the examples will appear in a separate directory under the "examples" folder. The necessary values for installation are stored in a "YAML" file with the prefix of "my< example-name >_values.yaml". These values serve as an override to the base set of configuration values, as contained in the "values.yaml" file of the ITX-LS Helm chart. 

Each example provides the "helm" command that installs the running version of ITX-LS. The first [File Listener](#file-listener) example specifies the following: `helm install filelsnr ..\.. -f myfile_values.yaml`. The `filelsnr` identifies the release name of the ITX-LS instance that will get deployed to the Kubernetes cluster. The `..\..` points to the root directory of the extracted "tgz" file - as referenced from the "file" example subdirectory, which is two sub-directories below the root directory. If the Helm command is executed from the root folder of the Helm chart, then the following command syntax could be used, `helm install filelsnr . -f examples\file\myfile_values.yaml`. 

Before running the examples, [Storage](#storage) must be provisioned as per the [PVC](#pvc) section.

After using the Helm install command, the ITX-LS can be accessed through any available HTTP port on your Windows machine, which defaults to 5017 in these examples.  This port ensures proper communication between ITX-LS and other REST-based applications, such as a browser or "curl".     
     
### Cleanup (Optional)
1. Pause Kubernetes.<sup>1</sup>\
`> minkube pause`
2. Resume Kubernetes.\
`> minkube resume`
3. Stop Kubernetes.\
`> minkube stop`

<sup>1</sup> Pausing and resuming the cluster is a convenient way to temporarily pause system processing without a complete cluster shutdown.

## File Listener

The File Listener example illustrates how existing maps and systems can be deployed to Kubernetes. All of the artifacts are under the "file" subdirectory of the "examples" folder in the ITX-LS Helm chart.  The example map, "OneInOneOut.lnx", and system flow, "OneInOneOut.msl", watches for new input files, namely "/data/inputs/in*.txt",  and converts them to uppercase versions, namely "/data/outputs/out*.txt". The folders need to be pre-created as per the steps in the [PVC storage provisioning section](#provision).

### Install
1. Change to the ITX-LS Helm chart "file" example directory location and use the "myfile_values.yaml" file<sup>1</sup>, which contains the following content:
``` { .yaml }
license: true
image:
  registry: "localhost"
  repository: "ibm-itx-ls"
  digest: ""
  tag: "11.0.3"
  pullPolicyOverride: true
  pullPolicy: IfNotPresent
  pullSecret: ""
persistence:
  logs:
    existingClaim: logs
  data:
    existingClaim: data
```
2. Install ITX-LS.\
`> helm install filelsnr ..\.. -f myfile_values.yaml`<sup>2</sup>

<sup>1</sup> The "license" field must be set to true for IBM license acceptance. The "repository" and "tag" values must match the name listed in [Step #4 of the Configuration:Kubernetes section](#kubernetes).\
<sup>2</sup> The "filelsnr" is the release name, which marks this ITX-LS instance and can be changed accordingly.

### Deploy
1. List the name of the ITX-LS container.\
`> kubectl get pods -l app.kubernetes.io/instance=filelsnr`
2. Copy the sample map to the container's default map location.\
`> kubectl cp OneInOneOut.lnx < name-from-step-1 >:/data/maps`\
`> kubectl cp OneInOneOut.msl < name-from-step-1 >:/data/systems`
3. Restart the pod.\
`> kubectl scale --replicas=0 deployment/filelsnr-itx-ls`\
`> kubectl scale --replicas=1 deployment/filelsnr-itx-ls`

### Execute
1. Trigger a request to execute the map.\
`> kubectl cp input.txt < name-from-prior-step-1 >:/data/inputs`
2. Copy the output results.\
`> kubectl cp < name-from-prior-step-1 >:/data/outputs/output.txt`
3. Examine the upper-case results in the "output.txt" file.

### Cleanup
1. Uninstall ITX-LS.\
`> helm uninstall filelsnr`
   
## HTTP Listener 
The HTTP Listener example illustrates how existing maps and systems can be deployed to Kubernetes to support REST requests. All of the artifacts are under the "http" subdirectory of the "examples" folder in the ITX-LS Helm chart.  The example map, "lsnrtest.lnx", and system flow, "lsnrtest.msl", watch for REST GET requests and serves up a web page as a response. 

### Install
1. Change to the ITX-LS Helm chart "http" example directory location and use the "myhttp_values.yaml" file, which contains the following content:
``` { .yaml }
license: true
image:
  registry: "localhost"
  repository: "ibm-itx-ls"
  digest: ""
  tag: "11.0.3"
  pullPolicyOverride: true
  pullPolicy: IfNotPresent
  pullSecret: ""
persistence:
  logs:
    existingClaim: logs
  data:
    existingClaim: data
```
2. Install ITX-LS.\
`> helm install httplsnr ..\.. -f myhttp_values.yaml`<sup></sup>

<sup>1</sup> The "license" field must be set to true for IBM license acceptance. The "repository" and "tag" values must match the name listed in [Step #4 of the Configuration:Kubernetes section](#kubernetes).\
<sup>2</sup> The "httplsnr" is the release name, which marks this ITX-LS instance and can be changed accordingly.

### Deploy
1. List the name of the ITX-LS container.\
`> kubectl get pods -l app.kubernetes.io/instance=httplsnr`
2. Copy the sample map to the container's default map location.\
`> kubectl cp lsnrtest.lnx < name-from-step-1 >:/data/maps`\
`> kubectl cp lsnrtest.msl < name-from-step-1 >:/data/systems`
3. Restart the pod.\
`> kubectl scale --replicas=0 deployment/httplsnr-itx-ls`\
`> kubectl scale --replicas=1 deployment/httplsnr-itx-ls`
4. Expose the ITX-LS REST API port.\
`> kubectl port-forward service/httplsnr-itx-ls 5017:5017`<sup>1</sup>

<sup>1</sup> Optionally use a different external port as follows, "< your-external-port >:5017".

### Execute
1. Use your browser or "curl" command line to make a REST API request to execute the map.\
`> curl -X GET "http://localhost:5017/example"`<sup>1</sup>
2. Examine the results, which will show a simple web page with the text: "Congratulations, you have successfully served a web page!". 

<sup>1</sup> Optionally use a different external port than 5017, as per step 4 in the previous Deploy section.

### Cleanup
1. Uninstall ITX-LS.\
`> helm uninstall httplsnr`

## Storage
The ITX-LS storage requires either a Persistent Volume Claim (PVC) or Cloud Object Storage (COS). The following sections describe how to setup deployments that use either [PVCs](#pvc) or [COS](#cos). Refer to the ITX-LS chart's "README.md" notes and "values.yaml" file for further details. When COS is used, PVCs are not required. The maps and systems are automatically downloaded from COS before Launcher even starts processing. In this way, administrators can securely automate the installation and deployment of maps and flows without manual intervention or end user involvement.  

### PVC
The typical and default ITX-LS installation requires two PVCs. One is mainly for map-related data, which is [defined](#define) below as "data", and another for process-related logs, which is [defined](#define) below as "logs". The size and storage attributes of both PVCs are specified under the "persistence.data" and "persistence.logs" sections of the "values.yaml" file. 

In order to satisfy the storage requirements of the PVC, a Kubernetes Persistent Volume (PV) must first be [provisioned](#provision), which is a step normally performed by an administrator before access is given to a Kubernetes cluster. The second step, which is typically done by the user, is to [define](#define) the PVC that will be used to deploy ITX maps and systems.  

#### Provision
1. Change to the ITX-LS "examples\storage" folder to examine the "mypv.yaml" file. A snippet of the PV definition follows:
``` { .yaml }
apiVersion: v1
kind: PersistentVolume
metadata:
  name: pvdata
spec:
  capacity:
    storage: 10Gi
  accessModes:
    - ReadWriteMany
  hostPath:
    path: /data/lsdata
```
The "hostPath.path" must be defined in minikube from an administrator console by running the following commands:\
`> minikube ssh`\
`> sudo mkdir -p /data/pvlogs /data/pvdata /data/pvdata/inputs /data/pvdata/outputs`\
`> sudo chmod -R ugo+w /data`\
`> exit`

2. Provision both PVs with the following command:\
`> kubectl apply -f mypv.yaml`
3. View the PVs with the following command:\
`> kubectl get pv pvdata pvlogs`

#### Define
1. Change to the ITX-LS "examples\storage" folder to examine the "mydata.yaml" and "mylogs.yaml" files. The "data" PVC definition follows:
``` { .yaml }
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: data
spec:
  accessModes:
  - ReadWriteMany
  resources:
    requests:
      storage: 10Gi
```
2. Provision both PVCs with the following command:\
`> kubectl apply -f mydata.yaml`\
`> kubectl apply -f mylogs.yaml`
3. View the PVCs with the following command:\
`> kubectl get pvc data logs`

### COS
Cloud Object Storage (COS) is supported during an ITX-LS installation as long as S3-based or Google-based cloud storage is accessible. The ITX-LS install will automatically download a user-specified "zip" file and then proceed to unzip it under the pre-defined "/data/maps" folder. In this way, the ITX-LS is automatically ready to execute map and flow requests without manual intervention.   

Refer to the "external.cos" section of the "values.yaml" file for setup of this capability. Once activated, ITX-LS will automatically be initialized and ready to process triggering systems after the successful download and deployment of the zip file contents. A COS status report can be viewed by examining the Kubernetes log file, as the following command illustrates: `kubectl logs < your-pod-name > -c ibm-itx-ls-prod-cos-download`.

## Istio
This section demonstrates integration with an Istio service mesh. The deployment seamlessly integrates with Istio to provide service-to-service communication within a Kubernetes-based service mesh environment. When the "istio.enabled" setting in the "values.yaml" is true, the deployed pods are automatically injected with an Istio sidecar proxy, which transparently intercepts inbound and outbound traffic. This enables consistent routing, load balancing, observability metrics, and security enforcement across the service mesh without requiring any application-specific changes. 

Before proceeding with this section, the Prometheus stack needs to be installed for telemetry purposes. Once the Prometheus stack is deployed on the Minikube cluster, metrics can be queried and graphically charted over time. 
1. Configure Helm repository.\
`> helm repo add prometheus-community https://prometheus-community.github.io/helm-charts`\
`> helm repo update`
2. Deploy Prometheus stack.\
`> helm install monitoring prometheus-community/kube-prometheus-stack --namespace monitoring --create-namespace`
3. Verify Prometheus deployment.<sup>1</sup>\
`> helm list -n monitoring`

### Prerequisite
The Istio service mesh is installed by following the steps below. 
1. Navigate to the Istio download site.\
`https://istio.io/latest/docs/setup/getting-started/#download`
2. Download the software by selecting the "Istio release" link and then clicking on the appropriate zip file.\
`e.g. https://github.com/istio/istio/releases/download/<latest-version>/istio-<latest-version>-win.zip`<sup>1</sup>
3. Unzip the software into a local directory and run the install from the 'bin' directory.\
`> istioctl install --set profile=demo -y`

<sup>1</sup> Minimum version: 1.29.2 or above

Verify the Istio system installation.
1. Confirm version of Istio.\
`istioctl version`
2. Query status of Istio control plane.\
`kubectl get pods -n istio-system`
3. Confirm "istiod" container and ingress/egress gateways are in "Running" state.
```
NAME                                    READY   STATUS 
istio-egressgateway-5bd755b557-5n8h9    1/1     Running
istio-ingressgateway-6497cf79bc-9llfq   1/1     Running
istiod-75659b6dd4-fr58n                 1/1     Running
```

Define a new project or namespace with Istio injection.
1. Create the namespace.\
`> kubectl create namespace istio-test`
2. Label the namespace.\
`> kubectl label namespace istio-test istio-injection=enabled`
3. Confirm the namesapce label configuration in the namespace.\
`> kubectl get namespace istio-test --show-labels`

### Install
1. Change to the ITX-LS Helm chart "istio" directory and use the "myistio_values.yaml" file, which contains the following content:
``` { .yaml }
istio:
  enabled: true
```
2. Install ITX-LS and Istio Prometheus monitoring.\
`> kubectl apply -f pod_monitor.yaml`\
`> helm install httplsnr ..\.. -f ..\http\myhttp_values.yaml -f myistio_values.yaml -n istio-test`
3. Confirm that two out of two containers are listed as ready.\
`> kubectl get pods -n istio-test` 

### Deploy
1. List the name of the ITX-LS container.\
`> kubectl get pods -l app.kubernetes.io/component=rest-v1 -n istio-test`
2. Copy the sample map to the container's default map location.\
`> kubectl cp ..\http\lsnrtest.lnx -n istio-test < name-from-step-1 >:/data/maps`\
`> kubectl cp ..\http\lsnrtest.msl -n istio-test < name-from-step-1 >:/data/systems`
3. Restart the pod.\
`> kubectl scale --replicas=0 deployment/httplsnr-itx-ls`\
`> kubectl scale --replicas=1 deployment/httplsnr-itx-ls`
4. Expose the Prometheus port.\
`> kubectl port-forward svc/monitoring-kube-prometheus-prometheus 9090:9090 -n monitoring`<sup>1</sup>

<sup>1</sup> Optionally use a different external port by replacing the first 9090 with the new one.

### Execute
1. Attach to the pod.\
`> kubectl exec -it -n istio-test <pod-name-from-Deploy-step-1> -- bash`
2. Make a HTTP Listner request.\
`> curl -X GET "http://httplsnr-itx-ls.istio-test.svc.cluster.local:5017/example"`
3. Open Prometheus dashboard to confirm that the istio service mesh is getting monitored.\
`http://localhost:9090/query`

### Queries

The following Prometheus queries illustrate Istio telemetry metrics that are scraped and exposed by the service mesh.

1. Count requests.<sup>1</sup>\
`sum(istio_request_duration_milliseconds_count{destination_service="httplsnr-itx-ls.istio-test.svc.cluster.local",reporter="destination"})`
2. Get p95 latency.<sup>2</sup>\
`histogram_quantile(0.95, sum(rate(istio_request_duration_milliseconds_bucket{destination_service="httplsnr-itx-ls.istio-test.svc.cluster.local",reporter="destination"}[1m])) by (le))`
3. Calculate rate of requests per second.<sup>3</sup>\
`sum(rate(istio_requests_total{destination_service="httplsnr-itx-ls.istio-test.svc.cluster.local",reporter="destination"}[1m]))`

<sup>1</sup>The count value starts at 1 and increments after each new request is made in Step 2 of Execute.\
<sup>2</sup>Simulate traffic with this command:\
`> while true; do seq 1 10 | xargs -P 10 -I {} curl -s -X GET "http://httplsnr-itx-ls.istio-test.svc.cluster.local/example"; sleep 1; echo "Enter CTRL-C to stop."; done`\
<sup>3</sup>Select the "Graph" tab.

### Cleanup
1. Delete pod monitor.\
`> kubectl delete -f pod_monitor.yaml`
2. Uninstall ITX-LS.\
`> helm uninstall httplsnr`
