# Release Notes

This document is release notes for IBM&reg; Sterling Transformation Extender Launcher Container 11.0.3
<br>&copy; Copyright IBM Corporation 2025, 2026 All rights reserved.
<br>Program Number : 5724-Q23


## What's new

This container version includes IBM&reg; Sterling Transformation Extender 11.0.3. It targets Red Hat OpenShift 4.20. IBM Sterling Transformation Extender Launcher Container 11.0.3 is based on IBM Sterling Transformation Extender 11.0.3 version.

What's new for IBM Sterling Transformation Extender 11.0.3 version is as follows:
https://www.ibm.com/docs/en/ste/11.0.3?topic=new-whats-in-v11030

### Service Mesh

Deployments can seamlessly integrate with an Istio service mesh to provide service-to-service communication. When the `istio.enabled` setting in the `values.yaml` file is set to `true`, deployed pods are automatically injected with an Istio sidecar proxy that transparently intercepts inbound and outbound traffic.

This integration provides consistent traffic routing, load balancing, observability metrics, and security enforcement across the service mesh without requiring application-specific changes.

### Examples

The Examples README includes new content demonstrating how to integrate a deployment with an Istio service mesh. It covers service mesh enablement, Prometheus metrics collection, and runtime diagnostics using standard observability tools.

## Fixes

Release notes for IBM Sterling Transformation Extender 11.0.3 follows:
https://www.ibm.com/support/pages/node/7274034

See `RESOLVED AUTHORIZED PROGRAM ANALYSIS REPORTS (APARs)` section for details.
<br>NOTE: Not all listed APARs are applicable for this container release.


## Prerequisites

Refer to the main `README` document.

## Version History

2.0.x - IBM Sterling Transformation Extender Launcher Container 10.1.2
<br>3.1.x - IBM Sterling Transformation Extender Launcher Container 11.0.2
<br>3.2.x - IBM Sterling Transformation Extender Launcher Container 11.0.3
* 3.2.0 - 20260625 : The image with ID 8e242d20d31d includes security patches and fixes applied through 11.0.3.0 build 46.

## Breaking Changes

Refer to the `Migration` section in the documentation.

## Documentation

For general IBM Sterling Transformation Extender documentation, refer to the product's [knowledge center](https://www.ibm.com/docs/en/ste/11.0.3).
