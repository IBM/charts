{{/*
Application name
*/}}
{{- define "itx-ls.appName" }}
  {{- "itx-ls" }}
{{- end }}
{{/*
Expand the name of the chart.
*/}}
{{- define "itx-ls.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "itx-ls.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default (include "itx-ls.appName" .) .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "itx-ls.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Annotations for metering
*/}}
{{- define "itx-ls.metering" -}}
productID: "d59a3123987c4e02a80fe63b9c624193"
productName: "IBM Sterling Transformation Extender Launcher Container"
productVersion: "11.0.3"
productMetric: "VIRTUAL_PROCESSOR_CORE"
productChargedContainers: "All"
{{- end -}}

{{/*
Selector labels
*/}}
{{- define "itx-ls.selectorLabels" -}}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/name: {{ include "itx-ls.appName" . }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "itx-ls.labels" -}}
{{ include "itx-ls.selectorLabels" . }}
app.kubernetes.io/managed-by: {{ .Release.Service | quote }}
helm.sh/chart: {{ include "itx-ls.chart" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
{{- end }}

{{/*
Directory path of files used for external integrations 
*/}}
{{- define "itx-ls.external.volume.path" -}}
{{- default "/xdata" .Values.external.data.volume.path }}
{{- end -}}

{{/*
Secret volume
*/}}
{{- define "itx-ls.secretvol" -}}
{{- $extsecrets := $.Values.external.secrets }}
{{- range $extsecret := $extsecrets }}
- name: {{ print $extsecret.name "-" $extsecret.data "-volume" | replace "." "-" | replace "_" "-" | lower | trunc 63 }}
  secret:
    secretName: {{ $extsecret.name }}
    defaultMode: {{ default "288" $extsecret.mode }}
{{- end -}}
{{- end -}}

{{/*
Secret volume mounts
*/}}
{{- define "itx-ls.secretvolmnt" -}}
{{- $extsecrets := $.Values.external.secrets }}
{{- range $extsecret := $extsecrets }}
- name: {{ print $extsecret.name "-" $extsecret.data "-volume" | replace "." "-" | replace "_" "-" | lower | trunc 63 }}
  mountPath: {{ printf "%s/%s/%s" $.Values.external.data.volume.path $.Values.external.data.secret.subpath $extsecret.data }}
  subPath: {{ $extsecret.data }}
  readOnly: true
{{- end -}}
{{- end -}}

{{/* Directory path of generic secret files */}}
{{- define "itx-ls.external.volume.path.secrets" -}}
{{- printf "%s/%s" (include "itx-ls.external.volume.path" . ) .Values.external.data.secret.subpath }}
{{- end -}}

{{/*
TLS volume
*/}}
{{- define "itx-ls.tlsvol" -}}
{{- $extsecrets := $.Values.external.tls }}
{{- range $extsecret := $extsecrets }}
- name: {{ print $extsecret.name "-tls-volume" | replace "." "-" | replace "_" "-" | lower | trunc 63 }}
  secret:
    secretName: {{ $extsecret.name }}
    defaultMode: {{ default "288" $extsecret.mode }}
    items:
      - key: tls.crt
        path: {{ printf "%s.crt" $extsecret.name }} 
      - key: tls.key
        path: {{ printf "%s.key" $extsecret.name }} 
{{- end -}}
{{- end -}}

{{/*
TLS volume mounts
*/}}
{{- define "itx-ls.tlsvolmnt" -}}
{{- $extsecrets := $.Values.external.tls }}
{{- range $extsecret := $extsecrets }}
- name: {{ print $extsecret.name "-tls-volume" | replace "." "-" | replace "_" "-" | lower | trunc 63 }}
  mountPath: {{ printf "%s/%s/%s" $.Values.external.data.volume.path $.Values.external.data.tls.subpath $extsecret.name }}
  readOnly: true
{{- end -}}
{{- end -}}

{{/*
TLS Environment variable that tracks import status
*/}}
{{- define "itx-ls.tlsenv" -}}
{{- $extsecrets := $.Values.external.tls }}
{{- $counter := 0 }}
{{- $files := "" }}
{{- range $extsecret := $extsecrets }}
{{- if $extsecret.import }}
{{- $counter = add1 $counter }}
{{- $files = printf "%s%s," $files $extsecret.name  }}
{{- end -}}
{{- end -}}
{{- if gt $counter 0 }}
- name: {{ print "ITX_TLS_IMPORT_LIST" }}
  value: {{ $files }}
{{- end -}}
{{- end -}}

{{/*
ConfigMap volume
*/}}
{{- define "itx-ls.configmap.vol" -}}
{{- $extcfgs := .Values.external.configMaps }}
{{- range $extcfg := $extcfgs }}
- name: {{ print $extcfg.name "-" $extcfg.key "-volume" | replace "." "-" | replace "_" "-" | lower | trunc 63 }}
  configMap:
    name: {{ $extcfg.name }}
    items:
    - key: {{ $extcfg.key }}
      path: {{ $extcfg.path }}
{{- end -}}
{{- end -}}

{{/*
ConfigMap volume mounts
*/}}
{{- define "itx-ls.configmap.volmnt" -}}
{{- $extcfgs := .Values.external.configMaps }}
{{- range $extcfg := $extcfgs }}
- name: {{ print $extcfg.name "-" $extcfg.key "-volume" | replace "." "-" | replace "." "_" | replace "_" "-" | lower | trunc 63 }}
  mountPath: {{ printf "%s/%s/%s" $.Values.external.data.volume.path $.Values.external.data.configMap.subpath $extcfg.path }}
  subPath: {{ $extcfg.path }}
  readOnly: true
{{- end -}}
{{- end -}}

{{/*
Create the name of the service account to use
*/}}
{{- define "itx-ls.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "itx-ls.fullname" .) .Values.serviceAccount.existingName }}
{{- else }}
{{- default "default" .Values.serviceAccount.existingName }}
{{- end }}
{{- end }}

{{/*
License accept value
*/}}
{{- define "itx-ls.license-accept" -}}
{{- if and (kindIs "bool" .Values.license) .Values.license -}}
"true"
{{- else -}}
{{ fail "You must read the license, https://ibm.biz/ITX_LauncherLicense_11_0_3, and confirm acceptance by setting the 'license' field in the \"values.yaml\" file to 'true'." }}
{{- end -}}
{{- end }}

{{/*
Image (Container) Repository
*/}}
{{- define "itx-ls.image.repository" -}}
  {{- if $.Values.image.repository -}}
  {{- if $.Values.image.registry -}}
  {{- print $.Values.image.registry "/" $.Values.image.repository -}}
  {{- else -}}
  {{- $.Values.image.repository -}}
  {{- end -}}
  {{- else -}}
  {{- fail "The itx-ls image repository must be defined." }}
  {{- end -}}
{{- end -}}

{{/*
Image (Container) Tag
*/}}
{{- define "itx-ls.image.tag" -}}
  {{- if $.Values.image.digest -}}
  @{{ $.Values.image.digest }}
  {{- else if $.Values.image.tag -}}
  :{{ $.Values.image.tag }}
  {{- else }}
  {{- fail "The itx-ls image tag must be defined." }}
  {{- end -}}
{{- end -}}

{{/*
Image (Container) Pull Policy
*/}}
{{- define "itx-ls.image.pull.policy" -}}
{{- if and .Values.image.digest .Values.image.pullPolicy -}}
{{ .Values.image.pullPolicy }}
{{- else if .Values.image.pullPolicyOverride -}}
{{ .Values.image.pullPolicy }}
{{- else -}}
Always
{{- end -}}
{{- end -}}
