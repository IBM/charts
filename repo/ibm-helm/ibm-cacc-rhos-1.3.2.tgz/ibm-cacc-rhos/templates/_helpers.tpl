{{/*
Generic key/value renderer (labels/annotations/etc.)
Usage:
  {{ include "cacc.render.kvs" (dict "map" .Values.globalAnnotations) }}
*/}}
{{- define "cacc.render.kvs" -}}
{{- range $k, $v := (.map | default dict) }}
{{ $k }}: {{ $v | quote }}
{{- end }}
{{- end }}

{{/*
Generic extra environment variables merger — global + service-level (service overrides global)
Usage:
  {{- include "cacc.extraEnv" (dict "Values" .Values "svcPath" "contentManagerService") | nindent 12 }}
*/}}
{{- define "cacc.extraEnv" -}}
{{- range $k, $v := (merge ((get .Values.services .svcPath).extraEnv | default dict) (.Values.global.extraEnv | default dict)) }}
- name: {{ $k }}
  value: {{ $v | quote }}
{{- end }}
{{- end }}

{{/*
-------------------------------------------------------------------------------
Labels (global + object-specific + service-specific)
-------------------------------------------------------------------------------
*/}}

{{/*
Global labels - applied to all resources
*/}}
{{- define "cacc.labels" -}}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/instance: {{ .Release.Name }}
helm.sh/chart: {{ .Chart.Name }}
{{- include "cacc.render.kvs" (dict "map" .Values.globalLabels) }}
{{- end }}

{{/*
All configMap labels
*/}}
{{- define "cacc.cm.labels" -}}
{{- include "cacc.render.kvs" (dict "map" .Values.objectSpecificLabels.configMap) }}
{{- end }}

{{/*
All deployment labels
*/}}
{{- define "cacc.deploy.labels" -}}
{{- include "cacc.render.kvs" (dict "map" .Values.objectSpecificLabels.deployment) }}
{{- end }}

{{/*
HorizontalPodAutoscaler labels
*/}}
{{- define "cacc.hpa.labels" -}}
{{- include "cacc.render.kvs" (dict "map" .Values.objectSpecificLabels.horizontalPodAutoscaler) }}
{{- end }}

{{/*
PersistentVolumeClaim labels
*/}}
{{- define "cacc.pvc.labels" -}}
{{- include "cacc.render.kvs" (dict "map" .Values.objectSpecificLabels.persistentVolumeClaim) }}
{{- end }}

{{/*
PodDisruptionBudget labels
*/}}
{{- define "cacc.pdb.labels" -}}
{{- include "cacc.render.kvs" (dict "map" .Values.objectSpecificLabels.podDisruptionBudget) }}
{{- end }}

{{/*
ServiceMonitor labels
*/}}
{{- define "cacc.serviceMonitor.labels" -}}
{{- include "cacc.render.kvs" (dict "map" .Values.objectSpecificLabels.serviceMonitor) }}
{{- end }}

{{/*
Service labels
*/}}
{{- define "cacc.svc.labels" -}}
{{- include "cacc.render.kvs" (dict "map" .Values.objectSpecificLabels.service) }}
{{- end }}

{{/*
All statefulSet labels
*/}}
{{- define "cacc.sts.labels" -}}
{{- include "cacc.render.kvs" (dict "map" .Values.objectSpecificLabels.statefulSet) }}
{{- end }}

{{/*
Service-specific labels
*/}}

{{/*
CA Ingress Deployment labels
*/}}
{{- define "cacc.deploy.ingress.labels" -}}
{{- include "cacc.render.kvs" (dict "map" .Values.services.caIngressService.labels) }}
{{- end }}

{{/*
Reporting Deployment labels
*/}}
{{- define "cacc.deploy.reporting.labels" -}}
{{- include "cacc.render.kvs" (dict "map" .Values.services.reportingService.labels) }}
{{- end }}

{{/*
Content Manager StatefulSet labels
*/}}
{{- define "cacc.sts.cm.labels" -}}
{{- include "cacc.render.kvs" (dict "map" .Values.services.contentManagerService.labels) }}
{{- end }}

{{/*
Rest Deployment labels
*/}}
{{- define "cacc.deploy.rest.labels" -}}
{{- include "cacc.render.kvs" (dict "map" .Values.services.restService.labels) }}
{{- end }}

{{/*
UI Deployment labels
*/}}
{{- define "cacc.deploy.ui.labels" -}}
{{- include "cacc.render.kvs" (dict "map" .Values.services.uiService.labels) }}
{{- end }}

{{/*
Smarts Deployment labels
*/}}
{{- define "cacc.deploy.smarts.labels" -}}
{{- include "cacc.render.kvs" (dict "map" .Values.services.smartsService.labels) }}
{{- end }}

{{/*
Dataset Service (DSS) Deployment labels
*/}}
{{- define "cacc.deploy.dss.labels" -}}
{{- include "cacc.render.kvs" (dict "map" .Values.services.dataService.labels) }}
{{- end }}

{{/*
Agentic AI Deployment labels
*/}}
{{- define "cacc.deploy.agenticai.labels" -}}
{{- include "cacc.render.kvs" (dict "map" .Values.services.agenticAIService.labels) }}
{{- end }}

{{/*
-------------------------------------------------------------------------------
Annotations (global + object-specific + service-specific)
-------------------------------------------------------------------------------
*/}}

{{/*
Global annotations
*/}}
{{- define "cacc.annotations" -}}
{{- include "cacc.render.kvs" (dict "map" .Values.globalAnnotations) }}
{{- end }}

{{/*
ConfigMap annotations
*/}}
{{- define "cacc.cm.annotations" -}}
{{- include "cacc.render.kvs" (dict "map" .Values.objectSpecificAnnotations.configMap) }}
{{- end }}

{{/*
Deployment annotations
*/}}
{{- define "cacc.deploy.annotations" -}}
{{- include "cacc.render.kvs" (dict "map" .Values.objectSpecificAnnotations.deployment) }}
{{- end }}

{{/*
PodDisruptionBudget annotations
*/}}
{{- define "cacc.pdb.annotations" -}}
{{- include "cacc.render.kvs" (dict "map" .Values.objectSpecificAnnotations.podDisruptionBudget) }}
{{- end }}

{{/*
HorizontalPodAutoscaler annotations
*/}}
{{- define "cacc.hpa.annotations" -}}
{{- include "cacc.render.kvs" (dict "map" .Values.objectSpecificAnnotations.horizontalPodAutoscaler) }}
{{- end }}

{{/*
PersistentVolumeClaim annotations
*/}}
{{- define "cacc.pvc.annotations" -}}
{{- include "cacc.render.kvs" (dict "map" .Values.objectSpecificAnnotations.persistentVolumeClaim) }}
{{- end }}

{{/*
ServiceMonitor annotations
*/}}
{{- define "cacc.serviceMonitor.annotations" -}}
{{- include "cacc.render.kvs" (dict "map" .Values.objectSpecificAnnotations.serviceMonitor) }}
{{- end }}

{{/*
Service annotations
*/}}
{{- define "cacc.svc.annotations" -}}
{{- include "cacc.render.kvs" (dict "map" .Values.objectSpecificAnnotations.service) }}
{{- end }}

{{/*
StatefulSet annotations
*/}}
{{- define "cacc.sts.annotations" -}}
{{- include "cacc.render.kvs" (dict "map" .Values.objectSpecificAnnotations.statefulSet) }}
{{- end }}

{{/*
Service-specific annotations
*/}}

{{/*
CA Ingress Deployment annotations
*/}}
{{- define "cacc.deploy.ingress.annotations" -}}
{{- include "cacc.render.kvs" (dict "map" .Values.services.caIngressService.annotations) }}
{{- end }}

{{/*
Reporting Deployment annotations
*/}}
{{- define "cacc.deploy.reporting.annotations" -}}
{{- include "cacc.render.kvs" (dict "map" .Values.services.reportingService.annotations) }}
{{- end }}

{{/*
Content Manager StatefulSet annotations
*/}}
{{- define "cacc.sts.cm.annotations" -}}
{{- include "cacc.render.kvs" (dict "map" .Values.services.contentManagerService.annotations) }}
{{- end }}

{{/*
Rest Deployment annotations
*/}}
{{- define "cacc.deploy.rest.annotations" -}}
{{- include "cacc.render.kvs" (dict "map" .Values.services.restService.annotations) }}
{{- end }}

{{/*
UI Deployment annotations
*/}}
{{- define "cacc.deploy.ui.annotations" -}}
{{- include "cacc.render.kvs" (dict "map" .Values.services.uiService.annotations) }}
{{- end }}

{{/*
Smarts Deployment annotations
*/}}
{{- define "cacc.deploy.smarts.annotations" -}}
{{- include "cacc.render.kvs" (dict "map" .Values.services.smartsService.annotations) }}
{{- end }}

{{/*
Dataset Service (DSS) Deployment annotations
*/}}
{{- define "cacc.deploy.dss.annotations" -}}
{{- include "cacc.render.kvs" (dict "map" .Values.services.dataService.annotations) }}
{{- end }}

{{/*
Agentic AI Deployment annotations
*/}}
{{- define "cacc.deploy.agenticai.annotations" -}}
{{- include "cacc.render.kvs" (dict "map" .Values.services.agenticAIService.annotations) }}
{{- end }}

{{/*
-------------------------------------------------------------------------------
PDB Disruption Budget Helper
-------------------------------------------------------------------------------
*/}}

{{/*
PDB disruption budget spec - renders either minAvailable or maxUnavailable
Usage: {{ include "cacc.pdb.disruptionBudget" (dict "pdb" .Values.services.restService.pdb "default" 1) }}
*/}}
{{- define "cacc.pdb.disruptionBudget" -}}
{{- if .pdb.maxUnavailable }}
maxUnavailable: {{ .pdb.maxUnavailable }}
{{- else }}
minAvailable: {{ .pdb.minAvailable | default .default }}
{{- end }}
{{- end }}

{{/*
-------------------------------------------------------------------------------
Other helpers
-------------------------------------------------------------------------------
*/}}

{{/*
Helper function to create nodeAffinity
*/}}
{{ define "cacc.nodeAffinity" }}
nodeAffinity:
  requiredDuringSchedulingIgnoredDuringExecution:
    nodeSelectorTerms:
    - matchExpressions:
      - key: kubernetes.io/arch
        operator: In
        values:
        - amd64
{{ end }}