{{/*
 Licensed Materials - Property of HCL
 (C) Copyright HCL Technologies Ltd. 2024, 2026.  All Rights Reserved.
 Note to U.S. Government Users Restricted Rights:
 Use, duplication or disclosure restricted by GSA ADP Schedule Contract
*/}}
{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}

{{- define "gitea.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "gitea.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create a default worker name.
*/}}
{{- define "gitea.workername" -}}
{{- printf "%s-%s" .global.Release.Name .worker | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "gitea.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create image name and tag used by the deployment.
*/}}
{{- define "gitea.image" -}}
{{- $fullOverride := .Values.image.fullOverride | default "" -}}
{{- $registry := default .Values.global.imageRegistry .Values.image.registry -}}
{{- $repository := .Values.image.repository -}}
{{- if $registry -}}
    {{- $registry = ($registry | clean | trimSuffix "/") -}}
{{- end -}}
{{- if (or (eq $registry "hclcr.io") (eq $registry "cp.icr.io/cp") (eq $registry "cp.stg.icr.io/cp") (eq $registry "preprod.icr.io/cp")) }}
    {{- $repository = (printf "devops-plan/%s" $repository) -}}
{{- end -}}
{{- $separator := ":" -}}
{{- $tag := .Values.image.tag | default .Chart.AppVersion | toString -}}
{{- $rootless := ternary "-rootless" "" (.Values.image.rootlessPull) -}}
{{- $digest := "" -}}
{{- if .Values.image.digest }}
    {{- $digest = (printf "@%s" (.Values.image.digest | toString)) -}}
    {{- $tag = "" -}}
    {{- $separator = "" -}}
{{- end -}}
{{- if $fullOverride }}
    {{- printf "%s" $fullOverride -}}
{{- else if $registry }}
    {{- printf "%s/%s%s%s%s%s" $registry $repository $separator $tag $rootless $digest -}}
{{- else -}}
    {{- printf "%s%s%s%s%s" $repository $separator $tag $rootless $digest -}}
{{- end -}}
{{- end -}}

{{/*
Docker Image Registry Secret Names evaluating values as templates

The Control chart's values.yaml has empty arrays for
.Values.imagePullSecrets and .Values.global.imagePullSecrets.  To
support overrides of subchart functions (for redis and postgres), which
don't have the empty array (they have image.pullSecrets instead of
imagePullSecrets), we try .Values.image.pullSecrets or a default empty
list if necessary.

*/}}
{{- define "gitea.images.pullSecrets" -}}
{{- $pullSecrets := list -}}
{{- if .Values.imagePullSecrets -}}
  {{- range .Values.imagePullSecrets -}}
      {{- if kindIs "map" . -}}
        {{- $pullSecrets = append $pullSecrets . -}}
      {{- else -}}
        {{- $pullSecrets = append $pullSecrets (dict "name" .) -}}
      {{- end -}}
  {{- end -}}
{{- end -}}
{{- if .Values.image.pullSecrets -}}
  {{- range .Values.image.pullSecrets -}}
      {{- if kindIs "map" . -}}
        {{- $pullSecrets = append $pullSecrets . -}}
      {{- else -}}
        {{- $pullSecrets = append $pullSecrets (dict "name" .) -}}
      {{- end -}}
  {{- end -}}
{{- end -}}
{{- if .Values.global.imagePullSecrets -}}
 {{- range .Values.global.imagePullSecrets -}}
   {{- if kindIs "map" . -}}
    {{- $pullSecrets = append $pullSecrets . -}}
   {{- else -}}
    {{- $pullSecrets = append $pullSecrets (dict "name" .) -}}
   {{- end -}}
 {{- end -}}
{{- else if .Values.global.imagePullSecret -}}
 {{- $pullSecrets = append $pullSecrets (dict "name" .Values.global.imagePullSecret) -}}
{{- end -}}
{{- if .Values.imagePullSecret -}}
 {{- $pullSecrets = append $pullSecrets (dict "name" .Values.imagePullSecret) -}}
{{- end -}}
{{- if (not (empty $pullSecrets)) }}
imagePullSecrets:
{{ toYaml $pullSecrets }}
{{- end }}
{{- end -}}


{{/*
Storage Class
*/}}
{{- define "gitea.persistence.baseClaimName" -}}
{{- $persistence := default dict .Values.persistence -}}
{{- tpl (default "{{.Release.Name}}-control-shared-storage" (get $persistence "claimName")) . -}}
{{- end -}}

{{- define "gitea.persistence.legacyClaimName" -}}
{{- $persistence := default dict .Values.persistence -}}
{{- $nfsV3 := default dict (get $persistence "nfsV3") -}}
{{- $migration := default dict (get $nfsV3 "migration") -}}
{{- $claimName := default "" (get $migration "sourceClaimName") -}}
{{- if $claimName -}}
{{- tpl $claimName . -}}
{{- else -}}
{{- include "gitea.persistence.baseClaimName" . -}}
{{- end -}}
{{- end -}}

{{- define "gitea.persistence.baseStorageClassName" -}}
{{- $persistence := default dict .Values.persistence -}}
{{- $global := default dict .Values.global -}}
{{- $platform := default dict (get $global "platform") -}}
{{- $plan := default dict (get $global "plan") -}}
{{- $globalPersistence := default dict (get $global "persistence") -}}
{{- $storageClass := (tpl (default "" (get $persistence "storageClass")) .) | default (tpl (default "" (get $global "storageClass")) .) -}}
{{- if (and (or (default false (get $platform "enabled")) (default false (get $plan "enabled"))) (gt (len $globalPersistence) 0) (eq $storageClass "")) -}}
{{- default "" (get $globalPersistence "rwoStorageClass") -}}
{{- else -}}
{{- $storageClass -}}
{{- end -}}
{{- end -}}

{{- define "gitea.persistence.nfsv3.sourceStorageClassName" -}}
{{- $persistence := default dict .Values.persistence -}}
{{- $nfsV3 := default dict (get $persistence "nfsV3") -}}
{{- $storageClass := default "" (get $nfsV3 "sourceStorageClass") -}}
{{- if not $storageClass -}}
{{- $storageClass = include "gitea.persistence.baseStorageClassName" . -}}
{{- end -}}
{{- if $storageClass -}}
{{- tpl $storageClass . -}}
{{- else -}}
{{- $claimName := include "gitea.persistence.legacyClaimName" . -}}
{{- $namespace := .Values.namespace | default .Release.Namespace -}}
{{- if $claimName -}}
{{- $claim := (lookup "v1" "PersistentVolumeClaim" $namespace $claimName) | default dict -}}
{{- $spec := default dict (get $claim "spec") -}}
{{- default "" (get $spec "storageClassName") -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "gitea.persistence.nfsv3.storageClassName" -}}
{{- $persistence := default dict .Values.persistence -}}
{{- $nfsV3 := default dict (get $persistence "nfsV3") -}}
{{- $storageClassName := default "" (get $nfsV3 "storageClassName") -}}
{{- if $storageClassName -}}
{{- tpl $storageClassName . | trunc 253 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-nfsv3" (include "gitea.fullname" .) | trunc 253 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{- define "gitea.persistence.nfsv3.targetStorageClassExists" -}}
{{- $persistence := default dict .Values.persistence -}}
{{- $nfsV3 := default dict (get $persistence "nfsV3") -}}
{{- if not (default false (get $nfsV3 "enabled")) -}}
false
{{- else -}}
{{- $storageClassName := include "gitea.persistence.nfsv3.storageClassName" . -}}
{{- $storageClass := (lookup "storage.k8s.io/v1" "StorageClass" "" $storageClassName) | default dict -}}
{{- if get $storageClass "metadata" -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "gitea.persistence.nfsv3.shouldUseCustomStorageClass" -}}
{{- $persistence := default dict .Values.persistence -}}
{{- $nfsV3 := default dict (get $persistence "nfsV3") -}}
{{- if not (default false (get $nfsV3 "enabled")) -}}
false
{{- else if eq (include "gitea.persistence.nfsv3.targetStorageClassExists" .) "true" -}}
true
{{- else -}}
{{- $sourceStorageClass := include "gitea.persistence.nfsv3.sourceStorageClassName" . -}}
{{- $explicitSourceStorageClass := default "" (get $nfsV3 "sourceStorageClass") -}}
{{- $triggerStorageClass := default "nfs-client" (get $nfsV3 "triggerStorageClass") -}}
{{- $provisioner := default "" (get $nfsV3 "provisioner") -}}
{{- if and $sourceStorageClass (or (eq $sourceStorageClass $triggerStorageClass) $explicitSourceStorageClass $provisioner) -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "gitea.persistence.nfsv3.canRenderCustomStorageClass" -}}
{{- $persistence := default dict .Values.persistence -}}
{{- $nfsV3 := default dict (get $persistence "nfsV3") -}}
{{- if ne (include "gitea.persistence.nfsv3.shouldUseCustomStorageClass" .) "true" -}}
false
{{- else if eq (include "gitea.persistence.nfsv3.targetStorageClassExists" .) "true" -}}
true
{{- else if (default "" (get $nfsV3 "provisioner")) -}}
true
{{- else -}}
{{- $sourceStorageClassName := include "gitea.persistence.nfsv3.sourceStorageClassName" . -}}
{{- if not $sourceStorageClassName -}}
false
{{- else -}}
{{- $sourceStorageClass := (lookup "storage.k8s.io/v1" "StorageClass" "" $sourceStorageClassName) | default dict -}}
{{- if get $sourceStorageClass "provisioner" -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "gitea.persistence.claimName" -}}
{{- $persistence := default dict .Values.persistence -}}
{{- $nfsV3 := default dict (get $persistence "nfsV3") -}}
{{- $claimName := include "gitea.persistence.baseClaimName" . -}}
{{- if eq (include "gitea.persistence.nfsv3.canRenderCustomStorageClass" .) "true" -}}
{{- $customClaimName := default "" (get $nfsV3 "claimName") -}}
{{- if $customClaimName -}}
{{- tpl $customClaimName . -}}
{{- else -}}
{{- printf "%s-nfsv3" $claimName | trunc 253 | trimSuffix "-" -}}
{{- end -}}
{{- else -}}
{{- $claimName -}}
{{- end -}}
{{- end -}}

{{- define "gitea.persistence.storageClassName" -}}
{{- if eq (include "gitea.persistence.nfsv3.canRenderCustomStorageClass" .) "true" -}}
{{- include "gitea.persistence.nfsv3.storageClassName" . -}}
{{- else -}}
{{- include "gitea.persistence.baseStorageClassName" . -}}
{{- end -}}
{{- end -}}

{{- define "gitea.persistence.nfsv3.sourceClaimExists" -}}
{{- $claimName := include "gitea.persistence.legacyClaimName" . -}}
{{- $namespace := .Values.namespace | default .Release.Namespace -}}
{{- if not $claimName -}}
false
{{- else -}}
{{- $claim := (lookup "v1" "PersistentVolumeClaim" $namespace $claimName) | default dict -}}
{{- if get $claim "metadata" -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "gitea.persistence.nfsv3.migrationRequired" -}}
{{- $persistence := default dict .Values.persistence -}}
{{- $nfsV3 := default dict (get $persistence "nfsV3") -}}
{{- $migration := default dict (get $nfsV3 "migration") -}}
{{- if default false (get $migration "force") -}}
true
{{- else if not (default false (get $migration "enabled")) -}}
false
{{- else if not .Release.IsUpgrade -}}
false
{{- else if ne (include "gitea.persistence.nfsv3.canRenderCustomStorageClass" .) "true" -}}
false
{{- else if eq (include "gitea.persistence.claimName" .) (include "gitea.persistence.legacyClaimName" .) -}}
false
{{- else if ne (include "gitea.persistence.nfsv3.sourceClaimExists" .) "true" -}}
false
{{- else -}}
true
{{- end -}}
{{- end -}}

{{- define "gitea.persistence.storageClass" -}}
{{- $storageClass := include "gitea.persistence.storageClassName" . -}}
{{- if $storageClass }}
storageClassName: {{ $storageClass | quote }}
{{- end }}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "gitea.labels" -}}
helm.sh/chart: {{ include "gitea.chart" . }}
app: {{ include "gitea.name" . }}
{{ include "gitea.selectorLabels" . }}
app.kubernetes.io/version: {{ .Values.image.tag | default .Chart.AppVersion | quote }}
version: {{ .Values.image.tag | default .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{- define "gitea.labels.actRunner" -}}
helm.sh/chart: {{ include "gitea.chart" . }}
app: {{ include "gitea.name" . }}-act-runner
{{ include "gitea.selectorLabels.actRunner" . }}
app.kubernetes.io/version: {{ .Values.image.tag | default .Chart.AppVersion | quote }}
version: {{ .Values.image.tag | default .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{/*
Selector labels
*/}}
{{- define "gitea.selectorLabels" -}}
app.kubernetes.io/name: {{ include "gitea.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{- define "gitea.selectorLabels.actRunner" -}}
app.kubernetes.io/name: {{ include "gitea.name" . }}-act-runner
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{- define "postgresql-ha.dns" -}}
{{- if (index .Values "postgresql-ha").enabled -}}
{{- printf "%s-postgresql-ha-pgpool.%s.svc.%s:%g" .Release.Name .Release.Namespace .Values.clusterDomain (index .Values "postgresql-ha" "service" "ports" "postgresql") -}}
{{- end -}}
{{- end -}}

{{- define "postgresql.dns" -}}
{{- if (index .Values "postgresql").enabled -}}
{{- printf "%s-%s.%s.svc.%s:%g" .Release.Name (default "postgresql" .Values.postgresql.nameOverride) .Release.Namespace .Values.clusterDomain .Values.postgresql.global.postgresql.service.ports.postgresql -}}
{{- end -}}
{{- end -}}

{{- define "redis.dns" -}}
{{- if and ((index .Values "redis-cluster").enabled) ((index .Values "redis").enabled) -}}
{{- fail "redis and redis-cluster cannot be enabled at the same time. Please only choose one." -}}
{{- else if (index .Values "redis-cluster").enabled -}}
{{- printf "redis+cluster://:%s@%s-redis-cluster.%s.svc.%s:%d/0?pool_size=100&idle_timeout=180s&" (index .Values "redis-cluster").global.redis.password .Release.Name .Release.Namespace .Values.clusterDomain ( (index .Values "redis-cluster").service.ports.redis | int ) -}}
{{- else if (index .Values "redis").enabled -}}
{{- printf "redis://:%s@%s-redis-master.%s.svc.%s:%d/0?pool_size=100&idle_timeout=180s&" (index .Values "redis").global.redis.password .Release.Name .Release.Namespace .Values.clusterDomain ( (index .Values "redis").master.service.ports.redis | int ) -}}
{{- end -}}
{{- end -}}

{{- define "redis.port" -}}
{{- if (index .Values "redis-cluster").enabled -}}
{{ (index .Values "redis-cluster").service.ports.redis }}
{{- else if (index .Values "redis").enabled -}}
{{ (index .Values "redis").master.service.ports.redis }}
{{- end -}}
{{- end -}}

{{- define "valkey.dns" -}}
{{- if and ((index .Values "valkey-cluster").enabled) ((index .Values "valkey").enabled) -}}
{{- fail "valkey and valkey-cluster cannot be enabled at the same time. Please only choose one." -}}
{{- else if (index .Values "valkey-cluster").enabled -}}
{{- printf "redis+cluster://:%s@%s-valkey-cluster-headless.%s.svc.%s:%g/0?pool_size=100&idle_timeout=180s&" (index .Values "valkey-cluster").global.valkey.password .Release.Name .Release.Namespace .Values.clusterDomain (index .Values "valkey-cluster").service.ports.valkey -}}
{{- else if (index .Values "valkey").enabled -}}
{{- printf "redis://:%s@%s-valkey-headless.%s.svc.%s:%g/0?pool_size=100&idle_timeout=180s&" (index .Values "valkey").global.valkey.password .Release.Name .Release.Namespace .Values.clusterDomain (index .Values "valkey").master.service.ports.valkey -}}

{{- end -}}
{{- end -}}

{{- define "valkey.port" -}}
{{- if (index .Values "valkey-cluster").enabled -}}
{{ (index .Values "valkey-cluster").service.ports.valkey }}
{{- else if (index .Values "valkey").enabled -}}
{{ (index .Values "valkey").master.service.ports.valkey }}
{{- end -}}
{{- end -}}

{{- define "redis.servicename" -}}
{{- if (index .Values "redis-cluster").enabled -}}
{{- printf "%s-redis-cluster.%s.svc.%s" .Release.Name .Release.Namespace .Values.clusterDomain -}}
{{- else if (index .Values "redis").enabled -}}
{{- printf "%s-redis-master.%s.svc.%s" .Release.Name .Release.Namespace .Values.clusterDomain -}}
{{- end -}}
{{- end -}}

{{- define "valkey.servicename" -}}
{{- if (index .Values "valkey-cluster").enabled -}}
{{- printf "%s-valkey-cluster.%s.svc.%s" .Release.Name .Release.Namespace .Values.clusterDomain -}}
{{- else if (index .Values "valkey").enabled -}}
{{- printf "%s-valkey-primary.%s.svc.%s" .Release.Name .Release.Namespace .Values.clusterDomain -}}
{{- end -}}
{{- end -}}

{{- define "gitea.default_domain" -}}
{{- printf "%s-http.%s.svc.%s" (include "gitea.fullname" .) .Release.Namespace .Values.clusterDomain -}}
{{- end -}}

{{- define "gitea.ldap_settings" -}}
{{- $idx := index . 0 }}
{{- $values := index . 1 }}

{{- if not (hasKey $values "bindDn") -}}
{{- $_ := set $values "bindDn" "" -}}
{{- end -}}

{{- if not (hasKey $values "bindPassword") -}}
{{- $_ := set $values "bindPassword" "" -}}
{{- end -}}

{{- $flags := list "notActive" "skipTlsVerify" "allowDeactivateAll" "synchronizeUsers" "attributesInBind" -}}
{{- range $key, $val := $values -}}
{{- if and (ne $key "enabled") (ne $key "existingSecret") -}}
{{- if eq $key "bindDn" -}}
{{- printf "--%s \"${GITEA_LDAP_BIND_DN_%d}\" " ($key | kebabcase) ($idx) -}}
{{- else if eq $key "bindPassword" -}}
{{- printf "--%s \"${GITEA_LDAP_PASSWORD_%d}\" " ($key | kebabcase) ($idx) -}}
{{- else if eq $key "port" -}}
{{- printf "--%s %d " $key ($val | int) -}}
{{- else if has $key $flags -}}
{{- printf "--%s " ($key | kebabcase) -}}
{{- else -}}
{{- printf "--%s %s " ($key | kebabcase) ($val | squote) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "gitea.oauth_settings" -}}
{{- $idx := index . 0 }}
{{- $values := index . 1 }}
{{- $Vals := index . 2 }}

{{- if not (hasKey $values "key") -}}
{{- $_ := set $values "key" (printf "${GITEA_OAUTH_KEY_%d}" $idx) -}}
{{- end -}}

{{- if not (hasKey $values "secret") -}}
{{- $_ := set $values "secret" (printf "${GITEA_OAUTH_SECRET_%d}" $idx) -}}
{{- end -}}

{{- range $key, $val := $values -}}
{{- if $Vals.Values.global.platform.enabled -}}

{{- if (and (ne $key "existingSecret") (ne $key "autoDiscoverUrl")) -}}
{{- printf "--%s %s " ($key | kebabcase) ($val | quote) -}}
{{- end -}}

{{- if eq $key "autoDiscoverUrl" -}}
{{- if not $Vals.Values.global.domain -}}
  {{- fail "Missing global domain" -}}
{{- end -}}
{{- if not $Vals.Values.global.platform -}}
  {{- fail "Missing required global.platform setting" -}}
{{- end -}}
{{- if not $Vals.Values.global.platform.oidc -}}
  {{- fail "Missing required global.platform.oidc" -}}
{{- end -}}
{{- if not $Vals.Values.global.platform.oidc.issuerPath -}}
  {{- fail "Missing required global.platform.oidc.issuerPath" -}}
{{- end -}}
{{- printf "--%s %s " ($key | kebabcase) ((print "https://" $Vals.Values.global.domain $Vals.Values.global.platform.oidc.issuerPath "/.well-known/openid-configuration") | quote) -}}
{{- end -}}

{{- else -}}

{{- if ne $key "existingSecret" -}}
{{- printf "--%s %s " ($key | kebabcase) ($val | quote) -}}
{{- end -}}

{{- end -}}
{{- end -}}
{{- end -}}


{{- define "gitea.public_protocol" -}}
{{- if or .Values.ingress.type (and .Values.ingress.enabled (gt (len .Values.ingress.tls) 0)) -}}
https
{{- else -}}
{{ .Values.gitea.config.server.PROTOCOL }}
{{- end -}}
{{- end -}}

{{- define "gitea.inline_configuration" -}}
  {{- include "gitea.inline_configuration.init" . -}}
  {{- include "gitea.inline_configuration.defaults" . -}}

  {{- $generals := list -}}
  {{- $inlines := dict -}}

  {{- range $key, $value := .Values.gitea.config  }}
    {{- if kindIs "map" $value }}
      {{- if gt (len $value) 0 }}
        {{- $section := default list (get $inlines $key) -}}
        {{- range $n_key, $n_value := $value }}
          {{- $section = append $section (printf "%s=%v" $n_key $n_value) -}}
        {{- end }}
        {{- $_ := set $inlines $key (join "\n" $section) -}}
      {{- end -}}
    {{- else }}
      {{- if or (eq $key "APP_NAME") (eq $key "RUN_USER") (eq $key "RUN_MODE") -}}
        {{- $generals = append $generals (printf "%s=%s" $key $value) -}}
      {{- else -}}
        {{- (printf "Key %s cannot be on top level of configuration" $key) | fail -}}
      {{- end -}}

    {{- end }}
  {{- end }}

  {{- $_ := set $inlines "_generals_" (join "\n" $generals) -}}
  {{- toYaml $inlines -}}
{{- end -}}

{{- define "gitea.inline_configuration.init" -}}
  {{- if not (hasKey .Values.gitea.config "cache") -}}
    {{- $_ := set .Values.gitea.config "cache" dict -}}
  {{- end -}}
  {{- if not (hasKey .Values.gitea.config "server") -}}
    {{- $_ := set .Values.gitea.config "server" dict -}}
  {{- end -}}
  {{- if not (hasKey .Values.gitea.config "metrics") -}}
    {{- $_ := set .Values.gitea.config "metrics" dict -}}
  {{- end -}}
  {{- if not (hasKey .Values.gitea.config "database") -}}
    {{- $_ := set .Values.gitea.config "database" dict -}}
  {{- end -}}
  {{- if not (hasKey .Values.gitea.config "security") -}}
    {{- $_ := set .Values.gitea.config "security" dict -}}
  {{- end -}}
  {{- if not .Values.gitea.config.repository -}}
    {{- $_ := set .Values.gitea.config "repository" dict -}}
  {{- end -}}
  {{- if not (hasKey .Values.gitea.config "oauth2") -}}
    {{- $_ := set .Values.gitea.config "oauth2" dict -}}
  {{- end -}}
  {{- if not (hasKey .Values.gitea.config "session") -}}
    {{- $_ := set .Values.gitea.config "session" dict -}}
  {{- end -}}
  {{- if not (hasKey .Values.gitea.config "queue") -}}
    {{- $_ := set .Values.gitea.config "queue" dict -}}
  {{- end -}}
  {{- if not (hasKey .Values.gitea.config "global_lock") -}}
    {{- $_ := set .Values.gitea.config "global_lock" dict -}}
  {{- end -}}
  {{- if not (hasKey .Values.gitea.config "queue.issue_indexer") -}}
    {{- $_ := set .Values.gitea.config "queue.issue_indexer" dict -}}
  {{- end -}}
  {{- if not (hasKey .Values.gitea.config "indexer") -}}
    {{- $_ := set .Values.gitea.config "indexer" dict -}}
  {{- end -}}
  {{- if not (hasKey .Values.gitea.config "actions") -}}
    {{- $_ := set .Values.gitea.config "actions" dict -}}
  {{- end -}}
{{- end -}}

{{- define "gitea.inline_configuration.defaults" -}}
  {{- include "gitea.inline_configuration.defaults.server" . -}}
  {{- include "gitea.inline_configuration.defaults.database" . -}}

  {{- if not .Values.gitea.config.repository.ROOT -}}
    {{- $_ := set .Values.gitea.config.repository "ROOT" "/data/git/gitea-repositories" -}}
  {{- end -}}
  {{- if not .Values.gitea.config.security.INSTALL_LOCK -}}
    {{- $_ := set .Values.gitea.config.security "INSTALL_LOCK" "true" -}}
  {{- end -}}
  {{- if not (hasKey .Values.gitea.config.metrics "ENABLED") -}}
    {{- $_ := set .Values.gitea.config.metrics "ENABLED" .Values.gitea.metrics.enabled -}}
  {{- end -}}
  {{- if and (not (hasKey .Values.gitea.config.metrics "TOKEN")) (.Values.gitea.metrics.token) (.Values.gitea.metrics.enabled) -}}
    {{- $_ := set .Values.gitea.config.metrics "TOKEN" .Values.gitea.metrics.token -}}
  {{- end -}}
  {{- /* Auto-enable the OpenTelemetry log writer when observability is on, so
         control-gitea logs flow by default and survive redeploys. Non-destructive:
         appends the "otel" writer to any existing log MODE. The logger name "otel"
         resolves to the registered "otel" writer type, so no [log.otel] subsection
         is needed. Requires a Gitea image built with the otel/log writer. */ -}}
  {{- if eq (include "otel.enabled" .) "true" -}}
    {{- if not (hasKey .Values.gitea.config "log") -}}
      {{- $_ := set .Values.gitea.config "log" dict -}}
    {{- end -}}
    {{- $log := index .Values.gitea.config "log" -}}
    {{- $mode := $log.MODE | default "console" -}}
    {{- if not (contains "otel" $mode) -}}
      {{- $_ := set $log "MODE" (printf "%s,otel" $mode) -}}
    {{- end -}}
  {{- end -}}
  {{- /* redis queue */ -}}
  {{- if or ((index .Values "redis-cluster").enabled) ((index .Values "redis").enabled) -}}
    {{- $_ := set .Values.gitea.config.queue "TYPE" "redis" -}}
    {{- $_ := set .Values.gitea.config.queue "CONN_STR" (include "redis.dns" .) -}}
    {{- $_ := set .Values.gitea.config.session "PROVIDER" "redis" -}}
    {{- $_ := set .Values.gitea.config.session "PROVIDER_CONFIG" (include "redis.dns" .) -}}
    {{- $_ := set .Values.gitea.config.cache "ADAPTER" "redis" -}}
    {{- $_ := set .Values.gitea.config.cache "HOST" (include "redis.dns" .) -}}
    {{- if not (get .Values.gitea.config.global_lock "SERVICE_TYPE") -}}
      {{- $_ := set .Values.gitea.config.global_lock "SERVICE_TYPE" "redis" -}}
    {{- end -}}
    {{- if not (get .Values.gitea.config.global_lock "SERVICE_CONN_STR") -}}
      {{- $_ := set .Values.gitea.config.global_lock "SERVICE_CONN_STR" (include "redis.dns" .) -}}
    {{- end -}}
  {{- else -}}
    {{- if not (get .Values.gitea.config.session "PROVIDER") -}}
      {{- $_ := set .Values.gitea.config.session "PROVIDER" "memory" -}}
    {{- end -}}
    {{- if not (get .Values.gitea.config.session "PROVIDER_CONFIG") -}}
      {{- $_ := set .Values.gitea.config.session "PROVIDER_CONFIG" "" -}}
    {{- end -}}
    {{- if not (get .Values.gitea.config.queue "TYPE") -}}
      {{- $_ := set .Values.gitea.config.queue "TYPE" "level" -}}
    {{- end -}}
    {{- if not (get .Values.gitea.config.queue "CONN_STR") -}}
      {{- $_ := set .Values.gitea.config.queue "CONN_STR" "" -}}
    {{- end -}}
    {{- if not (get .Values.gitea.config.cache "ADAPTER") -}}
      {{- $_ := set .Values.gitea.config.cache "ADAPTER" "memory" -}}
    {{- end -}}
    {{- if not (get .Values.gitea.config.cache "HOST") -}}
      {{- $_ := set .Values.gitea.config.cache "HOST" "" -}}
    {{- end -}}
  {{- end -}}
  {{- /* valkey queue */ -}}
  {{- if or ((index .Values "valkey-cluster").enabled) ((index .Values "valkey").enabled) -}}
    {{- $_ := set .Values.gitea.config.queue "TYPE" "redis" -}}
    {{- $_ := set .Values.gitea.config.queue "CONN_STR" (include "valkey.dns" .) -}}
    {{- $_ := set .Values.gitea.config.session "PROVIDER" "redis" -}}
    {{- $_ := set .Values.gitea.config.session "PROVIDER_CONFIG" (include "valkey.dns" .) -}}
    {{- $_ := set .Values.gitea.config.cache "ADAPTER" "redis" -}}
    {{- $_ := set .Values.gitea.config.cache "HOST" (include "valkey.dns" .) -}}
    {{- if not (get .Values.gitea.config.global_lock "SERVICE_TYPE") -}}
      {{- $_ := set .Values.gitea.config.global_lock "SERVICE_TYPE" "redis" -}}
    {{- end -}}
    {{- if not (get .Values.gitea.config.global_lock "SERVICE_CONN_STR") -}}
      {{- $_ := set .Values.gitea.config.global_lock "SERVICE_CONN_STR" (include "valkey.dns" .) -}}
    {{- end -}}
  {{- else -}}
    {{- if not (get .Values.gitea.config.session "PROVIDER") -}}
      {{- $_ := set .Values.gitea.config.session "PROVIDER" "memory" -}}
    {{- end -}}
    {{- if not (get .Values.gitea.config.session "PROVIDER_CONFIG") -}}
      {{- $_ := set .Values.gitea.config.session "PROVIDER_CONFIG" "" -}}
    {{- end -}}
    {{- if not (get .Values.gitea.config.queue "TYPE") -}}
      {{- $_ := set .Values.gitea.config.queue "TYPE" "level" -}}
    {{- end -}}
    {{- if not (get .Values.gitea.config.queue "CONN_STR") -}}
      {{- $_ := set .Values.gitea.config.queue "CONN_STR" "" -}}
    {{- end -}}
    {{- if not (get .Values.gitea.config.cache "ADAPTER") -}}
      {{- $_ := set .Values.gitea.config.cache "ADAPTER" "memory" -}}
    {{- end -}}
    {{- if not (get .Values.gitea.config.cache "HOST") -}}
      {{- $_ := set .Values.gitea.config.cache "HOST" "" -}}
    {{- end -}}
  {{- end -}}
  {{- if not .Values.gitea.config.indexer.ISSUE_INDEXER_TYPE -}}
     {{- $_ := set .Values.gitea.config.indexer "ISSUE_INDEXER_TYPE" "db" -}}
  {{- end -}}
{{- end -}}

{{- define "gitea.inline_configuration.defaults.server" -}}
  {{- if not (hasKey .Values.gitea.config.server "HTTP_PORT") -}}
    {{- $_ := set .Values.gitea.config.server "HTTP_PORT" .Values.service.http.port -}}
  {{- end -}}
  {{- if not .Values.gitea.config.server.PROTOCOL -}}
    {{- $_ := set .Values.gitea.config.server "PROTOCOL" "http" -}}
  {{- end -}}
  {{- if not (.Values.gitea.config.server.DOMAIN) -}}
    {{- if gt (len .Values.ingress.hosts) 0 -}}
      {{- $_ := set .Values.gitea.config.server "DOMAIN" ( tpl (index .Values.ingress.hosts 0).host $) -}}
    {{- else -}}
      {{- $_ := set .Values.gitea.config.server "DOMAIN" (include "gitea.default_domain" .) -}}
    {{- end -}}
  {{- end -}}
  {{- if not .Values.gitea.config.server.ROOT_URL -}}
    {{- if and .Values.global.plan.enabled (not .Values.global.platform.enabled) }}
    {{- $_ := set .Values.gitea.config.server "ROOT_URL" (printf "%s://%s%s.%s%s" (include "gitea.public_protocol" .) (include "gitea.fullname" . ) (default "" .Values.ingress.suffix) .Values.global.domain (default .Values.ingress.mapping.prefix .Values.ingress.path)) -}}
    {{- else }}
    {{- $_ := set .Values.gitea.config.server "ROOT_URL" (printf "%s://%s%s" (include "gitea.public_protocol" .) .Values.global.domain (default .Values.ingress.mapping.prefix .Values.ingress.path)) -}}
    {{- end }}
  {{- end -}}
  {{- if not .Values.gitea.config.server.SSH_DOMAIN -}}
    {{- $prefix := .Values.global.serviceDomainPrefix | default "" -}}
    {{- $_ := set .Values.gitea.config.server "SSH_DOMAIN" (printf "%s%s" $prefix .Values.global.domain) -}}
  {{- end -}}
  {{- if not .Values.gitea.config.server.SSH_PORT -}}
    {{- $_ := set .Values.gitea.config.server "SSH_PORT" .Values.service.ssh.port -}}
  {{- end -}}
  {{- if not (hasKey .Values.gitea.config.server "START_SSH_SERVER") -}}
    {{- if .Values.image.rootless -}}
      {{- $_ := set .Values.gitea.config.server "START_SSH_SERVER" "true" -}}
      {{- if not (hasKey .Values.gitea.config.server "SSH_LISTEN_PORT") -}}
        {{- if not .Values.gitea.config.server.SSH_LISTEN_PORT -}}
          {{- $_ := set .Values.gitea.config.server "SSH_LISTEN_PORT" .Values.gitea.config.server.SSH_PORT -}}
        {{- else -}}
          {{- $_ := set .Values.gitea.config.server "SSH_LISTEN_PORT" .Values.gitea.config.server.SSH_LISTEN_PORT -}}
        {{- end -}}
      {{- end -}}
    {{- else -}}
      {{- $_ := set .Values.gitea.config.server "START_SSH_SERVER" "false" -}}
    {{- end -}}
  {{- end -}}
  {{- if not (hasKey .Values.gitea.config.server "APP_DATA_PATH") -}}
    {{- $_ := set .Values.gitea.config.server "APP_DATA_PATH" "/data" -}}
  {{- end -}}
  {{- if not (hasKey .Values.gitea.config.server "ENABLE_PPROF") -}}
    {{- $_ := set .Values.gitea.config.server "ENABLE_PPROF" false -}}
  {{- end -}}
{{- end -}}

{{- define "gitea.inline_configuration.defaults.database" -}}
  {{- if (index .Values "postgresql-ha" "enabled") -}}
    {{- $_ := set .Values.gitea.config.database "DB_TYPE"   "postgres" -}}
    {{- if not (.Values.gitea.config.database.HOST) -}}
      {{- $_ := set .Values.gitea.config.database "HOST"      (include "postgresql-ha.dns" .) -}}
    {{- end -}}
    {{- $_ := set .Values.gitea.config.database "NAME"      (index .Values "postgresql-ha" "global" "postgresql" "database") -}}
    {{- $_ := set .Values.gitea.config.database "USER"      (index .Values "postgresql-ha" "global" "postgresql" "username") -}}
    {{- $_ := set .Values.gitea.config.database "PASSWD"    (index .Values "postgresql-ha" "global" "postgresql" "password") -}}
  {{- end -}}
  {{- if (index .Values "postgresql" "enabled") -}}
    {{- $_ := set .Values.gitea.config.database "DB_TYPE"   "postgres" -}}
    {{- if not (.Values.gitea.config.database.HOST) -}}
      {{- $_ := set .Values.gitea.config.database "HOST"      (include "postgresql.dns" .) -}}
    {{- end -}}
    {{- $_ := set .Values.gitea.config.database "NAME"      .Values.postgresql.global.postgresql.auth.database -}}
    {{- $_ := set .Values.gitea.config.database "USER"      .Values.postgresql.global.postgresql.auth.username -}}
    {{- $_ := set .Values.gitea.config.database "PASSWD"    .Values.postgresql.global.postgresql.auth.password -}}
  {{- end -}}
{{- end -}}

{{- define "gitea.init-additional-mounts" -}}
  {{- /* Honor the deprecated extraVolumeMounts variable when defined */ -}}
  {{- if gt (len .Values.extraInitVolumeMounts) 0 -}}
    {{- toYaml .Values.extraInitVolumeMounts -}}
  {{- else if gt (len .Values.extraVolumeMounts) 0 -}}
    {{- toYaml .Values.extraVolumeMounts -}}
  {{- end -}}
{{- end -}}

{{- define "gitea.container-additional-mounts" -}}
  {{- /* Honor the deprecated extraVolumeMounts variable when defined */ -}}
  {{- if gt (len .Values.extraContainerVolumeMounts) 0 -}}
    {{- toYaml .Values.extraContainerVolumeMounts -}}
  {{- else if gt (len .Values.extraVolumeMounts) 0 -}}
    {{- toYaml .Values.extraVolumeMounts -}}
  {{- end -}}
{{- end -}}

{{- define "gitea.gpg-key-secret-name" -}}
{{ default (printf "%s-gpg-key" (include "gitea.fullname" .)) .Values.signing.existingSecret }}
{{- end -}}

{{- define "gitea.serviceAccountName" -}}
{{ .Values.serviceAccount.name | default (include "gitea.fullname" .) }}
{{- end -}}

{{- define "ingress.annotations" -}}
  {{- if .Values.ingress.annotations }}
  annotations:
    {{- $tp := typeOf .Values.ingress.annotations }}
    {{- if eq $tp "string" }}
      {{- tpl .Values.ingress.annotations . | nindent 4 }}
    {{- else }}
      {{- toYaml .Values.ingress.annotations | nindent 4 }}
    {{- end }}
  {{- end }}
{{- end -}}

{{- define "gitea.admin.passwordMode" -}}
{{- if has .Values.gitea.admin.passwordMode (tuple "keepUpdated" "initialOnlyNoReset" "initialOnlyRequireReset") -}}
{{ .Values.gitea.admin.passwordMode }}
{{- else -}}
{{ printf "gitea.admin.passwordMode must be set to one of 'keepUpdated', 'initialOnlyNoReset', or 'initialOnlyRequireReset'. Received: '%s'" .Values.gitea.admin.passwordMode | fail }}
{{- end -}}
{{- end -}}

{{/* Create a functioning probe object for rendering. Given argument must be either a livenessProbe, readinessProbe, or startupProbe */}}
{{- define "gitea.deployment.probe" -}}
  {{- $probe := unset . "enabled" -}}
  {{- $probeKeys := keys $probe -}}
  {{- $containsCustomMethod := false -}}
  {{- $chartDefaultMethod := "tcpSocket" -}}
  {{- $nonChartDefaultMethods := list "exec" "httpGet" "grpc" -}}
  {{- range $probeKeys -}}
    {{- if has . $nonChartDefaultMethods -}}
      {{- $containsCustomMethod = true -}}
    {{- end -}}
  {{- end -}}
  {{- if $containsCustomMethod -}}
    {{- $probe = unset . $chartDefaultMethod -}}
  {{- end -}}
  {{- toYaml $probe -}}
{{- end -}}

{{- define "gitea.metrics-secret-name" -}}
{{ default (printf "%s-metrics-secret" (include "gitea.fullname" .)) }}
{{- end -}}

{{- define "gitea.toYaml" }}
  {{- if kindIs "map" . }}
    {{- if eq 0 (len .) }}
      {{- toYaml . }}
    {{- end }}
    {{- range $key, $value := . }}
      {{- if and (toString . | ne "null") (ne "invalid" (kindOf .)) }}
{{ $key }}: {{ include "gitea.toYaml" $value | indent 2 }}
      {{- end }}
    {{- end }}
  {{- else if kindIs "slice" . }}
    {{- if eq 0 (len .) }}
      {{- toYaml . }}
    {{- end }}
    {{- range $index, $element := . }}
- {{ include "gitea.toYaml" $element | indent 2 }}
    {{- end }}
  {{- else }}
    {{- toYaml . }}
  {{- end }}
{{- end }}

{{/* override the storage helper from REDIS */}}
{{- define "common.storage.class" -}}
{{- if not .persistence -}}
{{- fail "invalid persistence value from subchart" -}}
{{- end -}}
{{- $d := (dict "Values" . ) -}}
{{- $sc := (.global).storageClass | default .persistence.storageClass | default (.global).defaultStorageClass | default "" -}}
{{- $_ := set dict ".persistence.storageClass" $sc -}}
{{- include "gitea.persistence.storageClass" $d }}
{{- end -}}

{{/* override the imagePullSecrets helper from REDIS/POSTGRES */}}
{{- define "redis.imagePullSecrets" -}}
{{- include "gitea.images.pullSecrets" . -}}
{{- end -}}
{{- define "valkey.imagePullSecrets" -}}
{{- include "gitea.images.pullSecrets" . -}}
{{- end -}}
{{- define "postgresql.v1.imagePullSecrets" -}}
{{- include "gitea.images.pullSecrets" . -}}
{{- end -}}
{{- define "postgresql-ha.image.pullSecrets" -}}
{{- include "gitea.images.pullSecrets" . -}}
{{- end -}}
{{- define "redis-cluster.imagePullSecrets" -}}
{{- include "gitea.images.pullSecrets" . -}}
{{- end -}}
{{- define "valkey-cluster.imagePullSecrets" -}}
{{- include "gitea.images.pullSecrets" . -}}
{{- end -}}

{{/* override the image helper from REDIS */}}
{{- define "common.images.image" -}}
{{- $registryName := default .imageRoot.registry ((.global).imageRegistry) | clean | trimSuffix "/" -}}
{{- $repositoryName := .imageRoot.repository -}}
{{- $separator := ":" -}}
{{- $termination := .imageRoot.tag | toString -}}
{{- if (or (eq $registryName "hclcr.io") (eq $registryName "cp.icr.io/cp") (eq $registryName "cp.stg.icr.io/cp") (eq $registryName "preprod.icr.io/cp")) }}
    {{- $repositoryName = (printf "devops-plan/%s" $repositoryName) -}}
{{- end -}}

{{- if not .imageRoot.tag }}
  {{- if .chart }}
    {{- $termination = .chart.AppVersion | toString -}}
  {{- end -}}
{{- end -}}
{{- if .imageRoot.digest }}
    {{- $separator = "@" -}}
    {{- $termination = .imageRoot.digest | toString -}}
{{- end -}}
{{- if $registryName }}
    {{- printf "%s/%s%s%s" $registryName $repositoryName $separator $termination -}}
{{- else -}}
    {{- printf "%s%s%s"  $repositoryName $separator $termination -}}
{{- end -}}
{{- end -}}

{{- define "opensearch.servicename" -}}
{{- if ( index .Values "global" "platform").enabled  -}}
{{- $brand := .Values.global.devopsPlanBrand | lower -}}
{{- printf "%s-%s-devopsplan-prod-opensearch.%s.svc.%s" .Release.Name $brand .Release.Namespace .Values.clusterDomain -}}
{{- end -}}
{{- if and ( index .Values "global" "plan").enabled (not ( index .Values "global" "platform").enabled )  -}}
{{- $planFullName := include "ccm.subchart.fullname" . -}}
{{- printf "%s-opensearch.%s.svc.%s" $planFullName .Release.Namespace .Values.clusterDomain -}}
{{- end }}
{{- end -}}

{{/*
OpenTelemetry helper stubs.
Intentionally empty. When this chart is deployed under the platform parent chart,
the parent defines the real implementations, which override these stubs. Rendered
standalone, the stubs return empty output so "otel.enabled" is not "true" and the
templates that reference these helpers render cleanly with observability disabled.
*/}}
{{- define "otel.enabled" -}}{{- end -}}
{{- define "otel.sidecar.enabled" -}}{{- end -}}
{{- define "otel.endpoint" -}}{{- end -}}
{{- define "otel.env-vars" -}}{{- end -}}
{{- define "otel.sidecar.conditional" -}}{{- end -}}
{{- define "otel.sidecar.volume" -}}{{- end -}}
{{- define "otel.sidecar.configmap" -}}{{- end -}}
