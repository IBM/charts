# IBM Sterling B2B Integrator AS4 Service v6.2.2.1_1
## Introduction
Sterling B2B Integrator offers support for AS4 Service which provides optimized and dynamic end-to-end information flows..
To find out more, see 


## Chart Details
This sub-chart is deployed by B2BI charts on a container management platform with the following resources
Deployments
* Catalog Server with 1 replica by default
* Container Server with 1 replica by default
* Operaional Server with 1 replica by default
* Informational Server with 1 replica by default
Services
* Informational service - This service is used to access AS4 Application Server using a consistent IP address


## Prerequisites
1. Red Hat OpenShift Container Platform 
   Version 4.19.0 or later fixes
   Version 4.20.0 or later fixes
   Version 4.21.0 or later fixes
   Version 4.22.0 or later fixes
2. Kubernetes version >= 1.33 and <= 1.36

3. Helm version >= 3.21.x

4. Ensure that the docker images for AS4 Service from IBM Entitled Registry are downloaded and pushed to an image registry accessible to the cluster.

5. Ensure that B2BI must enable the AS4 Service.

6. Ensure that a supported MQ Server version (IBM MQ or ActiveMQ Server) is installed and accessible from inside the cluster and configure the same.

7. Provide external resource artifacts like the database driver jar, Key store and trust store files and so on using an init container for resources or a persistent volume for resources. Either of the option can be used but not both at the same time. 
  a. For using init container for resources when `resourcesInit.enabled` is `true`, create an init container image bundled with the required external resource artifacts and configure the image details in the `resourcesInit.image` section.
  b. For using persistent volume for resources when `appResourcesPVC.enabled` is `true`, create a persistent volume for application resources with access mode as 'Read Only Many' and place the required external resource artifacts in the mapped volume location.

8. When `logs.enableAppLogOnConsole` is `true`, logs will be redirected to App Console

9. Create custom network policies to enable required ingress and egress endpoints for required external services like rest document Service and grpc document Service integration services.
9. Use same B2BI secret to pull the image from a private registry or repository.
10. If applicable, create secrets with confidential certificates required by Database, MQ or DM for SSL connectivity using below command
    ```
	kubectl create secret generic <secret-name> --from-file=/path/to/<certificate>
	```
14. When installing the chart on a new database which does not have IBM Sterling AS4 Software schema tables and metadata, 
* ensure that `dataSetup.enable` parameter is set to `true`. 
This will create the required database tables and metadata in the database before installing the chart.

### Installation against a pre-loaded database
When installing the chart against a database which already has the Sterling B2B Integrator Software tables and factory meta data ensure that `datasetup.enable` parameter is set to `false`. This will avoid re-creating tables and overwriting factory data.


### Creating a Role Based Access Control (RBAC)
If you are deploying the application on a namespace other than the default namespace, and if you have not created Role Based Access Control (RBAC), create RBAC with the cluster admin role.

The following sample file illustrates RBAC for the default service account with the target namespace as `<namespace>`. The same can be applied to any existing or new service account created for the application by updating the service account name in the below RoleBinding template. 

```yaml
kind: Role
apiVersion: rbac.authorization.k8s.io/v1
metadata:
  name: ibm-as4-role-<namespace>
  namespace: <namespace>
rules:
  - apiGroups: ['route.openshift.io']
    resources: ['routes','routes/custom-host']
    verbs: ['get', 'watch', 'list', 'patch', 'update']
  - apiGroups: ['','batch']
    resources: ['secrets','configmaps','persistentvolumes','persistentvolumeclaims','pods','services','cronjobs','jobs']
    verbs: ['create', 'get', 'list', 'delete', 'patch', 'update']

---
kind: RoleBinding
apiVersion: rbac.authorization.k8s.io/v1
metadata:
  name: ibm-as4-rolebinding-<namespace>
  namespace: <namespace>
subjects:
  - kind: ServiceAccount
    name: default
    namespace: <namespace>
roleRef:
  kind: Role
  name: ibm-as4-role-<namespace>
  apiGroup: rbac.authorization.k8s.io
```  

### PodSecurityPolicy Requirements

With Kubernetes v1.25, Pod Security Policy (PSP) API has been removed and replaced with Pod Security Admission (PSA) contoller. Kubernetes PSA conroller enforces predefined Pod Security levels at the namespace level. The Kubernetes Pod Security Standards defines three different levels: privileged, baseline, and restricted. Refer to Kubernetes [`Pod Security Standards`] (https://kubernetes.io/docs/concepts/security/pod-security-standards/) documentation for more details. This chart is compatible with the restricted security level. 

For users upgrading from older Kubernetes version to v1.25 or higher, refer to Kubernetes [`Migrate from PSP`](https://kubernetes.io/docs/tasks/configure-pod-container/migrate-from-psp/) documentation to help with migrating from PodSecurityPolicies to the built-in Pod Security Admission controller.

For users continuing on older Kubernetes versions (<1.25) and using PodSecurityPolicies, choose either a predefined PodSecurityPolicy or have your cluster administrator create a custom PodSecurityPolicy for you. This chart is compatible with most restrictive policies.
Below is an optional custom PSP definition based on the IBM restricted PSP.

* Predefined PodSecurityPolicy name: [`ibm-restricted-psp`](https://ibm.biz/cpkspec-psp)
 
- From the user interface or command line, you can copy and paste the following snippets to create and enable the below custom PodSecurityPolicy based on IBM restricted PSP.
  - Custom PodSecurityPolicy definition:

    ```
    
    apiVersion: policy/v1beta1
    kind: PodSecurityPolicy
    metadata:
      name: "ibm-as4-psp"
      labels:
        app: "ibm-as4-psp"
      
    spec:
      privileged: false
      allowPrivilegeEscalation: false
      hostPID: false
      hostIPC: false
      hostNetwork: false
      allowedCapabilities:
      requiredDropCapabilities:
      - ALL
      allowedHostPaths:
      runAsUser:
        rule: MustRunAsNonRoot
      runAsGroup:
        rule: MustRunAs
        ranges:
        - min: 1
          max: 4294967294
      seLinux:
        rule: RunAsAny
      supplementalGroups:
        rule: MustRunAs
        ranges:
        - min: 1
          max: 4294967294
      fsGroup:
        rule: MustRunAs  
        ranges:
        - min: 1
          max: 4294967294
      volumes:
      - configMap
      - emptyDir
      - projected
      - secret
      - downwardAPI
      - persistentVolumeClaim
      - nfs
      forbiddenSysctls:
      - '*' 
    ```

  - Custom Role for the custom PodSecurityPolicy:

    ```
    apiVersion: rbac.authorization.k8s.io/v1
    kind: Role
    metadata:
      name: "ibm-as4-psp"
      labels:
        app: "ibm-as4-psp"
    rules:
    - apiGroups:
      - policy
      resourceNames:
      - "ibm-as4-psp"
      resources:
      - podsecuritypolicies
      verbs:
      - use
    ```

  - Custom Role binding for the custom PodSecurityPolicy:

    ```
    apiVersion: rbac.authorization.k8s.io/v1
    kind: RoleBinding
    metadata:
      name: "ibm-as4-psp"
      labels:
        app: "ibm-as4-psp"
    roleRef:
      apiGroup: rbac.authorization.k8s.io
      kind: Role
      name: "ibm-as4-psp"
    subjects:
    - apiGroup: rbac.authorization.k8s.io
      kind: Group
      name: system:serviceaccounts
      namespace: {{ NAMESPACE }}
    ```

### SecurityContextConstraints Requirements

Red Hat OpenShift provides a pre-defined or default set of SecurityContextConstraints (SCC). These SCCs are used to control permissions for pods. These permissions include actions that a pod can perform and what resources it can access. You can use SCCs to define a set of conditions that a pod must run with to be accepted into the system. Refer to OpenShift [`Managing Security Context Constraints`](https://docs.openshift.com/container-platform/4.11/authentication/managing-security-context-constraints.html#default-sccs_configuring-internal-oauth) documentation for more details on the default SCCs. This chart is compatible with both restricted and resticted-v2 (added in OpenShift v4.11) default SCCs and does not require a custom SCC to be defined explicity.

For OpenShift, choose either a predefined SCC or have your cluster administrator create a custom SCC for you as per the security profile and policies adopted for all OpenShift deployments. This chart is compatible with most restrictive security context constraints.
Below is an optional custom SCC definition based on the IBM restricted SCC.

* Predefined SecurityContextConstraints name: [`ibm-restricted-scc`](https://ibm.biz/cpkspec-scc)

- From the user interface or command line, you can copy and paste the following snippets to create and enable the below custom SCC based on IBM restricted SCC.

  - Custom SecurityContextConstraints definition:

    ```
    apiVersion: security.openshift.io/v1
    kind: SecurityContextConstraints
    metadata: 
      name: ibm-as4-scc
      labels:
       app: "ibm-as4-scc"
    allowHostDirVolumePlugin: false
    allowHostIPC: false
    allowHostNetwork: false
    allowHostPID: false
    allowHostPorts: false
    privileged: false
    allowPrivilegeEscalation: false
    allowPrivilegedContainer: false
    allowedCapabilities: 
    allowedFlexVolumes: []
    allowedUnsafeSysctls: []
    defaultAddCapabilities: []
    defaultAllowPrivilegeEscalation: false
    forbiddenSysctls:
      - "*"
    fsGroup:
      type: MustRunAs
      ranges:
      - min: 1
        max: 4294967294
    readOnlyRootFilesystem: false
    requiredDropCapabilities:
    - ALL
    runAsUser:
      type: MustRunAsRange
    # This can be customized for your host machine
    seLinuxContext:
      type: MustRunAs
    # seLinuxOptions:
    #   level:
    #   user:
    #   role:
    #   type:
    supplementalGroups:
      type: MustRunAs
      ranges:
      - min: 1
        max: 4294967294
    # This can be customized for your host machine
    volumes:
    - configMap
    - downwardAPI
    - emptyDir
    - persistentVolumeClaim
    - projected
    - secret
    - nfs
    priority: 0
    ```

    - Custom Role for the custom SecurityContextConstraints:
    
    ```
    apiVersion: rbac.authorization.k8s.io/v1
	  kind: Role
	  metadata:
     name: "ibm-as4-scc"
     labels:
      app: "ibm-as4-scc" 
	  rules:
	  - apiGroups:
  	  - security.openshift.io
  	  resourceNames:
      - "ibm-as4-scc"
      resources:
      - securitycontextconstraints
      verbs:
      - use
    
    ```

    - Custom Role binding for the custom SecurityContextConstraints:

    ```
    apiVersion: rbac.authorization.k8s.io/v1
    kind: RoleBinding
    metadata:
      name: "ibm-as4-scc"
      labels:
        app: "ibm-as4-scc"
    roleRef:
      apiGroup: rbac.authorization.k8s.io
      kind: Role
      name: "ibm-as4-scc"
    subjects:
    - apiGroup: rbac.authorization.k8s.io
      kind: Group
      name: system:serviceaccounts
      namespace: {{ NAMESPACE }}
    ```
## Network Policy

  For Certified Container deployments, few default network policies are created out of the box as per mandatory security guidelines. By default all ingress and egress traffic are denied with few additional policies to allow communication within cluster and on ports configured in the helm charts configuration. 
  Additionally custom ingress and egress policies can be configured in values yaml to allow traffic from and to specific external service endpoints.

  Note: By default all ingress and egress traffic from or to external services are denied. You will need to create custom network policies to allow ingress and egress traffic from or to services outside of the cluster like database, MQ, protocol adapter endpoints, any other third party service integration and so on.

  Out of the box Ingress policies
  *	Deny all ingress traffic
  *	Allow ingress traffic from all pods in the current namespace in the cluster
  *	Allow ingress traffic on the additional configured ports in helm values
  
  Out of the box Egress policies
  *	Deny all egress traffic
  *	Allow egress traffic within the cluster

## Resources Required

The following table describes the default usage and limits per pod

Pod                                       | Memory Requested  | Memory Limit | CPU Requested | CPU Limit
------------------------------------------| ------------------|--------------| --------------|----------
Catalog Server pod                        |       2 Gi        |     2 Gi     |      2        |    2
Container Server pod                      |       2 Gi        |     2 Gi     |      2        |    2
Operational Server pod                    |       2 Gi        |     2 Gi     |      2        |    2
Informational Server pod                  |       2 Gi        |     2 Gi     |      2        |    2

## Pre-install steps

Before installing the chart to your cluster, the cluster admin must perform the following pre-install steps.

* Create a namespace
* Create a ServiceAccount
    ```
    apiVersion: v1
    kind: ServiceAccount
    metadata: 
      name: {{ sa_name }}-nginxref-nginx
    imagePullSecrets:
    - name: sa-{{ NAMESPACE }}
    ```

If you use the custom security configuration provided here, you must specify messagesight-sa as the service account for your charts.


## Installing the Chart
* Verify B2Bi helm charts must have AS4 Service sub charts present into the b2bi charts location(ibm-as4-service-prod) for installation of AS4 Service.
* Prepare a custom values.yaml file based on the configuration section.
* It's sub-charts, so it will install  with B2BI charts installation.

> **Tip**: List all releases using `helm list`

* Generally teams have subsections for : 
   * Verifying the Chart
   * Uninstalling the Chart

### Verifying the Chart
See the instruction (from NOTES.txt within chart) after the helm installation completes for chart verification. The instruction can also be viewed by running the command: helm status my-release --tls.

### Uninstalling the Chart

To uninstall/delete the `my-release` deployment:

```bash
$ helm delete my-release --purge --tls
```

The command removes all the Kubernetes components associated with the chart and deletes the release.  If a delete can result in orphaned components include instructions with additional commands required for clean-up.  

For example :

When deleting a release with stateful sets the associated persistent volume will need to be deleted.  
Do the following after deleting the chart release to clean up orphaned Persistent Volumes.

```console
$ kubectl delete pvc -l release=my-release
```

### Cleanup any pre-reqs that were created
If cleanup scripts were included in the pak_extensions/post-delete directory; run them to cleanup namespace and cluster scoped resources when appropriate.

## Configuration
### The following table lists the configurable parameters for the AS4 sub-chart

Parameter                                      | Description                                                          | Default 
-----------------------------------------------| ---------------------------------------------------------------------| -------------
`license`                               | Accept AS4 license                                              | `false`
`licenseType`                           | Specify the license edition as per license agreement.                | non-prod
`image.repository`                      | Repository for AS4 docker images                                     | 
`image.tag          `                   | Docker image tag                                                     | `6.2.2.1_1`
`image.digest          `                | Docker image digest. Takes precedence over tag                       | 
`image.pullPolicy`                      | Pull policy for repository                                           | `IfNotPresent`
`image.pullSecret `         			   | Pull secret for repository access                                    | `ibm-entitlement-key`
`arch.amd64`                                   | Specify weight to be used for scheduling for architecture amd64      | `2 - No Preference`
`arch.ppc64le`                                 | Specify weight to be used for scheduling for architecture ppc64le    | `2 - No Preference`
`arch.s390x`                                   | Specify weight to be used for scheduling for architecture s390x      | `2 - No Preference`
`serviceAccount.name`                          | Existing service account name                                        | `default`
`persistence.enabled`                          | Enable storage access to persistent volumes                          | true
`persistence.useDynamicProvisioning`           | Enable dynamic provisioning of persistent volumes                    | false 
`resourcesInit.enabled`                        | Enable resource init containers                                      | true
`resourcesInit.image.repository`               | Repository for resource init container images                        |
`resourcesInit.image.tag`                      | Docker image tag                                                     |
`resourcesInit.image.digest`                   | Docker image digest. Takes precedence over tag                       |
`resourcesInit.image.pullPolicy`               | Pull policy for repository                                           | `IfNotPresent`
`resourcesInit.command`                        | Command to be executed in the resource init container                |
`appResourcesPVC.enabled`                      | Enable Application resource storage                                  | false 
`appResourcesPVC.storageClassName`             | Resources persistent volume storage class name                       | ``
`appResourcesPVC.selector.label`               | Resources persistent volume selector label                           | `intent`
`appResourcesPVC.selector.value`               | Resources persistent volume selector value                           | `resources`
`appResourcesPVC.accessMode`                   | Resources persistent volume access mode                              | `ReadOnlyMany`
`appResourcesPVC.size`                         | Resources persistent volume storage size                             | 500 Mi
`appResourcesPVC.preDefinedResourcePVCName`    | Predefined resources persistent volume name                          | 
`appLogsPVC.enabled`                      | Enable Application logs storage                                  | false
`appLogsPVC.storageClassName`                  | Logs persistent volume storage class name                            | ``
`appLogsPVC.selector.label`                    | Logs persistent volume selector label                                | `intent`
`appLogsPVC.selector.value`                    | Logs persistent volume selector value                                | `logs`
`appLogsPVC.accessMode`                        | Logs persistent volume access mode                                   | `ReadWriteMany`
`appLogsPVC.size`                              | Logs persistent volume storage size                                  | 500 Mi
`appLogsPVC.preDefinedLogsPVCName`             | Predefined logs persistent volume name                               |   
`appDocumentsPVC.enabled`                      | Enable Application document storage                                  | false
`appDocumentsPVC.storageClassName`             | Documents persistent volume storage class name                       | ``
`appDocumentsPVC.selector.label`               | Documents persistent volume selector label                           | `intent`
`appDocumentsPVC.selector.value`               | Documents persistent volume selector value                           | `storage`
`appDocumentsPVC.accessMode`                   | Documents persistent volume access mode                              | `ReadWriteMany`
`appDocumentsPVC.size`                         | Documents persistent volume storage size                             | 1Gi
`appDocumentsPVC.preDefinedDocumentPVCName`    | Predefined document persistent volume name                           |
`extraPVCs`                                    | Extra volume claims shared across all deployments                    | 
`security.supplementalGroups`                  | Supplemental group id to access the persistent volume                | 0
`security.fsGroup`                             | File system group id to access the persistent volume                 | 0
`security.runAsUser`                           | The User ID that needs to be run as by all containers                | 
`security.runAsGroup`                           | The Group ID that needs to be run as by all containers              | 
`dataSetup.enabled`                            | Enable database setup job execution                                  | true
`dataSetup.logLevel`                           | DataSetup log level                                                  | INFO
`dbSetup.dbVendor`                            | Database vendor - DB2/Oracle/MSSQL                                   | 
`dbSetup.dbHost`                              | Database host                                                        | 
`dbSetup.dbPort`                              | Database port                                                        | 
`dbSetup.dbDrivers`                           | Database driver jar name                                             | 
`dbSetup.dbSecret`                            | Database user secret name                                            | 
`dbSetup.identityDbData`                              | Identity Database name                                                 | 
`dbSetup.commsDbData`                              | Comms Database name                                                 | 
`dbSetup.infraDbData`                              | Infra Database name                                                 | 
`dbSetup.uiDbData`                              | UI Database name                                                 | 
`dbSetup.identitySchema`                              | Identity Schema name                                                 |
`dbSetup.commsSchema`                              | Comms Schema name                                                 |
`dbSetup.infraSchema`                              | Infra Schema name                                                 |
`dbSetup.uiSchema`                              | UI Schema name                                                 |
`useOracleServiceName`                          |  User Service Name for Oracle                                      | false
`dbSetup.usessl`                              | Enable SSL for database connection                                   | false
`dbSetup.sslVersion`                              | SSL Version for database connection                               |
`dbSetup.dbTruststore`                        | Database truststore file name including it's path relative to the mounted resources volume location. When `dbTruststoreSecret` is mentioned, provide the name of the key holding the certificate data.                         | 
`dbSetup.dbTruststoreSecret`                  | Name of the Database truststore secret containing the certificate, if applicable.                      | 
`dbSetup.dbKeystore`                          | Database keystore file name including it's path relative to the mounted resources volume location, if applicable. When `dbKeystoreSecret` is mentioned, provide the name of the key holding the certificate data.                         |
`dbSetup.dbKeystoreSecret`                    | Name of the Database keystore secret containing the certificate, if applicable.                       | 
`dbSetup.MSSQL_HOST_NAME_IN_CERTIFICATE`                      | MSSQL Database configuration to check Host Name in Certificate                     | 
`dbSetup.MSSQL_TRUST_SERVER_CERTIFICATE`                | MSSQL Database configuration trust server certificate                   | true
`dbSetup.MSSQL_ENCRYPT`                      | MSSQL Database configuration for encrypt.                     | true
`mqSetup.mqHost`                              | MQ Server host                                                        | 
`mqSetup.mqPort`                              | MQ Server port                                                        | 
`mqSetup.mqServerChannel`                           | MQ Server Channel Name                                             | 
`mqSetup.mqServerQueueManager`                           | MQ Server Queue Manager Name                                             | 
`mqSetup.mqSecret`                            | MQ Server user secret Name                                             | 
`mqSetup.enableSsl`                            | Enable SSL for MQ Connection						| true
`mqSetup.mqKeystore`                           | MQ keystore file name including it's path relative to the mounted resources volume location, if applicable. When `dbKeystoreSecret` is mentioned, provide the name of the key holding the certificate data.	| 
`mqSetup.mqKeystoreSecret`                     | Name of the MQ keystore secret containing the certificate, if applicable.    |
`mqSetup.mqTruststore`                         | Database truststore file name including it's path relative to the mounted resources volume location. When `dbTruststoreSecret` is mentioned, provide the name of the key holding the certificate data.		| 
`mqSetup.mqTruststoreSecret`                   | Name of the Database truststore secret containing the certificate, if applicable.  | 
`mqSetup.mqCiphersuite`                        | List of CipherSuites to be used for MQ ssl connection			| 
`mqSetup.mqProtocol`                           | SSL Version for MQ connection						| TLSv1.2
`wxsSetup.wxsSecret`                            | WXS Server user secret Name                                             | 
`setupCfg.sslProtocol`                          | Protocol to be used by liberty for communications.                    | TLSv1.2
`setupCfg.userexitAuthenticationOutboundServiceId`       | UserExit Authentication ServiceId for Outbound                         |
`setupCfg.userexitAuthenticationInboundServiceId`        | UserExit Authentication ServiceId for Inbound                          |
`logs.enableAppLogOnConsole`                   | Enable application logs redirection to pod console                   | `true` 
`ingress.enabled`                              | Enable ingress resource                                              | false
`ingress.controller`                           | Ingress controller class                                             | nginx
`ingress.annotations`                          | Additional annotations for the ingress resource                      |
`ingress.port`                                 | Ingress or router port if not 80 or 443                              |
`env.tz`                                       | Timezone for application runtime                                     | `UTC`
`env.extraEnvs`                                | Provide extra global environment variables                           |
`as4catalog.replicaCount`                             | AS4 Catalog Server deployment replica count         | 1
`as4catalog.env.jvmOptions`                           | JVM options for AS4Catalog server                  |
`as4catalog.env.extraEnvs`                            | Provide extra environment variables for AS4Catalog                          | 
`as4catalog.server.port`                            | Server port for AS4Catalog                          | 2809
`as4catalog.server.ssl.enabled`                            | SSL configuration                          | false
`as4catalog.resources`                                | CPU/Memory/Ephemeral Storage resource requests/limits                                  | 
`as4catalog.livenessProbe.initialDelaySeconds`        | Livenessprobe initial delay in seconds                               | 60
`as4catalog.livenessProbe.timeoutSeconds`             | Livenessprobe timeout in seconds                                     | 10
`as4catalog.livenessProbe.periodSeconds`              | Livenessprobe interval in seconds                                    | 60
`as4catalog.readinessProbe.initialDelaySeconds`       | ReadinessProbe initial delay in seconds                              | 60
`as4catalog.readinessProbe.timeoutSeconds`            | ReadinessProbe timeout in seconds                                    | 10
`as4catalog.readinessProbe.periodSeconds`             | ReadinessProbe interval in seconds                                   | 60
`as4catalog.readinessProbe.command`                   | ReadinessProbe command to be executed                                |
`as4catalog.readinessProbe.arg`                       | ReadinessProbe command arguments                                     |
`as4catalog.ingress.internal.host`                    | Internal Host name for ingress resource	                          |
`as4catalog.ingress.internal.tls.enabled`             | Enable TLS for ingress                                               | true
`as4catalog.ingress.internal.tls.secretName`          | TLS secret name                                                      |
`as4catalog.ingress.internal.extraPaths`              | Extra paths for ingress resource                                     | 
`as4catalog.ingress.external.host`                    | External Host name for ingress resource	                          |
`as4catalog.ingress.external.tls.enabled`             | Enable TLS for ingress                                               | true
`as4catalog.ingress.external.tls.secretName`          | TLS secret name                                                      |
`as4catalog.ingress.external.extraPaths`              | Extra paths for ingress resource                                     |    
`as4container.replicaCount`                             | AS4 Catalog Server deployment replica count         | 1
`as4container.env.jvmOptions`                           | JVM options for AS4Container server			|
`as4container.env.extraEnvs`                            | Provide extra environment variables for AS4Container                          | 
`as4container.server.port`                            | Server port for AS4Container                          | 3909
`as4container.server.ssl.enabled`                            | SSL configuration                          | false
`as4container.resources`                                | CPU/Memory/Ephemeral Storage resource requests/limits                | 
`as4container.livenessProbe.initialDelaySeconds`        | Livenessprobe initial delay in seconds                               | 60
`as4container.livenessProbe.timeoutSeconds`             | Livenessprobe timeout in seconds                                     | 10
`as4container.livenessProbe.periodSeconds`              | Livenessprobe interval in seconds                                    | 60
`as4container.readinessProbe.initialDelaySeconds`       | ReadinessProbe initial delay in seconds                              | 60
`as4container.readinessProbe.timeoutSeconds`            | ReadinessProbe timeout in seconds                                    | 10
`as4container.readinessProbe.periodSeconds`             | ReadinessProbe interval in seconds                                   | 60
`as4container.readinessProbe.command`                   | ReadinessProbe command to be executed                                |
`as4container.readinessProbe.arg`                       | ReadinessProbe command arguments                                     |
`as4container.autoscaling.enabled`                      | Enable autoscaling                                                   | false
`as4container.autoscaling.minReplicas`                  | Minimum replicas for autoscaling                                     | 1
`as4container.autoscaling.maxReplicas`                  | Maximum replicas for autoscaling                                     | 2
`as4container.autoscaling.targetCPUUtilizationPercentage`| Target CPU utilization                                              | 60
`as4container.ingress.internal.host`                    | Internal Host name for ingress resource	                          |
`as4container.ingress.internal.tls.enabled`             | Enable TLS for ingress                                               | true
`as4container.ingress.internal.tls.secretName`          | TLS secret name                                                      |
`as4container.ingress.internal.extraPaths`              | Extra paths for ingress resource                                     | 
`as4container.ingress.external.host`                    | External Host name for ingress resource	                          |
`as4container.ingress.external.tls.enabled`             | Enable TLS for ingress                                               | true
`as4container.ingress.external.tls.secretName`          | TLS secret name                                                      |
`as4container.ingress.external.extraPaths`              | Extra paths for ingress resource                                     |    
`as4operational.replicaCount`                             | AS4 Catalog Server deployment replica count         | 1
`as4operational.env.jvmOptions`                           | JVM options for AS4Operational server   | 
`as4operational.env.extraEnvs`                            | Provide extra environment variables for AS4Operational                          | 
`as4operational.server.port`                            | Server port for AS4Operational                          | 9443
`as4operational.server.ssl.enabled`                            | SSL configuration                          | false
`as4operational.extraPorts`                       | Extra ports for service                                              | 
`as4operational.backendService.type`                             | Service type                                                         | `LoadBalancer`
`as4operational.backendService.sessionAffinity`                       | Used to maintain session affinity                                    | `None`
`as4operational.backendService.sessionAffinityConfig.timeoutSeconds`  | Session affinity timeout in seconds                                  | 10800
`as4operational.backendService.externalTrafficPolicy`                 | Route external traffic to node-local or cluster-wide endpoints       | `Cluster`
`as4operational.backendService.ports`                       | Ports for service                                              |
`as4operational.backendService.portRanges`                       | Port ranges for service                                              |
`as4operational.backendService.loadBalancerIP`                   | LoadBalancer IP for service                                          |
`as4operational.backendService.loadBalancerSourceRanges`        | LoadBalancer IP Ranges for service                                          |
`as4operational.backendService.annotations`                      | Additional annotations for the asi backendService                    |
`as4operational.resources`                                | CPU/Memory/Ephemeral Storage resource requests/limits                                  | 
`as4operational.livenessProbe.initialDelaySeconds`        | Livenessprobe initial delay in seconds                               | 60
`as4operational.livenessProbe.timeoutSeconds`             | Livenessprobe timeout in seconds                                     | 10
`as4operational.livenessProbe.periodSeconds`              | Livenessprobe interval in seconds                                    | 60
`as4operational.readinessProbe.initialDelaySeconds`       | ReadinessProbe initial delay in seconds                              | 60
`as4operational.readinessProbe.timeoutSeconds`            | ReadinessProbe timeout in seconds                                    | 10
`as4operational.readinessProbe.periodSeconds`             | ReadinessProbe interval in seconds                                   | 60
`as4operational.readinessProbe.command`                   | ReadinessProbe command to be executed                                |
`as4operational.readinessProbe.arg`                       | ReadinessProbe command arguments                                     |
`as4operational.autoscaling.enabled`                      | Enable autoscaling                                                   | false
`as4operational.autoscaling.minReplicas`                  | Minimum replicas for autoscaling                                     | 1
`as4operational.autoscaling.maxReplicas`                  | Maximum replicas for autoscaling                                     | 2
`as4operational.autoscaling.targetCPUUtilizationPercentage`| Target CPU utilization                                              | 60
`as4operational.ingress.internal.host`                    | Internal Host name for ingress resource	                          |
`as4operational.ingress.internal.tls.enabled`             | Enable TLS for ingress                                               | true
`as4operational.ingress.internal.tls.secretName`          | TLS secret name                                                      |
`as4operational.ingress.internal.extraPaths`              | Extra paths for ingress resource                                     | 
`as4operational.ingress.external.host`                    | External Host name for ingress resource	                          |
`as4operational.ingress.external.tls.enabled`             | Enable TLS for ingress                                               | true
`as4operational.ingress.external.tls.secretName`          | TLS secret name                                                      |
`as4operational.ingress.external.extraPaths`              | Extra paths for ingress resource                                     |    
`as4informational.replicaCount`                             | AS4 Catalog Server deployment replica count         | 1
`as4informational.env.jvmOptions`                           | JVM options for AS4Informational server      | 
`as4informational.env.extraEnvs`                            | Provide extra environment variables for AS4Informational                          | 
`as4informational.server.port`                            | Server port for AS4Informational                          | 19443
`as4informational.server.ssl.enabled`                            | SSL configuration                          | false
`as4informational.server.ssl.keyStoreSecretName`                            | SSL configuration                          | false
`as4informational.server.ssl.keyStoreSecretName`                            | SSL configuration                          | false
`as4informational.extraPorts`                       | Extra ports for service                                              | 
`as4informational.resources`                                | CPU/Memory/Ephemeral Storage resource requests/limits                                  | 
`as4informational.livenessProbe.initialDelaySeconds`        | Livenessprobe initial delay in seconds                               | 60
`as4informational.livenessProbe.timeoutSeconds`             | Livenessprobe timeout in seconds                                     | 10
`as4informational.livenessProbe.periodSeconds`              | Livenessprobe interval in seconds                                    | 60
`as4informational.readinessProbe.initialDelaySeconds`       | ReadinessProbe initial delay in seconds                              | 60
`as4informational.readinessProbe.timeoutSeconds`            | ReadinessProbe timeout in seconds                                    | 10
`as4informational.readinessProbe.periodSeconds`             | ReadinessProbe interval in seconds                                   | 60
`as4informational.readinessProbe.command`                   | ReadinessProbe command to be executed                                |
`as4informational.readinessProbe.arg`                       | ReadinessProbe command arguments                                     |
`as4informational.autoscaling.enabled`                      | Enable autoscaling                                                   | false
`as4informational.autoscaling.minReplicas`                  | Minimum replicas for autoscaling                                     | 1
`as4informational.autoscaling.maxReplicas`                  | Maximum replicas for autoscaling                                     | 2
`as4informational.autoscaling.targetCPUUtilizationPercentage`| Target CPU utilization                                              | 60
`as4informational.ingress.internal.host`                    | Internal Host name for ingress resource	                          |
`as4informational.ingress.internal.tls.enabled`             | Enable TLS for ingress                                               | true
`as4informational.ingress.internal.tls.secretName`          | TLS secret name                                                      |
`as4informational.ingress.internal.extraPaths`              | Extra paths for ingress resource                                     | 
`as4informational.ingress.external.host`                    | External Host name for ingress resource	                          |
`as4informational.ingress.external.tls.enabled`             | Enable TLS for ingress                                               | true
`as4informational.ingress.external.tls.secretName`          | TLS secret name                                                      |
`as4informational.ingress.external.extraPaths`              | Extra paths for ingress resource                                     |    
`test.image.repository`                        | Repository for docker image used for helm test and cleanup           | 'ibmcom/common-utils'
`test.image.tag          `                     | helm test and cleanup docker image tag                               | `1.0.0.0`
`test.image.digest          `                  | helm test and cleanup docker image digest. Takes precedence over tag |
`test.image.pullPolicy`                        | Pull policy for helm test image repository                           | `IfNotPresent`
`documentService.enabled`       | Enable integration with document service                                | false
`documentService.sslEnabled`           | Enabling client SSL on the document service                              |false
`documentService.useGrpc`              | Using gRPC connection with document service                              |false
`documentService.grpcPoolSize`      | Maximum number of pool threads for gRPC connection                       |150
`documentService.readBufferSize`       | Read buffer size for Get document service                                | 32768
`documentService.service.externalPort`       | External HTTP port                                | 443
`documentService.service.externalGrpcPort`       | External gRPC port                                | 8044
|`documentService.serviceAccount.name`                                 | User wishes to use own/already created service account                                                 | default
|`documentService.application.ssl.enabled`                             |  Enabling client SSL on the document service                                                            | false
|`documentService.application.ssl.protocolVersion`                             |  TLS protocol version used for secure communication with the document service                                                            | TLSv1.3
|`documentService.application.ssl.tlsSecretName`                       |  Using the TLS secret name for communication between b2bi and the document service                      |
|`documentService.application.ssl.trustStoreSecretName`               |   Using the Trust store secret name for communication between b2bi and the document service            |
|`documentService.application.ssl.trustStoreType`               |   type of the trust store            | PKCS12
|`documentService.application.ssl.clientAuth`                        |   The server type of clientAuth for the document service                                                | want
|`documentService.application.objecstore.namespace`                  |   	Namespace as the top-level container for all buckets                                                                                                      |      |
|`documentService.connectionPoolConfig.maxTotalConnections`          |   max Total Connections handle by documentService.                                                                                                                                                   | 250     |
|`documentService.connectionPoolConfig.maxConnectionsPerRoute`       |   want to use object store type using by documentService.                                                                                                                                                   | 100     |
|`documentService.connectionPoolConfig.connectTimeout`               |   set time of documentService connectTimeout.                                                                                                                                                   | 10000     |
|`documentService.connectionPoolConfig.readTimeout`                  |   read Timeout by documentService.                                                                                                                                                   | 60000     |
|`documentService.connectionPoolConfig.idleTimeout`                  |   idle Timeout for documentService.                                                                                                                                                   | 60000     |
|`documentService.connectionPoolConfig.idleMonitorThread`            |   idle Monitor Thread for documentService.                                                                                                                                                   | true     |
|`documentService.connectionPoolConfig.waitTimeout`                  |   wait Time out by documentService.                                                                                                                                                   | 30000     |
|`documentService.connectionPoolConfig.keepAlive`                    |   keep Alive for documentService Pod.                                                                                                                                                   | 300000     |
|`documentService.connectionPoolConfig.retryCount`                   |   number of re try documentService                                                                                                                                                   |  2    |
|`documentService.connectionPoolConfig.disableContentCompression`     |  disable Content compression for documentService                                                                                                                                                    | true     |


A subset of the above parameters map to the env variables defined in [(PRODUCTNAME)](PRODUCTDOCKERURL). For more information please refer to the [(PRODUCTNAME)](PRODUCTDOCKERURL) image documentation.

Specify each parameter using the `--set key=value[,key=value]` argument to `helm install`.

Alternatively, a YAML file that specifies the values for the parameters can be provided while installing the chart. For example,

> **Tip**: You can use the default values.yaml

## Storage
* Define how storage works with the workload
* Dynamic vs PV pre-created
* Considerations if using hostpath, local volume, empty dir
* Loss of data considerations
* Any special quality of service or security needs for storage

## Limitations
* Deployment limits - can you deploy more than once, can you deploy into different namespace
* AS4 Service sub-chart will be deployed by B2BI charts. 
* AS4 catalog pod replica counts should be odd numbers only.
* AS4 Catalog pod cannot be auto scaled, it needs to be handled using replica counts only. 

Note: 
The application installation will automatically create some default internal routes on 
*	Internal Information route host for these web contexts – /as4svc


## Documentation
* Can have as many supporting links as necessary for this specific workload however don't overload the consumer with unnecessary information.
* Can be links to special procedures in the knowledge center.
