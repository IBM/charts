# CDC Access Server — Kubernetes Quickstart

The CDC Access Server is the central management hub for all CDC replication engines.
The CDC Management Console and the `chcclp` CLI connect to it on TCP port **10101** to
register datastores, manage subscriptions, and monitor replication.

A Helm release corresponds to a single Access Server instance. The release name becomes
the pod identity (e.g. `cdc-as-0`). The user store — containing user accounts and
registered datastores — is backed by a PersistentVolumeClaim and survives pod restarts.

> **Note:** For broader CDC architecture context, see the
> [IBM CDC Knowledge Center](https://www.ibm.com/docs/en/idr/11.4.0).

## Table of Contents

1. [Prerequisites](#1-prerequisites)
2. [Create a namespace](#2-create-a-namespace)
3. [Create the IBM Entitlement Key pull secret](#3-create-the-ibm-entitlement-key-pull-secret)
4. [Create the admin credentials secret](#4-create-the-admin-credentials-secret)
5. [Create your values file](#5-create-your-values-file)
6. [Deploy with Helm](#6-deploy-with-helm)
7. [Verify the deployment](#7-verify-the-deployment)
8. [Expose the Access Server for external access](#8-expose-the-access-server-for-external-access)
9. [Upgrade to a new chart version](#9-upgrade-to-a-new-chart-version)
10. [Rotate admin credentials](#10-rotate-admin-credentials)
11. [Uninstall](#11-uninstall)

---

## 1. Prerequisites

- **Kubernetes or OpenShift cluster:** Kubernetes 1.29 or higher is required (OpenShift 4.16+).
  See the [IBM Data Replication System Requirements](https://www.ibm.com/support/pages/node/608111)
  for the full list of supported platform versions.
- **Helm:** Version 3.0 or higher.
- **kubectl:** Configured to access your cluster.
- **IBM Entitlement Key:** Required for pulling images from the IBM entitled registry.
  Obtain yours from the [IBM Container Library](https://myibm.ibm.com/products-services/containerlibrary).
- **Block storage class:** A `ReadWriteOnce`-capable storage class must be available in the
  cluster. Run `kubectl get storageclass` to list available classes.

---

## 2. Create a namespace

```bash
kubectl create namespace <namespace>
```

All subsequent commands use `--namespace <namespace>` (or `-n <namespace>`). Substitute your
chosen namespace throughout this guide.

---

## 3. Create the IBM Entitlement Key pull secret

> **Note:** Create the pull secret **before** running `helm upgrade --install`. If the pod
> is scheduled before the secret exists it fails with `ImagePullBackOff`.

```bash
kubectl create secret docker-registry ibm-entitlement-key \
  --docker-server=cp.icr.io \
  --docker-username=cp \
  --docker-password=<your-entitlement-key> \
  --namespace <namespace>
```

**Using a private or air-gapped registry:** Mirror the Access Server image to your registry
using `samples/mirror-images.sh`, then add `common.imagePullPrefix` to your values file:

```yaml
common:
  imagePullPrefix: "<your-registry-prefix>"
  # Only needed if your pull secret is not named ibm-entitlement-key
  # imagePullSecrets:
  #   - name: <your-secret-name>
```

---

## 4. Create the admin credentials secret

The Access Server creates the initial admin user automatically on first startup using
credentials from this secret. The secret must exist **before** `helm upgrade --install`.

```bash
cat <<EOF | kubectl apply -f -
apiVersion: v1
kind: Secret
metadata:
  name: cdc-as-credentials
  namespace: <namespace>
type: Opaque
stringData:
  username: <admin-username>
  password: <admin-password>
EOF
```

> **Note:** Never put credentials in `values.yaml` or pass them via `--set` — both are
> stored in Helm's release history in the cluster. The secret approach keeps credentials
> out of all configuration files and version control.

---

## 5. Create your values file

Create a values override file — do **not** edit `values.yaml` directly, as it is
overwritten on every chart upgrade.

```yaml
license:
  accept: true
  # IDRAI  — IBM Data Replication AI Edition (standard entitlement)
  # IDRAIZ — IBM Data Replication AI Edition for z/OS (entitlement includes a DB2 for z/OS source)
  type: IDRAI

persistence:
  blockStorageClass: "<storage-class>"   # REQUIRED: name from kubectl get storageclass

adminCredentials:
  # Default is "cdc-as-credentials" — matches the secret created in step 4.
  # Override only if you named the secret differently.
  # secretName: "cdc-as-credentials"
```

For a fully annotated example including air-gapped registry configuration, see
[`samples/install-public-registry.yaml`](../samples/install-public-registry.yaml).

---

## 6. Deploy with Helm

```bash
helm upgrade --install cdc-as ./cdc-access-server \
  -f my-as-values.yaml \
  --namespace <namespace>
```

`cdc-as` is the Helm release name. It becomes the pod name (`cdc-as-0`) and the
in-cluster service hostname. Choose a name that is meaningful for your environment.

---

## 7. Verify the deployment

```bash
# Wait for the StatefulSet to roll out successfully
kubectl rollout status statefulset/cdc-as -n <namespace>

# Watch the pod reach Running state
kubectl get pods -n <namespace> -w

# Stream pod logs continuously
kubectl logs -n <namespace> statefulset/cdc-as -c access-server -f

# View current pod logs (without streaming)
kubectl logs -n <namespace> statefulset/cdc-as -c access-server

# View logs from the previous pod (useful after a crash or restart)
kubectl logs -n <namespace> statefulset/cdc-as -c access-server -p

# Check the service
kubectl get svc -n <namespace>
```

The in-cluster hostname for this Access Server instance follows this pattern:

```
<release-name>.<namespace>.svc.cluster.local:<service-port>
```

where `<release-name>` is the name you passed to `helm upgrade --install` (e.g. `cdc-as`)
and `<service-port>` is the value of `service.port` in your values file (default: `10101`).

Use this address when connecting the Management Console or `chcclp` to the Access Server
from within the same cluster. Helm also prints it immediately after `helm upgrade --install`
completes.

**Successful first startup** produces log output similar to:

```
Starting CDC Access Server on port 10101...
Access Server started with PID 37
Access Server is up on port 10101.
Creating Access Server admin user: <admin-username>
Admin user '<admin-username>' created successfully.
```

Confirm the admin user was created:

```bash
kubectl exec statefulset/cdc-as -c access-server -n <namespace> -- \
  /opt/cdcaccessserver/bin/dmlistusers
```

**Common problems:**

| Symptom | Likely cause | Fix |
|---|---|---|
| `ImagePullBackOff` | Pull secret missing or wrong server | Create secret before `helm upgrade --install`; use `cp.icr.io` for production |
| No user-creation log lines | Credentials secret does not exist in the namespace | The chart validated the secret name but not whether the secret exists — verify: `kubectl get secret cdc-as-credentials -n <namespace>` |
| `dmcreateuser failed` | Password does not meet CDC complexity rules | Update the secret with a compliant password and restart the pod |
| Admin user creation attempted again on restart | Sentinel file was deleted or lost | Expected on first boot only — sentinel file on the PVC prevents re-runs on subsequent restarts |

---

## 8. Expose the Access Server for external access

The Access Server listens on TCP port **10101** inside the container. This port is fixed —
it is not configurable at Helm install time. The chart creates a `ClusterIP` service
exposing this port within the cluster.

If the Management Console or `chcclp` runs outside the cluster, create an additional
Kubernetes service targeting the pod's named container port `as-port`. Choose the type
appropriate for your infrastructure:

- `NodePort` — exposes the port on each node at a static port number.
- `LoadBalancer` — provisions an external load balancer (typical on cloud-managed clusters).

Consult your Kubernetes provider documentation for the specific steps.

---

## 9. Upgrade to a new chart version

The new chart already contains the correct image digest — no manual image tag or digest
override is needed.

```bash
helm upgrade --install cdc-as cdc-access-server-<new-version>.tgz \
  -f my-as-values.yaml \
  --namespace <namespace>
```

> **Important:** Always pass your values file explicitly with `-f`. Running `helm upgrade`
> without `-f` resets all values to the chart defaults.

**Version upgrades — pod restarts automatically.** When the chart version changes, the image
digest in the pod spec changes and Kubernetes performs a rolling restart of the StatefulSet
automatically. Monitor it with:

```bash
kubectl rollout status statefulset/<release-name> -n <namespace>
```

**Configuration-only changes — manual restart required.** When `helm upgrade` changes only
values that do not affect the pod spec (for example `service.port` or `adminCredentials`
references), Kubernetes does not restart the pod automatically. After confirming the upgrade
succeeded, restart manually if needed:

```bash
kubectl rollout restart statefulset/<release-name> -n <namespace>
kubectl rollout status statefulset/<release-name> -n <namespace>
```

> **Note:** Credential rotation (updating the admin username or password in the secret) also
> requires a manual restart. See
> [samples/rotate-admin-credentials.md](../samples/rotate-admin-credentials.md) for the
> full procedure.

---

## 10. Rotate admin credentials

Credential rotation is a `kubectl` operation — no Helm values change is required.

```bash
cat <<EOF | kubectl apply -f -
apiVersion: v1
kind: Secret
metadata:
  name: cdc-as-credentials
  namespace: <namespace>
type: Opaque
stringData:
  username: <admin-username>
  password: <new-password>
EOF

kubectl rollout restart statefulset/cdc-as --namespace <namespace>
```

The user store on the PVC — registered datastores, subscriptions — is preserved across
restarts.

> **Note:** Updating the secret and restarting the pod updates the credentials used by the
> entrypoint. The Access Server user account in the CDC user store is updated accordingly
> on restart.

---

## 11. Uninstall

```bash
helm uninstall cdc-as --namespace <namespace>
```

The PersistentVolumeClaim is **not** deleted automatically. To remove it along with the
secret and namespace:

```bash
kubectl delete pvc -l app.kubernetes.io/instance=cdc-as -n <namespace>
kubectl delete secret cdc-as-credentials -n <namespace>
kubectl delete namespace <namespace>
```

> **Caution:** Deleting the PVC permanently destroys the Access Server user store including
> all registered datastores. Only do this when you are certain the data is no longer needed.
