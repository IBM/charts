# Upgrading to a new chart version

The new chart version already contains the correct image digest for this release — no manual
image tag or digest override is needed.

## Steps

1. Run `helm upgrade` with the new chart tarball and your existing values file:

   ```bash
   helm upgrade --install <release-name> cdc-access-server-<new-version>.tgz \
     -f my-as-values.yaml \
     --namespace <namespace>
   ```

> **Important:** Always pass your values file explicitly with `-f`. Running `helm upgrade`
> without `-f` resets all values to the chart defaults, overwriting your configuration.
