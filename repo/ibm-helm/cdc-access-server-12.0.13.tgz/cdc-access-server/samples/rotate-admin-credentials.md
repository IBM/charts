# Rotating admin credentials

Credential rotation is a `kubectl` operation — no Helm values change is required.
The Access Server picks up the new credentials on pod restart.

## Steps

1. Update the secret with the new credentials:

   ```bash
   cat <<EOF | kubectl apply -f -
   apiVersion: v1
   kind: Secret
   metadata:
     name: cdc-as-credentials
     namespace: <namespace>
   type: Opaque
   stringData:
     username: <admin-username>
     password: <new-password>
   EOF
   ```

2. Restart the Access Server pod:

   ```bash
   kubectl rollout restart statefulset/<release-name> --namespace <namespace>
   ```

3. Verify the pod restarts successfully:

   ```bash
   kubectl get pods --namespace <namespace> -w
   ```

The user store on the PVC — registered datastores and existing user accounts — is preserved
across restarts.
