{{/*
Operator deployment
Usage: {{ include "operator-core-library.operatorDeployment" (dict "root" . "lib" .Values.operatorLibraryConfig "config" .Values.streamsets) }}
*/}}
{{- define "operator-core-library.operatorDeployment" -}}
{{- $root := .root -}}
{{- $lib := .lib -}}
{{- $config := .config -}}
{{- $namespaces := (include "operator-core-library.watchNamespaces" $root | fromYamlArray) -}}
apiVersion: apps/v1
kind: Deployment
metadata:
  labels:
    control-plane: controller-manager
    {{- range $key, $value := $lib.labels }}
    {{ $key }}: {{ $value | quote }}
    {{- end }}
    component-id: {{ $root.Chart.Name }}
  name: {{ $lib.operatorName }}-controller-manager
  namespace: {{ $root.Values.global.operatorNamespace }}
spec:
  replicas: 1
  selector:
    matchLabels:
      control-plane: controller-manager
  template:
    metadata:
      annotations:
        kubectl.kubernetes.io/default-container: manager
        productChargedContainers: All
        productCloudpakRatio: "1:1"
        productID: {{ $lib.productID | quote }}
        productMetric: VIRTUAL_PROCESSOR_CORE
        productName: {{ $lib.productName | quote }}
        productVersion: {{ $lib.productVersion | default ($config.crVersion | default $root.Chart.AppVersion) | quote }}
      labels:
        control-plane: controller-manager
        {{- range $key, $value := $lib.labels }}
        {{ $key }}: {{ $value | quote }}
        {{- end }}
        {{- if $lib.additionalPodLabels }}
        {{- range $key, $value := $lib.additionalPodLabels }}
        {{ $key }}: {{ $value | quote }}
        {{- end }}
        {{- end }}
        component-id: {{ $root.Chart.Name }}
    spec:
      containers:
        - args:
            - --metrics-bind-address={{ $lib.metricsBindAddress | default "0" }}
            - --leader-elect
            - --health-probe-bind-address=:8081
            {{- range $config.additionalArgs }}
            - {{ . | quote }}
            {{- end }}
          image: {{ include "operator-core-library.operatorImage" (dict "root" $root "config" $config) }}
          imagePullPolicy: Always
          env:
            - name: WATCH_NAMESPACE
              value: {{ $namespaces | join "," | quote }}
            {{- if $lib.additionalEnvVars }}
            {{- range $lib.additionalEnvVars }}
            - name: {{ .name }}
              {{- if .value }}
              value: {{ .value | quote }}
              {{- else if .valueFrom }}
              valueFrom:
                {{- toYaml .valueFrom | nindent 16 }}
              {{- end }}
            {{- end }}
            {{- end }}
          volumeMounts:
            - name: operator-config
              mountPath: /resources/composed-resources/values/operator
          livenessProbe:
            httpGet:
              path: /healthz
              port: 8081
            initialDelaySeconds: 15
            periodSeconds: 20
          name: manager
          readinessProbe:
            httpGet:
              path: /readyz
              port: 8081
            initialDelaySeconds: 5
            periodSeconds: 10
          resources:
            limits:
              cpu: 500m
              memory: 512Mi
            requests:
              cpu: 10m
              memory: 128Mi
          securityContext:
            allowPrivilegeEscalation: false
            capabilities:
              drop:
                - ALL
      securityContext:
        runAsNonRoot: true
      serviceAccountName: {{ $lib.serviceAccountName }}
      {{- if $root.Values.global.imagePullSecret }}
      imagePullSecrets:
        - name: {{ $root.Values.global.imagePullSecret | quote }}
      {{- end }}
      volumes:
        - name: operator-config
          configMap:
            name: {{ $lib.operatorName }}-config
            items:
              - key: values.yaml
                path: values.yaml
      terminationGracePeriodSeconds: 10
{{- end -}}
