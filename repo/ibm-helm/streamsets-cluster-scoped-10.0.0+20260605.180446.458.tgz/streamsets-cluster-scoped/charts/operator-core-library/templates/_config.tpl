{{/*
Preserve relevant values from the helm release in a configmap, where it can be used as an overlay.
Usage: {{ include "operator-core-library.operatorConfig" (dict "root" . "lib" .Values.operatorLibraryConfig "config" .Values.streamsets) }}
*/}}
{{- define "operator-core-library.operatorConfig" -}}
{{- $root := .root -}}
{{- $lib := .lib -}}
{{- $config := .config -}}
apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ $lib.operatorName }}-config
  namespace: {{ $root.Values.global.operatorNamespace }}
  labels:
    {{- range $key, $value := $lib.labels }}
    {{ $key }}: {{ $value | quote }}
    {{- end }}
    component-id: {{ $root.Chart.Name }}
data:
  values.yaml: |
{{- if $root.Values.global }}
    global:
{{ $root.Values.global | toYaml | indent 6 }}
{{- end }}
{{- if $root.Values.ccs }}
    ccs:
{{ $root.Values.ccs | toYaml | indent 6 }}
{{- end }}
{{ $config | toYaml | indent 4 }}
{{- end -}}
