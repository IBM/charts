{{/*
Cluster role required for backup & restore
Usage: {{ include "operator-core-library.clusterRole" (dict "root" . "lib" .Values.operatorLibraryConfig) }}
*/}}
{{- define "operator-core-library.clusterRole" -}}
{{- $root := .root -}}
{{- $lib := .lib -}}
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: {{ $lib.crdPlural }}.{{ $lib.apiGroup }}-v1alpha1-{{ $root.Values.global.operatorNamespace }}-edit
  labels:
    {{- range $key, $value := $lib.labels }}
    {{ $key }}: {{ $value | quote }}
    {{- end }}
    component-id: {{ $root.Chart.Name }}
    rbac.authorization.k8s.io/aggregate-to-edit: "true"
rules:
- apiGroups: ["{{ $lib.apiGroup }}"]
  resources: ["{{ $lib.crdPlural }}"]
  verbs: ["get","list","watch","create","update","patch","delete"]
{{- if $lib.additionalClusterRules }}
{{- range $lib.additionalClusterRules }}
- apiGroups: {{ .apiGroups | toJson }}
  resources: {{ .resources | toJson }}
  verbs: {{ .verbs | toJson }}
{{- end }}
{{- end }}
{{- end -}}
