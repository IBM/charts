{{/*
Expand the name of the chart.
Defaults to ibm-wxd-opensearch unless nameOverride is provided.
*/}}
{{- define "opensearch-operator.name" -}}
{{- default "ibm-wxd-opensearch" .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "opensearch-operator.watchNamespaces" -}}
{{- $watchNamespaces := .Values.global.tetheredNamespaces | default list -}}
{{- if .Values.global.instanceNamespace -}}
{{- $watchNamespaces = append $watchNamespaces .Values.global.instanceNamespace -}}
{{- end -}}
{{- $watchNamespaces = prepend $watchNamespaces .Values.global.operatorNamespace }}
{{- uniq $watchNamespaces | join "," | quote }}
{{- end -}}

{{- define "opensearch-operator.watchNamespacesList" -}}
{{- $watchNamespaces := .Values.global.tetheredNamespaces | default list -}}
{{- if .Values.global.instanceNamespace -}}
{{- $watchNamespaces = append $watchNamespaces .Values.global.instanceNamespace -}}
{{- end -}}
{{- $watchNamespaces = prepend $watchNamespaces .Values.global.operatorNamespace }}
{{- uniq $watchNamespaces | toYaml }}
{{- end -}}

{{/*
Operator image pull prefix priority:
1. ibmWxdOpensearch.devImagePullPrefix (for staging/dev)
2. global.imagePullPrefix (for airgap or production)
3. default: icr.io (for online/default installs)

Note: global.installConfigImagePullPrefix is NOT used for OpenSearch operator images.
It is derived from olm-utils and is not required for OpenSearch.
*/}}
{{- define "opensearch-operator.operatorImagePullPrefix" -}}
{{- if .Values.ibmWxdOpensearch.devImagePullPrefix -}}
{{- .Values.ibmWxdOpensearch.devImagePullPrefix -}}
{{- else if .Values.global.imagePullPrefix -}}
{{- .Values.global.imagePullPrefix -}}
{{- else -}}
icr.io
{{- end -}}
{{- end -}}

{{/*
Component/operand image pull prefix priority:
1. ibmWxdOpensearch.devImagePullPrefix (for staging/dev)
2. global.imagePullPrefix (for airgap or custom registry)
3. default: cp.icr.io (for online/default installs)

Online/default behavior:
- When global.imagePullPrefix is "icr.io", component images use cp.icr.io
- This ensures operator images come from icr.io/cpopen and operands from cp.icr.io/cp/cpd

Airgap behavior:
- When global.imagePullPrefix is set to a private registry, both operator and operands use it

Note: global.installConfigImagePullPrefix is NOT used for OpenSearch component images.
*/}}
{{- define "opensearch-operator.componentImagePullPrefix" -}}
{{- if .Values.ibmWxdOpensearch.devImagePullPrefix -}}
{{- .Values.ibmWxdOpensearch.devImagePullPrefix -}}
{{- else if eq .Values.global.imagePullPrefix "icr.io" -}}
cp.icr.io
{{- else if .Values.global.imagePullPrefix -}}
{{- .Values.global.imagePullPrefix -}}
{{- else -}}
cp.icr.io
{{- end -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
Do not derive from Chart.Name or Release.Name because split packaging
may rename the chart (for example, adding -cluster-scoped), while
Kubernetes resource names must remain canonical.
*/}}
{{- define "opensearch-operator.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- include "opensearch-operator.name" . }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "opensearch-operator.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "opensearch-operator.labels" -}}
helm.sh/chart: {{ include "opensearch-operator.chart" . }}
{{ include "opensearch-operator.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "opensearch-operator.selectorLabels" -}}
app.kubernetes.io/name: {{ include "opensearch-operator.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "opensearch-operator.serviceAccountName" -}}
{{- if .Values.ibmWxdOpensearch.serviceAccount.create }}
{{- default (printf "%s-%s" (include "opensearch-operator.fullname" .) "controller-manager") .Values.ibmWxdOpensearch.serviceAccount.name }}
{{- else }}
{{- default "opensearch-operator-controller-manager" .Values.ibmWxdOpensearch.serviceAccount.name }}
{{- end }}
{{- end }}

{{- define "traefik.name" -}}
{{- printf "%s-traefik" (include "opensearch-operator.fullname" .) -}}
{{ end }}

{{- define "traefik.svc-addr-without-port" -}}
{{- printf "%s.%s.svc.cluster.local" (include "traefik.name" .) .Values.global.operatorNamespace -}}
{{- end -}}

{{/*
Create the name of the metrics service with proper truncation
*/}}
{{- define "opensearch-operator.metricsServiceName" -}}
{{- $fullname := include "opensearch-operator.fullname" . -}}
{{- $suffix := "-controller-manager-metrics-service" -}}
{{- $maxLength := int (sub 63 (len $suffix)) -}}
{{- printf "%s%s" ($fullname | trunc $maxLength | trimSuffix "-") $suffix -}}
{{- end }}
