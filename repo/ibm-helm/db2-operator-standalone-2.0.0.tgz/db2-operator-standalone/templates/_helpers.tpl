{{/*
Expand the name of the chart.
*/}}
{{- define "db2-operator.name" -}}
{{- default .Chart.Name .Values.db2u.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "db2-operator.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "db2-operator.labels" -}}
helm.sh/chart: {{ include "db2-operator.chart" . }}
{{ include "db2-operator.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | replace "+" "_" | trunc 63 | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
component-id: {{ .Chart.Name }}
{{- with .Values.db2u.commonLabels }}
{{ toYaml . }}
{{- end }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "db2-operator.selectorLabels" -}}
app.kubernetes.io/name: {{ include "db2-operator.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "db2-operator.serviceAccountName" -}}
{{- if .Values.db2u.serviceAccount.create }}
{{- default "db2-database-operator" .Values.db2u.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.db2u.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Namespace to use - supports both CPD (operatorNamespace) and standalone (metaNamespace with valueFrom)
*/}}
{{- define "db2-operator.namespace" -}}
{{- if .Values.global.operatorNamespace -}}
  {{- .Values.global.operatorNamespace -}}
{{- else if .Values.global.metaNamespace -}}
  {{- if kindIs "map" .Values.global.metaNamespace -}}
    {{- .Release.Namespace -}}
  {{- else -}}
    {{- .Values.global.metaNamespace -}}
  {{- end -}}
{{- else -}}
  {{- .Release.Namespace -}}
{{- end -}}
{{- end -}}

{{/*
Get unique list of namespaces to watch - supports both CPD and standalone patterns
*/}}
{{- define "db2-operator.watchNamespaces" -}}
{{- $namespaces := list -}}
{{- if and .Values.global.instanceNamespace (ne .Values.global.instanceNamespace "") -}}
  {{- $namespaces = append $namespaces .Values.global.instanceNamespace -}}
{{- end -}}
{{- if .Values.global.tetheredNamespaces -}}
  {{- range $ns := .Values.global.tetheredNamespaces -}}
    {{- if and $ns (ne $ns "") -}}
      {{- $namespaces = append $namespaces $ns -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- if kindIs "slice" .Values.global.watchNamespace -}}
  {{- range $ns := .Values.global.watchNamespace -}}
    {{- if and $ns (ne $ns "") -}}
      {{- $namespaces = append $namespaces $ns -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- $namespaces = append $namespaces (include "db2-operator.namespace" .) -}}
{{- $namespaces | uniq | toJson -}}
{{- end -}}

{{/*
Image pull secrets - supports both single string and array formats
*/}}
{{- define "db2-operator.imagePullSecrets" -}}
{{- if .Values.global.imagePullSecret -}}
- name: {{ .Values.global.imagePullSecret }}
{{- else if .Values.global.imagePullSecrets -}}
{{- range $secret := .Values.global.imagePullSecrets }}
- name: {{ $secret }}
{{- end }}
{{- else if .Values.db2u.imagePullSecrets -}}
{{- range $secret := .Values.db2u.imagePullSecrets }}
- name: {{ $secret }}
{{- end }}
{{- end -}}
{{- end -}}

{{/*
Validate compatibility with the legacy OLM-managed operator in the operator namespace.
If no legacy operator is installed, allow the chart install to proceed.
*/}}
{{- define "db2-operator.validateLegacyOperatorCompatibility" -}}
{{- $config := .Values.db2u.compatibilityCheck.oldOperatorCSV -}}
{{- if and $config.enabled (.Capabilities.APIVersions.Has "operators.coreos.com/v1alpha1") -}}
  {{- $namespace := include "db2-operator.namespace" . | trim -}}
  {{- $packageName := $config.packageName | trim -}}
  {{- $minimumVersion := $config.minimumVersion | trim -}}
  {{- $allowEqual := $config.allowEqual -}}
  {{- $state := dict "csvName" "" "csvVersion" "" -}}

  {{- $subscriptionList := lookup "operators.coreos.com/v1alpha1" "Subscription" $namespace "" -}}
  {{- if $subscriptionList -}}
    {{- range $subscription := $subscriptionList.items -}}
      {{- if eq (default "" $subscription.spec.name) $packageName -}}
        {{- $subscriptionCSV := coalesce $subscription.status.installedCSV $subscription.status.currentCSV $subscription.spec.startingCSV "" -}}
        {{- if ne $subscriptionCSV "" -}}
          {{- $_ := set $state "csvName" $subscriptionCSV -}}
          {{- $_ := set $state "csvVersion" (regexFind "[0-9]+\\.[0-9]+\\.[0-9]+" $subscriptionCSV) -}}
        {{- end -}}
      {{- end -}}
    {{- end -}}
  {{- end -}}

  {{- if eq (get $state "csvName") "" -}}
    {{- $csvList := lookup "operators.coreos.com/v1alpha1" "ClusterServiceVersion" $namespace "" -}}
    {{- if $csvList -}}
      {{- range $csv := $csvList.items -}}
        {{- $csvName := default "" $csv.metadata.name -}}
        {{- $candidateVersion := regexFind "[0-9]+\\.[0-9]+\\.[0-9]+" $csvName -}}
        {{- if and (hasPrefix (printf "%s.v" $packageName) $csvName) (ne $candidateVersion "") -}}
          {{- if or (eq (get $state "csvVersion") "") (semverCompare (printf ">%s" (get $state "csvVersion")) $candidateVersion) -}}
            {{- $_ := set $state "csvName" $csvName -}}
            {{- $_ := set $state "csvVersion" $candidateVersion -}}
          {{- end -}}
        {{- end -}}
      {{- end -}}
    {{- end -}}
  {{- end -}}

  {{- $detectedCSV := get $state "csvName" -}}
  {{- if ne $detectedCSV "" -}}
    {{- $detectedVersion := get $state "csvVersion" -}}
    {{- if eq $detectedVersion "" -}}
      {{- fail (printf "legacy operator compatibility check found CSV %q in namespace %q but could not parse its version" $detectedCSV $namespace) -}}
    {{- end -}}
    {{- $constraint := printf ">=%s" $minimumVersion -}}
    {{- if not $allowEqual -}}
      {{- $constraint = printf ">%s" $minimumVersion -}}
    {{- end -}}
    {{- if not (semverCompare $constraint $detectedVersion) -}}
      {{- fail (printf "legacy operator compatibility check failed in namespace %q: found old operator CSV %q (version %s), but the new operator requires %s %s or no old operator installed" $namespace $detectedCSV $detectedVersion (ternary "at least" "greater than" $allowEqual) $minimumVersion) -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- end -}}

{{/*
Validate that the license has been accepted.
*/}}
{{- define "db2-operator._validate-license" -}}
{{- if not .Values.global.licenseAccept }}
  {{- fail "Change global.licenseAccept to true to indicate have read and agree to license agreements" }}
{{- end }}
{{- end -}}
