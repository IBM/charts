{{/*
Expand the name of the chart.
*/}}
{{- define "db2-ums-collector.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "db2-ums-collector.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "db2-ums-collector.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "db2-ums-collector.labels" -}}
helm.sh/chart: {{ include "db2-ums-collector.chart" . }}
{{ include "db2-ums-collector.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "db2-ums-collector.selectorLabels" -}}
app.kubernetes.io/name: {{ include "db2-ums-collector.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "db2-ums-collector.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "db2-ums-collector.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Create the name of the metrics ConfigMap
*/}}
{{- define "db2-ums-collector.metricsConfigMapName" -}}
{{- if .Values.metrics.configMapName }}
{{- .Values.metrics.configMapName }}
{{- else }}
{{- include "db2-ums-collector.fullname" . }}-metrics
{{- end }}
{{- end }}

{{/*
Create the name of the state ConfigMap
*/}}
{{- define "db2-ums-collector.stateConfigMapName" -}}
{{- if .Values.metrics.stateConfigMapName }}
{{- .Values.metrics.stateConfigMapName }}
{{- else }}
{{- include "db2-ums-collector.fullname" . }}-state
{{- end }}
{{- end }}

{{/*
Get the namespace to use for collector resources
Priority:
1. If global.instanceNamespace is set, use it (allows parent chart to control collector namespace)
2. Otherwise, use Release.Namespace (default behavior)
This allows the collector to be installed in a different namespace than the release namespace
when global.instanceNamespace is specified, while UMS installation is controlled by ums.install
*/}}
{{- define "db2-ums-collector.namespace" -}}
{{- if .Values.global.instanceNamespace }}
{{- .Values.global.instanceNamespace }}
{{- else }}
{{- .Release.Namespace }}
{{- end }}
{{- end }}

{{/*
Convert comma-delimited watchNamespace string to a list
Returns empty list if string is empty
Handles both string format and list format (for backwards compatibility)
Priority: global.tetheredNamespaces > global.watchNamespace

Supported formats:
1. String (comma-delimited): "konrad1,konrad2,konrad3"
2. List: ["konrad1", "konrad2", "konrad3"]
3. Empty/nil: [] (watch only deployment namespace)

Note: valueFrom/fieldRef is NOT supported because Helm values are static at template time.
If you need dynamic namespace detection, use a list or string format.
*/}}
{{- define "db2-ums-collector.watchNamespacesList" -}}
{{- /* Check tetheredNamespaces first, then watchNamespace */ -}}
{{- $watchNs := .Values.global.tetheredNamespaces | default .Values.global.watchNamespace }}
{{- if $watchNs }}
{{- if kindIs "string" $watchNs }}
{{- /* Handle string format: split by comma and trim whitespace */ -}}
{{- $namespaces := splitList "," $watchNs }}
{{- $trimmedNamespaces := list }}
{{- range $namespaces }}
{{- $trimmed := trim . }}
{{- if $trimmed }}
{{- $trimmedNamespaces = append $trimmedNamespaces $trimmed }}
{{- end }}
{{- end }}
{{- $trimmedNamespaces }}
{{- else if kindIs "slice" $watchNs }}
{{- /* Handle list format: return as-is */ -}}
{{- $watchNs }}
{{- else if kindIs "map" $watchNs }}
{{- /* Handle map format (likely valueFrom/fieldRef from parent chart) */ -}}
{{- if hasKey $watchNs "valueFrom" }}
{{- /* This is a Kubernetes Pod spec structure (valueFrom.fieldRef), not a Helm value */ -}}
{{- /* Ignore it and return empty list - parent chart should use proper Helm values format */ -}}
{{- list }}
{{- else }}
{{- /* Unknown map structure - fail with helpful error */ -}}
{{- fail (printf "global.tetheredNamespaces/watchNamespace is a map but not a valueFrom structure. Use comma-delimited string (\"ns1,ns2\") or list ([\"ns1\", \"ns2\"]). Got: %v" $watchNs) }}
{{- end }}
{{- else }}
{{- /* Unsupported type - fail with helpful error */ -}}
{{- fail (printf "global.tetheredNamespaces/watchNamespace must be a string or list, got: %s. Use comma-delimited string (\"ns1,ns2\") or list ([\"ns1\", \"ns2\"])" (kindOf $watchNs)) }}
{{- end }}
{{- else }}
{{- /* Empty/nil - return empty list */ -}}
{{- list }}
{{- end }}
{{- end }}

{{/*
Get the operatorNamespace for ibm-usage-metering subchart
This helper allows the parent chart (db2-operator) to pass global.namespace
which will be used as operatorNamespace for the ibm-usage-metering subchart
Priority:
1. If ibm-usage-metering.global.operatorNamespace is explicitly set, use it
2. Otherwise, use global.namespace from parent chart
3. If neither is set, use Release.Namespace as fallback
*/}}
{{- define "db2-ums-collector.umsOperatorNamespace" -}}
{{- if index .Values "ibm-usage-metering" "global" "operatorNamespace" }}
{{- index .Values "ibm-usage-metering" "global" "operatorNamespace" }}
{{- else if .Values.global.namespace }}
{{- .Values.global.namespace }}
{{- else }}
{{- .Release.Namespace }}
{{- end }}
{{- end }}

{{/*
Get the operatorNamespace for ibm-usage-metering-cluster-scoped subchart
This helper allows the parent chart (db2-operator) to pass global.namespace
which will be used as operatorNamespace for the ibm-usage-metering-cluster-scoped subchart
Priority:
1. If ibm-usage-metering-cluster-scoped.global.operatorNamespace is explicitly set, use it
2. Otherwise, use global.namespace from parent chart
3. If neither is set, default to "ibm-usage-metering" (standard namespace for cluster-scoped resources)
*/}}
{{- define "db2-ums-collector.umsClusterScopedOperatorNamespace" -}}
{{- if index .Values "ibm-usage-metering-cluster-scoped" "global" "operatorNamespace" }}
{{- index .Values "ibm-usage-metering-cluster-scoped" "global" "operatorNamespace" }}
{{- else if .Values.global.namespace }}
{{- .Values.global.namespace }}
{{- else }}
{{- "ibm-usage-metering" }}
{{- end }}
{{- end }}

{{/*
Generate pod security context
Outputs the podSecurityContext as-is from values.yaml
runAsUser and fsGroup are only included if explicitly set in values
*/}}
{{- define "db2-ums-collector.podSecurityContext" -}}
{{- toYaml .Values.podSecurityContext | nindent 0 }}
{{- end }}

{{/*
Get the image repository
Constructs: {imagePullPrefix}/{repositoryPath}
*/}}
{{- define "db2-ums-collector.imageRepository" -}}
{{- $prefix := .Values.global.imagePullPrefix | default "icr.io" | trim }}
{{- $path := .Values.image.repositoryPath | default "db2u/db2-operator" | trim }}
{{- printf "%s/%s" $prefix $path }}
{{- end }}

{{/*
Get the image tag
*/}}
{{- define "db2-ums-collector.imageTag" -}}
{{- .Values.image.tag | default .Chart.AppVersion }}
{{- end }}

{{/*
Get the image pull policy
*/}}
{{- define "db2-ums-collector.imagePullPolicy" -}}
{{- .Values.image.pullPolicy | default "IfNotPresent" }}
{{- end }}