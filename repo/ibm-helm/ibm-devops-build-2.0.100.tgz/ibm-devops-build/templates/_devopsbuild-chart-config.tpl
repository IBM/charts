{{/*
license  parameter must be set to true
*/}}
{{- define "{{ .Chart.Name }}.licenseValidate.build" -}}
  {{ $license := .Values.license.accept }}
  {{- if $license  -}}
    true
  {{- end -}}
{{- end -}}

{{- define "{{ .Chart.Name }}.imagePath.build" -}}
{{- if or (eq .Values.global.imageRegistry "cp.icr.io/cp") (not .Values.global.imageRegistry) -}}
  cp.icr.io/cp
{{- else if and (.Values.global.imageRegistry) (.Values.image.repository) -}}
  {{ .Values.global.imageRegistry }}/{{ .Values.image.repository }}
{{- else if (.Values.global.imageRegistry) -}}
  {{ .Values.global.imageRegistry }}
{{- else -}}
  cp.icr.io/cp
{{- end -}}
{{- end -}}

{{/* Determine which image to use given the product version.  */}}
{{/* Values.version can be an imagespec to allow registries other than IBM ER */}}
{{- define "{{ .Chart.Name }}.imageSpec.build" -}}
{{- $imagePathName := include "{{ .Chart.Name }}.imagePath.build" . | trim -}}
{{ $imagePathName }}/ibm-devops-build-server:{{ .Values.version }}
{{- end -}}

{{- define "{{ .Chart.Name }}.imageSpec.agent.build" -}}
{{- $imagePathName := include "{{ .Chart.Name }}.imagePath.build" . | trim -}}
{{ $imagePathName}}/ibm-devops-build-agent:{{ .Values.agent.version }}
{{- end -}}

{{- define "{{ .Chart.Name }}.imageSpec.mcp-server.build" -}}
{{- $imagePathName := include "{{ .Chart.Name }}.imagePath.build" . | trim -}}
{{ $imagePathName}}/ibm-devops-build-mcp-server:{{ index .Values "mcp-server" "version" }}
{{- end -}}

{{- define "{{ .Chart.Name }}.externalImagePrefix.build" -}}
{{- if and (.Values.global.externalImageRegistry) (.Values.image.repository) -}}
  {{- printf "%s/%s/" .Values.global.externalImageRegistry .Values.image.repository -}}
{{- else if (.Values.global.externalImageRegistry) -}}
  {{- printf "%s/" .Values.global.externalImageRegistry -}}
{{- end -}}
{{- end -}}