{{- define "ibm-devops-build.labels" -}}
app.kubernetes.io/instance: '{{ .Release.Name }}'
app.kubernetes.io/managed-by: '{{ .Release.Service }}'
app.kubernetes.io/name: devops-build
app.kubernetes.io/part-of: '{{ .Chart.Name }}'
app.kubernetes.io/version: '{{ regexReplaceAll "-.*" .Chart.AppVersion "" }}'
helm.sh/chart: '{{ .Chart.Name }}-{{ .Chart.Version }}'
{{- end }}

{{- define "devopsbuild.securityContext" -}}
securityContext:
  runAsNonRoot: true
{{- if not (.Capabilities.APIVersions.Has "security.openshift.io/v1") }}
  runAsUser: 1001
  fsGroup: 1001
{{- else }}
  supplementalGroups: [1001]
{{- end }}
  seccompProfile:
    type: RuntimeDefault
{{- end -}}

{{- define "devopsbuild.containerSecurityContext" -}}
securityContext:
  privileged: false
  readOnlyRootFilesystem: false
  allowPrivilegeEscalation: false
  runAsNonRoot: true
  seccompProfile:
    type: RuntimeDefault
  capabilities:
    drop:
      - ALL
{{- if not (.Capabilities.APIVersions.Has "security.openshift.io/v1") }}
  runAsUser: 1001   # UID for 'ucb'
{{- end }}
{{- end -}}

{{/*
Private CA Bundle Volumes
Adds volumes required for private CA trust when privateCaBundleSecretName is set
*/}}
{{- define "devopsbuild.privateCaVolumes" -}}
{{- if .Values.global.privateCaBundleSecretName }}
{{- $privateCaCert := index (lookup "v1" "Secret" .Release.Namespace .Values.global.privateCaBundleSecretName).data "ca.crt" -}}
{{- if $privateCaCert }}
- name: private-ca-volume
  secret:
    secretName: {{ .Values.global.privateCaBundleSecretName }}
    items:
      - key: ca.crt
        path: ca.crt
- name: ca-trust-dir
  emptyDir: {}
{{- end }}
{{- end }}
{{- end -}}

{{/*
Private CA Bundle Init Container
Adds initContainer to update CA trust when privateCaBundleSecretName is set
Usage: {{ include "devopsbuild.privateCaInitContainer" (dict "imageSpec" $imageSpec "pullPolicy" .Values.image.pullPolicy "context" .) }}
*/}}
{{- define "devopsbuild.privateCaInitContainer" -}}
{{- if .context.Values.global.privateCaBundleSecretName }}
{{- $privateCaCert := index (lookup "v1" "Secret" .context.Release.Namespace .context.Values.global.privateCaBundleSecretName).data "ca.crt" -}}
{{- if $privateCaCert }}
- name: update-ca-trust
  image: {{ .imageSpec | quote }}
  {{- include "devopsbuild.containerSecurityContext" .context | nindent 2 }}
  imagePullPolicy: {{ .pullPolicy }}
  command: ["/bin/bash", "/scripts/update-ca-trust.sh"]
  volumeMounts:
    - name: private-ca-volume
      mountPath: /private-ca-volume
      readOnly: true
    - name: ca-trust-dir
      mountPath: /ca-trust-dir
    - name: scripts
      mountPath: /scripts
{{- end }}
{{- end }}
{{- end -}}

{{/*
Private CA Bundle Volume Mount for main container
Adds volume mount for CA trust directory when privateCaBundleSecretName is set
*/}}
{{- define "devopsbuild.privateCaVolumeMount" -}}
{{- if .Values.global.privateCaBundleSecretName }}
{{- $privateCaCert := index (lookup "v1" "Secret" .Release.Namespace .Values.global.privateCaBundleSecretName).data "ca.crt" -}}
{{- if $privateCaCert }}
- name: ca-trust-dir
  mountPath: /etc/pki/ca-trust/extracted
{{- end }}
{{- end }}
{{- end -}}