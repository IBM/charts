# Breaking Changes

- Starting with this release, the default value for storageSecurity.runAsUser is left blank. This change does not affect existing configurations during upgrades, ensuring backward compatibility. However, for fresh installations, it is recommended to explicitly set a value if needed; otherwise, a random user ID will be assigned based on the Security Context Constraints (SCC) applied to the pod.

# Fixes


# Prerequisites

Please refer prerequisites section from [README.md](README.md)

# Documentation

Please refer to [README.md](README.md) provided with chart for detailed installation instruction.

# Version History

| Chart  | Date          | Kubernetes Required | OpenShift Required  | Image(s) Supported           | Details                                    |
| ------ | ------------- | ------------------- | ------------------- | ---------------------------- | ------------------------------------------ |
| 4.3.0  | Sep 30, 2026  | >= 1.32             | >= 4.19             | ibmscc:6.4.3.0_2026-09-28    | IBM Sterling Control Center Monitor 6.4.3.0|
| ------ | ------------- | ------------------- | ------------------- | ---------------------------- | ------------------------------------------ |
