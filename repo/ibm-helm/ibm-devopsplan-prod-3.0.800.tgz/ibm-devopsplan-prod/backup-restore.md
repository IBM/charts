# Velero Deployment with S3 Bucket (AWS)

This guide explains how to deploy **Velero** on Kubernetes using **AWS S3** as the backup storage backend.  
Using **AWS S3** provides a reliable, scalable, and secure solution for backing up and restoring Kubernetes clusters, including **Persistent Volume Claims (PVCs)**.


---

## Prerequisites

### AWS CLI
Install:
https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html

Verify:
```bash
aws --version
```

### Velero CLI
Install:
https://velero.io/docs/v1.3.0/basic-install/

Verify:
```bash
velero version --client-only
```

---

## Step 1: Create S3 Bucket
### Through GUI

  a. Login to AWS Console → Search S3 → Click Create bucket

  b. Bucket name: <Bucket Name> (unique, lowercase)

  c. AWS Region: Region (i.e., us-east-1)

  d. Object Ownership: Keep ACLs disabled (default)

  e. Block ALL public access: Keep all 4 checkboxes checked (default)

  f. Bucket Versioning: Enable It → Click Create bucket

  g. Click your new bucket → Properties tab → Bucket Versioning → Edit → Enable → Save

  h. Permissions tab → Block public access → Edit → Confirm all 4 checkboxes checked → Save changes

  i. Permissions tab → Bucket policy → Edit → Paste this JSON (provide BUCKET-NAME):

  ```json
  {
    "Version": "2012-10-17",
    "Statement": [{
      "Sid": "VeleroBucketPolicy",
      "Effect": "Allow",
      "Principal": {"AWS": "*"},
      "Action": ["s3:GetObject","s3:DeleteObject","s3:PutObject","s3:AbortMultipartUpload","s3:ListMultipartUploadParts"],
      "Resource": "arn:aws:s3:::<BUCKET-NAME>*"
    },
    {
      "Sid": "VeleroListBucket",
      "Effect": "Allow",
      "Principal": {"AWS": "*"},
      "Action": "s3:ListBucket",
      "Resource": "arn:aws:s3:::<BUCKET-NAME>"
    }]
  }
  ```
   
  j. Save changes → Done!

Your Velero-ready S3 bucket is complete. Ready for Velero BackupStorageLocation configuration.

### Through AWS CLI

  a. Create bucket in AWS region

  ```bash
  aws s3api create-bucket \
    --bucket <Bucket Name> \
    --region <Bucket Region>
  ```

  b. Enable public access block:

  ```bash
  aws s3api put-public-access-block \
    --bucket <Bucket Name> \
    --public-access-block-configuration \
    "BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true"
  ```

  c. Enable versioning:

  ```bash
  aws s3api put-bucket-versioning \
    --bucket <Bucket Name> \
    --versioning-configuration Status=Enabled
  ```

  d. Enable bucket policy for Velero

  ```json
  cat > bucket-policy.json <<EOF
  {
    "Version": "2012-10-17",
    "Statement": [{
        "Sid": "VeleroBucketPolicy",
        "Effect": "Allow",
        "Principal": {"AWS": "*"},
        "Action": ["s3:GetObject", "s3:DeleteObject", "s3:PutObject", "s3:AbortMultipartUpload", "s3:ListMultipartUploadParts"],
        "Resource": "arn:aws:s3:::<Bucket Name>/*"
    }, 
    {
        "Sid": "VeleroListBucket",
        "Effect": "Allow", 
        "Principal": {"AWS": "*"},
        "Action": "s3:ListBucket",
        "Resource": "arn:aws:s3:::<Bucket Name>"
    }]
  }
  EOF
  ```

  ```bash
  aws s3api put-bucket-policy \
    --bucket <Bucket Name> \
    --policy file://bucket-policy.json
  ```

---

## Step 2: IAM Policy (Velero)
### Create IAM Policy #1 (Velero EC2/S3 Permissions)

  a. Login to AWS Console → IAM → Policies → Create policy
    
  b. JSON tab → Paste below shared policy

  ```json
  {
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "ec2:DescribeVolumes",
                "ec2:DescribeSnapshots",
                "ec2:CreateTags",
                "ec2:CreateVolume",
                "ec2:CreateSnapshot",
                "ec2:DeleteSnapshot"
            ],
            "Resource": "*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "s3:GetObject",
                "s3:DeleteObject",
                "s3:PutObject",
                "s3:AbortMultipartUpload",
                "s3:ListMultipartUploadParts"
            ],
            "Resource": [
                "arn:aws:s3:::<Bucket Name>/*"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "s3:ListBucket"
            ],
            "Resource": [
                "arn:aws:s3:::<Bucket Name>"
            ]
        }
    ]
  }
  ```

  b. Next → Name: Policy Name(Velero EC2/S3 Permissions i.e., HCLSW_AWS_AMBER_EKS_VELERO_SVC_POLICY) → Create policy

### Create IAM Policy #2 (Assume Role Policy)

  a. Login to AWS Console → IAM → Policies → Create policy

  b. JSON tab → Paste below shared policy

  ```json
  {
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "AllowSvcUsertoDescEC2Roles",
            "Effect": "Allow",
            "Action": [
                "ec2:Describe*",
                "iam:ListRoles"
            ],
            "Resource": "*"
        },
        {
            "Sid": "AllowSvcUser2assumeEKSRole",
            "Effect": "Allow",
            "Action": "sts:AssumeRole",
            "Resource": "arn:aws:iam::<Account ID>:role/<Role Name i.e, HCLSW_AWS_AMBER_EKS_VELERO_BACKUP_SVC_ROLE>"
        }
    ]
  }
  ```

  c. Next → Name: Policy Name(Velero Assume Role Policy i.e., HCLSW_AWS_AMBER_EKS_VELERO_BACKUP_SVC_ROLE_ASSUME_POLICY) → Create policy

---

## Step 3: Create IAM Role

  a. IAM → Roles → Create role

  b. Trusted entity → "Another AWS account" → Account ID: *************

  c. Permissions → Attach policies:

      (Policy Name : Velero EC2/S3 Permissions i.e., HCLSW_AWS_AMBER_EKS_VELERO_SVC_POLICY)

  d. Name: Role Name (IAM Role Name i.e., HCLSW_AWS_AMBER_EKS_VELERO_BACKUP_SVC_ROLE)

  e. Role ARN: arn:aws:iam::<Account ID>:role/<Role Name i.e, HCLSW_AWS_AMBER_EKS_VELERO_BACKUP_SVC_ROLE>

  f. Create role

---

## Step 4: Create IAM User

  a. IAM → Users → Create user

  b. Permissions → Attach policies:

    (Policy Name : Assume Role Policy i.e., HCLSW_AWS_AMBER_EKS_VELERO_BACKUP_SVC_ROLE_ASSUME_POLICY)

  c. Access: Programmatic access

  d. Name: User Name (IAM User Name i.e., HCLSW-AMBER-EKS-VELERO-SVC-USR)

  e. Create User

---

## Step 5: Create Kubernetes Secret

Use the secret_gen.sh script to create the Kubernetes secret.

  ```bash
  sh hcl-devopsplan-prod/files/secret_gen.sh
  ```

After running the Script, it will prompt for below shared details and follow the instructions

  ```bash
  Namespace: <Namespace where installing velero i.e., backup>
  AWS Access Key ID: <AWS Access Key ID>
  AWS Secret Access Key: <AWS Secret Access Key>
  Role ARN: <AWS Role ARN i.e., arn:aws:iam::<Account ID>:role/<Role Name i.e, HCLSW_AWS_AMBER_EKS_VELERO_BACKUP_SVC_ROLE>
  ```

---

## Step 6: Modify the values file i.e., values-s3bucket.yaml at path (hcl-devopsplan-prod/values-s3bucket.yaml)

```yaml
velero:
  bucket: "<Bucket Name>"
  region: "<Bucket Region i.e., us-east-1>"
  configuration:
    uploaderType: "kopia"

  initContainers:
    - name: velero-plugin-for-aws
      image: velero/velero-plugin-for-aws:v1.9.1
      volumeMounts:
        - mountPath: /target
          name: plugins

  credentials:
    existingSecret: credentials-velero

  awsAccessKeyId: "<Access key ID>"
  awsSecretAccessKey: "<Secret access key>"
  roleARN: "<Role ARN of the Role>"


  minioEnabled: false

backupRestore:
  minio:
    enabled: false
```

---

## Step 7: Install Velero

```bash
helm upgrade --install backup ./hcl-devopsplan-prod \
  -f hcl-devopsplan-prod/values-backup.yaml \
  -f hcl-devopsplan-prod/values-s3bucket.yaml \
  --set global.imagePullSecrets={hcl-entitlement-key} \
  -n backup
```

---

## Step 8: Verify the installation

To verify installation, run the following command:

```bash
kubectl get pods -n backup
velero backup-location get -n backup
```

---
