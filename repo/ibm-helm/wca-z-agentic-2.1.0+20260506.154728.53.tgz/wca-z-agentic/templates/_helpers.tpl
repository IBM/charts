{{/*
Create a comma-separated list of namespaces to watch
*/}}
{{- define "namespaceScope" -}}
{{- $watchNamespaces := .Values.global.tetheredNamespaces | default list -}}
{{- if .Values.global.instanceNamespace -}}
{{- $watchNamespaces = append $watchNamespaces .Values.global.instanceNamespace -}}
{{- end -}}
{{- $watchNamespaces = prepend $watchNamespaces .Values.global.operatorNamespace -}}
{{- uniq $watchNamespaces | join "," -}}
{{- end -}}