

{{- define "ibm-mq-agent.image" -}}
{{- if .Values.agent.deployment.tag -}}
{{ default "cp.icr.io" .Values.privateRegistry }}/{{ .Values.agent.deployment.repository }}:{{ .Values.agent.deployment.tag }}
{{- else if .Values.agent.deployment.sha -}}
{{ default "cp.icr.io" .Values.privateRegistry }}/{{ .Values.agent.deployment.repository }}@{{ .Values.agent.deployment.sha }}
{{- else -}}
{{ required "agent.deployment.tag or agent.deployment.sha must be set" "" }}
{{- end -}}
{{- end -}}

{{- define "ibm-mq-mcpServer.image" -}}
{{- if .Values.mcpServer.deployment.tag -}}
{{ default "cp.icr.io" .Values.privateRegistry }}/{{ .Values.mcpServer.deployment.repository }}:{{ .Values.mcpServer.deployment.tag }}
{{- else if .Values.mcpServer.deployment.sha -}}
{{ default "cp.icr.io" .Values.privateRegistry }}/{{ .Values.mcpServer.deployment.repository }}@{{ .Values.mcpServer.deployment.sha }}
{{- else -}}
{{ required "mcpServer.deployment.tag or mcpServer.deployment.sha must be set" "" }}
{{- end -}}
{{- end -}}

{{- define "ibm-mq-embeddingService.image" -}}
{{- if .Values.embeddingService.deployment.tag -}}
{{ default "cp.icr.io" .Values.privateRegistry }}/{{ .Values.embeddingService.deployment.repository }}:{{ .Values.embeddingService.deployment.tag }}
{{- else if .Values.embeddingService.deployment.sha -}}
{{ default "cp.icr.io" .Values.privateRegistry }}/{{ .Values.embeddingService.deployment.repository }}@{{ .Values.embeddingService.deployment.sha }}
{{- else -}}
{{ required "embeddingService.deployment.tag or embeddingService.deployment.sha must be set" "" }}
{{- end -}}
{{- end -}}

{{- define "ibm-mq-agent.service.name" -}}
ibm-mq-agent-{{ .Release.Name }}
{{- end -}}

{{- define "ibm-mq-agent.port" -}}
8001
{{- end -}}

{{- define "ibm-mq-agent.selectorLabels" -}}
app.kubernetes.io/name: "ibm-mq-agent"
app.kubernetes.io/instance: "{{ .Release.Name }}"
app.kubernetes.io/managed-by: "Helm"
app.kubernetes.io/component: integration
{{- end -}}

{{- define "ibm-mq-agent.labels" -}}
{{- include "ibm-mq-agent.selectorLabels" . }}
app.kubernetes.io/version: "{{ .Chart.Version | replace "+" "_" }}"
{{- end -}}

{{- define "mq-agent.providers.validProviders" }}
- watsonxService
- vllmService
{{- end -}}

{{- define "mq-agent.provider.defaultProvider.uri" }}
{{- (get .Values.agent.model.providers .Values.agent.model.defaultProvider).uri -}}
{{- end }}

{{- define "mq-agent.resolveRoleProvider" -}}
{{- /* Resolves which provider a role uses (role.provider or defaultProvider) */ -}}
{{- /* Usage: include "mq-agent.resolveRoleProvider" (dict "role" .Values.agent.model.roles.primaryLLM "defaultProvider" .Values.agent.model.defaultProvider) */ -}}
{{- if .role.provider -}}
{{- .role.provider -}}
{{- else -}}
{{- .defaultProvider -}}
{{- end -}}
{{- end -}}

{{- define "mq-agent.providers.getUsedProviders" -}}
{{- /*
Builds a dictionary of providers that are actually used by roles.
Returns a dict where keys are provider names and values are true.

Usage:
  {{- $usedProviders := include "mq-agent.providers.getUsedProviders" . | fromJson }}
*/ -}}
{{- $usedProviders := dict }}
{{- $defaultProvider := .Values.agent.model.defaultProvider }}
{{- $_ := set $usedProviders $defaultProvider true }}

{{- /* Add primaryLLM provider (always enabled) */ -}}
{{- $primaryLLM := .Values.agent.model.roles.primaryLLM }}
{{- if $primaryLLM.provider }}
  {{- $_ := set $usedProviders $primaryLLM.provider true }}
{{- end }}

{{- /* Add secondaryLLM provider (only if enabled) */ -}}
{{- if .Values.agent.model.roles.secondaryLLM }}
  {{- $secondaryLLM := .Values.agent.model.roles.secondaryLLM }}
  {{- $isEnabled := true }}
  {{- if hasKey $secondaryLLM "enabled" }}
    {{- $isEnabled = $secondaryLLM.enabled }}
  {{- end }}
  {{- if and $isEnabled $secondaryLLM.provider }}
    {{- $_ := set $usedProviders $secondaryLLM.provider true }}
  {{- end }}
{{- end }}

{{- $usedProviders | toJson -}}
{{- end -}}

{{- define "mq-agent.providers.validateProviderConfig" -}}
{{- /*
Validates the provider configuration structure in values.yaml.

This function ensures that:
1. The agent.model configuration exists and is properly structured
2. A defaultProvider is specified and references a valid provider
3. Required role (primaryLLM) is configured
4. Each role has a valid modelId

Note: Embeddings are provided by the local embedding service sidecar container,
not through the provider configuration.

Expected structure in values.yaml:
  agent:
    model:
      defaultProvider: "myWatsonX"  # Must reference a key in providers
      providers:
        myWatsonX:
          type: "watsonxService"
          uri: "https://us-south.ml.cloud.ibm.com"
          watsonxService:
            key: "..."
            projectID: "..."
      roles:
        primaryLLM:
          modelId: "ibm/granite-4-h-small"
          provider: "myWatsonX"  # Optional, uses defaultProvider if not set
        secondaryLLM:  # Optional
          modelId: "openai/gpt-oss-120b"
          enabled: true

Validation failures will cause helm install/upgrade to fail with error messages.
*/ -}}

{{- /* Validate agent.model exists */ -}}
{{- if not .Values.agent }}
  {{- fail "agent configuration is required but not set" }}
{{- end }}
{{- if not .Values.agent.model }}
  {{- fail "agent.model configuration is required but not set" }}
{{- end }}

{{- /* Validate defaultProvider exists and references a valid provider */ -}}
{{- if not (hasKey .Values.agent.model "defaultProvider") }}
  {{- fail "agent.model.defaultProvider is required but not set" }}
{{- end }}
{{- $defaultProvider := .Values.agent.model.defaultProvider }}
{{- if not $defaultProvider }}
  {{- fail "agent.model.defaultProvider is required but not set" }}
{{- end }}
{{- if not .Values.agent.model.providers }}
  {{- fail "agent.model.providers is required but not set" }}
{{- end }}
{{- if not (hasKey .Values.agent.model.providers $defaultProvider) }}
  {{- fail (printf "agent.model.defaultProvider '%s' does not reference a valid provider in agent.model.providers" $defaultProvider) }}
{{- end }}

{{- /* Validate required roles exist */ -}}
{{- if not (hasKey .Values.agent.model "roles") }}
  {{- fail "agent.model.roles is required but not set" }}
{{- end }}
{{- if not .Values.agent.model.roles }}
  {{- fail "agent.model.roles is required but not set" }}
{{- end }}
{{- if not (hasKey .Values.agent.model.roles "primaryLLM") }}
  {{- fail "agent.model.roles.primaryLLM is required but not set" }}
{{- end }}
{{- if not .Values.agent.model.roles.primaryLLM }}
  {{- fail "agent.model.roles.primaryLLM is required but not set" }}
{{- end }}

{{- /* Validate primaryLLM role (required, always enabled) */ -}}
{{- $primaryLLM := .Values.agent.model.roles.primaryLLM }}
{{- if not $primaryLLM.modelId }}
  {{- fail "agent.model.roles.primaryLLM.modelId is required but not set" }}
{{- end }}
{{- if hasKey $primaryLLM "enabled" }}
  {{- fail "agent.model.roles.primaryLLM cannot have 'enabled' field (it is always enabled)" }}
{{- end }}
{{- if $primaryLLM.provider }}
  {{- if not (hasKey .Values.agent.model.providers $primaryLLM.provider) }}
    {{- fail (printf "agent.model.roles.primaryLLM.provider '%s' does not reference a valid provider in agent.model.providers" $primaryLLM.provider) }}
  {{- end }}
{{- end }}

{{- /* Validate secondaryLLM role (optional, may be disabled) */ -}}
{{- if .Values.agent.model.roles.secondaryLLM }}
  {{- $secondaryLLM := .Values.agent.model.roles.secondaryLLM }}
  {{- $isEnabled := true }}
  {{- if hasKey $secondaryLLM "enabled" }}
    {{- $isEnabled = $secondaryLLM.enabled }}
  {{- end }}
  {{- if $isEnabled }}
    {{- if not $secondaryLLM.modelId }}
      {{- fail "agent.model.roles.secondaryLLM.modelId is required when secondaryLLM is enabled" }}
    {{- end }}
  {{- end }}
  {{- if $secondaryLLM.provider }}
    {{- if not (hasKey .Values.agent.model.providers $secondaryLLM.provider) }}
      {{- fail (printf "agent.model.roles.secondaryLLM.provider '%s' does not reference a valid provider in agent.model.providers" $secondaryLLM.provider) }}
    {{- end }}
  {{- end }}
{{- end }}

{{- /* Build list of providers that are actually used */ -}}
{{- $usedProviders := include "mq-agent.providers.getUsedProviders" . | fromJson }}

{{- /* Validate providers that are actually used */ -}}
{{- range $name, $provider := .Values.agent.model.providers }}
{{- if hasKey $usedProviders $name }}
  {{- /* Validate URI is present for all providers */ -}}
  {{- if not $provider.uri }}
    {{- fail (printf "Provider '%s' is missing required field 'uri'" $name) }}
  {{- end }}
  
  {{- if eq $provider.type "watsonxService" }}
    {{- if not $provider.watsonxService }}
      {{- fail (printf "Provider '%s' has type 'watsonxService' but no watsonxService configuration" $name) }}
    {{- end }}
    {{- if not $provider.watsonxService.projectID }}
      {{- fail (printf "Provider '%s' (watsonxService) is missing required field 'projectID'" $name) }}
    {{- end }}
    {{- if not $provider.watsonxService.key }}
      {{- fail (printf "Provider '%s' (watsonxService) is missing required field 'key'" $name) }}
    {{- end }}
  {{- else if eq $provider.type "vllmService" }}
    {{- if not $provider.vllmService }}
      {{- fail (printf "Provider '%s' has type 'vllmService' but no vllmService configuration" $name) }}
    {{- end }}
    {{- if not $provider.vllmService.key }}
      {{- $_ := printf "WARNING: Provider '%s' (vllmService) has no API key configured." $name | print }}
    {{- end }}
  {{- end }}
{{- end }}
{{- end }}
{{- end -}}

{{/*
Extract comma separated CIDR ip string from list 
*/}}

