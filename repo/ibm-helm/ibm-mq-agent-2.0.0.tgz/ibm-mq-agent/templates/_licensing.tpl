{{/*
  other valid licenses in future can be added here 
*/}}

{{- define "mq-agent.license.validLicenses" }}
- L-CXDB-XTZ9J8
- L-VEMB-RABZSN
- L-UHEB-WGGTYF
{{- end }}