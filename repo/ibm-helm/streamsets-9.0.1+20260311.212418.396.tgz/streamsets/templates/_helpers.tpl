{{/*
cpd-cli install-components requires you to supply operator/instance namespace flags,
but the tech spec requires us to be GitOps compliant, so this validation ensures that
we fail fast when install is driven by ArgoCD/Helm and namespaces are not supplied
*/}}
{{- define "streamsets.validate" -}}
{{- $opns := required "global.operatorNamespace is required" .Values.global.operatorNamespace -}}
{{- $instns := required "global.instanceNamespace is required" .Values.global.instanceNamespace -}}
{{- end -}}

{{- define "streamsets.operatorRegistry" -}}
{{- .Values.global.imagePullPrefix -}}
{{- end -}}

{{- define "streamsets.operandRegistry" -}}
{{- if .Values.streamsets.operandImagePullPrefix -}}
{{- .Values.streamsets.operandImagePullPrefix -}}
{{- else if eq .Values.global.imagePullPrefix "icr.io" -}}
cp.icr.io
{{- else -}}
{{- .Values.global.imagePullPrefix -}}
{{- end -}}
{{- end -}}

{{- define "streamsets.operatorImage" -}}
{{- $arch := required "global.arch is required" .Values.global.arch -}}
{{- $digest := index .Values.streamsets.operatorImageDigest $arch -}}
{{- if not $digest -}}
{{- fail (printf "Missing streamsets.operatorImageDigest.%s" $arch) -}}
{{- end -}}
{{- printf "%s/%s@%s" .Values.global.imagePullPrefix .Values.streamsets.operatorImageName $digest -}}
{{- end -}}

{{- define "streamsets.watchNamespaces" -}}
{{- $op := .Values.global.operatorNamespace -}}
{{- $inst := .Values.global.instanceNamespace -}}
{{- $t := .Values.global.tetheredNamespaces | default (list) -}}
{{- $ns := concat (list $op $inst) $t | compact | uniq -}}
{{- toYaml $ns -}}
{{- end -}}
