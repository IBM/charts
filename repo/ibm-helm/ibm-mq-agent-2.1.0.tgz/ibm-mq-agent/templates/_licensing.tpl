{{/*
  other valid licenses in future can be added here 
*/}}

{{- define "mq-agent.license.validLicenses" }}
- L-CXDB-XTZ9J8
- L-DPTV-SYNAFJ
- L-VCNK-GTT2F3
- L-HRAV-KRAE8U
{{- end }}