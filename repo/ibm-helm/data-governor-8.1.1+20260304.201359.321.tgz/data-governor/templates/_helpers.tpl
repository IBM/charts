{{/*
Build a consolidated list of target namespaces.
Combines tetheredNamespaces, instanceNamespace (if present), and operatorNamespace.
Returns a list with operatorNamespace first, followed by instanceNamespace (if present),
then tetheredNamespaces.
Usage:
  {{- $namespaces := include "data-governor.targetNamespaces" . | mustFromJson -}}
*/}}
{{- define "data-governor.targetNamespaces" -}}
{{- $targetNamespaces := .Values.global.tetheredNamespaces | default list -}}
{{- if .Values.global.instanceNamespace -}}
{{- $targetNamespaces = append $targetNamespaces .Values.global.instanceNamespace -}}
{{- end -}}
{{- $targetNamespaces = prepend $targetNamespaces .Values.global.operatorNamespace -}}
{{- toJson $targetNamespaces -}}
{{- end -}}