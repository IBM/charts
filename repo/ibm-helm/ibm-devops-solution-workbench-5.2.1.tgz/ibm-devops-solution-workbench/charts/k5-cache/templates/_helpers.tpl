{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "k5-cache.name" -}}
{{- default "k5-cache" .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Build the name of the stateful set, depending on HA is enabled or not
*/}}
{{- define "k5-cache.statfulset.name" -}}
{{- if .Values.cache.ha.enabled }}
{{- default "k5-cache-cluster" .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{ else }}
{{- default "k5-cache" .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{/*
Build the name of ca cert config map
*/}}
{{- define "k5-cache-ca-configmap.name" -}}
{{ include "k5-cache.name" . }}-ca-configmap
{{- end -}}

{{/*
Build the name of service
*/}}
{{- define "k5-cache-service.name" -}}
{{ include "k5-cache.name" . }}-service
{{- end -}}

{{/*
Build the name of headless service
*/}}
{{- define "k5-cache-headless-service.name" -}}
{{ include "k5-cache.name" . }}-headless-service
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
*/}}
{{- define "k5-cache.fullname" -}}
{{- $name := .Chart.Name -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create the name of service cert secret.
*/}}
{{- define "k5-cache.service-cert.name" -}}
{{- $name := .Chart.Name -}}
{{- printf "%s-service-cert" $name | quote -}}
{{- end -}}

{{/*
Build additional global route annotations
*/}}
{{- define "k5-cache.roots.annotations" -}}
{{- if .Values.global.k5.routes.annotations -}}
{{ tpl (toYaml .Values.global.k5.routes.annotations)  . }}
{{- end -}}
{{- end -}}

{{/*
Build an image from given values
*/}}
{{- define "k5-cache.image.builder" -}}
{{- $registry := .values.global.image.registry -}}
{{- $repository := .image.repository -}}
{{ if .values.global.imageRegistry }}
{{- $registry = .values.global.imageRegistry -}}
{{- $repository = printf "%s-%s" .values.global.image.prefix .image.repository -}}
{{- else if  .values.global.image.privateRegistry }}
{{- $registry = .values.global.image.privateRegistry -}}
{{- $repository = printf "%s-%s" .values.global.image.prefix .image.repository -}}
{{- end -}}
{{ if .image.digest }}
{{- printf "%s/%s@%s" $registry $repository .image.digest -}}
{{ else }}
{{- printf "%s/%s:%s" $registry $repository .image.tag -}}
{{- end -}}
{{- end -}}


{{/*
Build a list of allowed domains as a comma separated string - supports global and project specific allowedDomains
*/}}
{{- define "k5-cache.cors-allowed-domains.builder" -}}
{{- range $DOMAIN := .Values.global.k5.cors.allowedDomains -}}
{{ tpl $DOMAIN $ }}{{- printf "," }}
{{- end -}}
{{- if ((.Values.cors).allowedDomains) -}}
{{- range $DOMAIN := .Values.cors.allowedDomains -}}
{{ tpl $DOMAIN $ }}{{- printf "," }}
{{- end -}}
{{- end -}}
{{- end -}}


{{/*
Build the replica count:
  HA enabled: 6 (3 master / 3 slave nodes)
  HA disabled: 1 (only one single instance)
*/}}
{{- define "k5-cache.replicas" -}}
{{- if .Values.cache.ha.enabled }}6{{ else }}1{{- end -}}
{{- end -}}

{{- define "k5-cache.http.scheme.upperCase" -}}
{{- if (.Capabilities.APIVersions.Has "getambassador.io/v2") }}
{{- printf "HTTP" }}
{{- else }}
{{- printf "HTTPS" }}
{{- end }}
{{- end }}

{{- define "k5-cache.http.scheme" -}}
{{- if (.Capabilities.APIVersions.Has "getambassador.io/v2") }}
{{- printf "http" }}
{{- else }}
{{- printf "https" }}
{{- end }}
{{- end }}
