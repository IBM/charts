{{/*
Label stack used for labelling.
*/}}
{{- define "k5-cache.labels" -}}
app.kubernetes.io/version: {{ .Chart.AppVersion }}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version | replace "+" "_" }}
app.kubernetes.io/part-of: k5-designer
{{ template "k5-cache.matchLabels" . }}
{{- end -}}

{{- define "k5-cache.matchLabels" -}}
app.kubernetes.io/name: {{ template "k5-cache.fullname" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: {{ .Chart.Name }}
{{- end -}}
