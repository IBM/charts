{{- define "k5-cache.global.pod.annotations" }}
{{/*set via servicebuilder chart*/}}
{{- if .Values.global.k5.pod }}
{{- if .Values.global.k5.pod.annotations }}
{{- range $k, $v := .Values.global.k5.pod.annotations }}
{{- printf "\n%s: " $k -}}{{- printf "%s" $v | quote -}}
{{- end }}
{{- end }}
{{- end }}
{{- end -}}

{{- define "k5-cache.global.pod.labels" }}
{{/*set via servicebuilder chart*/}}
{{- if .Values.global.k5.pod }}
{{- if .Values.global.k5.pod.labels }}
{{- range $k, $v := .Values.global.k5.pod.labels }}
{{- printf "\n%s: " $k -}}{{- printf "%s" $v | quote -}}
{{- end }}
{{- end }}
{{- end }}
{{- end -}}
