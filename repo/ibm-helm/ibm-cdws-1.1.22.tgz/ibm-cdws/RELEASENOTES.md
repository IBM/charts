# Prerequisites

Please refer prerequisites section from [README.md](README.md)

# Documentation

Please refer to [README.md](README.md) provided with chart for detailed installation instruction.

# Version History

| Chart  | Date         | Kubernetes Required | OpenShift Required       | Image(s) Supported                                    | Details            |
| -----  | ------------ | ------------------- | ------------------------ | ----------------------------------------------------- | ------------------ | 
| 1.1.0  | Nov 22, 2024 | >= 1.27.0 < 1.30.0  | >= 4.14 <=4.16           | cdws6.4_certified_container_6.4.0.0:6.4.0.0_ifix000   | CDWS 6.4.0.0       |
| 1.1.1  | Dec 13, 2024 | >= 1.27.0 < 1.31.0  | >= 4.14 <=4.17           | cdws6.4_certified_container_6.4.0.0:6.4.0.0_ifix001   | CDWS 6.4.0.0       |
| 1.1.2  | Jan 09, 2025 | >= 1.27.0 < 1.31.0  | >= 4.14 <=4.17           | cdws6.4_certified_container_6.4.0.0:6.4.0.0_ifix002   | CDWS 6.4.0.0       |
| 1.1.3  | Feb 06, 2025 | >= 1.27.0 < 1.31.0  | >= 4.14 <=4.17           | cdws6.4_certified_container_6.4.0.1:6.4.0.1_ifix000   | CDWS 6.4.0.1       |
| 1.1.4  | Mar 03, 2025 | >= 1.27.0 < 1.32.0  | >= 4.14 <=4.17           | cdws6.4_certified_container_6.4.0.1:6.4.0.1_ifix001   | CDWS 6.4.0.1       |
| 1.1.5  | Mar 28, 2025 | >= 1.27.0 < 1.32.0  | >= 4.14 <=4.17           | cdws6.4_certified_container_6.4.0.2:6.4.0.2_ifix000   | CDWS 6.4.0.2       |
| 1.1.6  | May 22, 2025 | >= 1.27.0 < 1.32.0  | >= 4.14 <=4.17           | cdws6.4_certified_container_6.4.0.2:6.4.0.2_ifix001   | CDWS 6.4.0.2       |
| 1.1.7  | Jun 10, 2025 | >= 1.27.0 < 1.32.0  | >= 4.14 <=4.18           | cdws6.4_certified_container_6.4.0.2:6.4.0.2_ifix002   | CDWS 6.4.0.2       |
| 1.1.9  | Jun 25, 2025 | >= 1.27.0 < 1.32.0  | >= 4.14 <=4.18           | cdws6.4_certified_container_6.4.0.3:6.4.0.3_ifix000   | CDWS 6.4.0.3       |
| 1.1.10 | Jul 15, 2025 | >= 1.27.0 < 1.32.0  | >= 4.14 <=4.18           | cdws6.4_certified_container_6.4.0.3:6.4.0.3_ifix001   | CDWS 6.4.0.3       |
| 1.1.11 | Jul 28, 2025 | >= 1.27.0 < 1.32.0  | >= 4.14 <=4.18           | cdws6.4_certified_container_6.4.0.3:6.4.0.3_ifix002   | CDWS 6.4.0.3       |
| 1.1.12 | Sep 29, 2025 | >= 1.27.0 < 1.33.0  | >= 4.14 <=4.19           | cdws6.4_certified_container_6.4.0.4:6.4.0.4_ifix000   | CDWS 6.4.0.4       |
| 1.1.13 | Sep 30, 2025 | >= 1.27.0 < 1.33.0  | >= 4.14 <=4.19           | cdws6.4_certified_container_6.4.0.4:6.4.0.4_ifix001   | CDWS 6.4.0.4       |
| 1.1.14 | Dec 08, 2025 | >= 1.27.0 < 1.34.0  | >= 4.14 <=4.19           | cdws:6.4.0.5_iFix00-2025-11-27                        | CDWS 6.4.0.5       |
| 1.1.15 | Feb 06, 2026 | >= 1.27.0 < 1.34.0  | >= 4.14 <=4.19           | cdws:6.4.0.6_iFix00-2026-02-06                        | CDWS 6.4.0.6       |
| 1.1.16 | Apr 09, 2026 | >= 1.27.0 < 1.34.0  | >= 4.14 <=4.19           | cdws:6.4.0.7_iFix00-2026-04-09                        | CDWS 6.4.0.7       |
| 1.1.17 | May 29, 2026 | >= 1.27.0           | >= 4.14 <=4.19           | cdws:6.4.0.8_iFix00-2026-05-22                        | CDWS 6.4.0.8       |
| 1.1.18 | Jun 22, 2026 | >= 1.27.0           | >= 4.14 <=4.19           | cdws:6.4.0.8_iFix01-2026-06-22                        | CDWS 6.4.0.8       |
| 1.1.19 | Jul 13, 2026 | >= 1.27.0           | >= 4.14 <=4.19           | cdws:6.4.0.9_iFix00-2026-07-10                        | CDWS 6.4.0.9       |
| 1.1.20 | Jul 21, 2026 | >= 1.27.0           | >= 4.14 <=4.19           | cdws:6.4.0.9_iFix00-2026-07-10                        | CDWS 6.4.0.9       |
| 1.1.21 | Jul 29, 2026 | >= 1.27.0           | >= 4.14 <=4.19           | cdws:6.4.0.9_iFix01-2026-07-29                        | CDWS 6.4.0.9       |
| 1.1.22 | Aug 21, 2026 | >= 1.27.0           | >= 4.14 <=4.19           | cdws:6.4.0.10_iFix00-2026-08-20                       | CDWS 6.4.0.10      |


`Note: The images listed here are minimum supported container image for the respective helm chart version.`
