{{/*
Expand the name of the chart.
*/}}
{{- define "ibm-process-mining.name" -}}
{{- default .Release.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "ibm-process-mining.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "ibm-process-mining.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "ibm-process-mining.labels" -}}
helm.sh/chart: {{ include "ibm-process-mining.chart" . }}
{{ include "ibm-process-mining.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "ibm-process-mining.selectorLabels" -}}
app.kubernetes.io/name: {{ include "ibm-process-mining.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "ibm-process-mining.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "ibm-process-mining.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}


{{/*
Lookup secret value by secret name and key
Usage: {{ include "ibm-process-mining.secretValue" (dict "secretName" "my-secret" "key" "password" "context" .) }}
*/}}
{{- define "ibm-process-mining.secretValue" -}}
{{- $secret := lookup "v1" "Secret" .context.Release.Namespace .secretName -}}
{{- if $secret -}}
{{- index $secret.data .key | b64dec -}}
{{- else -}}
{{- "" -}}
{{- end -}}
{{- end -}}

{{/*
Validate with custom error message
*/}}
{{- define "ibm-process-mining.requiredMsg" -}}
{{- if or (not .value) (eq .value "") -}}
{{- fail .message -}}
{{- end -}}
{{- .value -}}
{{- end -}}

{{/*
Get logback configuration with loglevel replaced
Usage: {{ include "ibm-process-mining.logback" . }}
*/}}
{{- define "ibm-process-mining.logback" -}}
{{- $loglevel := .Values.loglevel | default "INFO" -}}
{{- .Values.logback | replace "{{loglevel}}" $loglevel -}}
{{- end -}}


{{/*
Concatenate image registry with image name from processmining images
Usage: {{ include "ibm-process-mining.image" (dict "imageName" "nginx" "context" .) }}
*/}}
{{- define "ibm-process-mining.image" -}}
{{- $image := index .context.Values.images.processmining .imageName -}}
{{- printf "%s/%s" .context.Values.images.registry $image -}}
{{- end -}}

{{/*
Concatenate image registry with image name from taskmining images
Usage: {{ include "ibm-process-mining.tmimage" (dict "imageName" "nginx" "context" .) }}
*/}}
{{- define "ibm-process-mining.tmimage" -}}
{{- $image := index .context.Values.images.taskmining .imageName -}}
{{- printf "%s/%s" .context.Values.images.registry $image -}}
{{- end -}}

{{/*
Helm annotations
*/}}
{{- define "ibm-process-mining.annotations" -}}
meta.helm.sh/release-name: {{ .Release.Name }}
meta.helm.sh/release-namespace: {{ .Release.Namespace }}
{{- end }}