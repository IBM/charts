{{/* Generate initcontainer */}}
{{- define "ibm-process-mining.initcontainer" }}
        - name: pem-to-keystore
          image: '{{ include "ibm-process-mining.image" (dict "imageName" "ssl" "context" .) }}'
          env:
              - name: keyfile
                value: /var/run/secrets/openshift.io/services_serving_certs/tls.key
              - name: crtfile
                value: /var/run/secrets/openshift.io/services_serving_certs/tls.crt
              - name: keystore_pkcs12
                value: /var/run/secrets/java.io/keystores/keystore.pkcs12
              - name: keystore_jks
                value: /var/run/secrets/java.io/keystores/keystore.jks
              - name: password
                value: changeit
          command: ['/bin/bash']
          args: ['-c', "openssl pkcs12 -export -inkey $keyfile -in $crtfile -out $keystore_pkcs12 -password pass:$password  &&  keytool -importkeystore -noprompt -srckeystore $keystore_pkcs12 -srcstoretype pkcs12 -destkeystore $keystore_jks -storepass $password -srcstorepass $password "]
          volumeMounts:
              - name: keystore-volume
                mountPath: /var/run/secrets/java.io/keystores
              - name: service-certs
                mountPath: /var/run/secrets/openshift.io/services_serving_certs
          securityContext:
              privileged: false
              readOnlyRootFilesystem: false
              runAsNonRoot: true
              capabilities:
                drop:
                - ALL
          resources:
              requests:
                cpu: 100m 
                memory: 200Mi
                ephemeral-storage: '{{ .Values.secretstore_default.storage.ephemeral.request }}'  
              limits:
                cpu: 500m 
                memory: 1Gi
                ephemeral-storage: '{{ .Values.secretstore_default.storage.ephemeral.limit }}' 
          ########################################################
          # for backend invocation
          ########################################################
        - name: pem-to-truststore
          image: '{{ include "ibm-process-mining.image" (dict "imageName" "ssl" "context" .) }}'
          env:
              - name: ca_bundle
                value: /var/run/secrets/kubernetes.io/serviceaccount/service-ca.crt
              - name: truststore_jks
                value: /var/run/secrets/java.io/keystores/truststore.jks
              - name: kubernetes_api_ca_bundle
                value: /var/run/secrets/kubernetes.io/serviceaccount/ca.crt
              - name: password
                value: changeit    
          command: ['/bin/bash']
          args: ['-c', "if [ -f /usr/lib/jvm/ibm-semeru-open-17-jdk/lib/security/cacerts ]; then cp /usr/lib/jvm/ibm-semeru-open-17-jdk/lib/security/cacerts $truststore_jks ;  fi && csplit -z -f crt- $ca_bundle '/-----BEGIN CERTIFICATE-----/' '{*}' && for file in crt-*; do keytool -import -noprompt -keystore $truststore_jks -file $file -storepass changeit -alias service-$file; done && csplit -z -f crtkca- $kubernetes_api_ca_bundle '/-----BEGIN CERTIFICATE-----/' '{*}' && for file in crtkca-*; do keytool -import -noprompt -keystore $truststore_jks -file $file -storepass changeit -alias kca-$file; done"]
          volumeMounts:
              - name: keystore-volume
                mountPath: /var/run/secrets/java.io/keystores
          securityContext:
              privileged: false
              readOnlyRootFilesystem: false
              runAsNonRoot: true
              capabilities:
                drop:
                - ALL
          resources:
              requests:
                cpu: 100m 
                memory: 200Mi
                ephemeral-storage: '{{ .Values.secretstore_default.storage.ephemeral.request }}'  
              limits:
                cpu: 500m 
                memory: 1Gi
                ephemeral-storage: '{{ .Values.secretstore_default.storage.ephemeral.limit }}' 
{{- end }}