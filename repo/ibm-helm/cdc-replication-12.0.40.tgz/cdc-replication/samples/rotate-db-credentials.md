# Rotate database credentials for a running CDC instance

Credential rotation is a `kubectl` operation — no Helm values change is required.
The CDC pod reads credentials from the Kubernetes Secret at startup. To apply
new credentials, update the secret and restart the pod.

## Steps

### 1. Update the secret with the new credentials

```bash
cat <<EOF | kubectl apply -f -
apiVersion: v1
kind: Secret
metadata:
  name: <secret-name>        # default: cdc-credentials
  namespace: <namespace>
type: Opaque
stringData:
  dbUsername: <new-username>
  dbPassword: <new-password>
EOF
```

### 2. Restart the CDC pod to pick up the new credentials

```bash
kubectl rollout restart statefulset/<release-name> --namespace <namespace>
```

### 3. Verify the pod restarts successfully

```bash
kubectl get pods --namespace <namespace> -w
```

> **Note:** The CDC engine reconnects to the database on startup using the credentials
> from the secret. No subscription state is lost during a credential rotation —
> replication resumes from the last committed bookmark.
