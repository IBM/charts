#!/usr/bin/env bash
# mirror-images.sh — copy CDC images to a private or air-gapped registry.
#
# Usage:
#   ./mirror-images.sh <your-registry-prefix>
#
# Example:
#   ./mirror-images.sh registry.example.com/cdc
#
# Prerequisites:
#   - skopeo installed and available on PATH
#   - Logged in to both registries:
#       skopeo login cp.icr.io
#       skopeo login <your-registry>
#
# This script reads mirror-images.txt (in the same directory) and copies each
# image to the target registry using skopeo copy --all. Using skopeo instead
# of docker pull/push preserves the image digest — required for digest-pinned
# deployments.

set -euo pipefail

if [ $# -ne 1 ]; then
  echo "Usage: $0 <target-registry-prefix>" >&2
  echo "Example: $0 registry.example.com/cdc" >&2
  exit 1
fi

TARGET_PREFIX="${1%/}"   # strip trailing slash if present
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
IMAGE_LIST="${SCRIPT_DIR}/mirror-images.txt"

if [ ! -f "${IMAGE_LIST}" ]; then
  echo "ERROR: mirror-images.txt not found at ${IMAGE_LIST}" >&2
  exit 1
fi

count=0
while IFS= read -r line; do
  # Skip blank lines and comment lines
  [[ -z "${line}" || "${line}" == \#* ]] && continue

  # Extract image name+tag from the source reference (strip registry prefix)
  # Source format: cp.icr.io/cp/data-replication/<name>:<tag>@sha256:<digest>
  image_with_tag=$(echo "${line}" | sed 's|.*data-replication/||' | cut -d@ -f1)
  target="${TARGET_PREFIX}/${image_with_tag}"

  echo "Copying: ${line}"
  echo "     To: ${target}"
  skopeo copy --all "docker://${line}" "docker://${target}"
  count=$((count + 1))
done < "${IMAGE_LIST}"

echo ""
echo "Done. Mirrored ${count} image(s) to ${TARGET_PREFIX}."
