# Upgrading to a new chart version

The new chart version already contains the correct image digest for this release — no manual
image tag or digest override is needed.

## Steps

1. Download and untar the new chart:

   ```bash
   tar -xzf cdc-replication-<new-version>.tgz
   ```

2. Run `helm upgrade` with your existing values file:

   ```bash
   helm upgrade --install <release-name> ./cdc-replication \
     -f my-values.yaml \
     --namespace <namespace>
   ```

> **Important:** Always pass your values file explicitly with `-f`. Running `helm upgrade`
> without `-f` resets all values to the chart defaults, overwriting your `productType`,
> instance configuration, and other settings.
