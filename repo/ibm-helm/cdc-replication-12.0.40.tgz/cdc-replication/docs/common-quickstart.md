# CDC Helm Chart — Common Quickstart

This guide covers the setup steps common to all CDC engine deployments. Before following a
product-specific quickstart, complete the steps in this guide.

## Table of Contents

1. [Prerequisites](#1-prerequisites)
2. [Understanding the Helm deployment model](#2-understanding-the-helm-deployment-model)
3. [CDC metadata schema and `overrideTargetTables`](#3-cdc-metadata-schema-and-overridetargettables)
4. [Create a namespace](#4-create-a-namespace)
5. [Create the IBM Entitlement Key pull secret](#5-create-the-ibm-entitlement-key-pull-secret)
6. [Using a private or air-gapped registry](#6-using-a-private-or-air-gapped-registry)
7. [Exposing the CDC service for external access](#7-exposing-the-cdc-service-for-external-access)
8. [Verify a deployment](#8-verify-a-deployment)
9. [Upgrade an existing installation](#9-upgrade-an-existing-installation)
10. [Uninstall](#10-uninstall)

---

## 1. Prerequisites

- **Kubernetes or OpenShift cluster:** Kubernetes 1.29 or higher is required (OpenShift 4.16+).
  See the [IBM Data Replication System Requirements](https://www.ibm.com/support/pages/node/608111)
  for the full list of supported platform versions.
- **Helm:** Version 3.0 or higher.
- **kubectl:** Configured to access your cluster.
- **IBM Entitlement Key:** Required for pulling images from the IBM entitled registry.
  Obtain yours from the [IBM Container Library](https://myibm.ibm.com/products-services/containerlibrary).
- **Block storage class:** A `ReadWriteOnce`-capable storage class must be available in the
  cluster. Run `kubectl get storageclass` to list available classes.

---

## 2. Understanding the Helm deployment model

A **Helm release** corresponds to a single **CDC instance**.

| Helm concept | CDC equivalent |
|---|---|
| `helm upgrade --install <release-name>` | Create or reconfigure a CDC instance |
| Release name (e.g. `cdc-udb`) | Instance identity — becomes the pod name (`cdc-udb-0`) |
| `helm upgrade` | Modify a running instance (configuration change or version upgrade) |
| `helm uninstall` | Remove the instance |

> **Note:** `helm uninstall` does **not** delete the PersistentVolumeClaim by default.
> Instance data is preserved. See [Uninstall](#10-uninstall) for how to remove it explicitly.

**Multiple instances:** Deploy multiple Helm releases into the same namespace to run
independent CDC instances side by side. Each release must have a unique release name and a
unique `service.port` to avoid conflicts.

---

## 3. CDC metadata schema and `overrideTargetTables`

Every CDC engine stores internal replication state in a set of metadata tables
(`TS_AUTH`, `TS_BOOKMARK`, `TS_CONFAUD`, `TS_DDLAUD`) inside a database schema you specify
via `instance.dbSchema`. This schema must already exist in the database before deployment —
CDC will not create it.

Each CDC instance must use a **unique schema**. Two instances sharing the same schema will
conflict: whichever starts second will either refuse to start or destroy the first instance's
replication state.

### `overrideTargetTables`

> **Caution:** Leave `instance.overrideTargetTables` at its default value of `false` for
> all standard deployments.
>
> Only set it to `true` when you are deliberately reusing a schema from a previously
> uninstalled CDC instance **and** you accept that all prior replication state in that schema
> will be permanently destroyed. When `true`, CDC drops and recreates its metadata tables on
> startup. Any other CDC instance still pointing at the same schema will immediately fail to
> start.
>
> After the first successful startup with `overrideTargetTables: true`, remove the setting
> from your values file (or set it back to `false`) to protect the new replication state.

---

## 4. Create a namespace

```bash
kubectl create namespace <namespace>
```

All subsequent commands use `--namespace <namespace>` (or `-n <namespace>`). Substitute your
chosen namespace throughout this guide.

---

## 5. Create the IBM Entitlement Key pull secret

> **Note:** Create the pull secret **before** running `helm upgrade --install`. If the pod
> is scheduled before the secret exists it fails with `ImagePullBackOff`.

```bash
kubectl create secret docker-registry ibm-entitlement-key \
  --docker-server=cp.icr.io \
  --docker-username=cp \
  --docker-password=<your-entitlement-key> \
  --namespace <namespace>
```

The chart is configured to use this secret by default. No additional values override is
required.

---

## 6. Using a private or air-gapped registry

Deploying into a network that cannot reach `cp.icr.io` requires two steps: mirror the images
to your private registry, then configure the chart to pull from it.

### Step A — Mirror the images

Use `skopeo copy --all` to mirror images. Do **not** use `docker pull` / `docker push` —
Docker re-encodes layers on push, which changes the digest and breaks digest-pinned
deployments.

The complete image list with exact `tag@sha256:<digest>` references is included in the chart
tarball as `samples/mirror-images.txt`.

Use the provided helper script to mirror all images in one step:

```bash
skopeo login cp.icr.io
skopeo login <your-registry>
samples/mirror-images.sh <your-registry-prefix>
```

The script reads `samples/mirror-images.txt` and runs `skopeo copy --all` for each image.

### Step B — Configure the chart

Add the following to your values override file:

```yaml
common:
  imagePullPrefix: "<your-registry-prefix>"
  # Only needed if your pull secret is not named ibm-entitlement-key
  # imagePullSecrets:
  #   - name: <your-secret-name>
```

---

## 7. Exposing the CDC service for external access

The CDC engine listens on a fixed TCP port **11701** inside the container. This port is a
hardcoded CDC constant — it is not configurable. The Access Server and Management Console
must be able to reach this port.

**Default behaviour:** The chart creates a `ClusterIP` service exposing port 11701 within
the cluster. If the Access Server and Management Console run inside the same cluster, no
further action is needed. The in-cluster hostname for the CDC engine follows this pattern:

```
<release-name>.<namespace>.svc.cluster.local
```

For example, a release named `cdc-udb` deployed to namespace `cdc` using the default port
is reachable at `cdc-udb.cdc.svc.cluster.local:11701`. Helm also prints this hostname in
the install output. To retrieve it at any time:

```bash
kubectl get svc <release-name> -n <namespace>
```

**External access:** If the Access Server or Management Console runs outside the cluster,
create an additional Kubernetes service that targets the CDC pod's named container port
`cdc-port`. The chart-managed `ClusterIP` service remains in place for in-cluster access.
Choose the service type appropriate for your infrastructure:

- `NodePort` — exposes the port on each node at a static port number.
- `LoadBalancer` — provisions an external load balancer (typical on cloud-managed clusters).

Consult your Kubernetes provider documentation for the specific steps to create and configure
an external service.

> **Note:** `service.port` in your values file controls the port exposed by the chart-managed
> `ClusterIP` service (default `11701`). Override it per release when multiple CDC instances
> share a namespace to avoid service port conflicts.

---

## 8. Verify a deployment

```bash
# Wait for the StatefulSet to roll out successfully
kubectl rollout status statefulset/<release-name> -n <namespace>

# Watch the pod reach Running state
kubectl get pods -n <namespace> -w

# Stream pod logs continuously
kubectl logs -n <namespace> <release-name>-0 -f

# View current pod logs (without streaming)
kubectl logs -n <namespace> <release-name>-0

# View logs from the previous pod (useful after a crash or restart)
kubectl logs -n <namespace> <release-name>-0 -p

# Check the service
kubectl get svc -n <namespace>
```

If the pod is not reaching `Running` state, inspect events and resource allocation:

```bash
kubectl describe pod -n <namespace> <release-name>-0
```

**Successful startup** produces log output similar to:

```
Importing configuration...
Configuration imported successfully.
```

followed by the CDC engine startup trace.

**Common problems:**

| Symptom | Likely cause | Fix |
|---|---|---|
| `ImagePullBackOff` / `403 Forbidden` | Pull secret missing or pointing to wrong server | Create the pull secret before `helm upgrade --install`; use `cp.icr.io` for production |
| `FailedToRetrieveImagePullSecret` | Secret not yet present when pod was scheduled | Create the secret, then re-run `helm upgrade --install` |
| Pod stuck in `Pending` | No node satisfies storage class or resource requests | Run `kubectl describe pod` and check Events; verify the storage class name |

---

## 9. Upgrade an existing installation

> **Best practice:** Keep your values override file in version control. Always pass it
> explicitly with `-f` — do **not** rely on `--reuse-values`.

```bash
helm upgrade --install <release-name> ./cdc-replication \
  -f <my-values>.yaml \
  --namespace <namespace>
```

> **Note:** Running `helm upgrade` without `-f <my-values>.yaml` resets all values to the
> chart defaults. Any configuration not in your values file will be lost.

The new chart version already contains the correct image digest — no manual image tag or
digest override is needed.

**Version upgrades — pod restarts automatically.** When the chart version changes, the image
digest in the pod spec changes and Kubernetes performs a rolling restart of the StatefulSet
automatically. Monitor it with:

```bash
kubectl rollout status statefulset/<release-name> -n <namespace>
```

Replication resumes from the last committed bookmark once the pod is back up — no
subscription state is lost.

**Configuration-only changes — manual restart required.** When `helm upgrade` changes only
values that affect the ConfigMap (for example `instance.dbHost`, `instance.dbSchema`, or
any `instance.properties` entry), Kubernetes does not restart the pod automatically. The
new `userconfig.xml` is written to the ConfigMap but the running CDC process does not pick
it up until the pod restarts. After confirming the upgrade succeeded, restart manually:

```bash
kubectl rollout restart statefulset/<release-name> -n <namespace>
kubectl rollout status statefulset/<release-name> -n <namespace>
```

> **Note:** Credential rotation (updating `dbUsername` or `dbPassword` in the secret) also
> requires a manual restart. See
> [samples/rotate-db-credentials.md](../samples/rotate-db-credentials.md) for the full
> procedure.

---

## 10. Uninstall

```bash
helm uninstall <release-name> --namespace <namespace>
```

The PersistentVolumeClaim is **not** deleted automatically. To remove it:

```bash
kubectl delete pvc -l app.kubernetes.io/instance=<release-name> -n <namespace>
```

> **Caution:** Deleting the PVC permanently destroys all CDC instance data including
> subscriptions and bookmarks. Only do this when you are certain the instance data is no
> longer needed.
