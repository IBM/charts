# CDC for IBM Db2 LUW — Kubernetes Quickstart

This guide walks through deploying the CDC for IBM Db2 LUW (UDB) engine in Kubernetes using
the `cdc-replication` Helm chart.

Before starting, complete the common setup steps in
[Common Quickstart](common-quickstart.md) (namespace, pull secret, storage class).

> **Note:** Database-side prerequisites — Db2 configuration, CDC schema creation, and user
> permissions — are covered in the
> [IBM CDC Knowledge Center](https://www.ibm.com/docs/en/idr/11.4.0).

## Table of Contents

1. [UDB-specific prerequisites](#1-udb-specific-prerequisites)
2. [Create the database credentials secret](#2-create-the-database-credentials-secret)
3. [Create your values file](#3-create-your-values-file)
4. [Deploy with Helm](#4-deploy-with-helm)
5. [Verify the deployment](#5-verify-the-deployment)
6. [Next steps](#6-next-steps)

---

## 1. UDB-specific prerequisites

In addition to the [common prerequisites](common-quickstart.md#1-prerequisites):

- **Block storage class:** `ReadWriteOnce`-capable. Run `kubectl get storageclass` to find
  the name for your cluster.
- **CDC metadata schema:** The schema specified in `instance.dbSchema` must already exist in
  Db2 before deployment. CDC will not create it.
- **Unique service port:** If you are deploying more than one CDC instance into the same
  namespace, each release must use a different `service.port` (default `11701`).

For schema requirements and the `overrideTargetTables` caution, see
[CDC metadata schema and `overrideTargetTables`](common-quickstart.md#3-cdc-metadata-schema-and-overridetargettables).

---

## 2. Create the database credentials secret

> **Note:** Create the secret **before** running `helm upgrade --install`. The pod will fail
> to start if the secret does not exist when it is scheduled.

```bash
cat <<EOF | kubectl apply -f -
apiVersion: v1
kind: Secret
metadata:
  name: cdc-credentials
  namespace: <namespace>
type: Opaque
stringData:
  dbUsername: <db2-username>
  dbPassword: <db2-password>
EOF
```

---

## 3. Create your values file

Create a values override file — do **not** edit `values.yaml` directly, as it is
overwritten on every chart upgrade.

```yaml
productType: udb

license:
  accept: true
  # IDRAI  — IBM Data Replication AI Edition (standard entitlement)
  # IDRAIZ — IBM Data Replication AI Edition for z/OS (entitlement includes a DB2 for z/OS source)
  # Set to match your purchased entitlement.
  type: IDRAI

persistence:
  blockStorageClass: "<storage-class>"   # REQUIRED: name from kubectl get storageclass

instance:
  dbHost: "<db2-hostname>"
  dbPort: 50000                          # default Db2 port; adjust if different
  dbName: "<database-name>"
  dbSchema: "<cdc-schema>"              # must already exist in Db2

  # Uncomment only when reusing a schema from a previously uninstalled instance.
  # See the caution in step 1 before setting this to true.
  # overrideTargetTables: true
```

For a fully annotated example including air-gapped registry and multiple-instance
configurations, see [`samples/install-public-registry.yaml`](../samples/install-public-registry.yaml).

---

## 4. Deploy with Helm

```bash
helm upgrade --install cdc-udb ./cdc-replication \
  -f my-udb-values.yaml \
  --namespace <namespace>
```

`cdc-udb` is the Helm release name. It becomes the pod name (`cdc-udb-0`) and identifies
this CDC instance within the namespace. Choose a name that is meaningful for your environment.

---

## 5. Verify the deployment

```bash
# Wait for the StatefulSet to roll out successfully
kubectl rollout status statefulset/cdc-udb -n <namespace>

# Watch the pod reach Running state
kubectl get pods -n <namespace> -w

# Stream pod logs continuously
kubectl logs -n <namespace> cdc-udb-0 -f

# View current pod logs (without streaming)
kubectl logs -n <namespace> cdc-udb-0

# View logs from the previous pod (useful after a crash or restart)
kubectl logs -n <namespace> cdc-udb-0 -p

# Check the service
kubectl get svc -n <namespace>
```

The in-cluster hostname for this CDC instance follows this pattern:

```
<release-name>.<namespace>.svc.cluster.local:<service-port>
```

where `<release-name>` is the name you passed to `helm upgrade --install` (e.g. `cdc-udb`)
and `<service-port>` is the value of `service.port` in your values file (default: `11701`).

Use this address when configuring Access Server to connect to the engine. Helm also prints
it immediately after `helm upgrade --install` completes.

A successful startup produces log output similar to:

```
Importing configuration...
Configuration imported successfully.
```

followed by the CDC engine startup trace.

For general verification steps and a common problems table, see
[Verify a deployment](common-quickstart.md#8-verify-a-deployment).

**UDB-specific problems:**

| Symptom | Likely cause | Fix |
|---|---|---|
| CDC metadata tables already exist on fresh install | Previous install left tables in the schema | Drop `TS_AUTH`, `TS_BOOKMARK`, `TS_CONFAUD`, `TS_DDLAUD` from the schema, then redeploy |

---

## 6. Next steps

- **Set up replication:** Use the CDC Management Console or Access Server to create and start
  subscriptions. See the
  [IBM CDC Knowledge Center](https://www.ibm.com/docs/en/idr/11.4.0) for full configuration
  guidance.
- **Connect Access Server:** The CDC engine listens on the service port configured in step 4.
  See [Exposing the CDC service for external access](common-quickstart.md#6-exposing-the-cdc-service-for-external-access)
  if Access Server runs outside the cluster.
- **Additional deployment patterns:** See the [`samples/`](../samples/) directory for
  air-gapped registry, multiple instances, credential rotation, and upgrade examples.
