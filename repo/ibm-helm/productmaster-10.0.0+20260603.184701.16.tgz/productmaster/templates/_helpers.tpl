{{/*
Expand the name of the chart.
*/}}
{{- define "productmaster.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "productmaster.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "productmaster.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "productmaster.labels" -}}
helm.sh/chart: {{ include "productmaster.chart" . }}
{{ include "productmaster.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "productmaster.selectorLabels" -}}
app.kubernetes.io/name: {{ include "productmaster.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Generate the ServiceAccount name:
- If .Values.productmaster.serviceAccountName is provided, use it.
- Else, use "<chartName>-sa"
*/}}
{{- define "productmaster.serviceAccountName" -}}
{{- if .Values.global.serviceAccountName -}}
{{- .Values.global.serviceAccountName -}}
{{- else -}}
{{- printf "%s-sa" .Chart.Name -}}
{{- end -}}
{{- end }}


{{/*
Generate the productmasterServiceCR name:
- If .Values.productmaster.productmasterservicecr name is provided, use it.
- Else, use "productmasterservice-cr"
*/}}
{{- define "productmaster.productmasterServiceCRName" -}}
{{- if .Values.productmaster.productmasterServiceCRName -}}
{{- .Values.productmaster.productmasterServiceCRName -}}
{{- else -}}
productmasterservice-cr
{{- end -}}
{{- end -}}

{{/*
Generate the productmasterCR name:
- If .Values.productmaster_instance.productmaster name is provided, use it.
- Else, use "productmaster-cr"
*/}}
{{- define "productmaster_instance.productmasterInstanceCRName" -}}
{{- if .Values.productmaster_instance.productmasterInstanceCRName -}}
{{- .Values.productmaster_instance.productmasterInstanceCRName -}}
{{- else -}}
productmaster-cr
{{- end -}}
{{- end -}}