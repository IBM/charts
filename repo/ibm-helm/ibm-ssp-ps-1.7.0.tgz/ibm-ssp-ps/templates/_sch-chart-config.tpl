{{- /*
Chart specific config file for SCH (Shared Configurable Helpers)
_sch-chart-config.tpl is a config file for the chart to specify additional
values and/or override values defined in the sch/_config.tpl file.

*/ -}}

{{- /*
"sch.chart.config.values" contains the chart specific values used to override or provide
additional configuration values used by the Shared Configurable Helpers.
*/ -}}
{{- define "ibm-ssp-ps.sch.chart.config.values" -}}
sch:
  chart:
    appName: "ibm-ssp-ps"
    metering:
    {{- if eq (toString .Values.licenseType | lower) "non-prod"  }}
      productName: "IBM Sterling Secure Proxy Non Production Certified Container"
      productID: "e18189cc82074dba85acbe6b764090a7"
    {{- else }}
      productName: "IBM Sterling Secure Proxy Certified Container"
      productID: "9b921dda8dd141bf8869ead1a790d4da"
    {{- end }}
      productVersion: "6.2.2"
      productMetric: "VIRTUAL_PROCESSOR_CORE"
      productChargedContainers: ""
    podSecurityContext:
      runAsNonRoot: true
      supplementalGroups: [65534] 
      fsGroup: 65534
      runAsGroup: 0
      runAsUser: 1000   
      seccompProfile:
        type: "RuntimeDefault"	  
    containerSecurityContext:
      privileged: false
      runAsUser: 1000
      readOnlyRootFilesystem: false
      allowPrivilegeEscalation: false
      capabilities:
        drop: [ "ALL" ]
{{- end -}}
