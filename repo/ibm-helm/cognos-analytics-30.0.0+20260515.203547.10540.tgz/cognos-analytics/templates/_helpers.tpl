{{/*
Returns watch namespaces as comma-seperated values.
*/}}
{{- define "cognos_analytics.watch_namespace" -}}
{{- $watchNamespaces := .Values.global.tetheredNamespaces | default list -}}
{{- if .Values.global.instanceNamespace -}}
{{- $watchNamespaces = append $watchNamespaces .Values.global.instanceNamespace -}}
{{- end -}}
{{- $watchNamespaces = prepend $watchNamespaces .Values.global.operatorNamespace }}
{{- uniq $watchNamespaces | join "," | quote }}
{{- end -}}
