{{/*
Custom Resource
Usage: {{ include "operator-core-library.customResource" (dict "root" . "lib" .Values.operatorLibraryConfig "config" .Values.streamsets) }}
*/}}
{{- define "operator-core-library.customResource" -}}
{{- $root := .root -}}
{{- $lib := .lib -}}
{{- $config := .config -}}
{{- if $config.deployCR }}
apiVersion: {{ $lib.apiGroup }}/v1alpha1
kind: {{ $lib.crdKind }}
metadata:
  annotations:
    case.version: {{ $config.caseVersion | default $root.Chart.Version | quote }}
  {{- if $lib.labels }}
  labels:
    {{- range $key, $value := $lib.labels }}
    {{ $key }}: {{ $value | quote }}
    {{- end }}
    component-id: {{ $root.Chart.Name }}
  {{- end }}
  finalizers:
    - {{ $lib.apiGroup }}/finalizer
  name: {{ $lib.crName }}
  namespace: {{ $root.Values.global.instanceNamespace }}
spec:
  blockStorageClass: {{ $root.Values.global.blockStorageClass }}
  configuration: {}
  license:
    accept: true
  version: {{ $config.crVersion | default $root.Chart.AppVersion | quote }}
  useNamespacedPullSecret: true
  imagePullSecret: {{ $root.Values.global.imagePullSecret | quote }}
  {{- if $root.Values.global.imagePullPrefix }}
  imagePullPrefix: {{ $root.Values.global.imagePullPrefix | quote }}
  {{- end }}
  {{- if $config.scaleConfig }}
  scaleConfig: {{ $config.scaleConfig | quote }}
  {{- end }}
  operandImagePullPrefix: {{ include "operator-core-library.operandRegistry" (dict "root" $root "config" $config) | quote }}
{{- end }}
{{- end -}}
