{{/* vim: set filetype=mustache: */}}

{{/* This file is generated in helm-charts/Makefile */}}
{{/* DO NOT EDIT BY HAND                            */}}

{{/* Generate the kafka image map */}}
{{- define "strimzi.kafka.image.map" }}
            - name: EVENTSTREAMS_DEFAULT_KAFKA_EXPORTER_IMAGE
              value: {{ template "strimzi.image" (merge . (dict "key" "kafkaExporter" "tagSuffix" "")) }}
            - name: EVENTSTREAMS_DEFAULT_CRUISE_CONTROL_IMAGE
              value: {{ template "strimzi.image" (merge . (dict "key" "cruiseControl" "tagSuffix" "")) }}
            - name: EVENTSTREAMS_KAFKA_IMAGES
              value: |                 
                4.1.0={{ template "strimzi.image" (merge . (dict "key" "kafka" "tagSuffix" "")) }}
                4.1.1={{ template "strimzi.image" (merge . (dict "key" "kafka" "tagSuffix" "")) }}
                4.2.0={{ template "strimzi.image" (merge . (dict "key" "kafka" "tagSuffix" "")) }}
            - name: EVENTSTREAMS_KAFKA_CONNECT_IMAGES
              value: |                 
                4.1.0={{ template "strimzi.image" (merge . (dict "key" "kafkaConnect" "tagSuffix" "")) }}
                4.1.1={{ template "strimzi.image" (merge . (dict "key" "kafkaConnect" "tagSuffix" "")) }}
                4.2.0={{ template "strimzi.image" (merge . (dict "key" "kafkaConnect" "tagSuffix" "")) }}
            - name: EVENTSTREAMS_KAFKA_MIRROR_MAKER_2_IMAGES
              value: |                 
                4.1.0={{ template "strimzi.image" (merge . (dict "key" "kafkaMirrorMaker2" "tagSuffix" "")) }}
                4.1.1={{ template "strimzi.image" (merge . (dict "key" "kafkaMirrorMaker2" "tagSuffix" "")) }}
                4.2.0={{ template "strimzi.image" (merge . (dict "key" "kafkaMirrorMaker2" "tagSuffix" "")) }}
{{- end -}}
