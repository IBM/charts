{{- define "eventstreams.namespaced" }}
- apiGroups:
    - ""
  # The Event Streams Operator requires the "get" and "list" permissions for namespaces
  # This is to allow the operator to query the namespaces in the cluster and watch all that it can see when
  # WATCHED_NAMESPACES has the value '*'
  resources:
    - namespaces
  verbs:
    - get
    - list
    - watch

- apiGroups:
  # The Event Streams Operator requires the "get" and "list" permissions for nodes
  # This is to allow the operator to label Kafka brokers in a rack-aware installation
    - ""
  resources:
    - nodes
  verbs:
    - list
    - get

- apiGroups:
  # The Event Streams Operator creates monitoring dashboards.
    - monitoringcontroller.cloud.ibm.com
  resources:
    - monitoringdashboards
  verbs:
    - create
    - get
    - patch
    - delete

- apiGroups:
    - ""
 # The Event Streams Operator requires the "patch" permissions for pods
 # This is to allow the operator to delegate the same permissions to the Admin API
  resources:
    - pods
  verbs:
    - patch

- apiGroups:
    - monitoring.coreos.com
  # The Event Streams Operator requires the "get", "create" and "patch" permissions for servicemonitors
  # This is to allow the operator to create and manage the resources required for an Event Streams instance
  resources:
    - servicemonitors
  verbs:
    - get
    - create
    - patch

- apiGroups:
    - eventstreams.ibm.com
  # The Event Streams Operator requires the "*" permissions for eventstreams, eventstreamsgeoreplicator and kafkausers
  # This is to allow the operator to create and manage the resources required for an Event Streams and Event Streams geo-replicator instance
  resources:
    - "eventstreams"
    - "eventstreams/status"
    - "eventstreamsgeoreplicators"
    - "eventstreamsgeoreplicators/status"
    # The entity operator runs which needs to access and manage KafkaTopics and KafkaUsers resources
    - kafkatopics
    - kafkatopics/status
    - kafkausers
    - kafkausers/status
  verbs:
    - get
    - list
    - watch
    - create
    - delete
    - patch
    - update

- apiGroups:
    - "eventstreams.ibm.com"
  resources:
    # The cluster operator runs the KafkaAssemblyOperator, which needs to access and manage Kafka resources
    - kafkas
    - kafkas/status
    # The cluster operator runs the KafkaConnectAssemblyOperator, which needs to access and manage KafkaConnect resources
    - kafkaconnects
    - kafkaconnects/status
    # The cluster operator runs the KafkaConnectorAssemblyOperator, which needs to access and manage KafkaConnector resources
    - kafkaconnectors
    - kafkaconnectors/status
    # The cluster operator runs the KafkaMirrorMakerAssemblyOperator, which needs to access and manage KafkaMirrorMaker resources
    - kafkamirrormakers
    - kafkamirrormakers/status
    # The cluster operator runs the KafkaBridgeAssemblyOperator, which needs to access and manage BridgeMaker resources
    - kafkabridges
    - kafkabridges/status
    # The cluster operator runs the KafkaMirrorMaker2AssemblyOperator, which needs to access and manage KafkaMirrorMaker2 resources
    - kafkamirrormaker2s
    - kafkamirrormaker2s/status
    # The cluster operator runs the KafkaRebalanceAssemblyOperator, which needs to access and manage KafkaRebalance resources
    - kafkarebalances
    - kafkarebalances/status
    # The cluster operator runs the KafkaAssemblyOperator, which needs to access and manage KafkaNodePool resources
    - kafkanodepools
    - kafkanodepools/status
  verbs:
    - get
    - list
    - watch
    - create
    - delete
    - patch
    - update

- apiGroups:
    - "core.eventstreams.ibm.com"
  resources:
    # The cluster operator uses StrimziPodSets to manage the Kafka and ZooKeeper pods
    - strimzipodsets
    - strimzipodsets/status
  verbs:
    - get
    - list
    - watch
    - create
    - delete
    - patch
    - update

- apiGroups:
    - "oidc.security.ibm.com"
  # The Event Streams Operator requires the "get", "create", "patch" and "delete" permissions for oidc clients
  # This is to allow the operator to create and manage an oidc client request required for authentication in Event Streams
  resources:
    - clients
  verbs:
    - get
    - create
    - patch
    - delete

- apiGroups:
    - "cp4i.ibm.com"
  # The Event Streams Operator requires the "get", "create", "patch" and "delete" permissions for oidc clients
  # This is to allow the operator to create and manage an oidc client request required for authentication in Event Streams
  resources:
    - cp4iservicesbindings
  verbs:
    - get
    - create
    - patch
    - delete

- apiGroups:
    - "operator.ibm.com"
  resources:
    - operandrequests
  verbs:
    - get
    - list
    - create
    - patch
    - delete

- apiGroups:
    - operators.coreos.com
   # The Event Streams Operator requires the "get" and "list" permissions for ClusterServiceVersions
   # This is to allow the operator to query dependent CSVs for their version and namespace scope
  resources:
    - clusterserviceversions
  verbs:
    - get
    - list

- apiGroups:
    - batch
    # The Event Streams Operator requires the "list", "get", "create", "patch" and "delete" permissions for
    # jobs. This is to allow the operator to create and manage jobs required
    # for Event Streams Apicurio Registry v1 to Apicurio Registry v2 data migration
  resources:
    - jobs
  verbs:
    - list
    - get
    - create
    - patch
    - delete
- apiGroups:
    - "keycloak.integration.ibm.com"
  # The Event Streams Operator requires the "get", "create", "patch" and "delete" permissions for integrationKeycloak clients
  # This is to allow the operator to create and manage an integration keycloak request required for authentication in Event Streams
  resources:
    - integrationkeycloakclients
  verbs:
    - get
    - create
    - patch
    - delete
{{- end -}}