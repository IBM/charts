{{/*
for now use a static name, since ingressroutes for each OS engine
have to know this during provisioning in the console
*/}}
{{ define "traefik-auth-plugin.name" }}
{{- printf "%s-traefik-auth-plugin" (include "opensearch-operator.fullname" .) -}}
{{ end }}

{{- define "traefik-auth-plugin.svc-addr" -}}
{{- printf "%s.%s.svc.cluster.local:%d" (include "traefik-auth-plugin.name" .) .Values.global.operatorNamespace (.Values.ibmWxdOpensearch.traefikAuthPlugin.listenPort | int) -}}
{{- end -}}

{{- define "traefik-auth-plugin.svc-addr-without-port" -}}
{{- printf "%s.%s.svc.cluster.local" (include "traefik-auth-plugin.name" .) .Values.global.operatorNamespace -}}
{{- end -}}

{{- define "traefik-auth-plugin.svc-addr-same-ns" -}}
{{- printf "%s:%d" (include "traefik-auth-plugin.name" .) (.Values.ibmWxdOpensearch.traefikAuthPlugin.listenPort | int) -}}
{{- end -}}

{{ define "traefik-auth-plugin.cm-name" }}
{{- printf "%s-config" (include "traefik-auth-plugin.name" .) -}}
{{ end }}

