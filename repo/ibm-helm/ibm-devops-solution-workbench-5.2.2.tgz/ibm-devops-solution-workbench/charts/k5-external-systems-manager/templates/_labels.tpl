{{/*
Label stack used for labelling.
*/}}
{{- define "k5-external-systems-manager.labels" -}}
app.kubernetes.io/version: {{ .Chart.AppVersion }}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version | replace "+" "_" }}
app.kubernetes.io/part-of: k5-hub
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{ template "k5-external-systems-manager.matchLabels" . }}
{{- end -}}

{{/*
Default match labels.
*/}}
{{- define "k5-external-systems-manager.matchLabels" -}}
app.kubernetes.io/name: {{ template "k5-external-systems-manager.fullname" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/*
Label used to select server pods only.
*/}}
{{- define "k5-external-systems-manager.serverSelector" -}}
app.kubernetes.io/component: {{ .Chart.Name }}-server
{{- end -}}
