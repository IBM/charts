{{/*
Leader election role
Usage: {{ include "operator-core-library.leaderElectionRole" (dict "root" . "lib" .Values.operatorLibraryConfig) }}
*/}}
{{- define "operator-core-library.leaderElectionRole" -}}
{{- $root := .root -}}
{{- $lib := .lib -}}
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  labels:
    {{- range $key, $value := $lib.labels }}
    {{ $key }}: {{ $value | quote }}
    {{- end }}
    component-id: {{ $root.Chart.Name }}
  name: {{ $lib.operatorName }}-leader-election-role
  namespace: {{ $root.Values.global.operatorNamespace }}
rules:
  - apiGroups: [""]
    resources: ["configmaps"]
    verbs: ["get", "list", "watch", "create", "update", "patch", "delete"]
  - apiGroups: ["coordination.k8s.io"]
    resources: ["leases"]
    verbs: ["get", "list", "watch", "create", "update", "patch", "delete"]
  - apiGroups: [""]
    resources: ["events"]
    verbs: ["create", "patch"]
{{- end -}}

{{/*
Leader election role binding
Usage: {{ include "operator-core-library.leaderElectionRoleBinding" (dict "root" . "lib" .Values.operatorLibraryConfig) }}
*/}}
{{- define "operator-core-library.leaderElectionRoleBinding" -}}
{{- $root := .root -}}
{{- $lib := .lib -}}
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  labels:
    {{- range $key, $value := $lib.labels }}
    {{ $key }}: {{ $value | quote }}
    {{- end }}
    component-id: {{ $root.Chart.Name }}
  name: {{ $lib.operatorName }}-leader-election-rolebinding
  namespace: {{ $root.Values.global.operatorNamespace }}
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: Role
  name: {{ $lib.operatorName }}-leader-election-role
subjects:
  - kind: ServiceAccount
    name: {{ $lib.serviceAccountName }}
    namespace: {{ $root.Values.global.operatorNamespace }}
{{- end -}}

{{/*
Service account
Usage: {{ include "operator-core-library.serviceAccount" (dict "root" . "lib" .Values.operatorLibraryConfig) }}
*/}}
{{- define "operator-core-library.serviceAccount" -}}
{{- $root := .root -}}
{{- $lib := .lib -}}
apiVersion: v1
kind: ServiceAccount
metadata:
  labels:
    {{- range $key, $value := $lib.labels }}
    {{ $key }}: {{ $value | quote }}
    {{- end }}
    component-id: {{ $root.Chart.Name }}
  name: {{ $lib.serviceAccountName }}
  namespace: {{ $root.Values.global.operatorNamespace }}
{{- end -}}

{{/*
Manager role
Usage: {{ include "operator-core-library.managerRole" (dict "root" . "lib" .Values.operatorLibraryConfig "namespace" $ns) }}
*/}}
{{- define "operator-core-library.managerRole" -}}
{{- $root := .root -}}
{{- $lib := .lib -}}
{{- $ns := .namespace -}}
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  {{- if $lib.labels }}
  labels:
    {{- range $key, $value := $lib.labels }}
    {{ $key }}: {{ $value | quote }}
    {{- end }}
    component-id: {{ $root.Chart.Name }}
  {{- else }}
  labels:
    component-id: {{ $root.Chart.Name }}
  {{- end }}
  name: {{ $lib.operatorName }}-manager-role
  namespace: {{ $ns }}
rules:
  {{- if $lib.additionalRules }}
  {{- range $lib.additionalRules }}
  - apiGroups: {{ .apiGroups | toJson }}
    resources: {{ .resources | toJson }}
    verbs: {{ .verbs | toJson }}
  {{- end }}
  {{- end }}
  - apiGroups: ["apps"]
    resources: ["deployments"]
    verbs: ["create", "delete", "get", "list", "patch", "update", "watch"]
  - apiGroups: ["apps"]
    resources: ["deployments/scale"]
    verbs: ["get", "list", "patch", "update"]
  - apiGroups: ["apps"]
    resources: ["statefulsets"]
    verbs: ["create", "delete", "get", "list", "patch", "update", "watch"]
  - apiGroups: ["autoscaling"]
    resources: ["horizontalpodautoscalers"]
    verbs: ["create", "delete", "get", "list", "patch", "update", "watch"]
  - apiGroups: ["batch"]
    resources: ["jobs"]
    verbs: ["create", "delete", "get", "list", "patch", "update", "watch"]
  - apiGroups: [""]
    resources: ["configmaps"]
    verbs: ["create", "delete", "get", "list", "patch", "update", "watch"]
  - apiGroups: [""]
    resources: ["events"]
    verbs: ["create", "patch"]
  - apiGroups: [""]
    resources: ["persistentvolumeclaims"]
    verbs: ["create", "delete", "get", "list", "patch", "update", "watch"]
  - apiGroups: [""]
    resources: ["pods"]
    verbs: ["create", "delete", "get", "list", "patch", "update", "watch"]
  - apiGroups: [""]
    resources: ["secrets"]
    verbs: ["create", "delete", "get", "list", "patch", "update", "watch"]
  - apiGroups: [""]
    resources: ["serviceaccounts"]
    verbs: ["create", "delete", "get", "list", "patch", "update", "watch"]
  - apiGroups: [""]
    resources: ["services"]
    verbs: ["create", "delete", "get", "list", "patch", "update", "watch"]
  - apiGroups: ["networking.k8s.io"]
    resources: ["networkpolicies"]
    verbs: ["create", "delete", "get", "list", "patch", "update", "watch"]
  - apiGroups: ["policy"]
    resources: ["poddisruptionbudgets"]
    verbs: ["create", "delete", "get", "list", "patch", "update", "watch"]
  - apiGroups: ["rbac.authorization.k8s.io"]
    resources: ["rolebindings", "roles"]
    verbs: ["create", "delete", "get", "list", "patch", "update", "watch"]
  - apiGroups: ["{{ $lib.apiGroup }}"]
    resources: ["{{ $lib.crdPlural }}"]
    verbs: ["create", "delete", "get", "list", "patch", "update", "watch"]
  - apiGroups: ["{{ $lib.apiGroup }}"]
    resources: ["{{ $lib.crdPlural }}/finalizers"]
    verbs: ["update"]
  - apiGroups: ["{{ $lib.apiGroup }}"]
    resources: ["{{ $lib.crdPlural }}/status"]
    verbs: ["get", "patch", "update"]
  - apiGroups: ["zen.cpd.ibm.com"]
    resources: ["zenextensions"]
    verbs: ["create", "delete", "get", "list", "patch", "update", "watch"]
  - apiGroups: ["zen.cpd.ibm.com"]
    resources: ["zenservices"]
    verbs: ["get", "list", "watch"]
  - apiGroups: ["ccs.cpd.ibm.com"]
    resources: ["ccs"]
    verbs: ["create", "get", "list", "patch", "update", "watch"]
{{- end -}}

{{/*
Manager role binding
Usage: {{ include "operator-core-library.managerRoleBinding" (dict "root" . "lib" .Values.operatorLibraryConfig "namespace" $ns) }}
*/}}
{{- define "operator-core-library.managerRoleBinding" -}}
{{- $root := .root -}}
{{- $lib := .lib -}}
{{- $ns := .namespace -}}
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  labels:
    {{- range $key, $value := $lib.labels }}
    {{ $key }}: {{ $value | quote }}
    {{- end }}
    component-id: {{ $root.Chart.Name }}
  name: {{ $lib.operatorName }}-manager-rolebinding
  namespace: {{ $ns }}
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: Role
  name: {{ $lib.operatorName }}-manager-role
subjects:
  - kind: ServiceAccount
    name: {{ $lib.serviceAccountName }}
    namespace: {{ $root.Values.global.operatorNamespace }}
{{- end -}}
