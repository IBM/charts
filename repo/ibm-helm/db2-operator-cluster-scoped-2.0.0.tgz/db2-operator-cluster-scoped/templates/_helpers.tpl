{{/*
Expand the name of the chart.
*/}}
{{- define "db2-operator.name" -}}
{{- default .Chart.Name .Values.db2u.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "db2-operator.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "db2-operator.labels" -}}
helm.sh/chart: {{ include "db2-operator.chart" . }}
{{ include "db2-operator.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | replace "+" "_" | trunc 63 | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
component-id: {{ .Chart.Name }}
{{- with .Values.db2u.commonLabels }}
{{ toYaml . }}
{{- end }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "db2-operator.selectorLabels" -}}
app.kubernetes.io/name: {{ include "db2-operator.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

