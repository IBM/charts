#!/bin/bash
# Observability Stack Setup using existing OpenSearch
# Components: Data Prepper + OpenTelemetry Collector (uses existing OpenSearch + Dashboards)
# Full compatibility with OpenSearch Observability features (Trace Analytics, Service Maps, etc.)

set -e

NAMESPACE_PROVIDED="${NAMESPACE:-}"
OPENSEARCH_NAMESPACE="${OPENSEARCH_NAMESPACE:-default}"
RELEASE_NAME="${RELEASE_NAME:-}"
DATA_PREPPER_VERSION="${DATA_PREPPER_VERSION:-2.6.1}"

ALLOW_INSECURE_DEFAULT_CREDS="${ALLOW_INSECURE_DEFAULT_CREDS:-false}"
ALLOW_INSECURE_TLS="${ALLOW_INSECURE_TLS:-false}"

# Detect existing OpenSearch
if [ -z "$RELEASE_NAME" ]; then
    echo "Detecting existing OpenSearch installation..."
    RELEASE_NAME=$(kubectl get deployment -n $OPENSEARCH_NAMESPACE -o name | grep 'ibm-devopsplan-prod-opensearch' | head -1 | sed 's/.*\/\(.*\)-ibm-devopsplan-prod-opensearch/\1/')
    if [ -z "$RELEASE_NAME" ]; then
        echo "ERROR: Could not detect OpenSearch installation. Please set RELEASE_NAME environment variable."
        echo "Example: RELEASE_NAME=my-release ./observability-setup.sh"
        exit 1
    fi
    echo "Detected release: $RELEASE_NAME"
fi

# Set namespace - use provided value or default to ${RELEASE_NAME}-observability
if [ -z "$NAMESPACE_PROVIDED" ]; then
    NAMESPACE="${RELEASE_NAME}-observability"
else
    NAMESPACE="$NAMESPACE_PROVIDED"
fi

echo "================================================"
echo "Setting up OpenSearch Observability Components"
echo "Namespace: $NAMESPACE"
echo "================================================"

OPENSEARCH_HOST="$RELEASE_NAME-ibm-devopsplan-prod-opensearch.$OPENSEARCH_NAMESPACE.svc.cluster.local"
OPENSEARCH_URL="https://$OPENSEARCH_HOST:9200"

echo "Using existing OpenSearch at: $OPENSEARCH_URL"

# Get OpenSearch credentials
OPENSEARCH_SECRET="$RELEASE_NAME-ibm-devopsplan-prod-opensearch"
echo "Checking for OpenSearch credentials in secret: $OPENSEARCH_SECRET"

if ! kubectl get secret "$OPENSEARCH_SECRET" -n $OPENSEARCH_NAMESPACE &>/dev/null; then
    if [ "$ALLOW_INSECURE_DEFAULT_CREDS" = "true" ]; then
        echo "WARNING: Secret $OPENSEARCH_SECRET not found. Using default credentials (admin/admin)
        OPENSEARCH_USER="admin"
        OPENSEARCH_PASS="admin"
    else
        echo "ERROR: Secret $OPENSEARCH_SECRET not found in namespace $OPENSEARCH_NAMESPACE."
        echo "Please create the secret with OpenSearch credentials or set ALLOW_INSECURE_DEFAULT_CREDS=true for dev/local environments."
        exit 1
    fi
else
    OPENSEARCH_USER=$(kubectl get secret "$OPENSEARCH_SECRET" -n $OPENSEARCH_NAMESPACE -o jsonpath='{.data.opensearch-username}' | base64 -d 2>/dev/null)
    OPENSEARCH_PASS=$(kubectl get secret "$OPENSEARCH_SECRET" -n $OPENSEARCH_NAMESPACE -o jsonpath='{.data.opensearch-password}' | base64 -d 2>/dev/null)
    if [ -z "$OPENSEARCH_USER" ] || [ -z "$OPENSEARCH_PASS" ]; then
        echo "ERROR: Could not decode credentials from secret $OPENSEARCH_SECRET."
        exit 1
    fi
fi

# Create namespace
kubectl create namespace $NAMESPACE --dry-run=client -o yaml | kubectl apply -f -

# Add Helm repositories
echo "Adding Helm repositories..."
helm repo add open-telemetry https://open-telemetry.github.io/opentelemetry-helm-charts
helm repo update

# Install Data Prepper for trace and log processing
echo "Installing Data Prepper..."
cat > /tmp/data-prepper-config.yaml << DATAPREPPER_CONFIG
version: "2"

entry-pipeline:
  source:
    otel_trace_source:
      ssl: false
      port: 21890
    otel_metrics_source:
      ssl: false
      port: 21891
    otel_logs_source:
      ssl: false
      port: 21892
  processor:
    - otel_traces:
    - otel_metrics:
    - otel_logs:
  sink:
    - pipeline:
        name: "trace-pipeline"
    - pipeline:
        name: "metrics-pipeline"
    - pipeline:
        name: "logs-pipeline"

trace-pipeline:
  source:
    pipeline:
      name: "entry-pipeline"
  processor:
    - otel_trace_group:
        hosts:
          - "$OPENSEARCH_URL"
        username: "$OPENSEARCH_USER"
        password: "$OPENSEARCH_PASS"
        insecure: $ALLOW_INSECURE_TLS
    - service_map:
  sink:
    - opensearch:
        hosts:
          - "$OPENSEARCH_URL"
        username: "$OPENSEARCH_USER"
        password: "$OPENSEARCH_PASS"
        insecure: $ALLOW_INSECURE_TLS
        index_type: "trace-analytics-raw"
        dlq_file: "/usr/share/data-prepper/data/trace-dlq.log"

service-map-pipeline:
  source:
    pipeline:
      name: "trace-pipeline"
  processor:
    - service_map_stateful:
  sink:
    - opensearch:
        hosts:
          - "$OPENSEARCH_URL"
        username: "$OPENSEARCH_USER"
        password: "$OPENSEARCH_PASS"
        insecure: $ALLOW_INSECURE_TLS
        index_type: "trace-analytics-service-map"

metrics-pipeline:
  source:
    pipeline:
      name: "entry-pipeline"
  processor:
    - otel_metrics:
  sink:
    - opensearch:
        hosts:
          - "$OPENSEARCH_URL"
        username: "$OPENSEARCH_USER"
        password: "$OPENSEARCH_PASS"
        insecure: $ALLOW_INSECURE_TLS
        index_type: "metrics-otel"
        dlq_file: "/usr/share/data-prepper/data/metrics-dlq.log"

logs-pipeline:
  source:
    pipeline:
      name: "entry-pipeline"
  processor:
    - grok:
        match:
          log: [ "%{COMMONAPACHELOG}" ]
        target_key: "apache"
        keep_empty_captures: true
    - date:
        from_time_received: true
        destination: "@timestamp"
  sink:
    - opensearch:
        hosts:
          - "$OPENSEARCH_URL"
        username: "$OPENSEARCH_USER"
        password: "$OPENSEARCH_PASS"
        insecure: $ALLOW_INSECURE_TLS
        index_type: "logs"
        dlq_file: "/usr/share/data-prepper/data/logs-dlq.log"

DATAPREPPER_CONFIG

kubectl create configmap data-prepper-config \
  --from-file=pipelines.yaml=/tmp/data-prepper-config.yaml \
  --namespace $NAMESPACE \
  --dry-run=client -o yaml | kubectl apply -f -

# Create Data Prepper deployment
cat > /tmp/data-prepper-deployment.yaml << DATAPREPPER_DEPLOY
apiVersion: v1
kind: Service
metadata:
  name: data-prepper
  namespace: $NAMESPACE
spec:
  selector:
    app: data-prepper
  ports:
    - name: otel-traces
      port: 21890
      targetPort: 21890
    - name: otel-metrics
      port: 21891
      targetPort: 21891
    - name: otel-logs
      port: 21892
      targetPort: 21892
  type: ClusterIP
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: data-prepper
  namespace: $NAMESPACE
spec:
  replicas: 1
  selector:
    matchLabels:
      app: data-prepper
  template:
    metadata:
      labels:
        app: data-prepper
    spec:
      containers:
      - name: data-prepper
        image: opensearchproject/data-prepper:2.6.1
        ports:
        - containerPort: 21890
          name: otel-traces
        - containerPort: 21891
          name: otel-metrics
        - containerPort: 21892
          name: otel-logs
        volumeMounts:
        - name: config
          mountPath: /usr/share/data-prepper/pipelines/
        resources:
          requests:
            cpu: 500m
            memory: 1Gi
          limits:
            memory: 2Gi
      volumes:
      - name: config
        configMap:
          name: data-prepper-config
DATAPREPPER_DEPLOY

kubectl apply -f /tmp/data-prepper-deployment.yaml

# Wait for Data Prepper to be ready
echo "Waiting for Data Prepper to be ready..."
kubectl wait --for=condition=available deployment/data-prepper -n $NAMESPACE --timeout=300s

# Install OpenTelemetry Collector with filelog receiver
echo "Installing OpenTelemetry Collector with log collection..."
cat > /tmp/otel-collector-values.yaml << OTEL_EOF
mode: daemonset

presets:
  kubernetesAttributes:
    enabled: true
  kubeletMetrics:
    enabled: true
  hostMetrics:
    enabled: true

config:
  receivers:
    otlp:
      protocols:
        grpc:
          endpoint: 0.0.0.0:4317
        http:
          endpoint: 0.0.0.0:4318
    
    # File log receiver for container logs
    filelog:
      include:
        - /var/log/pods/*/*/*.log
      include_file_path: true
      include_file_name: false
      operators:
        # Parse CRI-O / containerd format
        - type: regex_parser
          id: parser-containerd
          regex: '^(?P<time>[^\s]+) (?P<stream>stdout|stderr) (?P<logtag>[^\s]*) (?P<log>.*)$'
          timestamp:
            parse_from: attributes.time
            layout: '%Y-%m-%dT%H:%M:%S.%LZ'
        # Extract Kubernetes metadata from file path
        - type: regex_parser
          id: extract-metadata
          regex: '^.*\/(?P<namespace>[^_]+)_(?P<pod_name>[^_]+)_(?P<uid>[a-f0-9\-]+)\/(?P<container_name>[^\/_]+)\/(?P<restart_count>\d+)\.log$'
          parse_from: attributes["log.file.path"]
        # Move log content to body
        - type: move
          from: attributes.log
          to: body
        # Add resource attributes
        - type: move
          from: attributes.namespace
          to: resource["k8s.namespace.name"]
        - type: move
          from: attributes.pod_name
          to: resource["k8s.pod.name"]
        - type: move
          from: attributes.container_name
          to: resource["k8s.container.name"]
    
    prometheus:
      config:
        scrape_configs:
          - job_name: 'kubernetes-pods'
            kubernetes_sd_configs:
              - role: pod
            relabel_configs:
              - source_labels: [__meta_kubernetes_pod_annotation_prometheus_io_scrape]
                action: keep
                regex: true
              - source_labels: [__meta_kubernetes_pod_annotation_prometheus_io_path]
                action: replace
                target_label: __metrics_path__
                regex: (.+)
              - source_labels: [__address__, __meta_kubernetes_pod_annotation_prometheus_io_port]
                action: replace
                regex: ([^:]+)(?::\d+)?;(\d+)
                replacement: \$1:\$2
                target_label: __address__

    kubeletstats:
      collection_interval: 30s
      auth_type: "serviceAccount"
      endpoint: "\${K8S_NODE_NAME}:10250"
      insecure_skip_verify: ${ALLOW_INSECURE_TLS}
      metric_groups:
        - node
        - pod
        - container
        - volume

  processors:
    batch:
      timeout: 10s
      send_batch_size: 1024
    
    memory_limiter:
      check_interval: 5s
      limit_percentage: 80
      spike_limit_percentage: 25
    
    k8sattributes:
      auth_type: "serviceAccount"
      passthrough: false
      extract:
        metadata:
          - k8s.namespace.name
          - k8s.deployment.name
          - k8s.statefulset.name
          - k8s.daemonset.name
          - k8s.cronjob.name
          - k8s.job.name
          - k8s.node.name
          - k8s.pod.name
          - k8s.pod.uid
          - k8s.pod.start_time
          - k8s.container.name
        labels:
          - tag_name: app
            key: app
            from: pod
        annotations:
          - tag_name: version
            key: version
            from: pod
      pod_association:
        - sources:
            - from: resource_attribute
              name: k8s.pod.name
        - sources:
            - from: resource_attribute
              name: k8s.namespace.name

    # Add resource detection
    resourcedetection:
      detectors: [env, system, docker, eks, ec2, ecs, elastic_beanstalk, lambda, azure, aks, gcp, gke, googlecloud, heroku, openshift]
      timeout: 5s

  exporters:
    debug:
      verbosity: detailed
    
    # Send traces to Data Prepper
    otlp/traces:
      endpoint: data-prepper.$NAMESPACE.svc.cluster.local:21890
      tls:
        insecure: ${ALLOW_INSECURE_TLS}
    
    # Send metrics to Data Prepper
    otlp/metrics:
      endpoint: data-prepper.$NAMESPACE.svc.cluster.local:21891
      tls:
        insecure: ${ALLOW_INSECURE_TLS}
    
    # Send logs to Data Prepper
    otlp/logs:
      endpoint: data-prepper.$NAMESPACE.svc.cluster.local:21892
      tls:
        insecure: ${ALLOW_INSECURE_TLS}

  service:
    pipelines:
      traces:
        receivers: [otlp]
        processors: [memory_limiter, k8sattributes, resourcedetection, batch]
        exporters: [otlp/traces, debug]
      
      metrics:
        receivers: [otlp, prometheus, kubeletstats, hostmetrics]
        processors: [memory_limiter, k8sattributes, resourcedetection, batch]
        exporters: [otlp/metrics]
      
      logs:
        receivers: [otlp, filelog]
        processors: [memory_limiter, k8sattributes, resourcedetection, batch]
        exporters: [otlp/logs]

# Resources
resources:
  limits:
    memory: 1Gi
  requests:
    cpu: 300m
    memory: 512Mi

# Service account
serviceAccount:
  create: true

# Tolerations
tolerations:
  - effect: NoSchedule
    operator: Exists

# Volume mounts for log collection
extraVolumes:
  - name: varlogpods
    hostPath:
      path: /var/log/pods
  - name: varlibdockercontainers
    hostPath:
      path: /var/lib/docker/containers

extraVolumeMounts:
  - name: varlogpods
    mountPath: /var/log/pods
    readOnly: true
  - name: varlibdockercontainers
    mountPath: /var/lib/docker/containers
    readOnly: true

# Environment variables
env:
  - name: K8S_NODE_NAME
    valueFrom:
      fieldRef:
        fieldPath: spec.nodeName

OTEL_EOF

helm upgrade --install opentelemetry-collector open-telemetry/opentelemetry-collector \
  --namespace $NAMESPACE \
  --values /tmp/otel-collector-values.yaml \
  --wait --timeout 5m

# Create index patterns and dashboards
echo "Waiting for Data Prepper to be ready..."
kubectl wait --for=condition=available deployment/data-prepper -n $NAMESPACE --timeout=300s

echo ""
echo "================================================"
echo "OpenSearch Observability Components Installed!"
echo "================================================"
echo ""
echo "Using existing OpenSearch:"
echo "  Host: $OPENSEARCH_HOST"
echo "  Dashboards: Already deployed (check your existing dashboards)"
echo ""
echo "New Components Added:"
echo "  ✓ Data Prepper - Telemetry processor for Trace Analytics"
echo "  ✓ OpenTelemetry Collector - Unified log/metric/trace collection"
echo ""
echo "OpenSearch Native Observability Features Now Available:"
echo "  ✓ Trace Analytics - Service maps and span analysis"
echo "  ✓ Application Analytics - Correlation between logs and traces"
echo "  ✓ Event Analytics - Pattern detection in logs"
echo ""
echo "Access Your Existing OpenSearch Dashboards:"
echo "  URL: http://<your-ingress-ip>/opensearch-dashboards"
echo "  Then navigate to 'Observability' in the left menu"
echo ""
echo "Data Collection:"
echo "  - Logs: Automatically collected from all pods via OTel filelog receiver"
echo "  - Metrics: Add annotation 'prometheus.io/scrape=true' to your pods"
echo "  - Traces: Send to opentelemetry-collector.$NAMESPACE:4317 (gRPC) or :4318 (HTTP)"
echo ""
echo "New Indexes Created in OpenSearch:"
echo "  - otel-v1-apm-span-* (traces)"
echo "  - otel-v1-apm-service-map (service relationships)"
echo "  - ss4o_logs-* (logs in Simple Schema for Observability)"
echo "  - ss4o_metrics-* (metrics)"
echo ""
echo "Observability components:"
kubectl get pods -n $NAMESPACE
echo ""
echo "Services:"
kubectl get svc -n $NAMESPACE
echo ""
echo "To send traces from your apps, use these endpoints:"
echo "  gRPC: opentelemetry-collector.$NAMESPACE.svc.cluster.local:4317"
echo "  HTTP: opentelemetry-collector.$NAMESPACE.svc.cluster.local:4318"

