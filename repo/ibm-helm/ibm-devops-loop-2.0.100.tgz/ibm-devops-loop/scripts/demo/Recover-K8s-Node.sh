#!/bin/bash
# Purpose: Emergency script to recover a node suffering from 100% disk usage.
# - Aggressively vacuums journals to 50MB
# - Purges DNF/Yum metadata
# - Nuclear-prunes all container objects
# - Deletes pods in Evicted / ImagePullBackOff
# - Attempts to restart crio and kubelet 
# Dry-run Command: bash Recover-k8s-Node.sh --dry-run
# Interactive run Command : bash Recover-k8s-Node.sh

set -u

echo "===== Recover-Node started: $(date -u) ====="

DRY_RUN=false

while [ "$#" -gt 0 ]; do
  case "$1" in
    --dry-run) DRY_RUN=true; shift ;;
    -h|--help) echo "Usage: $0 [--dry-run]"; exit 0 ;;
    *) shift ;;
  esac
done

confirm() {
  echo
  echo "*** DANGEROUS: This will aggressively delete caches, images and may remove pods/containers." >&2
  read -r -p "Type YES to proceed: " token
  if [ "$token" != "YES" ]; then
    echo "Aborted by user." >&2
    exit 2
  fi
}

maybe_run() {
  if [ "$DRY_RUN" = true ]; then
    echo "DRY-RUN: $*"
  else
    echo "RUN: $*"
    eval "$@"
  fi
}

vacuum_journal() {
  if command -v journalctl >/dev/null 2>&1; then
    echo "Vacuuming journal to 50MB..."
    maybe_run sudo journalctl --vacuum-size=50M || true
  else
    echo "journalctl not present; skipping." 
  fi
}

purge_package_cache() {
  echo "Purging DNF/Yum metadata and caches..."
  maybe_run sudo dnf clean all || maybe_run sudo yum clean all || true
  maybe_run sudo rm -rf /var/cache/dnf/* /var/cache/yum/* /var/cache/dnf || true
}

nuclear_prune_containers() {
  echo "Performing SAFE container runtime cleanup (non-disruptive)...."
  # Docker
  if command -v docker >/dev/null 2>&1; then
    echo "Docker: pruning unused resources...."
    maybe_run sudo docker container prune -f || true
    maybe_run sudo docker image prune -af || true
    maybe_run sudo docker volume prune -f || true
  fi
  # Podman
  if command -v podman >/dev/null 2>&1; then
    echo "Podman: pruning unused resources...."
    maybe_run sudo podman container prune -f || true
    maybe_run sudo podman image prune -a -f || true
    maybe_run sudo podman volume prune -f || true
  fi
  # CRI-O / containerd via crictl (SAFE mode)
  if command -v crictl >/dev/null 2>&1; then
    echo "CRI runtime: removing exited containers only...."
    if [ "$DRY_RUN" = false ]; then
      # Remove exited containers only
      sudo crictl ps -a --state Exited -q | xargs -r sudo crictl rm || true
      # Remove unused images only (prune)
      sudo crictl rmi --prune || true
    else
      echo "DRY-RUN: would remove exited containers and unused images"
    fi
  fi
  echo "Safe container cleanup completed."
}

delete_k8s_pods() {
  if ! command -v kubectl >/dev/null 2>&1; then
    echo "kubectl not found; skipping Kubernetes pod deletions."
    return
  fi
  echo "Identifying Evicted and ImagePullBackOff pods..."
  # Use kubectl text output, filter lines containing Evicted or ImagePullBackOff
  kubectl get pods --all-namespaces --no-headers 2>/dev/null | grep -E "Evicted|ImagePullBackOff" | awk '{print $1" "$2" "$4}' | while read -r ns name status; do
    echo "Pod to delete: $ns/$name (status: $status)"
    if [ "$DRY_RUN" = true ]; then
      echo "DRY-RUN: kubectl delete pod $name -n $ns --grace-period=0 --force"
    else
      kubectl delete pod "$name" -n "$ns" --grace-period=0 --force || true
    fi
  done
}

restart_services() {
  echo "Attempting to restart crio and kubelet to kickstart services..."
  maybe_run sudo systemctl restart crio || true
  maybe_run sudo systemctl restart kubelet || true
  echo "Service statuses (short):"
  maybe_run sudo systemctl status crio --no-pager -l -n 5 || true
  maybe_run sudo systemctl status kubelet --no-pager -l -n 5 || true
}

main() {
  confirm
  vacuum_journal
  purge_package_cache
  nuclear_prune_containers
  delete_k8s_pods
  echo
  restart_services
  echo 
  echo "===== Recover-Node ended: $(date -u) ====="
}

main
