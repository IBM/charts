#!/bin/bash
NAMESPACE=devops-loop
HELM_NAME=devops-loop

echo "Deleting the older devops-loop folder, cert.pem and key.pem, if exixts"
rm -rf ibm-devops-loop hcl-devops-loop ca-for-browser.pem cert.pem key.pem

echo "Uninstalling $HELM_NAME helm"
helm uninstall $HELM_NAME -n $NAMESPACE

echo "Deleting the $NAMESPACE namespace"
kubectl delete namespace $NAMESPACE
