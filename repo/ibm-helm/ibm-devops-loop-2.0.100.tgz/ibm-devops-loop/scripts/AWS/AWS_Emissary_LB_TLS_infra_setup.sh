#!/bin/bash

# DevOps Loop - AWS Infrastructure Setup Script
# Version: 1.4

set -euo pipefail

# Color codes
readonly RED='\033[0;31m'
readonly GREEN='\033[0;32m'
readonly YELLOW='\033[1;33m'
readonly BLUE='\033[0;34m'
readonly NC='\033[0m'


# VARIABLES - values to be filled as per your environment

DOMAIN="${DOMAIN:-""}"
ACM_CERT_ARN="${ACM_CERT_ARN:-""}"
NAMESPACE="${NAMESPACE:-"emissary-system"}"
VPC_CIDR="${VPC_CIDR:-""}"
# Instance label for selector
APP_INSTANCE_LABEL="devops-loop" 


print_status() { echo -e "${BLUE}[INFO]${NC} $1"; }
print_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
print_error() { echo -e "${RED}[ERROR]${NC} $1"; }

validate_input() {
    if [[ -z "$DOMAIN" || -z "$ACM_CERT_ARN" || -z "$VPC_CIDR" ]]; then
        print_error "Please ensure DOMAIN, ACM_CERT_ARN, and VPC_CIDR are set in the script variables."
        exit 1
    fi
}

create_namespaces() {
    print_status "Creating namespaces..."
    kubectl create namespace "$NAMESPACE" --dry-run=client -o yaml | kubectl apply -f -
}

install_emissary() {
    print_status "Installing Emissary CRDs..."
    kubectl apply -f https://app.getambassador.io/yaml/emissary/3.9.1/emissary-crds.yaml

    print_status "Waiting for Emissary API extension to be ready in $NAMESPACE..."
    kubectl wait --timeout=90s --for=condition=available deployment emissary-apiext -n "$NAMESPACE"

    print_status "Adding Emissary Helm repo..."
    helm repo add datawire https://app.getambassador.io
    helm repo update

    # AWS NodePort configuration
    cat <<EOF > emissary-values.yaml
service:
  type: NodePort
  ports:
    - name: http
      port: 80
      targetPort: 8080
EOF

    print_status "Installing Emissary Ingress via Helm..."
    helm upgrade --install emissary-ingress datawire/emissary-ingress \
        --namespace "$NAMESPACE" \
        -f emissary-values.yaml
}

create_emissary_listener() {
    print_status "Creating Emissary Listener (L7)..."
    cat <<EOF | kubectl apply -f -
apiVersion: getambassador.io/v3alpha1
kind: Listener
metadata:
  name: emissary-http-listener
  namespace: $NAMESPACE
spec:
  port: 8080
  protocol: HTTP
  securityModel: XFP
  hostBinding:
    namespace:
      from: SELF
EOF
}

create_aws_ingress() {
    print_status "Creating AWS ALB Ingress for $DOMAIN..."
    cat <<EOF | kubectl apply -f -
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: ${NAMESPACE}-ingress
  namespace: $NAMESPACE
  annotations:
    kubernetes.io/ingress.class: alb
    alb.ingress.kubernetes.io/scheme: internet-facing
    alb.ingress.kubernetes.io/target-type: ip
    alb.ingress.kubernetes.io/listen-ports: '[{"HTTP": 80}, {"HTTPS":443}]'
    alb.ingress.kubernetes.io/certificate-arn: ${ACM_CERT_ARN}
    alb.ingress.kubernetes.io/ssl-redirect: '443'
    # Explicit SSL Policy
    alb.ingress.kubernetes.io/ssl-policy: ELBSecurityPolicy-TLS13-1-2-2021-06
    alb.ingress.kubernetes.io/healthcheck-port: traffic-port
	alb.ingress.kubernetes.io/healthcheck-matcher: '200,301'
    alb.ingress.kubernetes.io/healthcheck-path: /ambassador/v0/check_ready
spec:
  # Modern Ingress Class field
  ingressClassName: alb
  rules:
    - host: ${DOMAIN}
      http:
        paths:
          - path: /
            pathType: Prefix
            backend:
              service:
                name: emissary-ingress
                port:
                  number: 80
EOF
}

create_l4_service() {
    print_status "Creating Network Load Balancer (L4) for SSH/WebSockets..."
    cat <<EOF | kubectl apply -f -
apiVersion: v1
kind: Service
metadata:
  name: ${NAMESPACE}-nlb
  namespace: $NAMESPACE
  annotations:
    service.beta.kubernetes.io/aws-load-balancer-type: "external"
    service.beta.kubernetes.io/aws-load-balancer-nlb-target-type: "ip"
    service.beta.kubernetes.io/aws-load-balancer-scheme: "internal"
    service.beta.kubernetes.io/load-balancer-source-ranges: "$VPC_CIDR"
spec:
  type: LoadBalancer
  # Targets the app workload directly instead of emissary
  selector:
    app.kubernetes.io/instance: $APP_INSTANCE_LABEL
  ports:
    - name: deploy-wss
      port: 7919
      targetPort: 7919
    - name: build-wss
      port: 7920
      targetPort: 7920
    - name: control-ssh
      port: 9022
      targetPort: 9022
EOF
}

main() {
    validate_input
    print_status "Starting setup for $DOMAIN in namespace $NAMESPACE"
    create_namespaces
    install_emissary
    create_emissary_listener
    create_aws_ingress
    create_l4_service

    echo
    print_success "Infrastructure setup complete!"
    print_status "Restricted access to $VPC_CIDR on NLB."
}

main "$@"
