#!/bin/bash

# DevOps Loop - Emissary Infrastructure Setup Script
# Production Environment
# Version: 1.0

set -euo pipefail

# Color codes for output formatting
readonly RED='\033[0;31m'
readonly GREEN='\033[0;32m'
readonly YELLOW='\033[1;33m'
readonly BLUE='\033[0;34m'
readonly NC='\033[0m'

# Global variables
DOMAIN=""
STATIC_IP_ADDRESS=""
STATIC_IP_NAME=""
NAMESPACE=""

# Logging functions
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

# Function to clean variables
clean_variable() {
    echo "$1" | xargs | tr -d '\n\r'
}

# Function to validate namespace format
validate_namespace_format() {
    local namespace=$1
    if [[ $namespace =~ ^[a-z0-9]([-a-z0-9]*[a-z0-9])?$ ]]; then
        return 0
    else
        return 1
    fi
}

# Function to validate IP format
validate_ip_format() {
    local ip=$1
    if [[ $ip =~ ^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$ ]]; then
        IFS='.' read -ra ADDR <<< "$ip"
        for i in "${ADDR[@]}"; do
            if [[ $i -gt 255 ]]; then
                return 1
            fi
        done
        return 0
    else
        return 1
    fi
}

# Function to find static IP name by IP address
find_static_ip_name() {
    local ip_address=$1
    print_status "Searching for global static IP name for address: $ip_address" >&2

    local ip_name=$(gcloud compute addresses list --global --filter="address:$ip_address" --format="value(name)" 2>/dev/null)

    if [[ -n "$ip_name" ]]; then
        print_success "Found global static IP name: $ip_name" >&2
        echo "$ip_name"
        return 0
    else
        print_error "No global static reserved IP found with address: $ip_address" >&2
        print_error "Please ensure the IP address is correct and is a global static reserved IP in your GCP project" >&2

        print_status "Available global static reserved IPs in your project:" >&2
        gcloud compute addresses list --global --format="table(name,address,status)" 2>/dev/null >&2 || true

        return 1
    fi
}

# Function to validate domain format
validate_domain_format() {
    local domain=$1
    if [[ $domain =~ ^[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$ ]]; then
        return 0
    else
        return 1
    fi
}

# Function to prompt for user input
get_user_input() {
    echo
    print_status "DevOps Loop - Emissary Infrastructure Setup"
    echo "=============================================="

    # Get Domain
    while true; do
        read -p "Enter the FQDN (e.g., mcloop.hcltechswnp.com): " DOMAIN_RAW
        DOMAIN=$(clean_variable "$DOMAIN_RAW")

        if [[ -z "$DOMAIN" ]]; then
            print_error "Domain cannot be empty. Please provide a valid FQDN."
            continue
        fi

        if validate_domain_format "$DOMAIN"; then
            break
        else
            print_error "Invalid domain format. Please provide a valid FQDN (e.g., mcloop.hcltechswnp.com)"
            continue
        fi
    done

    # Get Static IP
    while true; do
        read -p "Enter the global static reserved IP address (e.g., 34.102.136.180): " STATIC_IP_ADDRESS_RAW
        STATIC_IP_ADDRESS=$(clean_variable "$STATIC_IP_ADDRESS_RAW")

        if [[ -z "$STATIC_IP_ADDRESS" ]]; then
            print_error "IP address cannot be empty. Please provide a valid IP address."
            continue
        fi

        if ! validate_ip_format "$STATIC_IP_ADDRESS"; then
            print_error "Invalid IP address format. Please provide a valid IPv4 address."
            continue
        fi

        STATIC_IP_NAME=$(find_static_ip_name "$STATIC_IP_ADDRESS")
        if [[ $? -eq 0 && -n "$STATIC_IP_NAME" ]]; then
            STATIC_IP_NAME=$(clean_variable "$STATIC_IP_NAME")
            break
        else
            continue
        fi
    done

    # Get Namespace
    while true; do
        read -p "Enter the target namespace (e.g., devops-loop): " NAMESPACE_RAW
        NAMESPACE=$(clean_variable "$NAMESPACE_RAW")

        if [[ -z "$NAMESPACE" ]]; then
            print_error "Namespace cannot be empty. Please provide a valid namespace."
            continue
        fi

        if validate_namespace_format "$NAMESPACE"; then
            break
        else
            print_error "Invalid namespace format. Must be lowercase alphanumeric with hyphens (e.g., devops-loop)"
            continue
        fi
    done

    print_success "Input validation completed"
    print_status "Domain: $DOMAIN"
    print_status "Static IP Address: $STATIC_IP_ADDRESS"
    print_status "Static IP Name: $STATIC_IP_NAME"
    print_status "Target Namespace: $NAMESPACE"
}

# Function to create namespaces
create_namespaces() {
    print_status "Creating required namespaces..."

    kubectl create namespace emissary-system --dry-run=client -o yaml | kubectl apply -f -
    kubectl create namespace "$NAMESPACE" --dry-run=client -o yaml | kubectl apply -f -

    print_success "Namespaces created successfully"
}

# Function to install Emissary CRDs
install_emissary_crds() {
    print_status "Installing Emissary CRDs..."

    kubectl apply -f https://app.getambassador.io/yaml/emissary/3.9.1/emissary-crds.yaml

    # Wait for deployment to be available
    kubectl wait --timeout=90s --for=condition=available deployment emissary-apiext -n emissary-system

    # Wait for webhook service endpoints to be ready
    print_status "Waiting for Emissary webhook service to be ready..."
    local max_attempts=30
    local attempt=1

    while [[ $attempt -le $max_attempts ]]; do
        local endpoints=$(kubectl get endpoints emissary-apiext -n emissary-system -o jsonpath='{.subsets[*].addresses[*].ip}' 2>/dev/null || echo "")

        if [[ -n "$endpoints" ]]; then
            print_success "Emissary webhook service is ready"
            break
        fi

        print_status "Attempt $attempt/$max_attempts: Waiting for webhook endpoints..."
        sleep 5
        ((attempt++))

        if [[ $attempt -gt $max_attempts ]]; then
            print_error "Webhook service endpoints not ready within timeout"
            return 1
        fi
    done

    # Additional wait to ensure webhook is fully operational
    print_status "Ensuring webhook is fully operational..."
    sleep 10

    print_success "Emissary CRDs installed successfully"
}

# Function to create Emissary ports configuration
create_emissary_ports_config() {
    print_status "Creating Emissary ports configuration..."

    cat <<EOF > emissary-ports.yaml
service:
  type: NodePort
  ports:
    - name: http
      port: 8080
      targetPort: 8080
EOF

    print_success "Emissary ports configuration created"
}

# Function to install Emissary Ingress
install_emissary_ingress() {
    print_status "Installing Emissary Ingress..."

    # Add Datawire Helm repository
    helm repo add datawire https://app.getambassador.io
    helm repo update

    # Install Emissary Ingress with retry mechanism
    local max_attempts=3
    local attempt=1

    while [[ $attempt -le $max_attempts ]]; do
        print_status "Installation attempt $attempt/$max_attempts..."

        if helm install emissary-ingress --namespace "$NAMESPACE" datawire/emissary-ingress -f emissary-ports.yaml; then
            print_success "Emissary Ingress Helm chart installed successfully"
            break
        else
            print_warning "Installation attempt $attempt failed"
            if [[ $attempt -lt $max_attempts ]]; then
                print_status "Waiting 30 seconds before retry..."
                sleep 30
            else
                print_error "Failed to install Emissary Ingress after $max_attempts attempts"
                return 1
            fi
        fi
        ((attempt++))
    done

    # Wait for deployment to be ready
    kubectl -n "$NAMESPACE" wait --for condition=available --timeout=90s deploy -lapp.kubernetes.io/instance=emissary-ingress

    print_success "Emissary Ingress installed successfully"
}

# Function to create Backend Config
create_backend_config() {
    print_status "Creating Backend Config..."

    cat <<EOF > backend-config.yaml
apiVersion: cloud.google.com/v1
kind: BackendConfig
metadata:
  name: emissary-backend-config
  namespace: $NAMESPACE
spec:
  timeoutSec: 300
  connectionDraining:
    drainingTimeoutSec: 60
  healthCheck:
    checkIntervalSec: 10
    healthyThreshold: 1
    port: 8877
    requestPath: /ambassador/v0/check_ready
    timeoutSec: 5
    type: HTTP
    unhealthyThreshold: 3
EOF

    kubectl apply -f backend-config.yaml
    print_success "Backend Config created successfully"
}

# Function to create Managed Certificate
create_managed_certificate() {
    print_status "Creating Managed Certificate..."

    cat <<EOF > managed-certificate.yaml
apiVersion: networking.gke.io/v1
kind: ManagedCertificate
metadata:
  name: managed-cert
  namespace: $NAMESPACE
spec:
  domains:
    - ${DOMAIN}
EOF

    kubectl apply -f managed-certificate.yaml
    print_success "Managed Certificate created successfully"
}

# Function to patch Emissary service
patch_emissary_service() {
    print_status "Patching Emissary service with backend config annotation..."

    kubectl patch service emissary-ingress -n "$NAMESPACE" -p '{"metadata":{"annotations":{"cloud.google.com/backend-config":"{\"default\": \"emissary-backend-config\"}"}}}'

    print_success "Emissary service patched successfully"
}

# Function to create Listener
create_listener() {
    print_status "Creating Emissary Listener..."

    cat <<EOF > listener.yaml
apiVersion: getambassador.io/v3alpha1
kind: Listener
metadata:
  name: ${NAMESPACE}-http-listener
  namespace: $NAMESPACE
  labels:
    app.kubernetes.io/component: http-listener
    app.kubernetes.io/instance: $NAMESPACE
spec:
  hostBinding:
    namespace:
      from: SELF
  l7Depth: 1
  port: 8080
  protocol: HTTP
  securityModel: XFP
EOF

    kubectl apply -f listener.yaml
    print_success "Emissary Listener created successfully"
}

# Function to create Ingress
create_ingress() {
    print_status "Creating Kubernetes Ingress..."

    cat <<EOF > ingress.yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: ${NAMESPACE}-ingress
  namespace: $NAMESPACE
  labels:
    app.kubernetes.io/component: ingress
    app.kubernetes.io/name: ${NAMESPACE}-ingress
  annotations:
    kubernetes.io/ingress.class: "gce"
    kubernetes.io/ingress.global-static-ip-name: "${STATIC_IP_NAME}"
    networking.gke.io/managed-certificates: "managed-cert"
    nginx.ingress.kubernetes.io/proxy-buffer-size: "32k"
    nginx.ingress.kubernetes.io/proxy-buffers-number: "8"
    nginx.ingress.kubernetes.io/proxy-busy-buffers-size: "32k"
spec:
  rules:
    - host: ${DOMAIN}
      http:
        paths:
          - path: /
            pathType: Prefix
            backend:
              service:
                name: emissary-ingress
                port:
                  number: 8080
EOF

    kubectl apply -f ingress.yaml
    print_success "Kubernetes Ingress created successfully"
}

# Function to create L4 Load Balancer service
create_l4_loadbalancer() {
    print_status "Creating L4 Load Balancer service..."

    cat <<EOF > l4-loadbalancer.yaml
apiVersion: v1
kind: Service
metadata:
  name: ${NAMESPACE}-load-balancer
  namespace: $NAMESPACE
spec:
  type: LoadBalancer
  selector:
    app.kubernetes.io/instance: emissary-ingress
    app.kubernetes.io/name: emissary-ingress
  ports:
    - name: deploy-wss
      port: 7919
      targetPort: 7919
    - name: build-wss
      port: 7920
      targetPort: 7920
    - name: control-ssh
      port: 9022
      targetPort: 9022
EOF

    kubectl apply -f l4-loadbalancer.yaml
    print_success "L4 Load Balancer service created successfully"
}

# Function to get L4 LoadBalancer external IP with inline progress
get_l4_external_ip() {
    local max_attempts=30
    local attempt=1
    local external_ip=""

    while [[ $attempt -le $max_attempts ]]; do
        external_ip=$(kubectl get service "${NAMESPACE}-load-balancer" -n "$NAMESPACE" -o jsonpath='{.status.loadBalancer.ingress[0].ip}' 2>/dev/null || echo "")

        if [[ -n "$external_ip" && "$external_ip" != "null" ]]; then
            echo "$external_ip"
            return 0
        fi

        sleep 5
        ((attempt++))
    done

    echo ""
}

# Function to clean up temporary files
cleanup_temp_files() {
    print_status "Cleaning up temporary files..."

    local temp_files=(
        "emissary-ports.yaml"
        "backend-config.yaml"
        "managed-certificate.yaml"
        "listener.yaml"
        "ingress.yaml"
        "l4-loadbalancer.yaml"
    )

    for file in "${temp_files[@]}"; do
        if [[ -f "$file" ]]; then
            rm -f "$file"
        fi
    done

    print_success "Temporary files cleaned up"
}

# Function to display deployment status and DNS instructions
display_deployment_status() {
    echo
    print_success "Emissary Infrastructure Setup Completed!"
    echo "========================================"

    # Show progress for L4 LoadBalancer IP assignment
    printf "${BLUE}[INFO]${NC} Waiting for L4 LoadBalancer external IP assignment"

    local max_attempts=30
    local attempt=1
    local l4_external_ip=""

    while [[ $attempt -le $max_attempts ]]; do
        l4_external_ip=$(kubectl get service "${NAMESPACE}-load-balancer" -n "$NAMESPACE" -o jsonpath='{.status.loadBalancer.ingress[0].ip}' 2>/dev/null || echo "")

        if [[ -n "$l4_external_ip" && "$l4_external_ip" != "null" ]]; then
            printf "\n"
            break
        fi

        printf "."
        sleep 5
        ((attempt++))
    done

    if [[ -z "$l4_external_ip" || "$l4_external_ip" == "null" ]]; then
        printf "\n"
    fi

    # Display DNS mapping instructions
    echo
    print_success "DNS MAPPING INSTRUCTIONS:"
    echo "========================================="
    print_status "Configure the following DNS records in your DNS provider:"
    echo
    echo "1. HTTPS/HTTP Traffic (L7 Load Balancer):"
    echo "   Record Type: A"
    echo "   Name: $DOMAIN"
    echo "   Value: $STATIC_IP_ADDRESS"
    echo

    if [[ -n "$l4_external_ip" && "$l4_external_ip" != "null" ]]; then
        echo "2. WebSocket/SSH Traffic (L4 Load Balancer):"
        echo "   Record Type: A"
        echo "   Name: service-$DOMAIN"
        echo "   Value: $l4_external_ip"
    else
        echo "2. WebSocket/SSH Traffic (L4 Load Balancer):"
        echo "   Record Type: A"
        echo "   Name: service-$DOMAIN"
        echo "   Value: <Pending - Check manually>"
        echo
        print_status "Get L4 IP with: kubectl get svc ${NAMESPACE}-load-balancer -n $NAMESPACE"
    fi

    echo
    print_warning "IMPORTANT NOTES:"
    echo "• Certificate provisioning may take 10-60 minutes to complete"
    echo "• DNS propagation may take up to 24-48 hours"

    echo
    print_status "Useful Commands:"
    echo "• Check certificate: kubectl get managedcertificate managed-cert -n $NAMESPACE"
    echo "• Check ingress: kubectl get ingress ${NAMESPACE}-ingress -n $NAMESPACE"
    echo "• Check L4 service: kubectl get svc ${NAMESPACE}-load-balancer -n $NAMESPACE"
    echo "• Check all resources: kubectl get all -n $NAMESPACE"
}

# Main execution function
main() {
    echo "DevOps Loop - Emissary Infrastructure Setup Script"
    echo "================================================="

    # Check prerequisites
    command -v kubectl >/dev/null 2>&1 || { print_error "kubectl is required but not installed. Aborting."; exit 1; }
    command -v helm >/dev/null 2>&1 || { print_error "helm is required but not installed. Aborting."; exit 1; }
    command -v gcloud >/dev/null 2>&1 || { print_error "gcloud is required but not installed. Aborting."; exit 1; }

    # Execute setup steps
    get_user_input
    create_namespaces
    install_emissary_crds
    create_emissary_ports_config
    install_emissary_ingress
    create_backend_config
    create_managed_certificate
    patch_emissary_service
    create_listener
    create_ingress
    create_l4_loadbalancer
    cleanup_temp_files
    display_deployment_status

    print_success "Setup completed successfully!"
}

# Execute main function
main "$@"
