# Observability - Integrated Helm Subchart

Complete observability solution using **OpenSearch native Observability features** integrated directly into your Helm chart as a subchart:
- **Logs** - OpenTelemetry Collector with filelog receiver
- **Metrics** - OpenTelemetry Collector with Prometheus scraping + kubelet stats
- **Traces** - OpenTelemetry Collector with OTLP protocol
- **Data Prepper** - Official OpenSearch telemetry processor for Trace Analytics & Service Maps

## Architecture

```
Applications/Pods
    ↓
OpenTelemetry Collector (DaemonSet)
    ↓ (OTLP)
Data Prepper
    ↓
Existing OpenSearch (from ibm-devopsplan-prod)
    ↓
Existing OpenSearch Dashboards (with native Observability plugin)
```

This is deployed as a **Helm subchart** - no shell scripts required!

## Quick Start

### Enable Observability

Edit `values.yaml`:
```yaml
observability:
  enabled: true
```

Deploy:
```bash
helm upgrade my-release . -f values.yaml
```

That's it! The subchart will:
1. Auto-detect your existing OpenSearch instance
2. Use existing credentials from secrets
3. Deploy Data Prepper and OpenTelemetry Collector
4. Start collecting logs/metrics/traces automatically

## Components Installed

**Architecture Note**: This subchart deploys observability-specific components (Data Prepper + OTel Collector) that work with your **existing** OpenSearch from ibm-devopsplan-prod. The Data Prepper is separate because:
- It's NOT included in ibm-devopsplan-prod
- It transforms OTel telemetry into OpenSearch's observability formats
- It can be scaled/disabled independently

### 1. Data Prepper (Helm Subchart)
- Official OpenSearch telemetry processor
- Processes traces into service maps
- Converts metrics/logs to SS4O format
- Deployed as Kubernetes Deployment

### 2. OpenTelemetry Collector (Helm Subchart)
- **Single unified collector** for logs, metrics, and traces
- Filelog receiver for container log collection
- Prometheus scraper for annotated pods
- Kubelet metrics for node/pod/container stats
- OTLP receiver for application traces (gRPC :4317, HTTP :4318)
- Deployed as Kubernetes DaemonSet
- Kubernetes metadata enrichment

### 3. Uses Your Existing Infrastructure
- ✅ Uses existing OpenSearch (from ibm-devopsplan-prod subchart)
- ✅ Uses existing OpenSearch Dashboards
- ✅ Auto-discovers connection details and credentials
- ✅ No duplicate deployments

## Configuration

All configuration is in `values.yaml`:

```yaml
observability:
  enabled: true  # Set to true to enable
  
  # OpenSearch connection (auto-configured)
  opensearch:
    host: ""  # Auto-detected: {{ .Release.Name }}-ibm-devopsplan-prod-opensearch
    existingSecret: ""  # Auto-detected from parent chart
  
  # Data Prepper resources
  dataPrepper:
    enabled: true
    replicaCount: 1
    resources:
      requests:
        cpu: 500m
        memory: 1Gi
  
  # OpenTelemetry Collector resources
  otelCollector:
    enabled: true
    filelog:
      enabled: true  # Collect pod logs
    prometheus:
      enabled: true  # Scrape Prometheus metrics
    kubeletstats:
      enabled: true  # Collect node/pod metrics
    hostMetrics:
      enabled: true  # Collect host metrics
```

See [charts/observability/values.yaml](../charts/observability/values.yaml) for all options.

## Access OpenSearch Dashboards

Your existing OpenSearch Dashboards deployment already has the Observability plugin. Just navigate to it:

1. Go to your existing OpenSearch Dashboards: `/opensearch-dashboards`

2. Login with your existing credentials

3. **Navigate to Observability** (new left sidebar menu):
   - **Trace Analytics** - View service maps, latency, errors
   - **Application Analytics** - Correlate logs with traces
   - **Event Analytics** - Query and visualize log patterns

## Using Native Observability Features

### Trace Analytics
Automatically available after first traces are received:

1. Go to **Observability** → **Trace Analytics**
2. View:
   - **Dashboard** - Latency trends, error rates, trace groups
   - **Services** - Service map showing dependencies
   - **Traces** - Individual trace details with spans

### Application Analytics
Correlate logs with traces:

1. Go to **Observability** → **Application Analytics**  
2. Create applications grouping services
3. View logs, traces, and metrics in unified view
4. Filter by trace ID to see related logs

### Event Analytics
Query and visualize logs:

1. Go to **Observability** → **Event Analytics**
2. Use PPL (Piped Processing Language) or SQL
3. Create visualizations from query results
4. Save queries for reuse

## Enable Metrics Collection for Your Pods

Add these annotations to your pod/deployment to enable automatic metrics scraping:

```yaml
metadata:
  annotations:
    prometheus.io/scrape: "true"
    prometheus.io/port: "8080"      # Your metrics port
    prometheus.io/path: "/metrics"   # Your metrics endpoint (optional, defaults to /metrics)
```

## Send Distributed Traces

Configure your application to send traces to the OpenTelemetry Collector service:

**Service name pattern**: `{{ .Release.Name }}-observability-otel-collector`

**Endpoints:**
- **gRPC**: `{{ .Release.Name }}-observability-otel-collector:4317`
- **HTTP**: `{{ .Release.Name }}-observability-otel-collector:4318`

Or use the full cluster DNS:
- **gRPC**: `{{ .Release.Name }}-observability-otel-collector.{{ .Release.Namespace }}.svc.cluster.local:4317`
- **HTTP**: `{{ .Release.Name }}-observability-otel-collector.{{ .Release.Namespace }}.svc.cluster.local:4318`

### Examples

**Go:**
```go
import (
    "go.opentelemetry.io/otel"
    "go.opentelemetry.io/otel/exporters/otlp/otlptrace/otlptracegrpc"
    "go.opentelemetry.io/otel/sdk/trace"
)

exporter, _ := otlptracegrpc.New(ctx,
    otlptracegrpc.WithEndpoint("{{ .Release.Name }}-observability-otel-collector:4317"),
    otlptracegrpc.WithInsecure(),
)
tp := trace.NewTracerProvider(trace.WithBatcher(exporter))
otel.SetTracerProvider(tp)
```

Note: Replace `{{ .Release.Name }}` with your actual Helm release name (e.g., `my-release-observability-otel-collector:4317`)

**Java (Spring Boot):**
```yaml
# application.yml
management:
  otlp:
    tracing:
      endpoint: http://{{ .Release.Name }}-observability-otel-collector:4318/v1/traces
```

**Python:**
```python
from opentelemetry import trace
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor

trace.set_tracer_provider(TracerProvider())
otlp_exporter = OTLPSpanExporter(
    endpoint="{{ .Release.Name }}-observability-otel-collector:4317",
    insecure=True
)
trace.get_tracer_provider().add_span_processor(BatchSpanProcessor(otlp_exporter))
```

**Node.js:**
```javascript
const { NodeTracerProvider } = require('@opentelemetry/sdk-trace-node');
const { OTLPTraceExporter } = require('@opentelemetry/exporter-trace-otlp-grpc');

const provider = new NodeTracerProvider();
provider.addSpanProcessor(new BatchSpanProcessor(new OTLPTraceExporter({
  url: '{{ .Release.Name }}-observability-otel-collector:4317',
})));
provider.register();
```

## Key Metrics Available

- **Node metrics**: CPU, memory, disk, network usage
- **Pod metrics**: CPU, memory, restart counts, status
- **Container metrics**: Resource usage per container
- **Application metrics**: From Prometheus annotations
- **Trace metrics**: Latency percentiles (p50, p90, p99), error rates, throughput

## OpenSearch Index Patterns

The stack creates these indexes automatically:

- **otel-v1-apm-span-*** - Raw trace spans
- **otel-v1-apm-service-map** - Service relationship data
- **ss4o_logs-*** - Logs in Simple Schema for Observability format
- **ss4o_metrics-otel-*** - Metrics from OTel Collector
- **ss4o_metrics-prometheus-*** - Scraped Prometheus metrics

## Create Dashboards

### Using Native Observability Dashboards

OpenSearch comes with **pre-built dashboards** for traces:

1. Go to **Observability** → **Trace Analytics** → **Dashboard**
2. View out-of-the-box visualizations:
   - Latency by service
   - Error rate trends
   - Trace group statistics
   - Service map

### Custom Dashboards

1. Go to **Dashboard** → **Create new dashboard**
2. Add visualizations from:
   - **ss4o_logs-*** for log analysis
   - **ss4o_metrics-*** for metric charts
   - **otel-v1-apm-span-*** for trace data

### Recommended Visualizations

- **Error Rate Over Time**: Line chart from trace spans with error=true
- **Service Dependencies**: Use built-in Service Map
- **Top Slow Requests**: Data table sorted by duration
- **Log Patterns**: Use Event Analytics pattern detection
- **Pod Resource Usage**: Metrics from kubeletstats

## Monitoring Best Practices

### Log Levels
Ensure your apps log with proper levels:
- `ERROR` - Actionable failures
- `WARN` - Potential issues
- `INFO` - Important events
- `DEBUG` - Detailed troubleshooting

### Structured Logging
Use JSON format for better parsing:
```json
{"timestamp":"2026-01-21T10:30:00Z","level":"ERROR","message":"Database connection failed","service":"api","error":"connection timeout"}
```

### Metric Labels
Add useful labels to your metrics:
- `service` - Service name
- `environment` - dev/staging/prod
- `version` - Application version

## Alerting

OpenSearch has **built-in alerting** via the Alerting plugin:

### Create Trace-Based Alerts

1. Go to **Alerting** → **Monitors**
2. Create monitor for high latency:
   ```
   Index: otel-v1-apm-span-*
   Condition: Average duration > 1000ms
   Action: Send Slack/email notification
   ```

### Create Log-Based Alerts

1. Monitor error logs:
   ```
   Index: ss4o_logs-*
   Condition: Count of level="ERROR" > 10 in 5 minutes
   Action: Create incident in PagerDuty
   ```

### Notification Channels

Configure destinations:
- **Slack** - Webhook integration
- **Email** - SMTP configuration
- **PagerDuty** - API key integration
- **Custom Webhook** - Any HTTP endpoint

## Troubleshooting

### Logs not appearing
```bash
# Check OTel Collector is running (DaemonSet)
kubectl get daemonset -l app.kubernetes.io/name=observability

# Check OTel Collector pods
kubectl get pods -l app.kubernetes.io/component=otel-collector

# Check OTel Collector logs (look for filelog receiver)
kubectl logs -l app.kubernetes.io/component=otel-collector --tail=100 | grep -i filelog

# Check Data Prepper
kubectl get pods -l app.kubernetes.io/component=data-prepper
kubectl logs -l app.kubernetes.io/component=data-prepper --tail=50

# Verify OpenSearch indices
kubectl exec -n {{ .Release.Namespace }} {{ .Release.Name }}-ibm-devopsplan-prod-opensearch-0 -- \
  curl -k -u admin:admin https://localhost:9200/_cat/indices | grep ss4o_logs
```

### Observability not enabled
```bash
# Check if observability subchart is enabled
helm get values {{ .Release.Name }} | grep -A 5 observability

# Enable it
helm upgrade {{ .Release.Name }} . --set observability.enabled=true
```

### Traces not appearing
```bash
# Check Data Prepper is receiving traces
kubectl logs -l app.kubernetes.io/component=data-prepper --tail=50 | grep trace

# Check trace indices exist
kubectl exec {{ .Release.Name }}-ibm-devopsplan-prod-opensearch-0 -- \
  curl -k -u admin:admin https://localhost:9200/_cat/indices | grep otel-v1-apm

# Test sending a trace
kubectl run -it --rm debug --image=curlimages/curl --restart=Never -- \
  curl -X POST http://{{ .Release.Name }}-observability-otel-collector:4318/v1/traces \
  -H "Content-Type: application/json" \
  -d '{"resourceSpans":[{"resource":{"attributes":[{"key":"service.name","value":{"stringValue":"test-service"}}]},"scopeSpans":[{"spans":[{"traceId":"5b8aa5a2d2c872e8321cf37308d69df2","spanId":"051581bf3cb55c13","name":"test-span","kind":1,"startTimeUnixNano":"1609459200000000000","endTimeUnixNano":"1609459201000000000"}]}]}]}'
```

### Metrics not appearing
```bash
# Check OTel Collector metrics pipeline
kubectl logs -l app.kubernetes.io/component=otel-collector --tail=100 | grep -i metrics

# Verify pod annotations
kubectl get pods -n <your-namespace> -o jsonpath='{range .items[*]}{.metadata.name}{"\t"}{.metadata.annotations.prometheus\.io/scrape}{"\n"}{end}'

# Check Data Prepper metrics processing
kubectl logs -l app.kubernetes.io/component=data-prepper --tail=50 | grep metrics
```

### Can't access OpenSearch Dashboards
```bash
# Check dashboard pod
kubectl get pods -n observability -l app.kubernetes.io/name=opensearch-dashboards

# Check ingress
kubectl get ingress -n observability

# Port-forward for testing
kubectl port-forward -n observability svc/opensearch-dashboards 5601:5601
# Then access: http://localhost:5601/opensearch-dashboards
```

## Resource Requirements

## Resource Requirements

**Minimum for demo:**
- Data Prepper: 500m CPU, 1GB RAM
- OTel Collector: 300m CPU, 512MB RAM per node

**Production recommendations:**
- Data Prepper: 1 CPU, 2GB RAM, 2 replicas
- OTel Collector: 500m CPU, 1GB RAM per node

Configure in `values.yaml`:
```yaml
observability:
  dataPrepper:
    replicaCount: 2
    resources:
      requests:
        cpu: 1
        memory: 2Gi
  otelCollector:
    resources:
      requests:
        cpu: 500m
        memory: 1Gi
```

## DORA Metrics Tracking

Use OpenSearch Observability to track key DevOps metrics:

### 1. Deployment Frequency
**Using Trace Analytics:**
- Tag deployments with version in traces
- Query: `service.version` changes over time
- Create visualization in Event Analytics

**Using Logs:**
```
source = ss4o_logs-* | where log contains "deployment" and level = "INFO" 
| stats count() by bin(@timestamp, 1d)
```

### 2. Lead Time for Changes
**Correlate git commits with deployments:**
- Add git.commit.sha to trace attributes
- Track time from commit to first production trace
- Use Application Analytics to correlate

**Query example:**
```
index=otel-v1-apm-span-* | where git.commit.sha exists 
| stats min(@timestamp) by git.commit.sha
```

### 3. Mean Time to Recovery (MTTR)
**Using Trace Analytics:**
- Monitor error rate spikes in Dashboard
- Track time from error spike to resolution
- Set up alerts for error rate > threshold

**Query for incidents:**
```
source = otel-v1-apm-span-* | where status.code = "ERROR"
| stats count() by bin(@timestamp, 5m)
| where count > 10
```

### 4. Change Failure Rate
**Monitor post-deployment errors:**
- Compare error rates before/after deployment
- Use service.version to filter
- Calculate % of deployments causing errors

**Query example:**
```
source = otel-v1-apm-span-* 
| where @timestamp > now() - 1h
| stats count(status.code = "ERROR") as errors, count() as total by service.version
| eval failure_rate = errors/total*100
```

### Creating DORA Dashboards

1. Go to **Dashboard** → **Create**
2. Add panels for each metric
3. Use PPL or SQL queries from above
4. Set refresh interval (1 hour recommended)
5. Share with team

## Next Steps

1. **Set up retention policies** - Configure index lifecycle management
2. **Create alerts** - Set up monitoring for critical errors
3. **Build dashboards** - Create visualizations for your key metrics
4. **Instrument applications** - Add tracing to your microservices
5. **Document runbooks** - Link alerts to troubleshooting guides

## Cleanup

To remove the observability stack:

```bash
kubectl delete deployment data-prepper -n observability
kubectl delete svc data-prepper -n observability
kubectl delete configmap data-prepper-config -n observability
helm uninstall opentelemetry-collector -n observability
helm uninstall opensearch-dashboards -n observability
helm uninstall opensearch -n observability
kubectl delete namespace observability
```

## Best Practices

### 1. Sampling Strategy
For high-volume traces, configure sampling in your apps:
```yaml
# Keep 10% of traces, all errors
OTEL_TRACES_SAMPLER=parentbased_traceidratio
OTEL_TRACES_SAMPLER_ARG=0.1
```

### 2. Log Levels in Production
- Use INFO as default
- Enable DEBUG only for specific services
- Always log ERRORs with full context

### 3. Cardinality Management
Avoid high-cardinality labels in metrics:
- ❌ user_id, session_id, trace_id
- ✅ service, environment, status_code

### 4. Retention Policies
Configure index lifecycle management:
```bash
# Keep hot data 7 days, warm 30 days, delete after 90 days
PUT _plugins/_ism/policies/logs-policy
{
  "policy": {
    "description": "Log retention policy",
    "default_state": "hot",
    "states": [...]
  }
}
```

### 5. Resource Limits
Set appropriate limits to prevent OOM:
- OTel Collector: `memory_limiter` processor at 80%
- Data Prepper: Batch size limits
- OpenSearch: Circuit breakers configured

## References

- [OpenSearch Observability Plugin](https://opensearch.org/docs/latest/observing-your-data/)
- [Data Prepper Documentation](https://opensearch.org/docs/latest/data-prepper/)
- [OpenTelemetry Documentation](https://opentelemetry.io/docs/)
- [Simple Schema for Observability (SS4O)](https://github.com/opensearch-project/opensearch-catalog/tree/main/docs/schema)
- [Trace Analytics](https://opensearch.org/docs/latest/observing-your-data/trace/index/)
- [DORA Metrics](https://www.devops-research.com/research.html)
- [PPL Query Language](https://opensearch.org/docs/latest/search-plugins/sql/ppl/index/)

## What's Different from Basic Setup?

This setup provides **native OpenSearch Observability** instead of basic log aggregation:

| Feature | Basic Setup | Native Observability |
|---------|-------------|---------------------|
| Log Collection | ✅ Fluent Bit | ✅ OTel Collector |
| Metrics | ✅ Prometheus scraping | ✅ Prometheus + kubelet + host |
| Traces | ⚠️ Debug only | ✅ Full trace analytics |
| Service Maps | ❌ Not available | ✅ Automatic generation |
| Log-Trace Correlation | ❌ Manual | ✅ Automatic via trace ID |
| Pre-built Dashboards | ❌ None | ✅ Trace Analytics dashboard |
| Data Format | Custom | SS4O (standardized) |
| Alerting | Manual setup | Built-in monitors |
| Pattern Detection | Manual queries | Event Analytics |

The native approach follows OpenSearch's **official observability path** with Data Prepper as the recommended processor.
