#!/bin/bash
#
# DevOps Loop - Reinstallation Script
#
# This script focuses on reinstall-specific tasks and calls the main installation script
# for common functionality.

set -e


NAMESPACE=
if [ -z "$NAMESPACE" ]; then
  echo "ERROR: NAMESPACE not set."
  exit 1
fi

HELM_NAME=
if [ -z "$HELM_NAME" ]; then
  echo "ERROR: HELM_NAME not set."
  exit 1
fi

LOOP_VERSION=2.0.100

ADDITIONAL_HELM_OPTIONS=""

check_mongodb() {  
  MONGO_HELM_RELEASE_NAME="${MONGO_HELM_RELEASE_NAME:-devops-loop-mongo}"
      
  if kubectl get secret mongodb-url-secret --namespace ${NAMESPACE} > /dev/null 2>&1; then
      kubectl delete secret mongodb-url-secret --namespace ${NAMESPACE}
  fi
  
  if kubectl get pvc ${MONGO_HELM_RELEASE_NAME}-mongodb -n ${NAMESPACE} > /dev/null 2>&1; then
    export MONGO_ADDITIONAL_INSTALL_OPTIONS="${MONGO_ADDITIONAL_INSTALL_OPTIONS} \
      --set persistence.existingClaim=${MONGO_HELM_RELEASE_NAME}-mongodb \
      --set persistence.enabled=true \
      --set volumePermissions.enabled=true \
      --set architecture=standalone"
  fi
}

run_reinstall() {  
  check_mongodb  
  
  MONGO_CHART_VERSION="${MONGO_CHART_VERSION:-14.13.0}"
  MONGO_IMAGE_TAG="${MONGO_IMAGE_TAG:-6.0}"
  MONGO_IMAGE_REPO="${MONGO_IMAGE_REPO:-bitnamilegacy/mongodb}"
  MONGO_HELM_RELEASE_NAME="${MONGO_HELM_RELEASE_NAME:-devops-loop-mongo}"
  MONGO_NAMESPACE="${MONGO_NAMESPACE:-${NAMESPACE}}"
  MONGO_PVC_SIZE=${MONGO_PVC_SIZE:-20Gi}
  
  helm repo add bitnami https://charts.bitnami.com/bitnami --force-update 1> /dev/null

  MONGO_INSTALL_OPTIONS="\
    --set image.repository=${MONGO_IMAGE_REPO} \
    --set image.tag=${MONGO_IMAGE_TAG} \
    --set persistence.size=${MONGO_PVC_SIZE}
  "
    
  if [ -n "${RWO_STORAGE_CLASS}" ]; then
    MONGO_INSTALL_OPTIONS="${MONGO_INSTALL_OPTIONS} --set persistence.storageClass=${RWO_STORAGE_CLASS}"
  fi
  
  if [ -n "${MONGO_ADDITIONAL_INSTALL_OPTIONS}" ]; then
    MONGO_INSTALL_OPTIONS="${MONGO_INSTALL_OPTIONS} ${MONGO_ADDITIONAL_INSTALL_OPTIONS}"
  fi

  helm upgrade --install ${MONGO_HELM_RELEASE_NAME} \
    --version ${MONGO_CHART_VERSION} \
    ${MONGO_INSTALL_OPTIONS} \
    --namespace=${MONGO_NAMESPACE} \
    --create-namespace \
    bitnami/mongodb 1> /dev/null || { echo "Failed to install MongoDB"; return 1; }
    
  MONGODB_ROOT_PASSWORD=$(kubectl  get secret --namespace ${NAMESPACE} ${MONGO_HELM_RELEASE_NAME}-mongodb -o jsonpath="{.data.mongodb-root-password}" | base64 -d)
  
  MONGO_URL="mongodb://root:${MONGODB_ROOT_PASSWORD}@${MONGO_HELM_RELEASE_NAME}-mongodb:27017/admin"

  kubectl create secret generic mongodb-url-secret --namespace ${NAMESPACE} --from-literal=password="${MONGO_URL}" 1> /dev/null || { echo "Failed to create MongoDB secret"; return 1; }
  
  helm upgrade --install ${HELM_NAME} ibm-helm/ibm-devops-loop --version ${LOOP_VERSION} \
  ${ADDITIONAL_HELM_OPTIONS} \
  -n ${NAMESPACE} \
  --reuse-values || return 1

  echo
  echo "Re-installation process completed successfully!"

}

run_reinstall
