#!/bin/bash

#=============================================================================
# MinIO Installation Script
#
# This script automates the installation of MinIO
#
# Instructions:
# 1. Place 'minio.yaml' and 'minio-oc.yaml' in the same directory.
# 2. Edit the variables in the "CONFIGURATION" section below.
# 3. Run the script: ./install-minio.sh
#=============================================================================

set -e

# ----------------------- CONFIGURATION -----------------------
#               ** EDIT THE VALUES IN THIS SECTION **

# 1. CLUSTER ENVIRONMENT & STORAGE
#    The name of the StorageClass for MinIO's persistent volume.
#    This MUST exist in your target cluster.
#    Examples: "ibmc-block-gold", "ibmc-vpc-block-10iops-tier", "nfs-client"
#OBJECT_STORAGE_CLASS="ibmc-vpc-block-10iops-tier"
OBJECT_STORAGE_CLASS=

# 2. MINIO NETWORKING
#    How Velero connect to MinIO .
#    Options:
#      "route"   -> For OpenShift clusters.
#      "service" -> For IKS, standard Kubernetes (on-prem/VM) clusters using a NodePort service.
# MINIO_CONNECTION_TYPE="service"
MINIO_CONNECTION_TYPE=

# 3. CLUSTER DOMAIN NAME
#   Example: "apps.my-openshift-cluster.com"
#MINIO_HOST_NAME="platform-test-ikstest.us-east.containers.appdomain.cloud"
MINIO_HOST_NAME=

# 4. MINIO CREDENTIALS
#    The access key and secret key for MinIO.
#    Ensure the access key is at least 3 characters and the secret key at least 8.
#MINIO_ACCESS_KEY="MinioLoops"
#MINIO_SECRET_KEY="MinioLoops123"
MINIO_ACCESS_KEY=
MINIO_SECRET_KEY=
MINIO_BUCKET_NAME=

# ----------------------- END OF CONFIGURATION -----------------------

# --- Utility Functions (Do not edit) ---
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'
handle_error() { echo -e "${RED}ERROR: An error occurred at line $1${NC}"; exit 1; }
trap 'handle_error $LINENO' ERR
log_section() { echo -e "\n${BLUE}====== $1 ======${NC}\n"; }
log_success() { echo -e "${GREEN}✓ $1${NC}"; }
log_info()    { echo -e "$1"; }
log_warning() { echo -e "${YELLOW}⚠ $1${NC}"; }
log_error()   { echo -e "${RED}$1${NC}"; }

log_section "Starting MinIO Installation"

# 1. Detect Environment
IS_OPENSHIFT=$(kubectl api-versions | grep -q "route.openshift.io" && echo true || echo false)
if [ "$IS_OPENSHIFT" = true ]; then
    log_info "OpenShift cluster detected."
else
    log_info "Standard Kubernetes cluster detected."
fi

# 2. Prepare Namespaces
log_info "Ensuring namespaces 'loops-minio' exist..."
kubectl create namespace loops-minio --dry-run=client -o yaml | kubectl apply -f -


# 3. Apply MinIO Manifests and configure Networking
log_info "Templating and applying MinIO manifests..."
if [ "$MINIO_CONNECTION_TYPE" = "service" ] && [ "$IS_OPENSHIFT" = false ]; then
    cp $(dirname "$0")/minio.yaml $(dirname "$0")/minio.yaml.bak
    sed -i "s/##OBJECT_STORAGE_CLASS##/$OBJECT_STORAGE_CLASS/g" minio.yaml
    sed -i "s/##MINIO_ACCESS_KEY##/$MINIO_ACCESS_KEY/g" minio.yaml
    sed -i "s/##MINIO_SECRET_KEY##/$MINIO_SECRET_KEY/g" minio.yaml
    kubectl apply -f minio.yaml
    log_success "MinIO manifests applied (Deployment, Service, Secret, PVC configured)"
fi

if [ "$MINIO_CONNECTION_TYPE" = "route" ] && [ "$IS_OPENSHIFT" = true ]; then
    cp $(dirname "$0")/minio-route.yaml  $(dirname "$0")/minio-oc.yaml.bak
    sed -i "s/##OBJECT_STORAGE_CLASS##/$OBJECT_STORAGE_CLASS/g" minio-oc.yaml
    sed -i "s/##MINIO_ACCESS_KEY##/$MINIO_ACCESS_KEY/g" minio-oc.yaml
    sed -i "s/##MINIO_SECRET_KEY##/$MINIO_SECRET_KEY/g" minio-oc.yaml
    sed -i "s/minio-ntwk-api/minio-api.$MINIO_HOST_NAME/g" minio-oc.yaml
    sed -i "s/minio-ntwk-ui/minio-ui.$MINIO_HOST_NAME/g" minio-oc.yaml
    kubectl apply -f minio-oc.yaml
    log_success "MinIO manifests applied (Deployment, Service, Secret, PVC, and Route configured)"
fi

# 4. Wait for MinIO to be ready
log_info "Waiting for MinIO deployment to be ready..."
kubectl wait --for=condition=available --timeout=300s deployment/minio -n loops-minio
log_success "MinIO is running."

# 5. Determine the correct S3 URL (internal) and public URL (external)
if [ "$MINIO_CONNECTION_TYPE" = "route" ]; then
    S3_URL_PUBLIC="https://minio-api.${MINIO_HOST_NAME}"
    S3_URL_INTERNAL="https://minio-api.${MINIO_HOST_NAME}"
else # service using NodePort
    NODE_PORT=$(kubectl get svc minio-service -n loops-minio -o jsonpath='{.spec.ports[?(@.name=="api")].nodePort}')
    NODE_IP=$(kubectl get nodes -o jsonpath='{.items[0].status.addresses[?(@.type=="InternalIP")].address}')
    S3_URL_PUBLIC="http://${NODE_IP}:${NODE_PORT}"
    S3_URL_INTERNAL="http://minio-service.loops-minio.svc.cluster.local:9000"
fi

log_section "Installation Summary"
echo "✅ MinIO installed in namespace: loops-minio"
echo "✅ MinIO public URL: $S3_URL_PUBLIC"
echo "✅ MinIO api access URL: $S3_URL_INTERNAL"

echo
# 6. Create Bucket 
echo "To create bucket for velero backup..."
MINIO_POD=$(kubectl get pods -n loops-minio -l app=minio -o jsonpath='{.items[0].metadata.name}')
echo "Enable port-forward to MinIO pod and create bucket manually."
echo "kubectl port-forward --address 0.0.0.0 pod/$MINIO_POD -n loops-minio 9000:9000 9090:9090" 
echo "Access MinIO web UI at: http://localhost:9090 (Username: $MINIO_ACCESS_KEY, Password: $MINIO_SECRET_KEY)"
