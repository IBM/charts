# Backup and Restore - DevOps Loop

## Overview

This guide provides instructions for creating backups of the DevOps Loop application's data. Our strategy uses **Velero** to capture all necessary persistent data and store into object store like AWS S3, and MinIO.

Due to the different types of storage used by the application, we employ a hybrid backup approach:
* **CSI Snapshots:** For fast, efficient, block-level backups of volumes on block storage.
* **fs-volume Backups:** For volumes on file storage (which does not support snapshots), Velero performs a pod copy.

---
## Summary and Best Practices

For a successful backup and restore strategy, always remember the following:

-   **Test Your Restores:** Periodically test your entire backup and restore process in a non-production environment to ensure it works as expected.
-   **Know Your Storage:** Understand which volumes support CSI snapshots and which require file-system volume backups via pod annotations.
-   **Database Integrity:** For critical databases, supplement Velero backups with backups taken using native, database-vendor-recommended tools. This guarantees data consistency.
-   **Backup Configuration:** Always keep a copy of your Helm `values.yaml` file or any other deployment configurations alongside your Velero backups.
-   **MinIO as Object Store:** This guide uses MinIO for object storage for reference purpose, but you can configure Velero to use other cloud providers' object storage solutions (e.g., AWS S3).
---
## Prerequisites

-   Your IBM DevOps Loop application should be running and healthy in the `devops-loop` namespace.
-   Your cluster's block storage classes must have a corresponding `VolumeSnapshotClass` configured for CSI snapshots to work.
-   You must have `cluster-admin` permissions on the Kubernetes cluster.
-   The following CLI tools must be installed locally: `kubectl`, `helm`, and the CLI for your cloud provider (e.g., `ibmcloud`, `aws`).

---
## 1. Installation: MinIO

**NOTE**: If you already have an object storage solution configured (like AWS S3), you can skip this step.
This procedure uses a script to install MinIO.

> ⚠️ **Configuring MinIO in on-prem/VM environments**
>
> In order to make MinIO accessible to Velero, 
> The MiniIO service should be exposed via service with type NodePort.
> However, this approach is less secure and not recommended for production environments.
> If you choose to use this approach, ensure that your network policies and firewall rules are configured to restrict access to trusted sources only.
>
> The MinIO installation script provided here is intended for reference purposes only.
> It may require modifications to fit your specific environment and security requirements.
> Always follow best practices for securing MinIO, including setting up proper access controls and encryption.



Before running the installation script, it requires to fill in configuration details.
Run the installation script:
```bash
./ibm-devops-loop/scripts/backup-restore/install-minio.sh
```
On successful installation, the script will output the MinIO access credentials and endpoint URL.
Make sure to save these credentials securely, as they will be needed for configuring Velero.

**Create a Bucket for velero backup:**
```bash
# Start port-forwarding to access MinIO locally
kubectl port-forward --address 0.0.0.0 pod/minio -n loops-minio 9000:9000 9090:9090

# Use MinIO Web UI to create a bucket
# Open your web browser and navigate to http://localhost:9090
# Log in using the access key and secret key provided by the installation script
# Create a new bucket named "loops-backup" (or any name you prefer)
```

---

## 2. Installation: Velero

This procedure uses a script to install Velero v1.16.1 server and Velero CLI.

Before running the installation script, it requires to fill in configuration details.
Run the installation script:
```bash
./ibm-devops-loop/scripts/backup-restore/install-velero.sh
```

---
## 3. Backup Procedure


### Understanding the Two Backup Methods

The DevOps Loop application uses two types of storage, and we must back them up differently.

1.  **Block Storage (Automatic Snapshots):** Most data resides on block storage. Velero backs this up automatically using fast and reliable **CSI snapshots**.
2.  **File Storage (Manual Annotation Required):** Some components use file storage, which does not support snapshots. To solve this, Velero performs a **fs-volume backup**. We must manually enable this by adding a special **annotation** to the application pods.

### Step 3.1: Annotate Pods for fs-volume Backup

Before running the backup, you must annotate the pods that use file storage. This annotation tells Velero to perform a fs-volume backup of pods to copy the data within their volumes.

The following script will automatically find the correct pods and add the required annotations:
```bash
./ibm-devops-loop/scripts/backup-restore/annotate-pods.sh
```
> **Note:** If this step is missed, **data on file storage will not be backed up.**

### Step 3.2: Run the Velero Backup

This command includes all PVCs, PVs, Secrets

```bash
# Command Syntax
velero backup create <BACKUP_NAME> --include-namespaces devops-loop --include-resources persistentvolumeclaims,persistentvolumes,secrets -n velero

# Example
velero backup create data-only-backup --include-namespaces devops-loop --include-resources persistentvolumeclaims,persistentvolumes,secrets -n velero
```

> ⚠️ **Critical for Data Integrity**
>
> For databases, it is strongly recommended to perform a backup using native database tools in addition to the Velero backup. This ensures your data is in a fully consistent state before Velero captures the volume.

---
## 4. Restore Procedure

This command restores an application from a previously created Velero backup.

```bash
# Command Syntax
velero restore create <RESTORE_NAME> --from-backup <BACKUP_NAME> -n velero

# Example
velero restore create restore-data-only-backup --from-backup data-only-backup -n velero
```

---
## 5. Re-installing the Application

Before triggering the re-install process, make sure the velero restore process completed successfully.

Run this script to reinstall the application using Helm:
```bash
./ibm-devops-loop/scripts/backup-restore/reinstall-devops-loop.sh
```

### ❗️ Critical: Handling PersistentVolume Size Errors

During a reinstall or Helm upgrade, you may encounter an error if the default volume size in the Helm chart is smaller than the size of the volume you are restoring.

To prevent this, you must override the default sizes using Helm's `--set` options in the reinstall script.

```bash
# Example of Helm options to set correct PVC sizes
ADDITIONAL_HELM_OPTIONS="\
--set ibm-devops-build.volumes.conf.storage=10Gi \
--set ibm-devops-build.volumes.libExt.storage=10Gi \
--set ibm-devops-build.volumes.plugin.storage=10Gi \
--set ibm-devopsplan-prod.persistence.analytics.config.size=10Gi \
--set ibm-devopsplan-prod.persistence.analytics.share.size=10Gi \
--set ibm-devopsplan-prod.persistence.search.config.size=10Gi \
--set ibm-devopsplan-prod.persistence.search.share.size=10Gi"
```

---
## 6. Troubleshooting

Use these commands to check the status and logs of your backup and restore jobs.

### Backup Commands
```bash
# Check the status of all backups
velero get backup

# Get detailed information about a specific backup
velero describe backup <backup-name>

# View the logs for a specific backup
velero backup logs <backup-name>
```

### Restore Commands
```bash
# Check the status of all restores
velero get restore

# Get detailed information about a specific restore
velero describe restore <restore-name>

# View the logs for a specific restore
velero restore logs <restore-name>
```