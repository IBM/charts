#!/bin/bash

#=============================================================================
# Velero Installation Script
#
# This script automates the installation of Velero CLI and Velero Server.
#
# Instructions:
# 1. Edit the variables in the "CONFIGURATION" section below.
# 2. Run the script: ./install-velero.sh
#=============================================================================

set -e

# ----------------------- CONFIGURATION -----------------------
#               ** EDIT THE VALUES IN THIS SECTION **

# OBJECT STORE PROVIDER
#    Set the object store provider to one of the following:
#    "aws"   -> For AWS S3 or MinIO (using AWS S3)
#    "other" -> For other S3-compatible storage (not covered in this script)

# 1. AWS/MinIO CONFIGURATION
#    Uncomment and set the following variables to use AWS S3 as the object store.
#    Ensure the AWS CLI is installed and configured before running this script.
#    If using MinIO, ensure it is installed and accessible.
#
#
# If using AWS S3, uncomment and set the following variables
# OBJECT_STORE_PROVIDER="aws"
# AWS_REGION="your-aws-region"
# OBJECT_STORAGE_VELERO_PLUGIN="velero/velero-plugin-for-aws:v1.12.1"
# S3_API_URL="http://s3.us-east-1.amazonaws.com"
OBJECT_STORE_PROVIDER=
AWS_REGION=
OBJECT_STORAGE_VELERO_PLUGIN="velero/velero-plugin-for-aws:v1.12.1"
S3_API_URL=

# 2. OBJECT STORAGE CONFIGURATION
#    The name of the bucket to use for backups.
#    This bucket MUST exist in your object store.
#    Examples: "my-velero-bucket", "loops-backup"
#AWS_BUCKET_NAME="my-velero-bucket"
AWS_ACCESS_KEY_ID=
AWS_SECRET_ACCESS_KEY=
BUCKET_NAME=

# ----------------------- END OF CONFIGURATION -----------------------

# --- Utility Functions (Do not edit) ---
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'
handle_error() { echo -e "${RED}ERROR: An error occurred at line $1${NC}"; exit 1; }
trap 'handle_error $LINENO' ERR
log_section() { echo -e "\n${BLUE}====== $1 ======${NC}\n"; }
log_success() { echo -e "${GREEN}✓ $1${NC}"; }
log_info()    { echo -e "$1"; }
log_warning() { echo -e "${YELLOW}⚠ $1${NC}"; }
log_error()   { echo -e "${RED}$1${NC}"; }

log_section "Starting Velero Installation"

# 1. Detect Environment
IS_OPENSHIFT=$(kubectl api-versions | grep -q "route.openshift.io" && echo true || echo false)
if [ "$IS_OPENSHIFT" = true ]; then
    log_info "OpenShift cluster detected."
else
    log_info "Standard Kubernetes cluster detected."
fi

# 2. Prepare Namespaces
log_info "Ensuring namespaces 'velero' exist..."
kubectl create namespace velero --dry-run=client -o yaml | kubectl apply -f -


# 3. Prepare and Install Velero
log_section "Installing Velero CLI"
  
wget -q https://github.com/vmware-tanzu/velero/releases/download/v1.16.1/velero-v1.16.1-linux-amd64.tar.gz
tar -xf velero-v1.16.1-linux-amd64.tar.gz
sudo mv velero-v1.16.1-linux-amd64/velero /usr/local/bin/
rm -rf velero-v1.16.1-linux-amd64*

# Verify installation
velero version --client-only
log_success "Velero CLI installed successfully"

log_section "Installing Velero Server"

# 4. Create credentials file
cat > credentials-velero <<EOF
[default]
aws_access_key_id=${AWS_ACCESS_KEY_ID}
aws_secret_access_key=${AWS_SECRET_ACCESS_KEY}
EOF

# 5. Install Velero server
if [ "$OBJECT_STORE_PROVIDER" = "aws" ]; then
  velero install \
  --features=EnableCSI \
  --provider $OBJECT_STORE_PROVIDER \
  --plugins $OBJECT_STORAGE_VELERO_PLUGIN \
  --bucket $BUCKET_NAME \
  --secret-file ./credentials-velero \
  --snapshot-location-config region=$AWS_REGION \
  --backup-location-config region=$AWS_REGION,s3ForcePathStyle="true",s3Url="${S3_API_URL}" \
  --use-volume-snapshots=true \
  --use-node-agent \
  --namespace velero
else
  log_error "Unsupported OBJECT_STORE_PROVIDER: $OBJECT_STORE_PROVIDER"
  exit 1
fi

# 6. Add necessary privileges for OpenShift
if [ "$IS_OPENSHIFT" = true ]; then
  log_info "Adding privileged SCC to Velero service accounts..."
  oc adm policy add-scc-to-user privileged -z velero -n velero
  oc adm policy add-scc-to-user privileged -z velero-node-agent -n velero
  
  log_info "Patching node-agent DaemonSet for privileged access..."
  kubectl patch daemonset/node-agent -n velero --type json \
    -p='[{"op":"add","path":"/spec/template/spec/containers/0/securityContext","value":{"privileged":true,"runAsUser":0}}]'
  
  log_success "Velero security context configured for OpenShift"
fi

# 7. Wait for Velero to be ready
log_info "Waiting for Velero deployment to be ready..."
kubectl wait --for=condition=available --timeout=300s deployment/velero -n velero
log_success "Velero is running."
log_success "Velero installation complete."

log_section "Installation Summary"
echo "✅ Velero installed in namespace: velero"


