#!/bin/bash
# This script removes the Velero backup annotation from all pods in a specified namespace.

# Prompt the user for the namespace
read -p "Enter the namespace to remove Velero annotations from: " ns

# Check if the namespace was provided
if [ -z "$ns" ]; then
  echo "Error: You must enter a namespace."
  exit 1
fi

echo "Searching for pods with Velero backup annotations in namespace '$ns'..."

# Find all pods that have the specific annotation and loop through them
for pod in $(kubectl get pods -n "$ns" -o jsonpath="{.items[?(@.metadata.annotations['backup.velero.io/backup-volumes'])].metadata.name}"); do
  echo "Removing annotation from pod '$pod'..."
  # Remove the annotation by specifying the key with a minus sign at the end
  kubectl annotate pod "$pod" -n "$ns" backup.velero.io/backup-volumes-
done

echo "Done. All Velero backup annotations have been removed from pods in namespace '$ns'."