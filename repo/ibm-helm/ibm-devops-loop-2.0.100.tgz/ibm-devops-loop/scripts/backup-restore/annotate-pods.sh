#!/bin/bash

# This script scans all running pods in a specified namespace and annotates those
# that use PersistentVolumeClaims (PVCs) associated with a given StorageClass (which do not have snapshot support).
# The annotation added is 'backup.velero.io/backup-volumes' with the names of the volumes that should be backed up.
# Usage: ./annotate-pods.sh <namespace> <file-storage-class>
# Example: ./annotate-pods.sh my-namespace my-storage-class


if [ -z "$1" ] && [ -z "$2" ]; then
  echo "Usage: $0 <namespace> <file-storage-class>"
  exit 1
fi

ns=$1
FILE_STORAGE_CLASS=$2

echo " Starting scan in namespace '${ns}' for pods using StorageClass '${FILE_STORAGE_CLASS}'..."

kubectl get pods -n ${ns} --field-selector=status.phase=Running -o custom-columns=:metadata.name --no-headers | while read POD_NAME; do
  # For each pod, get the list of PVCs it uses.
  PVC_NAMES=$(kubectl get pod ${POD_NAME} -n ${ns} -o jsonpath='{.spec.volumes[*].persistentVolumeClaim.claimName}')

  if [ -z "$PVC_NAMES" ]; then   
    continue
  fi

  VOLUMES_TO_ANNOTATE=""

  for PVC_NAME in $PVC_NAMES; do
    PVC_STORAGE_CLASS=$(kubectl get pvc ${PVC_NAME} -n ${ns} -o jsonpath='{.spec.storageClassName}')

    if [ "$PVC_STORAGE_CLASS" == "$FILE_STORAGE_CLASS" ]; then
      # If it matches, we need to find the corresponding 'volume' name inside the pod spec.
      VOLUME_NAME=$(kubectl get pod ${POD_NAME} -n ${ns} -o jsonpath="{.spec.volumes[?(@.persistentVolumeClaim.claimName=='${PVC_NAME}')].name}")
      
      if [ -n "$VOLUMES_TO_ANNOTATE" ]; then
        VOLUMES_TO_ANNOTATE="${VOLUMES_TO_ANNOTATE},${VOLUME_NAME}"
      else
        VOLUMES_TO_ANNOTATE="${VOLUME_NAME}"
      fi
    fi
  done

  # If we found any volumes that need annotation, apply it to the pod.
  if [ -n "$VOLUMES_TO_ANNOTATE" ]; then
    echo "  -> Applying annotation to pod '${POD_NAME}' for volume(s): ${VOLUMES_TO_ANNOTATE}"
    kubectl annotate pod ${POD_NAME} -n ${ns} \
      backup.velero.io/backup-volumes="${VOLUMES_TO_ANNOTATE}" \
      --overwrite  
  fi

done
