
{{- define "global.logging-functions" -}}
log_info() { echo "[$(date -u +%Y-%m-%dT%H:%M:%S.%3NZ)] [info] $@"; }
log_warn() { echo "[$(date -u +%Y-%m-%dT%H:%M:%S.%3NZ)] [warn] $@"; }
log_error() { echo "[$(date -u +%Y-%m-%dT%H:%M:%S.%3NZ)] [error] $@"; }
log_debug() { echo "[$(date -u +%Y-%m-%dT%H:%M:%S.%3NZ)] [log] $@"; }
{{- end -}}