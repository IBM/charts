# Observability Subchart - Installation Guide

## Quick Start

### 1. Enable Observability

Edit your parent chart's `values.yaml`:

```yaml
observability:
  enabled: true
```

### 2. Deploy

```bash
helm upgrade --install my-release . --values values.yaml
```

### 3. Verify Deployment

```bash
# Check all observability pods
kubectl get pods -l app.kubernetes.io/name=observability

# Check Data Prepper logs
kubectl logs -l app.kubernetes.io/component=data-prepper

# Check OTel Collector logs
kubectl logs -l app.kubernetes.io/component=otel-collector
```

### 4. Access Dashboards

Navigate to your existing OpenSearch Dashboards:
- **Trace Analytics**: Observability → Trace Analytics
- **Service Maps**: Observability → Trace Analytics → Services
- **Logs**: Discover → Create pattern `ss4o_logs-*`
- **Metrics**: Discover → Create pattern `ss4o_metrics-*`

## Architecture

```
┌───────────────────────────────────────────────────────────────────────┐
│                       Kubernetes Cluster                               │
│                                                                         │
│  ┌─────────────────────────────┐  ┌─────────────────────────────┐      │
│  │ Application Pod (tenant)    │  │ Application Pod (loop)      │      │
│  │  ┌─────────┐ ┌───────────┐  │  │  ┌─────────┐ ┌───────────┐  │      │
│  │  │  App    │ │ OTel      │  │  │  │  App    │ │ OTel      │  │      │
│  │  │Container│→│ Sidecar   │  │  │  │Container│→│ Sidecar   │  │      │
│  │  └─────────┘ └─────┬─────┘  │  │  └─────────┘ └─────┬─────┘  │      │
│  └────────────────────┼────────┘  └────────────────────┼────────┘      │
│                       │ OTLP                           │ OTLP          │
│                       └───────────────┬───────────────┘               │
│                                       │                               │
│                                       ▼                               │
│            ┌───────────────────────────────────────┐               │
│            │  Central OTel Collector (Deployment)  │               │
│            │  • OTLP receiver                      │               │
│            │  • Receives from all sidecars          │               │
│            └───────────────────┬───────────────────┘               │
│                                   │ OTLP                            │
│                                   ▼                                 │
│            ┌───────────────────────────────────────┐               │
│            │  Data Prepper (Deployment)            │               │
│            │  • Readiness probe on port 21890       │               │
│            │  • Trace pipeline (otel_trace_raw)     │               │
│            │  • Metrics pipeline                   │               │
│            │  • Logs pipeline                      │               │
│            │  • Service map pipeline                │               │
│            └───────────────────┬───────────────────┘               │
│                                   │                                 │
│                                   ▼                                 │
│            ┌───────────────────────────────────────┐               │
│            │ OpenSearch (Existing)                 │               │
│            │ (From ibm-devopsplan-prod)            │               │
│            │  • otel-v1-apm-span-* (traces)         │               │
│            │  • otel-v1-apm-service-map             │               │
│            │  • ss4o_logs-* (logs)                  │               │
│            │  • ss4o_metrics-otel-* (metrics)       │               │
│            └───────────────────────────────────────┘               │
│                                                                         │
└───────────────────────────────────────────────────────────────────────┘
```

**Architecture Notes**: 
- **Sidecar pattern**: Each instrumented application pod has an OTel Collector sidecar that receives telemetry on localhost (4317/4318)
- **Central Collector**: A Deployment-mode OTel Collector aggregates telemetry from all sidecars
- **Data Prepper**: Transforms OTLP data into OpenSearch's native formats with a readiness probe on port 21890 for startup reliability
- **Auto-provisioned**: Index templates and dashboard patterns are automatically created via Helm Jobs

## Configuration Examples

### Minimal (Auto-Discovery)

Uses existing OpenSearch from parent chart:

```yaml
observability:
  enabled: true
```

### Production Configuration

```yaml
observability:
  enabled: true
  
  dataPrepper:
    replicaCount: 2
    resources:
      requests:
        cpu: 1
        memory: 2Gi
      limits:
        cpu: 2
        memory: 4Gi
  
  otelCollector:
    resources:
      requests:
        cpu: 500m
        memory: 1Gi
      limits:
        cpu: 2
        memory: 2Gi
    receivers:
      filelog: true
      prometheus: true
      kubeletstats: true
      hostMetrics: true
```

### Custom OpenSearch

Connect to external OpenSearch:

```yaml
observability:
  enabled: true
  opensearch:
    host: "opensearch.example.com"
    port: 9200
    protocol: https
    existingSecret: "my-opensearch-secret"
    usernameKey: "username"
    passwordKey: "password"
```

### Selective Features

Enable only specific receivers:

```yaml
observability:
  enabled: true
  otelCollector:
    receivers:
      filelog: true        # Collect container logs automatically
      prometheus: false    # Disable Prometheus scraping (use OTLP push instead)
      kubeletstats: true   # Node/pod metrics from kubelet
      hostMetrics: true    # Host-level metrics
```

**Recommendation**: Disable `prometheus` scraping if all your apps send metrics via OTLP. Enable it only for legacy apps without OTel instrumentation.

## Telemetry Collection Strategy

### Sidecar Pattern (Recommended)

Applications send telemetry to their local OTel sidecar on `localhost:4318`:

```yaml
env:
- name: OTEL_EXPORTER_OTLP_ENDPOINT
  value: "http://localhost:4318"
```

**Benefits:**
- ✅ **Reliable local collection** - No network hops within the pod
- ✅ **Service isolation** - Each app has its own collector
- ✅ **Resource attributes** - Sidecar adds `service.name` automatically
- ✅ **Buffering** - Sidecar buffers data during central collector unavailability

### Logs via OTLP (Trace Correlation)

Send ERROR logs via OTLP for automatic trace correlation:

```yaml
# Spring Boot - application.yml
management:
  otlp:
    logs:
      endpoint: http://localhost:4318/v1/logs
```

**Benefits:**
- ✅ **Trace-log correlation** - Errors include `trace_id` and `span_id`
- ✅ **Minimal overhead** - Only errors sent via OTLP (~1-5% of logs)

### Hybrid Pattern: Auto-Send Errors + Span Events (Recommended)

**Problem**: Filelog gives you all logs but no trace correlation (no span_id/trace_id).

**Solution**: Automatically send ERROR logs via OTLP while keeping regular logs in filelog.

#### Step 1: Auto-Send Errors (Minimal Setup)

**Go (Gitea, etc.):**
```go
import (
    "log/slog"
    "go.opentelemetry.io/contrib/bridges/otelslog"
    "go.opentelemetry.io/otel/exporters/otlp/otlplog/otlploggrpc"
    "go.opentelemetry.io/otel/log/global"
    sdklog "go.opentelemetry.io/otel/sdk/log"
)

func setupLogging() {
    // Create OTLP log exporter
    exporter, _ := otlploggrpc.New(context.Background(),
        otlploggrpc.WithEndpoint("my-release-observability-otel-collector:4317"),
        otlploggrpc.WithInsecure(),
    )
    
    // Logger provider that only sends ERROR and above
    loggerProvider := sdklog.NewLoggerProvider(
        sdklog.WithProcessor(
            sdklog.NewBatchProcessor(exporter,
                // Filter: only ERROR severity and above
                sdklog.WithFilter(func(record sdklog.Record) bool {
                    return record.Severity() >= sdklog.SeverityError
                }),
            ),
        ),
    )
    global.SetLoggerProvider(loggerProvider)
    
    // Bridge slog to OTel (optional - if using slog)
    logger := slog.New(otelslog.NewHandler("my-service"))
    slog.SetDefault(logger)
}

// Usage - works with standard logging
log.Println("Regular log")  // → stdout → filelog only
log.Fatal("Database connection failed")  // → stdout + OTLP with trace context!
```

**Spring Boot:**
```yaml
# application.yml
spring:
  application:
    name: my-service

management:
  otlp:
    logs:
      endpoint: http://my-release-observability-otel-collector:4318/v1/logs
  tracing:
    sampling:
      probability: 1.0

# logback-spring.xml
<configuration>
  <!-- Console appender for ALL logs (filelog picks up from stdout) -->
  <appender name="CONSOLE" class="ch.qos.logback.core.ConsoleAppender">
    <encoder>
      <pattern>%d{HH:mm:ss.SSS} [%thread] %-5level %logger{36} - %msg%n</pattern>
    </encoder>
  </appender>

  <!-- OpenTelemetry appender for ERRORS only -->
  <appender name="OTLP" class="io.opentelemetry.instrumentation.logback.appender.v1_0.OpenTelemetryAppender">
    <immediateFlush>false</immediateFlush>
    <!-- This appender automatically includes trace context -->
  </appender>

  <root level="INFO">
    <!-- All logs to console (filelog) -->
    <appender-ref ref="CONSOLE" />
  </root>

  <!-- Only errors to OTLP -->
  <root level="ERROR">
    <appender-ref ref="OTLP" />
  </root>
</configuration>
```

```xml
<!-- pom.xml - add dependency -->
<dependency>
  <groupId>io.opentelemetry.instrumentation</groupId>
  <artifactId>opentelemetry-logback-appender-1.0</artifactId>
  <version>2.0.0-alpha</version>
</dependency>
```

**Raw Java (Log4j2):**
```xml
<!-- log4j2.xml -->
<?xml version="1.0" encoding="UTF-8"?>
<Configuration status="WARN">
  <Appenders>
    <!-- Console appender for ALL logs (filelog collects) -->
    <Console name="Console" target="SYSTEM_OUT">
      <PatternLayout pattern="%d{HH:mm:ss.SSS} [%t] %-5level %logger{36} - %msg%n"/>
    </Console>
    
    <!-- OTLP appender for ERRORS only -->
    <OpenTelemetry name="OpenTelemetryAppender">
      <OtlpGrpcLogExporter endpoint="http://my-release-observability-otel-collector:4317"/>
    </OpenTelemetry>
  </Appenders>
  
  <Loggers>
    <Root level="info">
      <!-- All logs to console -->
      <AppenderRef ref="Console"/>
    </Root>
    
    <!-- Errors also go to OTLP -->
    <Root level="error">
      <AppenderRef ref="OpenTelemetryAppender"/>
    </Root>
  </Loggers>
</Configuration>
```

```xml
<!-- pom.xml -->
<dependency>
  <groupId>io.opentelemetry.instrumentation</groupId>
  <artifactId>opentelemetry-log4j-appender-2.17</artifactId>
  <version>2.0.0-alpha</version>
</dependency>
```

**Python:**
```python
import logging
from opentelemetry import trace
from opentelemetry._logs import set_logger_provider
from opentelemetry.sdk._logs import LoggerProvider, LoggingHandler
from opentelemetry.sdk._logs.export import BatchLogRecordProcessor
from opentelemetry.exporter.otlp.proto.grpc._log_exporter import OTLPLogExporter

# Setup OTel logging
logger_provider = LoggerProvider()
exporter = OTLPLogExporter(
    endpoint="my-release-observability-otel-collector:4317",
    insecure=True
)
logger_provider.add_log_record_processor(BatchLogRecordProcessor(exporter))
set_logger_provider(logger_provider)

# Configure root logger for console (filelog)
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

# Add OTel handler ONLY for ERROR level and above
otel_handler = LoggingHandler(
    level=logging.ERROR,  # Only errors go to OTLP
    logger_provider=logger_provider
)
logging.getLogger().addHandler(otel_handler)

# Usage
logger = logging.getLogger(__name__)
logger.info("Regular log")  # → stdout → filelog only
logger.error("Database error", exc_info=True)  # → stdout + OTLP with trace_id!
```

**Backpressure Configuration:**

**Go:**
```go
// Full configuration with backpressure handling
exporter, _ := otlploggrpc.New(context.Background(),
    otlploggrpc.WithEndpoint("my-release-observability-otel-collector:4317"),
    otlploggrpc.WithInsecure(),
    otlploggrpc.WithTimeout(10*time.Second), // Don't wait forever
)

loggerProvider := sdklog.NewLoggerProvider(
    sdklog.WithProcessor(
        sdklog.NewBatchProcessor(exporter,
            // Backpressure settings
            sdklog.WithMaxQueueSize(8192),           // Buffer size
            sdklog.WithExportTimeout(30*time.Second), // Max export time
            sdklog.WithExportMaxBatchSize(512),       // Batch size
            // Filter: only errors
            sdklog.WithFilter(func(record sdklog.Record) bool {
                return record.Severity() >= sdklog.SeverityError
            }),
        ),
    ),
)
```

**Spring Boot:**
```yaml
# application.yml
management:
  otlp:
    logs:
      endpoint: http://my-release-observability-otel-collector:4318/v1/logs
  metrics:
    export:
      otlp:
        batch-size: 512
        max-queue-size: 8192
        timeout: 10s

# logback-spring.xml
<appender name="OTLP" class="io.opentelemetry.instrumentation.logback.appender.v1_0.OpenTelemetryAppender">
  <!-- Don't block application on slow collector -->
  <immediateFlush>false</immediateFlush>
  <queueSize>8192</queueSize>
  <discardingThreshold>0</discardingThreshold> <!-- Drop oldest when full -->
  <maxFlushTime>30</maxFlushTime> <!-- Seconds -->
</appender>
```

**Raw Java (Log4j2):**
```xml
<OpenTelemetry name="OpenTelemetryAppender">
  <OtlpGrpcLogExporter 
    endpoint="http://my-release-observability-otel-collector:4317"
    timeout="10000"
    compressionEnabled="true"/>
  <!-- Async configuration for backpressure -->
  <AsyncLogger name="com.example" level="error" includeLocation="true">
    <AppenderRef ref="OpenTelemetryAppender">
      <BlockingQueue>
        <capacity>8192</capacity>
        <discardWhenFull>true</discardWhenFull> <!-- Drop, don't block -->
      </BlockingQueue>
    </AppenderRef>
  </AsyncLogger>
</OpenTelemetry>
```

Or using AsyncAppender:
```xml
<Appenders>
  <OpenTelemetry name="OtlpSync" .../>
  
  <Async name="AsyncOTLP" bufferSize="8192">
    <AppenderRef ref="OtlpSync"/>
    <!-- Drop oldest messages when buffer full, don't block -->
    <BlockingQueueFactory class="org.apache.logging.log4j.core.async.ArrayBlockingQueueFactory">
      <Capacity>8192</Capacity>
    </BlockingQueueFactory>
  </Async>
</Appenders>
```

**Python:**
```python
from opentelemetry.sdk._logs.export import BatchLogRecordProcessor

# Configure backpressure handling
exporter = OTLPLogExporter(
    endpoint="my-release-observability-otel-collector:4317",
    insecure=True,
    timeout=10  # seconds - don't wait forever
)

# Batch processor with queue limits
processor = BatchLogRecordProcessor(
    exporter,
    max_queue_size=8192,           # Buffer size
    max_export_batch_size=512,      # Batch size
    schedule_delay_millis=5000,     # Export every 5s
    export_timeout_millis=30000,    # 30s max export time
)

logger_provider = LoggerProvider()
logger_provider.add_log_record_processor(processor)

# Handler that drops logs when queue full (non-blocking)
otel_handler = LoggingHandler(
    level=logging.ERROR,
    logger_provider=logger_provider
)
# Set handler to not block
otel_handler.setLevel(logging.ERROR)
```

**Key Backpressure Settings:**
- **Queue/Buffer Size**: 8192+ for error logs (enough for burst of errors)
- **Export Timeout**: 10-30 seconds (don't wait indefinitely)
- **Batch Size**: 512 records (balance between latency and throughput)
- **Behavior When Full**: **Drop oldest** (don't block application)
- **Async Processing**: Always use async/batch exporters

**Why These Settings:**
- 8192 buffer handles ~10 minutes of errors at high rate
- Timeouts prevent indefinite blocking
- Drop-oldest ensures application never blocks
- Only ~1-5% of logs (errors) means very low backpressure risk

#### Step 2: Span Events for Business Correlation

For non-error correlation points:

```go
func processRequest(ctx context.Context) {
    span := trace.SpanFromContext(ctx)
    
    // Regular detailed logging to stdout (collected by filelog)
    log.Printf("Processing request with params: %+v", complexData)
    
    // Lightweight span event for correlation (minimal, no backpressure concern)
    span.AddEvent("request.processed",
        trace.WithAttributes(
            attribute.String("correlation_key", requestID),
            attribute.String("status", "success"),
        ),
    )
}
```

**Benefits:**
- ✅ Full detailed logs via filelog (no backpressure, no data loss)
- ✅ **Errors automatically correlated to traces** (no extra code)
- ✅ Exception stack traces with trace context
- ✅ Minimal bandwidth - only errors (~1-5% of log volume)
- ✅ Manual span events for key business moments
- ✅ Best of both worlds

**In OpenSearch Dashboards:**
1. View trace in Trace Analytics
2. See span events with correlation keys
3. Jump to Logs (Discover) and search by correlation_key or time range
4. Full detailed logs available

This is the **recommended production pattern** - combines reliability of filelog with trace correlation capability.

## Application Integration

### Instrumenting Applications

#### Go Application (with Sidecar)

```go
package main

import (
    "context"
    "go.opentelemetry.io/otel"
    "go.opentelemetry.io/otel/exporters/otlp/otlptrace/otlptracegrpc"
    sdktrace "go.opentelemetry.io/otel/sdk/trace"
)

func main() {
    ctx := context.Background()
    
    // Create OTLP exporter - sidecar on localhost
    exporter, err := otlptracegrpc.New(ctx,
        otlptracegrpc.WithEndpoint("localhost:4317"),
        otlptracegrpc.WithInsecure(),
    )
    if err != nil {
        panic(err)
    }
    
    // Create tracer provider
    tp := sdktrace.NewTracerProvider(
        sdktrace.WithBatcher(exporter),
    )
    otel.SetTracerProvider(tp)
    
    // Your application code...
}
```

#### Java (Spring Boot) with Sidecar

Add to `application.yml`:

```yaml
management:
  otlp:
    tracing:
      endpoint: http://localhost:4318/v1/traces  # Sidecar on localhost
  tracing:
    sampling:
      probability: 1.0

spring:
  application:
    name: my-service
```

#### Python Application (with Sidecar)

```python
from opentelemetry import trace
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor

# Configure OTLP exporter - sidecar on localhost
otlp_exporter = OTLPSpanExporter(
    endpoint="localhost:4317",
    insecure=True
)

# Set up tracer provider
trace.set_tracer_provider(TracerProvider())
trace.get_tracer_provider().add_span_processor(
    BatchSpanProcessor(otlp_exporter)
)

# Use tracer in your code
tracer = trace.get_tracer(__name__)
with tracer.start_as_current_span("my-operation"):
    # Your code here
    pass
```

#### Node.js Application (with Sidecar)

```javascript
const { NodeTracerProvider } = require('@opentelemetry/sdk-trace-node');
const { OTLPTraceExporter } = require('@opentelemetry/exporter-trace-otlp-grpc');
const { BatchSpanProcessor } = require('@opentelemetry/sdk-trace-base');

const provider = new NodeTracerProvider();
const exporter = new OTLPTraceExporter({
  url: 'localhost:4317',  // Sidecar on localhost
});

provider.addSpanProcessor(new BatchSpanProcessor(exporter));
provider.register();
```

### Exposing Prometheus Metrics (Legacy Apps Only)

**Note**: This is only needed for apps **without** OpenTelemetry instrumentation. Modern OTel apps send metrics via OTLP (see examples above).

For legacy apps that expose Prometheus `/metrics` endpoints, add annotations:

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: my-app
  annotations:
    prometheus.io/scrape: "true"
    prometheus.io/port: "8080"
    prometheus.io/path: "/metrics"
spec:
  containers:
    - name: app
      image: my-app:latest
      ports:
        - containerPort: 8080
          name: metrics
```

## Post-Installation Tasks

### 1. Create Index Patterns

In OpenSearch Dashboards:

1. Go to **Management** → **Stack Management** → **Index Patterns**
2. Create patterns:
   - `ss4o_logs-*` (for logs)
   - `ss4o_metrics-*` (for metrics)
   - `otel-v1-apm-span-*` (for traces - may be auto-created)

### 2. Import Dashboards

1. Go to **Management** → **Saved Objects**
2. Import provided dashboard definitions (if available)
3. Or use built-in **Trace Analytics** and **Service Maps**

### 3. Set Up Alerts

Create alerts for:
- High error rates in traces
- Latency SLO violations
- Pod restart counts
- Resource utilization thresholds

### 4. Configure Retention

Set up Index State Management (ISM) policies:

```json
{
  "policy": {
    "description": "Delete old logs after 30 days",
    "default_state": "hot",
    "states": [
      {
        "name": "hot",
        "actions": [],
        "transitions": [
          {
            "state_name": "delete",
            "conditions": {
              "min_index_age": "30d"
            }
          }
        ]
      },
      {
        "name": "delete",
        "actions": [
          {
            "delete": {}
          }
        ]
      }
    ]
  }
}
```

## Troubleshooting

### Pods Not Starting

```bash
# Check pod status
kubectl get pods -l app.kubernetes.io/name=observability

# Check events
kubectl get events --sort-by='.lastTimestamp' | grep observability

# Describe pod for details
kubectl describe pod -l app.kubernetes.io/component=data-prepper
```

### No Data in OpenSearch

```bash
# 1. Verify OTel Collector is running
kubectl logs -l app.kubernetes.io/component=otel-collector --tail=50

# 2. Check Data Prepper connectivity to OpenSearch
kubectl exec -it deployment/my-release-observability-data-prepper -- \
  curl -k -u $OPENSEARCH_USERNAME:$OPENSEARCH_PASSWORD \
  https://my-release-ibm-devopsplan-prod-opensearch:9200/_cluster/health

# 3. Send a test trace
kubectl run test-trace --image=curlimages/curl --rm -it -- \
  curl -X POST http://my-release-observability-otel-collector:4318/v1/traces \
  -H "Content-Type: application/json" \
  -d '{"resourceSpans":[{"resource":{"attributes":[{"key":"service.name","value":{"stringValue":"test"}}]},"scopeSpans":[{"spans":[{"traceId":"00112233445566778899aabbccddeeff","spanId":"0011223344556677","name":"test-span","kind":1,"startTimeUnixNano":"1234567890000000000","endTimeUnixNano":"1234567891000000000"}]}]}]}'

# 4. Check indices in OpenSearch
kubectl exec -it deployment/my-release-ibm-devopsplan-prod-opensearch-0 -- \
  curl -k -u admin:admin https://localhost:9200/_cat/indices?v
```

### High Resource Usage

```bash
# Check resource usage
kubectl top pods -l app.kubernetes.io/name=observability

# Reduce resources if needed
# Edit values.yaml and lower CPU/memory requests
```

### Permission Errors

```bash
# Verify RBAC
kubectl get clusterrole my-release-observability
kubectl get clusterrolebinding my-release-observability
kubectl get serviceaccount my-release-observability

# Check SELinux on nodes (if applicable)
# Ensure SELinux is in enforcing mode, not permissive
```

## Uninstallation

To disable observability:

```yaml
observability:
  enabled: false
```

Then upgrade:

```bash
helm upgrade my-release .
```

To completely remove (including data):

```bash
# Delete Helm resources
helm upgrade my-release . --set observability.enabled=false

# Delete indices (CAUTION: This deletes all observability data)
kubectl exec -it deployment/my-release-ibm-devopsplan-prod-opensearch-0 -- \
  curl -X DELETE -k -u admin:admin \
  "https://localhost:9200/ss4o_logs-*,ss4o_metrics-*,otel-v1-apm-*"
```

## Best Practices

1. **Resource Sizing**: Start with defaults, monitor, and adjust based on actual usage
2. **Sampling**: Use sampling for high-traffic applications to reduce costs
3. **Retention**: Set appropriate retention policies based on compliance requirements
4. **Alerting**: Configure alerts for critical observability metrics
5. **Security**: Use TLS and proper authentication in production
6. **Testing**: Test observability stack in non-prod environments first
7. **Documentation**: Document custom dashboards and alert configurations

## Support

For issues:
1. Check logs: `kubectl logs -l app.kubernetes.io/name=observability`
2. Review configuration: `helm get values my-release`
3. Verify templates: `helm template my-release .`
4. Check OpenSearch health: Access Dashboards → Stack Monitoring

## References

- [OpenTelemetry Documentation](https://opentelemetry.io/docs/)
- [OpenSearch Data Prepper](https://opensearch.org/docs/latest/data-prepper/)
- [OpenSearch Observability](https://opensearch.org/docs/latest/observability/)
- [Helm Subcharts](https://helm.sh/docs/chart_template_guide/subcharts_and_globals/)
