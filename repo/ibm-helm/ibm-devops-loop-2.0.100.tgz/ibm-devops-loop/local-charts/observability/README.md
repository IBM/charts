# Observability Subchart

This Helm subchart deploys a complete observability solution using OpenTelemetry and OpenSearch Data Prepper.

## Why a Separate Observability Stack?

This subchart deploys **observability-specific** components that work with your existing OpenSearch:
- **Data Prepper** - Transforms OTel data into OpenSearch formats (Trace Analytics, Service Maps, SS4O schema)
- **OTel Collector** - Collects traces, metrics, and logs from applications and infrastructure

**Important**: The parent chart (ibm-devopsplan-prod) includes OpenSearch and Dashboards, but **NOT** Data Prepper. Data Prepper is essential for OpenSearch observability features and is deployed separately to:
- Process telemetry data specifically for observability use cases
- Scale independently based on observability load
- Enable/disable observability without affecting the main application
- Maintain different pipeline configurations for traces, metrics, and logs

## Overview

**Architecture:**
- **OpenTelemetry Sidecar**: Per-application sidecar collector that receives telemetry on localhost
- **OpenTelemetry Collector** (Deployment): Central collector that aggregates telemetry from all sidecars
- **Data Prepper**: Processes and transforms telemetry data for OpenSearch (with readiness probe for startup reliability)
- **Your Existing OpenSearch**: Stores and analyzes telemetry data (auto-discovered)

**Data Flow:**
```
Application → OTel Sidecar (localhost:4317/4318) → Central OTel Collector → Data Prepper → OpenSearch
```

**Key Features:**
- **Sidecar pattern**: Each instrumented app has an OTel sidecar for reliable local telemetry collection
- Distributed tracing with OTLP protocol
- OpenSearch native observability (Trace Analytics, Service Maps)
- Simple Schema for Observability (SS4O) for logs and metrics
- **Auto-provisioned index patterns**: Dashboard setup job creates `ss4o_logs-*`, `ss4o_metrics-otel-*`, `otel-v1-apm-span-*`
- **Auto-provisioned index templates**: Index template job ensures correct mappings for trace data

## Installation

### As Part of Parent Chart

Add to your `values.yaml`:

```yaml
observability:
  enabled: true
```

Then upgrade your release:

```bash
helm upgrade --install my-release .
```

### Standalone Installation

```bash
helm install observability ./charts/observability \
  --set enabled=true \
  --set opensearch.host=my-opensearch \
  --set opensearch.existingSecret=my-secret
```

## Configuration

### Minimal Configuration

```yaml
observability:
  enabled: true
```

This uses auto-discovery to connect to your existing OpenSearch from the `ibm-devopsplan-prod` subchart.

### Custom OpenSearch

```yaml
observability:
  enabled: true
  opensearch:
    host: "my-opensearch.example.com"
    port: 9200
    protocol: https
    existingSecret: "my-opensearch-secret"
    usernameKey: "username"
    passwordKey: "password"
```

### Resource Configuration

```yaml
observability:
  dataPrepper:
    replicaCount: 2
    resources:
      requests:
        cpu: 1
        memory: 2Gi
  otelCollector:
    resources:
      requests:
        cpu: 500m
        memory: 1Gi
```

### Feature Toggles

```yaml
observability:
  otelCollector:
    receivers:
      filelog: true        # Container logs
      prometheus: true     # Pod metrics  
      kubeletstats: true   # Node/pod stats
      hostMetrics: true    # Host-level metrics
```

## Application Integration

### Sidecar Pattern (Recommended)

Applications send telemetry to an OTel sidecar running in the same pod on `localhost`:

**Environment Variable:**
```bash
OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4318
```

**Java (Spring Boot) - application.yml:**
```yaml
management:
  otlp:
    tracing:
      endpoint: http://localhost:4318/v1/traces
```

The sidecar is automatically injected using the `otel.sidecar` helper template when `platform.observability.enabled=true`.

### Direct to Central Collector (Alternative)

For applications without sidecars:

```bash
OTEL_EXPORTER_OTLP_ENDPOINT=http://{{ .Release.Name }}-otel-collector:4317
```

### Export Metrics

Annotate your pods:

```yaml
apiVersion: v1
kind: Pod
metadata:
  annotations:
    prometheus.io/scrape: "true"
    prometheus.io/port: "8080"
    prometheus.io/path: "/metrics"
```

## Viewing Telemetry Data

Access your OpenSearch Dashboards:

1. **Trace Analytics**: Observability → Trace Analytics
2. **Service Maps**: Observability → Trace Analytics → Services
3. **Logs**: Discover → Create index pattern `ss4o_logs-*`
4. **Metrics**: Discover → Create index pattern `ss4o_metrics-*`

## Troubleshooting

### Docker Desktop Mount Propagation Issue

If you see this error on Docker Desktop:
```
Error: failed to start container "otel-collector": Error response from daemon: 
path / is mounted on / but it is not a shared or slave mount
```

**Quick Fix:**
```bash
docker run --rm --privileged --pid=host alpine:latest \
  nsenter -t 1 -m -u -n -i sh -c "mount --make-rshared /"
```

See [DOCKER-DESKTOP-SETUP.md](DOCKER-DESKTOP-SETUP.md) for permanent solutions.

### General Troubleshooting

**Check OTel Collector:**
```bash
kubectl logs -l app.kubernetes.io/component=otel-collector
kubectl describe deployment -l app.kubernetes.io/component=otel-collector
```

**Check Data Prepper:**
```bash
kubectl logs -l app.kubernetes.io/component=data-prepper
kubectl get pods -l app.kubernetes.io/component=data-prepper
```

**Verify OpenSearch Connection:**
```bash
kubectl exec -it deployment/{{ .Release.Name }}-observability-data-prepper -- \
  curl -k $OPENSEARCH_URL/_cluster/health
```

**Check Telemetry Flow:**
```bash
# Send test trace
kubectl run test-trace --image=curlimages/curl --rm -it -- \
  curl -X POST http://{{ .Release.Name }}-observability-otel-collector:4318/v1/traces \
  -H "Content-Type: application/json" \
  -d '{"resourceSpans":[]}'
```

## Values Reference

| Parameter | Description | Default |
|-----------|-------------|---------|
| `enabled` | Enable observability stack | `false` |
| `global.imageRegistry` | Private registry path (see [PRIVATE-REGISTRY.md](PRIVATE-REGISTRY.md)) | `""` |
| `opensearch.host` | OpenSearch host (auto-discovered) | `""` |
| `opensearch.existingSecret` | Secret with credentials | Auto-detected |
| `dataPrepper.image.repository` | Data Prepper image (public registry) | `opensearchproject/data-prepper` |
| `dataPrepper.image.name` | Data Prepper image name (private registry) | `opensearchproject/data-prepper` |
| `dataPrepper.replicaCount` | Number of Data Prepper replicas | `1` |
| `dataPrepper.resources` | Resource requests/limits | See values.yaml |
| `otelCollector.receivers.filelog.enabled` | Collect container logs | `true` |
| `otelCollector.receivers.prometheus.enabled` | Scrape Prometheus metrics | `true` |
| `otel-collector.image.repository` | OTel Collector full image path | `otel/opentelemetry-collector-contrib` |
| `serviceAccount.create` | Create ServiceAccount | `true` |
| `rbac.create` | Create RBAC resources | `true` |

See [values.yaml](values.yaml) for complete configuration options.

## Private Registry / Air-Gapped Deployment

For deployments requiring private container registries, see [PRIVATE-REGISTRY.md](PRIVATE-REGISTRY.md) for:
- Image preparation and tagging
- Global registry configuration
- Development overrides
- Troubleshooting

**Quick Start:**
```bash
REGISTRY="hclsoftware-docker-dev.us-artifactory1.nonprod.hclpnp.com/rational-devops"

helm upgrade --install devops-loop . \
  --set global.imageRegistry="${REGISTRY}" \
  --set platform.observability.enabled=true \
  --set observability.otel-collector.image.repository="${REGISTRY}/otel-opentelemetry-collector-contrib" \
  -f values-platform-enable.yaml
```
