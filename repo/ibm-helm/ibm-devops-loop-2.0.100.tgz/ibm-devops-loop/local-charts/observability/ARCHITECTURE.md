# Observability Architecture

## Overview

This observability stack combines the official OpenTelemetry Collector Helm chart with a custom Data Prepper deployment:
- **OTel Collector**: Uses the official, well-maintained Helm chart
- **Data Prepper**: Custom deployment (no official Helm chart exists yet)

## Architecture

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         Kubernetes Cluster                               │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│  ┌─────────────────────────────┐  ┌─────────────────────────────┐       │
│  │ Application Pod (tenant)    │  │ Application Pod (loop)      │       │
│  │  ┌─────────┐ ┌───────────┐  │  │  ┌─────────┐ ┌───────────┐  │       │
│  │  │ App     │ │ OTel      │  │  │  │ App     │ │ OTel      │  │       │
│  │  │Container│→│ Sidecar   │  │  │  │Container│→│ Sidecar   │  │       │
│  │  └─────────┘ └─────┬─────┘  │  │  └─────────┘ └─────┬─────┘  │       │
│  └────────────────────┼────────┘  └────────────────────┼────────┘       │
│                       │ OTLP                           │ OTLP           │
│                       └────────────────┬───────────────┘                │
│                                        ↓                                 │
│            ┌───────────────────────────────────────────┐                │
│            │ Central OTel Collector (Deployment)       │                │
│            │ - Chart: open-telemetry/opentelemetry-collector            │
│            │ - Mode: Deployment (centralized)          │                │
│            │ - Receives OTLP from all sidecars         │                │
│            └─────────────────────┬─────────────────────┘                │
│                                  │ OTLP                                  │
│                                  ↓                                       │
│            ┌───────────────────────────────────────────┐                │
│            │ Data Prepper (Custom Deployment)          │                │
│            │ - Readiness probe on port 21890           │                │
│            │ - Transforms OTLP → OpenSearch format     │                │
│            │ - Pipelines: traces, logs, metrics,       │                │
│            │   service-map                             │                │
│            └─────────────────────┬─────────────────────┘                │
│                                  │                                       │
└──────────────────────────────────┼───────────────────────────────────────┘
                                   ↓
                 ┌─────────────────────────────┐
                 │ OpenSearch (Existing)        │
                 │ From: ibm-devopsplan-prod    │
                 │ Indices:                     │
                 │  - otel-v1-apm-span-*        │
                 │  - otel-v1-apm-service-map   │
                 │  - ss4o_logs-*               │
                 │  - ss4o_metrics-otel-*       │
                 └─────────────────────────────┘
```

## Why This Approach?

### Using the Official OTel Collector Chart
✅ **Battle-tested** - Used in production by thousands of deployments  
✅ **Actively maintained** - Regular updates, security patches, bug fixes  
✅ **Feature-rich** - Advanced configurations and presets included  
✅ **Well-documented** - Extensive community docs and examples  

### Custom Data Prepper Deployment
The Data Prepper Helm chart is relatively immature and not widely adopted, so we use a custom deployment that:
✅ **Integrates seamlessly** - Auto-discovers your OpenSearch instance  
✅ **Stays simple** - Only includes what you need  
✅ **Easy to maintain** - Straightforward template you control  
✅ **No Official Chart** - OpenSearch doesn't provide an official Helm chart for Data Prepper yet  

## Configuration Layers

### Layer 1: Parent Chart (values.yaml)
Simple, high-level configuration:
```yaml
platform:
  observability:
    enabled: true

observability:
  opensearch:
    host: ""  # Auto-detected
  dataPrepper:
    enabled: true
  otelCollector:
    enabled: true
    resources:
      requests:
        cpu: 300m
        memory: 512Mi
```

### Layer 2: Observability Subchart (charts/observability/values.yaml)
Maps parent values to official chart format:
```yaml
otel-collector:
  mode: deployment  # Centralized collector
  image:
    repository: otel/opentelemetry-collector-contrib
  config:
    receivers: {...}
    processors: {...}
    exporters: {...}
```

### Layer 3: Official Chart
Handles DaemonSet, ServiceAccount, RBAC, ConfigMaps automatically

## Deployment

```bash
# Standard deployment - official chart is automatically pulled
helm dependency update .
helm upgrade --install devops-loop . -f values-platform-enable.yaml

# Check official chart was downloaded
ls charts/observability/charts/
# Output: opentelemetry-collector-0.97.1.tgz
```

## Maintenance

### Updating OTel Collector
```bash
# Edit charts/observability/Chart.yaml
dependencies:
  - name: opentelemetry-collector
    version: 0.98.0  # <-- Update version

# Update dependencies
cd charts/observability && helm dependency update
```

### Updating Data Prepper
```bash
# Edit charts/observability/values.yaml
dataPrepper:
  image:
    tag: "2.7.0"  # <-- Update version
```

## Migration Path

### Current: Custom Subchart (before hybrid)
- ✅ Simple
- ❌ You maintain everything
- ❌ Manual updates

### Now: Hybrid (official OTel + custom Data Prepper)
- ✅ Community maintains OTel Collector
- ✅ You only maintain Data Prepper
- ✅ Simplified parent interface preserved

### Future: Full Official (when Data Prepper chart available)
- Add Data Prepper as dependency when official chart released
- Even less maintenance burden

## Troubleshooting

### Check Official Chart Status
```bash
helm list -n <namespace>
kubectl get deployment -l app.kubernetes.io/name=opentelemetry-collector
```

### View Official Chart Config
```bash
kubectl get configmap <release>-otel-collector-opentelemetry-collector -o yaml
```

### Debug Official Chart
```bash
kubectl logs -l app.kubernetes.io/name=opentelemetry-collector -f
```

## References

- [OpenTelemetry Collector Helm Chart](https://github.com/open-telemetry/opentelemetry-helm-charts/tree/main/charts/opentelemetry-collector)
- [Data Prepper Documentation](https://opensearch.org/docs/latest/data-prepper/)
- [OTel Collector Documentation](https://opentelemetry.io/docs/collector/)
