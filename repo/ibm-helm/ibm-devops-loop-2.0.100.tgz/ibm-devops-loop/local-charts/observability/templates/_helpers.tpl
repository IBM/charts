{{/*
Expand the name of the chart.
*/}}
{{- define "observability.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "observability.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "observability.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "observability.labels" -}}
helm.sh/chart: {{ include "observability.chart" . }}
{{ include "observability.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "observability.selectorLabels" -}}
app.kubernetes.io/name: {{ include "observability.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "observability.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "observability.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Get OpenSearch host - auto-discover from parent chart or use override
*/}}
{{- define "observability.opensearchHost" -}}
{{- if .Values.opensearch.host }}
{{- .Values.opensearch.host }}
{{- else }}
{{- printf "%s-ibm-devopsplan-prod-opensearch" .Release.Name }}
{{- end }}
{{- end }}

{{/*
Get OpenSearch URL
*/}}
{{- define "observability.opensearchUrl" -}}
{{- printf "%s://%s:%d" .Values.opensearch.protocol (include "observability.opensearchHost" .) (int .Values.opensearch.port) }}
{{- end }}

{{/*
Get OpenSearch credentials secret
*/}}
{{- define "observability.opensearchSecret" -}}
{{- if .Values.opensearch.existingSecret }}
{{- .Values.opensearch.existingSecret }}
{{- else }}
{{- printf "%s-ibm-devopsplan-prod-opensearch" .Release.Name }}
{{- end }}
{{- end }}
