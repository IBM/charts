# Docker Desktop Setup for Observability

## Mount Propagation Issue on Docker Desktop (WSL2)

When deploying the observability stack on Docker Desktop with WSL2, you may encounter this error:

```
Error: failed to start container "otel-collector": Error response from daemon: 
path / is mounted on / but it is not a shared or slave mount
```

This occurs because the OTel Collector DaemonSet needs to mount host paths (`/var/log/pods`) with shared propagation, but Docker Desktop's WSL2 distribution doesn't enable this by default.

## Permanent Solutions

**IMPORTANT**: Options 1 and 2 must be run in the `docker-desktop` WSL instance, not your Ubuntu/other WSL instance!

### Option 1: Systemd Service (Permanent - Requires docker-desktop WSL)

**⚠️ This must be run in the docker-desktop WSL instance:**

```bash
# Access the docker-desktop WSL instance (from Windows)
wsl -d docker-desktop

# Create the service file
sudo tee /etc/systemd/system/docker-mount-fix.service > /dev/null << 'SERVICE'
[Unit]
Description=Enable shared mount propagation for Docker
DefaultDependencies=no
After=local-fs.target
Before=docker.service

[Service]
Type=oneshot
ExecStart=/bin/mount --make-rshared /
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
SERVICE

# Enable and start the service
sudo systemctl daemon-reload
sudo systemctl enable docker-mount-fix.service
sudo systemctl start docker-mount-fix.service

# Verify
sudo systemctl status docker-mount-fix.service
```

### Option 2: WSL Boot Command (Permanent - Requires docker-desktop WSL)

**⚠️ This must be run in the docker-desktop WSL instance:**

```bash
# Access the docker-desktop WSL instance (from Windows)
wsl -d docker-desktop

# Add to /etc/wsl.conf in your WSL2 distribution:

```bash
# Edit /etc/wsl.conf
sudo tee -a /etc/wsl.conf > /dev/null << 'WSLCONF'
[boot]
command = "mount --make-rshared /"
WSLCONF

# Restart WSL (from Windows PowerShell)
# wsl --shutdown
# wsl
```

### Option 3: Docker Desktop VM Direct Access (Works from any WSL instance)

**✅ This option works from Ubuntu or any WSL instance:**

Run this whenever Docker Desktop restarts:

```bash
docker run --rm --privileged --pid=host alpine:latest \
  nsenter -t 1 -m -u -n -i sh -c "mount --make-rshared / && echo 'Mount propagation enabled'"
```

### Option 4: Add to Install Script (Works from any WSL instance)

**✅ This option works from Ubuntu or any WSL instance:**

Update your installation script to automatically fix mount propagation:

```bash
#!/bin/bash

# Fix mount propagation for Docker Desktop
echo "Checking mount propagation..."
if docker info 2>/dev/null | grep -q "Operating System.*Docker Desktop"; then
  echo "Docker Desktop detected - enabling mount propagation"
  docker run --rm --privileged --pid=host alpine:latest \
    nsenter -t 1 -m -u -n -i sh -c "mount --make-rshared /" || \
    echo "Warning: Could not enable mount propagation. Manual fix may be required."
fi

# Continue with helm installation
helm upgrade --install devops-loop . \
  -n devops-loop \
  -f values.yaml \
  -f values-platform-enable.yaml \
  -f values-images.yaml
```

## Verification

After applying the fix, verify mount propagation is enabled:

```bash
# Check if / is shared
docker run --rm --privileged --pid=host alpine:latest \
  nsenter -t 1 -m -u -n -i sh -c "mount | grep ' / '"

# Should show: ... rw,shared ...
```

Then restart the OTel Collector pods:

```bash
kubectl delete pod -l app.kubernetes.io/name=opentelemetry-collector -n devops-loop
kubectl get pods -n devops-loop | grep otel
```

## Alternative: Disable Host Path Mounting

If mount propagation cannot be enabled, you can disable filelog collection:

```yaml
# values.yaml
observability:
  enabled: true
  otel-collector:
    presets:
      logsCollection:
        enabled: false  # Disable host path mounting
```

**Note**: This disables automatic container log collection. Applications will need to send logs via OTLP.

## Troubleshooting

### Check Mount Propagation Status

```bash
# From WSL2
mount | grep -E "^/ "

# Should show: / on / type ext4 (rw,shared,relatime,...)
```

### Check Docker Desktop Context

```bash
docker context ls
# Should show: default * docker-desktop
```

### Restart Docker Desktop

Sometimes a complete restart helps:

```bash
# Windows PowerShell
wsl --shutdown
# Then start Docker Desktop again
```

### Check Kubernetes Node

```bash
kubectl get nodes -o wide
kubectl describe node docker-desktop | grep -A 10 "Allocatable"
```

## Production Deployments

For production Kubernetes clusters (not Docker Desktop):

- **Standard K8s clusters** (EKS, GKE, AKS): Mount propagation is already configured correctly
- **On-premise clusters**: Ensure kubelet is configured with proper mount propagation
- **Air-gapped**: No additional configuration needed beyond image registry settings

This issue is **specific to Docker Desktop development environments** and does not affect production deployments.

## Related Documentation

- [OpenTelemetry Collector Configuration](README.md)
- [Troubleshooting Guide](../../DEBUGGING-403.md)
- [Private Registry Setup](PRIVATE-REGISTRY.md)
