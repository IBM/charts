# Image Registry Configuration - Quick Reference

## Summary

The observability chart supports `global.imageRegistry` for private/air-gapped deployments while allowing easy override for development.

## Two Images Required

| Image | Public | Private Registry Path |
|-------|--------|----------------------|
| Data Prepper | `opensearchproject/data-prepper:2.6.1` | `${REGISTRY}/opensearchproject/data-prepper:2.6.1` |
| OTel Collector | `otel/opentelemetry-collector-contrib:0.93.0` | `${REGISTRY}/otel-opentelemetry-collector-contrib:0.93.0` |

## Production (Private Registry)

```bash
REGISTRY="hclsoftware-docker-dev.us-artifactory1.nonprod.hclpnp.com/rational-devops"

# Deploy with private registry
helm upgrade --install devops-loop . \
  --set global.imageRegistry="${REGISTRY}" \
  --set platform.observability.enabled=true \
  --set observability.otel-collector.image.repository="${REGISTRY}/otel-opentelemetry-collector-contrib" \
  -f values-platform-enable.yaml
```

**Result:**
- Data Prepper: `hclsoftware-docker-dev.us-artifactory1.nonprod.hclpnp.com/rational-devops/opensearchproject/data-prepper:2.6.1`
- OTel Collector: `hclsoftware-docker-dev.us-artifactory1.nonprod.hclpnp.com/rational-devops/otel-opentelemetry-collector-contrib:0.93.0`

## Development (Public Registry)

```bash
# Deploy with public registries (no private images yet)
helm upgrade --install devops-loop . \
  --set global.imageRegistry="" \
  --set platform.observability.enabled=true \
  -f values-platform-enable.yaml
```

**Result:**
- Data Prepper: `opensearchproject/data-prepper:2.6.1`
- OTel Collector: `otel/opentelemetry-collector-contrib:0.93.0`

## How It Works

### Data Prepper (Automatic)

Template logic in `templates/data-prepper/deployment.yaml`:

```yaml
{{- if .Values.global.imageRegistry }}
image: "{{ .Values.global.imageRegistry }}/{{ .Values.dataPrepper.image.name }}:{{ .Values.dataPrepper.image.tag }}"
{{- else }}
image: "{{ .Values.dataPrepper.image.repository }}:{{ .Values.dataPrepper.image.tag }}"
{{- end }}
```

### OTel Collector (Manual Override)

The official chart doesn't auto-detect `global.imageRegistry`, so you must explicitly set:

```bash
--set observability.otel-collector.image.repository="${REGISTRY}/otel-opentelemetry-collector-contrib"
```

## Image Preparation

See [PRIVATE-REGISTRY.md](PRIVATE-REGISTRY.md) for detailed instructions. Quick version:

```bash
REGISTRY="hclsoftware-docker-dev.us-artifactory1.nonprod.hclpnp.com/rational-devops"

# Pull public images
docker pull otel/opentelemetry-collector-contrib:0.93.0
docker pull opensearchproject/data-prepper:2.6.1

# Tag for private registry
docker tag otel/opentelemetry-collector-contrib:0.93.0 \
  ${REGISTRY}/otel-opentelemetry-collector-contrib:0.93.0
docker tag opensearchproject/data-prepper:2.6.1 \
  ${REGISTRY}/opensearchproject/data-prepper:2.6.1

# Push
docker login ${REGISTRY}
docker push ${REGISTRY}/otel-opentelemetry-collector-contrib:0.93.0
docker push ${REGISTRY}/opensearchproject/data-prepper:2.6.1
```

## Verification

```bash
# Check deployed images
kubectl get pods -n devops-loop -o jsonpath='{range .items[*]}{.metadata.name}{"\t"}{.spec.containers[0].image}{"\n"}{end}' | grep -E 'otel|data-prepper'
```

## Files Modified

1. **charts/observability/values.yaml**
   - Added `global.imageRegistry: ""`
   - Added `dataPrepper.image.name` for private registry path
   - Documented OTel Collector behavior

2. **charts/observability/templates/data-prepper/deployment.yaml**
   - Added conditional logic to use `global.imageRegistry` when set

3. **charts/observability/PRIVATE-REGISTRY.md** (NEW)
   - Complete guide for private registry deployment
   - Image sync script
   - Troubleshooting

4. **charts/observability/APPLICATION-INTEGRATION.md** (NEW)
   - How applications connect to collectors
   - Language-specific examples

5. **charts/observability/README.md**
   - Added private registry section
   - Updated values reference table

## See Also

- [PRIVATE-REGISTRY.md](PRIVATE-REGISTRY.md) - Complete private registry guide
- [APPLICATION-INTEGRATION.md](APPLICATION-INTEGRATION.md) - How apps connect
- [ARCHITECTURE.md](ARCHITECTURE.md) - Component architecture and design decisions
