#!/usr/bin/env bash
# NOTE: Client creation logic is shared; candidate to move into a library chart for subchart reuse.

set -e

SCRIPT_DIR="$(dirname "${BASH_SOURCE[0]}")"

is_keycloak_debug_enabled() {
  [ "${KEYCLOAK_DEBUG:-false}" = "true" ]
}

keycloak_debug_log() {
  if is_keycloak_debug_enabled; then
    echo "[keycloak-debug] $*"
  fi
}

extract_request_method_url() {
  local method="GET"
  local url=""
  local previous=""

  for arg in "$@"; do
    if [ "$previous" = "-X" ] && [ -n "$arg" ]; then
      method="$arg"
      previous=""
      continue
    fi

    if [ -z "$url" ] && [[ "$arg" == http://* || "$arg" == https://* ]]; then
      url="$arg"
    fi

    previous="$arg"
  done

  echo "$method|$url"
}

refresh_admin_token() {
  . "$SCRIPT_DIR/admin-token.sh"
}

keycloak_request() {
  local include_headers="$1"
  shift

  local request_info
  request_info="$(extract_request_method_url "$@")"
  local request_method="${request_info%%|*}"
  local request_url="${request_info#*|}"

  refresh_admin_token
  keycloak_debug_log "request method=$request_method url=$request_url"

  local response
  if [ "$include_headers" = "true" ]; then
    response="$(curl -s -w "\n%{http_code}" -i $CAFILE "$@" -H "Authorization: Bearer $ADMIN_TOKEN")"
  else
    response="$(curl -s -w "\n%{http_code}" $CAFILE "$@" -H "Authorization: Bearer $ADMIN_TOKEN")"
  fi

  local http_code
  http_code=$(echo "$response" | tail -n1)
  keycloak_debug_log "response method=$request_method url=$request_url status=$http_code"

  if [ "$http_code" -eq 401 ]; then
    echo "Received 401 from Keycloak. Refreshing admin token and retrying once..."
    refresh_admin_token
    keycloak_debug_log "retry method=$request_method url=$request_url reason=401"
    if [ "$include_headers" = "true" ]; then
      response="$(curl -s -w "\n%{http_code}" -i $CAFILE "$@" -H "Authorization: Bearer $ADMIN_TOKEN")"
    else
      response="$(curl -s -w "\n%{http_code}" $CAFILE "$@" -H "Authorization: Bearer $ADMIN_TOKEN")"
    fi
    http_code=$(echo "$response" | tail -n1)
    keycloak_debug_log "response method=$request_method url=$request_url status=$http_code retry=1"
  fi

  echo "$response"
}

if [ -z "$ADMIN_TOKEN" ]; then
  refresh_admin_token
fi

id=$(. "$SCRIPT_DIR/client-id.sh")

if [ -z "$id" ]; then
  echo "No id found for $CLIENT_ID, so creating a new client..."
  method=POST
fi

if [ "${STANDARD_FLOW:-true}" = "true" ] && [ -z "$BASE_URL" ]; then
  echo "BASE_URL is required when standard flow is enabled for $CLIENT_ID"
  exit 1
fi

if [ -z "$CLIENT_SECRET" ] && [ "${STANDARD_FLOW:-true}" = "false" ] && [ "${DIRECT_ACCESS_GRANTS:-false}" = "false" ]; then
  echo "Creating audience-only public client (no flows enabled)"
fi

service_accounts_enabled=false

if [ "${AUTHORIZATION_SERVICES:-false}" = "true" ] || [ -n "$ROLE_MAPPINGS" ]; then
  service_accounts_enabled=true
fi

if [ "$service_accounts_enabled" = true ] && [ -z "$CLIENT_SECRET" ]; then
  echo "Service accounts require a client secret"
  exit 1
fi

if [ -n "$CLIENT_SECRET" ]; then

  json_client_payload=$(cat <<EOF
{
  "clientId": "$CLIENT_ID",
  "clientAuthenticatorType": "client-secret",
  "standardFlowEnabled": ${STANDARD_FLOW:-true},
  "directAccessGrantsEnabled": ${DIRECT_ACCESS_GRANTS:-false},
  "publicClient": false,
  "bearerOnly": false,
  "secret": "$CLIENT_SECRET",
  "serviceAccountsEnabled": ${service_accounts_enabled},$( [ -n "$FRONT_CHANNEL_LOGOUT_URL" ] && echo '
  "frontchannelLogout": true,' )
  "attributes": {$( [ -n "$FRONT_CHANNEL_LOGOUT_URL" ] && echo '
    "frontchannel.logout.url": "'"$FRONT_CHANNEL_LOGOUT_URL"'",' )
    "oauth2.device.authorization.grant.enabled": "${OAUTH2_DEVICE_AUTHORIZATION_GRANTS:-false}",
    "standard.token.exchange.enabled": "${STANDARD_TOKEN_EXCHANGE:-false}"$( [ -n "$LOGIN_THEME" ] && echo ",\"login_theme\": \"$LOGIN_THEME\"" )
    $( [ -n "$ACCESS_TOKEN_LIFESPAN" ] && echo ",\"access.token.lifespan\": \"$ACCESS_TOKEN_LIFESPAN\"" )
  },$( [ "${STANDARD_FLOW:-true}" = "true" ] && echo '
  "baseUrl": "'"${BASE_URL}"'",
  "redirectUris": '"${REDIRECT_URIS:-[\"${BASE_URL}/*\"]}",'
  "webOrigins": '"${WEB_ORIGINS:-[\"+\"]}," )
  "authorizationServicesEnabled": ${AUTHORIZATION_SERVICES:-false}
}
EOF
)

  echo "Enabling client $json_client_payload"

  response=$(keycloak_request true -X ${method:-PUT} "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$id" \
    -H 'Content-Type: application/json' \
    -d "${json_client_payload}")

  http_code=$(echo "$response" | tail -n1)

  body=$(echo "$response" | sed '$d')

  if [ "$http_code" -ge 300 ]; then
    echo "Failed to enable client. HTTP response code: $http_code"
    echo "Response: $body"
    exit 1
  fi

  id_location=$(echo "$body" | sed -n 's#^location:[ ]*##ip' | tr -d '\r')

else

  if [ "${STANDARD_FLOW:-true}" = "true" ] && [ -z "$FRONT_CHANNEL_LOGOUT_URL" ]; then
    echo "No front channel logout URL found for public client $CLIENT_ID with standard flow enabled"
    exit 1
  fi

  json_client_payload=$(cat <<EOF
{
  "clientId": "$CLIENT_ID",
  "standardFlowEnabled": ${STANDARD_FLOW:-true},
  "directAccessGrantsEnabled": ${DIRECT_ACCESS_GRANTS:-false},
  "publicClient": true,$( [ "${STANDARD_FLOW:-true}" = "true" ] && [ -n "$FRONT_CHANNEL_LOGOUT_URL" ] && echo '
  "frontchannelLogout": true,' )
  "attributes": {
    $(if [ "${PKCE_CODE_CHALLENGE_METHOD_SKIP:-false}" != "true" ]; then echo '"pkce.code.challenge.method": "S256",'; fi)$( [ "${STANDARD_FLOW:-true}" = "true" ] && [ -n "$FRONT_CHANNEL_LOGOUT_URL" ] && echo '
    "frontchannel.logout.url": "'"$FRONT_CHANNEL_LOGOUT_URL"'",' )
    "oauth2.device.authorization.grant.enabled": "${OAUTH2_DEVICE_AUTHORIZATION_GRANTS:-false}"$( [ -n "$LOGIN_THEME" ] && echo ",\"login_theme\": \"$LOGIN_THEME\"" )
  }$( [ "${STANDARD_FLOW:-true}" = "true" ] && echo ',
  "baseUrl": "'"${BASE_URL}"'",
  "redirectUris": '"${REDIRECT_URIS:-[\"${BASE_URL}/*\"]}",'
  "webOrigins": '"${WEB_ORIGINS:-[\"+\"]}" )
}
EOF
)

  echo "Enabling client $json_client_payload"

  response="$(keycloak_request true -X ${method:-PUT} "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$id" \
    -H 'Content-Type: application/json' \
    -d "${json_client_payload}")"

  http_code=$(echo "$response" | tail -n1)

  body=$(echo "$response" | sed '$d')

  if [ "$http_code" -ge 300 ]; then
    echo "Failed to enable client. HTTP response code: $http_code"
    echo "Response: $body"
    exit 1
  fi

  id_location=$(echo "$body" | sed -n 's#^location:[ ]*##ip' | tr -d '\r')

fi

if [ -n "$id_location" ]; then
  echo "Location found for $CLIENT_ID is $id_location"
  id="${id_location##*/}"
fi

if [ -n "$OPTIONAL_SCOPES" ] && [ -n "$id" ]; then
  echo "Processing client scopes for client ID: $id"
  
  echo "$OPTIONAL_SCOPES" | jq -r '.[]' | while read -r scope_name; do
    if [ -n "$DEFAULT_SCOPES" ] && echo "$DEFAULT_SCOPES" | jq -e --arg scope "$scope_name" 'index($scope) != null' >/dev/null; then
      echo "Skipping optional assignment for '$scope_name' because it is configured as a default scope"
      continue
    fi

    echo "Checking scope '$scope_name'..."
    
    response="$(keycloak_request false -X GET "$KEYCLOAK_URL/admin/realms/$REALM_NAME/client-scopes?first=0&max=1000")"
    http_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | sed '$d')
    if [ "$http_code" -ge 300 ]; then
      echo "Failed to list client scopes. HTTP response code: $http_code"
      echo "Response: $body"
      exit 1
    fi
    scope_id=$(echo "$body" | jq -r ".[] | select(.name==\"$scope_name\") | .id")
    
    if [ -n "$scope_id" ]; then
      echo "Found existing scope ID: $scope_id for scope: $scope_name"
    else
      echo "Scope '$scope_name' not found. Creating it..."
      
      scope_payload=$(cat <<EOF
{
  "name": "$scope_name",
  "description": "$scope_name",
  "protocol": "openid-connect",
  "attributes": {
    "include.in.token.scope": "true",
    "display.on.consent.screen": "true"
  }
}
EOF
)
      
      response=$(keycloak_request true -X POST "$KEYCLOAK_URL/admin/realms/$REALM_NAME/client-scopes" \
        -H 'Content-Type: application/json' \
        -d "$scope_payload")
      
      http_code=$(echo "$response" | tail -n1)
      body=$(echo "$response" | sed '$d')
      
      if [ "$http_code" -ge 300 ]; then
        if [ "$http_code" -eq 409 ]; then
          echo "Client scope '$scope_name' already exists (409 on create); resolving existing ID and continuing"
        else
          echo "Failed to create client scope '$scope_name'. HTTP response code: $http_code"
          echo "Response: $body"
          exit 1
        fi
      else
        echo "Successfully created client scope: $scope_name"
      fi

      response="$(keycloak_request false -X GET "$KEYCLOAK_URL/admin/realms/$REALM_NAME/client-scopes?first=0&max=1000")"
      http_code=$(echo "$response" | tail -n1)
      body=$(echo "$response" | sed '$d')
      if [ "$http_code" -ge 300 ]; then
        echo "Failed to list client scopes after creation. HTTP response code: $http_code"
        echo "Response: $body"
        exit 1
      fi
      scope_id=$(echo "$body" | jq -r ".[] | select(.name==\"$scope_name\") | .id")

      if [ -z "$scope_id" ]; then
        echo "Failed to resolve scope ID for '$scope_name' after create/retry flow"
        exit 1
      fi
    fi
    
    if [ -n "$scope_id" ]; then
      echo "Assigning scope '$scope_name' (ID: $scope_id) to client..."
      
      response=$(keycloak_request false -X PUT "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$id/optional-client-scopes/$scope_id")
      
      http_code=$(echo "$response" | tail -n1)
      body=$(echo "$response" | sed '$d')
      
      if [ "$http_code" -ge 300 ]; then
        echo "Failed to assign scope '$scope_name' to client. HTTP response code: $http_code"
        echo "Response: $body"
        exit 1
      fi
      echo "Successfully assigned scope '$scope_name' to client"
    else
      echo "Could not obtain scope ID for '$scope_name'"
      exit 1
    fi
  done
fi

if [ -n "$DEFAULT_SCOPES" ] && [ -n "$id" ]; then
  echo "Processing default client scopes for client ID: $id"
  
  echo "$DEFAULT_SCOPES" | jq -r '.[]' | while read -r scope_name; do
    echo "Checking default scope '$scope_name'..."
    
    response="$(keycloak_request false -X GET "$KEYCLOAK_URL/admin/realms/$REALM_NAME/client-scopes?first=0&max=1000")"
    http_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | sed '$d')
    if [ "$http_code" -ge 300 ]; then
      echo "Failed to list default scopes. HTTP response code: $http_code"
      echo "Response: $body"
      exit 1
    fi
    scope_id=$(echo "$body" | jq -r ".[] | select(.name==\"$scope_name\") | .id")
    
    if [ -n "$scope_id" ]; then
      echo "Found existing scope ID: $scope_id for default scope: $scope_name"
    else
      echo "Default scope '$scope_name' not found. Creating it..."
      
      scope_payload=$(cat <<EOF
{
  "name": "$scope_name",
  "description": "$scope_name",
  "protocol": "openid-connect",
  "attributes": {
    "include.in.token.scope": "true",
    "display.on.consent.screen": "true"
  }
}
EOF
)
      
      response=$(keycloak_request true -X POST "$KEYCLOAK_URL/admin/realms/$REALM_NAME/client-scopes" \
        -H 'Content-Type: application/json' \
        -d "$scope_payload")
      
      http_code=$(echo "$response" | tail -n1)
      body=$(echo "$response" | sed '$d')
      
      if [ "$http_code" -ge 300 ]; then
        if [ "$http_code" -eq 409 ]; then
          echo "Default client scope '$scope_name' already exists (409 on create); resolving existing ID and continuing"
        else
          echo "Failed to create default client scope '$scope_name'. HTTP response code: $http_code"
          echo "Response: $body"
          exit 1
        fi
      else
        echo "Successfully created default client scope: $scope_name"
      fi

      response="$(keycloak_request false -X GET "$KEYCLOAK_URL/admin/realms/$REALM_NAME/client-scopes?first=0&max=1000")"
      http_code=$(echo "$response" | tail -n1)
      body=$(echo "$response" | sed '$d')
      if [ "$http_code" -ge 300 ]; then
        echo "Failed to list default scopes after creation. HTTP response code: $http_code"
        echo "Response: $body"
        exit 1
      fi
      scope_id=$(echo "$body" | jq -r ".[] | select(.name==\"$scope_name\") | .id")

      if [ -z "$scope_id" ]; then
        echo "Failed to resolve scope ID for default scope '$scope_name' after create/retry flow"
        exit 1
      fi
    fi
    
    if [ -n "$scope_id" ]; then
	
	  echo "Removing scope '$scope_name' from optional scopes (if present) before assigning as default..."
      response=$(keycloak_request false -X DELETE \
        "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$id/optional-client-scopes/$scope_id")
      http_code=$(echo "$response" | tail -n1)
      if [ "$http_code" -lt 300 ]; then
        echo "Cleared optional scope assignment for '$scope_name' (HTTP: $http_code)"
      elif [ "$http_code" -eq 404 ]; then
        echo "Scope '$scope_name' was not assigned as optional (HTTP: 404), nothing to remove"
      else
        echo "Failed to remove '$scope_name' from optional scopes before assigning as default. HTTP response code: $http_code"
        body=$(echo "$response" | sed '$d')
        echo "Response: $body"
        exit 1
      fi
	
      echo "Assigning default scope '$scope_name' (ID: $scope_id) to client..."
      
      response=$(keycloak_request false -X PUT "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$id/default-client-scopes/$scope_id")
      
      http_code=$(echo "$response" | tail -n1)
      body=$(echo "$response" | sed '$d')
      
      if [ "$http_code" -ge 300 ]; then
        echo "Failed to assign default scope '$scope_name' to client. HTTP response code: $http_code"
        echo "Response: $body"
        exit 1
      fi
      echo "Successfully assigned default scope '$scope_name' to client"
    else
      echo "Could not obtain scope ID for default scope '$scope_name'"
      exit 1
    fi
  done
fi

if [ -n "$ROLES_CLAIM" ]; then 

  response="$(keycloak_request false -X GET "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$id/protocol-mappers/models")"
  http_code=$(echo "$response" | tail -n1)
  body=$(echo "$response" | sed '$d')
  if [ "$http_code" -ge 300 ]; then
    echo "Failed to get the protocol mappers. HTTP response code: $http_code"
    echo "Response: $body"
    exit 1
  fi

  echo "Protocol mappers: $body"

  mapper_enabled="$(echo "$body" | jq '.[] | select(.name=="realm_roles" and .protocolMapper=="oidc-usermodel-realm-role-mapper")')"

  echo "Mapper_enabled: $mapper_enabled"

  if [ -n "$mapper_enabled" ]; then
    echo "The protocol mapper: realm_roles is already present."
  
  else

    json_role_mapper_payload=$(cat <<EOF
{
      "name":"realm_roles",
      "protocol":"openid-connect",
      "protocolMapper":"oidc-usermodel-realm-role-mapper",
      "consentRequired":false,
      "config":{
        "claim.name":"$ROLES_CLAIM",
        "jsonType.label":"String",
        "access.token.claim":"true",
        "id.token.claim":"$ENABLE_ID_TOKEN",
        "userinfo.token.claim":"true",
        "multivalued": "true"
      }
    }
EOF
)

    echo "Adding mapper $json_role_mapper_payload"

    response="$(keycloak_request true -X POST "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$id/protocol-mappers/models" \
      -H 'Content-Type: application/json' \
      -d "${json_role_mapper_payload}")"
    http_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | sed '$d')
    if [ "$http_code" -ge 300 ]; then
      echo "Failed to add realm roles mapper. HTTP response code: $http_code"
      echo "Response: $body"
      exit 1
    fi

  fi

fi

if [ -n "$TEAMSPACES_CLAIM" ]; then 

  response="$(keycloak_request false -X GET "$KEYCLOAK_URL/admin/realms/$REALM_NAME/users/profile")"
  http_code=$(echo "$response" | tail -n1)
  profile_body=$(echo "$response" | sed '$d')
  if [ "$http_code" -ge 300 ]; then
    echo "Failed to get the user profile. HTTP response code: $http_code"
    echo "Response: $profile_body"
    exit 1
  fi

  echo "User profile: $profile_body"

  teamspaces_attr_enabled="$(echo "$profile_body" | jq 'any(.attributes[]; .name == "teamspaces")')"

  echo "Teamspaces attribute enabled: $teamspaces_attr_enabled"

  if [ "$teamspaces_attr_enabled" == "true" ]; then
    echo "In the user profile: 'teamspaces' is already present"

  else
    new_attr_json='{"name":"teamspaces","displayName":"teamspaces","validations":{},"annotations":{},"permissions":{"view":["admin","user"],"edit":["admin"]},"group":"user-metadata","multivalued":true}'

    updated_profile_body="$(echo "$profile_body" | jq --argjson new_attr "$new_attr_json" '.attributes += [$new_attr]')"

    response="$(keycloak_request true -X PUT "$KEYCLOAK_URL/admin/realms/$REALM_NAME/users/profile" \
      -H 'Content-Type: application/json' \
      -d "$updated_profile_body")"
    http_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | sed '$d')
    if [ "$http_code" -ge 300 ]; then
      echo "Failed to add 'teamspaces' attribute to the user profile. HTTP response code: $http_code"
      echo "Response: $body"
      exit 1
    fi
    echo "Successfully added 'teamspaces' attribute."

  fi

  response="$(keycloak_request false -X GET "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$id/protocol-mappers/models")"
  http_code=$(echo "$response" | tail -n1)
  body=$(echo "$response" | sed '$d')
  if [ "$http_code" -ge 300 ]; then
    echo "Failed to get the protocol mappers. HTTP response code: $http_code"
    echo "Response: $body"
    exit 1
  fi

  echo "Protocol mappers: $body"

  mapper_enabled="$(echo "$body" | jq '.[] | select(.name=="teamspaces" and .protocolMapper=="oidc-usermodel-attribute-mapper")')"

  echo "Mapper_enabled: $mapper_enabled"

  if [ -n "$mapper_enabled" ]; then
    echo "The protocol mapper: teamspaces is already present."
  
  else

    json_attribute_payload=$(cat <<EOF
{
      "name":"teamspaces",
      "protocol":"openid-connect",
      "protocolMapper":"oidc-usermodel-attribute-mapper",
      "consentRequired":false,
      "config":{
        "user.attribute":"teamspaces",
        "claim.name":"$TEAMSPACES_CLAIM",
        "jsonType.label":"String",
        "access.token.claim":"true",
        "id.token.claim":"$ENABLE_ID_TOKEN",
        "userinfo.token.claim":"true",
        "multivalued": "true"
      }
    }
EOF
)

    echo "Adding mapper $json_attribute_payload"

    response="$(keycloak_request true -X POST "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$id/protocol-mappers/models" \
      -H 'Content-Type: application/json' \
      -d "${json_attribute_payload}")"
    http_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | sed '$d')
    if [ "$http_code" -ge 300 ]; then
      echo "Failed to add attribute mapper - teamspaces. HTTP response code: $http_code"
      echo "Response: $body"
      exit 1
    fi
    echo "Successfully added attribute mapper - teamspaces"

  fi

fi

if [ -n "$ENTITLEMENTS_CLAIM" ]; then 

  response="$(keycloak_request false -X GET "$KEYCLOAK_URL/admin/realms/$REALM_NAME/users/profile")"
  http_code=$(echo "$response" | tail -n1)
  profile_body=$(echo "$response" | sed '$d')
  if [ "$http_code" -ge 300 ]; then
    echo "Failed to get the user profile. HTTP response code: $http_code"
    echo "Response: $profile_body"
    exit 1
  fi

  echo "User profile: $profile_body"

  entitlements_attr_enabled="$(echo "$profile_body" | jq 'any(.attributes[]; .name == "entitlements")')"

  echo "Entitlements attribute enabled: $entitlements_attr_enabled"

  if [ "$entitlements_attr_enabled" == "true" ]; then
    echo "In the user profile: 'entitlements' is already present"

  else
    new_attr_json='{"name":"entitlements","displayName":"entitlements","validations":{},"annotations":{},"permissions":{"view":["admin","user"],"edit":["admin"]},"group":"user-metadata","multivalued":true}'

    updated_profile_body="$(echo "$profile_body" | jq --argjson new_attr "$new_attr_json" '.attributes += [$new_attr]')"

    response="$(keycloak_request true -X PUT "$KEYCLOAK_URL/admin/realms/$REALM_NAME/users/profile" \
      -H 'Content-Type: application/json' \
      -d "$updated_profile_body")"
    http_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | sed '$d')
    if [ "$http_code" -ge 300 ]; then
      echo "Failed to add 'entitlements' attribute to the user profile. HTTP response code: $http_code"
      echo "Response: $body"
      exit 1
    fi
    echo "Successfully added 'entitlements' attribute."

  fi

  response="$(keycloak_request false -X GET "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$id/protocol-mappers/models")"
  http_code=$(echo "$response" | tail -n1)
  body=$(echo "$response" | sed '$d')
  if [ "$http_code" -ge 300 ]; then
    echo "Failed to get the protocol mappers. HTTP response code: $http_code"
    echo "Response: $body"
    exit 1
  fi

  echo "Protocol mappers: $body"

  mapper_enabled="$(echo "$body" | jq '.[] | select(.name=="entitlements" and .protocolMapper=="oidc-usermodel-attribute-mapper")')"

  echo "Mapper_enabled: $mapper_enabled"

  if [ -n "$mapper_enabled" ]; then
    echo "The protocol mapper: entitlements is already present."
  
  else

    json_attribute_payload=$(cat <<EOF
{
      "name":"entitlements",
      "protocol":"openid-connect",
      "protocolMapper":"oidc-usermodel-attribute-mapper",
      "consentRequired":false,
      "config":{
        "user.attribute":"entitlements",
        "claim.name":"$ENTITLEMENTS_CLAIM",
        "jsonType.label":"String",
        "access.token.claim":"true",
        "id.token.claim":"$ENABLE_ID_TOKEN",
        "userinfo.token.claim":"true",
        "multivalued": "true"
      }
    }
EOF
)

    echo "Adding mapper $json_attribute_payload"

    response="$(keycloak_request true -X POST "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$id/protocol-mappers/models" \
      -H 'Content-Type: application/json' \
      -d "${json_attribute_payload}")"
    http_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | sed '$d')
    if [ "$http_code" -ge 300 ]; then
      echo "Failed to add attribute mapper - entitlements. HTTP response code: $http_code"
      echo "Response: $body"
      exit 1
    fi
    echo "Successfully added attribute mapper - entitlements"

  fi

fi

if [ -n "$ROLE_MAPPINGS" ]; then
  
  response="$(keycloak_request true "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$id/service-account-user" \
      -H 'Accept: application/json')"
  http_code=$(echo "$response" | tail -n1)
  body=$(echo "$response" | sed '$d')
  if [ "$http_code" -ge 300 ]; then
    echo "Failed to get service-account user. HTTP response code: $http_code"
    echo "Response: $body"
    exit 1
  fi
  user_id="$(echo "$body" | sed -r -n 's/.*"id":"([^"]*)",.*/\1/p')"
  echo "user_id: $user_id"
  
  # Set an email for the service account, as it's required by Velocity and code
  # Sanitize CLIENT_ID for email address (replace colons and other invalid chars with dashes)
  sanitized_client_id=$(echo "$CLIENT_ID" | tr ':' '-')
  
  # Set a first and last name for the service account, as required by Code
  service_account_first_name="$sanitized_client_id"
  service_account_last_name="system-user"
  
  json_service_account_fields_payload=$(cat <<EOF
  {
    "email": "$sanitized_client_id@hcl-software.com",
    "firstName": "$service_account_first_name",
    "lastName": "$service_account_last_name"
  }
EOF
  )
  echo "Adding service account fields $json_service_account_fields_payload"
    response="$(keycloak_request true -X PUT "$KEYCLOAK_URL/admin/realms/$REALM_NAME/users/$user_id" \
      -H 'Content-Type: application/json' \
      -d "${json_service_account_fields_payload}")"
  http_code=$(echo "$response" | tail -n1)
  body=$(echo "$response" | sed '$d')
  if [ "$http_code" -ge 300 ]; then
    echo "Failed to set service account fields. HTTP response code: $http_code"
    echo "Response: $body"
    exit 1
  fi

  for perm_group in $ROLE_MAPPINGS; do
    perm_roles="$(tr '|' ' ' <<< "${perm_group#*|}")"
    perm_client=${perm_group%%|*}
    echo perm_client: $perm_client

    response="$(keycloak_request false -X GET "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients?clientId=$perm_client")"
    http_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | sed '$d')
    if [ "$http_code" -ge 300 ]; then
      echo "Failed to resolve client ID for role mapping client '$perm_client'. HTTP response code: $http_code"
      echo "Response: $body"
      exit 1
    fi

    perm_id="$(echo "$body" | jq -r '.[0].id // empty')"
    echo perm_id: $perm_id

    if [ -z "$perm_id" ]; then
      echo "Role mapping client '$perm_client' was not found in realm '$REALM_NAME'. Creating a temporary placeholder client."
      tmp_client_payload=$(cat <<EOF
{
  "clientId": "$perm_client",
  "enabled": true,
  "protocol": "openid-connect",
  "publicClient": false,
  "bearerOnly": false,
  "serviceAccountsEnabled": true,
  "standardFlowEnabled": false,
  "directAccessGrantsEnabled": false,
  "implicitFlowEnabled": false,
  "redirectUris": [
    "*"
  ],
  "webOrigins": [
    "*"
  ]
}
EOF
)
      create_response="$(keycloak_request true -X POST "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients" \
        -H 'Content-Type: application/json' \
        -d "$tmp_client_payload")"
      create_http_code=$(echo "$create_response" | tail -n1)
      create_body=$(echo "$create_response" | sed '$d')
      if [ "$create_http_code" -ge 300 ] && [ "$create_http_code" -ne 409 ]; then
        echo "Failed to create temporary role mapping client '$perm_client'. HTTP response code: $create_http_code"
        echo "Response: $create_body"
        exit 1
      fi

      response="$(keycloak_request false -X GET "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients?clientId=$perm_client")"
      http_code=$(echo "$response" | tail -n1)
      body=$(echo "$response" | sed '$d')
      if [ "$http_code" -ge 300 ]; then
        echo "Failed to resolve client ID for temporary role mapping client '$perm_client'. HTTP response code: $http_code"
        echo "Response: $body"
        exit 1
      fi

      perm_id="$(echo "$body" | jq -r '.[0].id // empty')"
      if [ -z "$perm_id" ]; then
        echo "Temporary role mapping client '$perm_client' was not resolvable after create attempt."
        exit 1
      fi
      echo "Temporary role mapping client '$perm_client' is available with id: $perm_id"
    fi

    response="$(keycloak_request true "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$perm_id/roles" \
     -H 'Accept: application/json')"
    http_code=$(echo "$response" | tail -n1)
    roles=$(echo "$response" | sed '$d')
    if [ "$http_code" -ge 300 ]; then
      echo "Failed to get client roles for $perm_client. HTTP response code: $http_code"
      echo "Response: $roles"
      exit 1
    fi
    echo "Client Roles: $roles"

    payload=
    for role in $perm_roles; do
      p="$(sed -r -n 's/.*("id":"[^"]*","name":"'"$role"'","description":"[^"]*"),.*/\1/p' <<< "$roles")"
      echo "Checking role: $role"
      if [ -n "$p" ]; then
        echo "Adding client role: $p"
        payload="$payload,{$p}"
      fi
    done

    if [ -n "$payload" ]; then
      echo "Creating client role mapping: $payload"
      response=$(keycloak_request true -X POST "$KEYCLOAK_URL/admin/realms/$REALM_NAME/users/$user_id/role-mappings/clients/$perm_id" \
        -H 'Content-Type: application/json' \
        -d @-<<EOF
[${payload:1}]
EOF
    )
      http_code=$(echo "$response" | tail -n1)
      body=$(echo "$response" | sed '$d')
      if [ "$http_code" -ge 300 ]; then
        echo "Failed to create client role mapping. HTTP response code: $http_code"
        echo "Response: $body"
        exit 1
      fi
    fi

    response="$(keycloak_request true "$KEYCLOAK_URL/admin/realms/$REALM_NAME/roles" \
     -H 'Accept: application/json')"
    http_code=$(echo "$response" | tail -n1)
    realm_roles=$(echo "$response" | sed '$d')
    if [ "$http_code" -ge 300 ]; then
      echo "Failed to get realm roles. HTTP response code: $http_code"
      echo "Response: $realm_roles"
      exit 1
    fi

    echo "Realm Roles: $realm_roles"
    payload=
    for realm_role in $perm_roles; do
      echo "Checking role: $realm_role"
      p="$(sed -r -n 's/.*("id":"[^"]*","name":"'"$realm_role"'","description":"[^"]*"),.*/\1/p' <<< "$realm_roles")"
      if [ -n "$p" ]; then
        echo "Adding realm role: $p"
        payload="$payload,{$p}"
      fi
    done

    if [ -n "$payload" ]; then
      echo "Creating realm role mapping: $payload"
      response=$(keycloak_request true -X POST "$KEYCLOAK_URL/admin/realms/$REALM_NAME/users/$user_id/role-mappings/realm" \
        -H 'Content-Type: application/json' \
        -d @-<<EOF
[${payload:1}]
EOF
    )
      http_code=$(echo "$response" | tail -n1)
      body=$(echo "$response" | sed '$d')
      if [ "$http_code" -ge 300 ]; then
        echo "Failed to create realm role mapping. HTTP response code: $http_code"
        echo "Response: $body"
        exit 1
      fi
    fi
  done
fi

# Add client-level audience mappers for specific scopes
# Format: CLIENT_AUDIENCE_SCOPES="scope1->audience1,scope2->audience2"
# Example: CLIENT_AUDIENCE_SCOPES="api:loop:all->api:loop,api:plan:all->api:plan"
if [ -n "${CLIENT_AUDIENCE_SCOPES:-}" ]; then
  echo "Processing client-level audience mappers..."
  
  # Split by comma to get individual scope->audience pairs
  IFS=',' read -ra MAPPER_SPECS <<< "$CLIENT_AUDIENCE_SCOPES"
  
  for mapper_spec in "${MAPPER_SPECS[@]}"; do
    # Skip empty entries
    if [ -z "$mapper_spec" ]; then
      continue
    fi
    
    # Split by -> to get scope and audience
    scope_name="${mapper_spec%%->*}"
    audience="${mapper_spec##*->}"
    
    if [ -z "$scope_name" ] || [ -z "$audience" ]; then
      echo "Invalid mapper spec: $mapper_spec (expected format: scope->audience)"
      continue
    fi
    
    echo "Processing audience mapper for scope '$scope_name' with audience '$audience'..."
    
    # Ensure the audience client exists (bearer-only client for the audience)
    if [[ "$audience" == api:* ]]; then
      echo "Ensuring audience client '$audience' exists..."
      
      # Check if audience client already exists
      response="$(keycloak_request false -X GET "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients?clientId=$audience")"
      http_code=$(echo "$response" | tail -n1)
      body=$(echo "$response" | sed '$d')
      if [ "$http_code" -ge 300 ]; then
        echo "Failed to query audience client '$audience'. HTTP: $http_code"
        echo "Response: $body"
        continue
      fi
      audience_client_id=$(echo "$body" | jq -r '.[0].id // empty')
      
      if [ -z "$audience_client_id" ]; then
        echo "Creating bearer-only audience client '$audience'..."
        
        audience_payload=$(jq -n \
          --arg clientId "$audience" \
          '{
            clientId: $clientId,
            bearerOnly: true,
            publicClient: false,
            standardFlowEnabled: false,
            directAccessGrantsEnabled: false,
            serviceAccountsEnabled: false,
            authorizationServicesEnabled: false
          }')
        
        response=$(keycloak_request true -X POST "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients" \
          -H 'Content-Type: application/json' \
          -d "$audience_payload")
        
        http_code=$(echo "$response" | tail -n1)
        body=$(echo "$response" | sed '$d')
        
        if [ "$http_code" -ge 300 ]; then
          echo "Failed to create audience client '$audience'. HTTP: $http_code"
          echo "Response: $body"
          continue
        fi
        echo "Successfully created audience client '$audience'"
      else
        echo "Audience client '$audience' already exists"
      fi
    fi
    
    echo "Checking if client has scope '$scope_name' to add audience mapper for '$audience'..."
    
    # Check if client has this scope (check both optional and default scopes)
    response="$(keycloak_request false -X GET \
      "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$id/optional-client-scopes")"
    http_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | sed '$d')
    if [ "$http_code" -ge 300 ]; then
      echo "Failed to list optional scopes for client. HTTP: $http_code"
      echo "Response: $body"
      continue
    fi
    has_optional_scope=$(echo "$body" | jq -r --arg scope "$scope_name" '.[] | select(.name==$scope) | .id')
    
    response="$(keycloak_request false -X GET \
      "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$id/default-client-scopes")"
    http_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | sed '$d')
    if [ "$http_code" -ge 300 ]; then
      echo "Failed to list default scopes for client. HTTP: $http_code"
      echo "Response: $body"
      continue
    fi
    has_default_scope=$(echo "$body" | jq -r --arg scope "$scope_name" '.[] | select(.name==$scope) | .id')
    
    if [ -z "$has_optional_scope" ] && [ -z "$has_default_scope" ]; then
      echo "Client does not have scope '$scope_name', skipping audience mapper"
      continue
    fi
    
    echo "Client has scope '$scope_name', adding audience mapper..."
    
    # Create unique mapper name
    mapper_name="${scope_name}-audience-mapper"
    
    # Check if mapper already exists
    response="$(keycloak_request false -X GET \
      "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$id/protocol-mappers/models")"
    http_code=$(echo "$response" | tail -n1)
    existing_mappers=$(echo "$response" | sed '$d')
    if [ "$http_code" -ge 300 ]; then
      echo "Failed to list existing protocol mappers. HTTP: $http_code"
      echo "Response: $existing_mappers"
      continue
    fi
    
    mapper_id=$(echo "$existing_mappers" | jq -r --arg name "$mapper_name" \
      '.[] | select(.name==$name) | .id' | head -n1)
    
    # Create the audience mapper payload
    mapper_payload=$(jq -n \
      --arg name "$mapper_name" \
      --arg audience "$audience" \
      '{
        name: $name,
        protocol: "openid-connect",
        protocolMapper: "oidc-audience-mapper",
        consentRequired: false,
        config: {
          "id.token.claim": "false",
          "lightweight.claim": "false",
          "access.token.claim": "true",
          "introspection.token.claim": "true",
          "included.client.audience": $audience
        }
      }')
    
    echo "Mapper payload for '$mapper_name' with audience '$audience':"
    echo "$mapper_payload" | jq '.'
    
    # Upsert the mapper (update if exists, create if not)
    if [ -n "$mapper_id" ] && [ "$mapper_id" != "null" ]; then
      echo "Updating audience mapper '$mapper_name' on client..."
      mapper_payload=$(echo "$mapper_payload" | jq --arg id "$mapper_id" '.id = $id')
      response=$(keycloak_request true -X PUT \
        "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$id/protocol-mappers/models/$mapper_id" \
        -H 'Content-Type: application/json' \
        -d "$mapper_payload")
    else
      echo "Creating audience mapper '$mapper_name' on client..."
      response=$(keycloak_request true -X POST \
        "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$id/protocol-mappers/models" \
        -H 'Content-Type: application/json' \
        -d "$mapper_payload")
    fi
    
    http_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | sed '$d')
    
    if [ "$http_code" -ge 300 ]; then
      echo "Failed to upsert audience mapper '$mapper_name' for client. HTTP: $http_code"
      echo "Response: $body"
      # Don't exit, continue with other mappers
    else
      echo "Successfully upserted audience mapper '$mapper_name' for audience '$audience'"
    fi
  done
fi
