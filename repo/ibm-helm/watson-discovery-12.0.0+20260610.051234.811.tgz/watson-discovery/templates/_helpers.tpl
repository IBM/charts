{{- define "discovery.operator.image" -}}
{{- $root := (index . 0) -}}
{{- $image := (index . 1 ) -}}
  {{- if $root.Values.global.imagePullPrefix -}}
{{- $root.Values.global.imagePullPrefix | trimSuffix "/" }}/
  {{- end -}}
{{- $image.name -}}
  {{- if $image.tag -}}
:{{ $image.tag -}}
  {{- end -}}
  {{- if $image.digest -}}
@{{ $image.digest }}
  {{- end -}}
{{- end -}}

{{- define "discovery.imagePullSecrets" -}}
{{- $operatorSecret := .Values.watsonDiscovery.operator.image.pullSecret -}}
{{- $globalSecret := .Values.global.imagePullSecret -}}
{{- if $operatorSecret }}
imagePullSecrets:
- name: {{ $operatorSecret }}
{{- else if $globalSecret }}
imagePullSecrets:
- name: {{ $globalSecret }}
{{- end -}}
{{- end -}}

{{- define "discovery.dockerRegistryPrefix" -}}
{{- $operandPrefix := "" -}}
{{- if and .Values.watsonDiscovery.operand .Values.watsonDiscovery.operand.imagePullPrefix -}}
  {{- $operandPrefix = .Values.watsonDiscovery.operand.imagePullPrefix -}}
{{- end -}}
{{- $globalPrefix := .Values.global.imagePullPrefix -}}
{{- if $operandPrefix -}}
{{ $operandPrefix }}
{{- else if eq $globalPrefix "icr.io" -}}
cp.icr.io
{{- else if $globalPrefix -}}
{{ $globalPrefix }}
{{- end -}}
{{- end -}}

{{- define "discovery.names.fullCompName" -}}
  {{- $root := (index . 0) -}}
  {{- $compName := (index . 1 ) -}}
  {{- $releaseName := $root.Values.watsonDiscovery.crName -}}
  {{- $appName := $root.Values.watsonDiscovery.appName -}}
  {{- (printf "%s-%s-%s" $releaseName $appName $compName) -}}
{{- end -}}

{{- define "isExcluded" -}}
{{- $key := index . 0 -}}
{{- $excludes := index . 1 -}}
{{- range $e := $excludes -}}
{{- if (eq $key $e ) -}}
true
{{- end -}}
{{- end -}}
false
{{- end -}}

{{- define "discovery.metadata.labels.standard" -}}
  {{- $params := . -}}
  {{- $top := first $params -}}
  {{- $compName := (include "discovery.utils.getItem" (list $params 1 "")) -}}

app.kubernetes.io/name: {{ quote $top.Values.watsonDiscovery.appName }}
helm.sh/chart: {{ $top.Chart.Name | quote }}
{{- /* Allow for overriding the app.kubernetes.io/managed-by parameter */ -}}
  {{- if (gt (len $params) 2) }}
    {{- $moreLabels := (index $params 2) -}}
    {{- if hasKey $moreLabels "app.kubernetes.io/managed-by" }}
app.kubernetes.io/managed-by: {{ index $moreLabels "app.kubernetes.io/managed-by" | quote }}
    {{- else }}
app.kubernetes.io/managed-by: {{ $top.Release.Service | quote }}
    {{- end }}
  {{- else }}
app.kubernetes.io/managed-by: {{ $top.Release.Service | quote }}
  {{- end }}
app.kubernetes.io/instance: {{ $top.Release.Name | quote }}
release: {{ $top.Release.Name | quote }}
  {{- if $compName }}
app.kubernetes.io/component: {{ $compName | quote }}
  {{- end -}}

  {{- if (gt (len $params) 2) -}}
    {{- $moreLabels := (index $params 2) -}}
    {{- range $k, $v := $moreLabels }}
      {{- if (not (eq $k "app.kubernetes.io/managed-by"))}}
{{ $k }}: {{ $v | quote }}
      {{- end -}}
    {{- end -}}
  {{- end -}}
{{- end -}}

{{- define "discovery.metadata.annotations.metering" -}}
  {{- $params := . -}}
  {{- $top := first $params -}}
  {{- if (gt (len $params) 1) -}}
    {{- $metering := (index $params 1) -}}
    {{- $excluded := (list "productChargedContainers" "productMetric" "productCloudpakRatio")}}
    {{- range $k, $v := $metering }}
      {{- /* Handle these ilmt parameters outside of the loop */ -}}
      {{- if not (has $k $excluded) }}
{{ $k }}: {{ $v | quote }}
      {{- end }}
    {{- end }}
    {{- /* Future note: This section could be less clunky with Helm 2.12 which can handle parameter reassignment via `=` */}}
    {{- if (eq (len $params) 5) }}
productMetric: {{ (index $params 2) | default $metering.productMetric | quote }}
      {{- if or (index $params 3) (hasKey $metering "productCloudpakRatio") }}
productCloudpakRatio: {{ (index $params 3) | default $metering.productCloudpakRatio | quote }}
      {{- end }}
      {{- if (index $params 4) }}
productChargedContainers: {{ (index $params 4) | join ";" }}
      {{- else if (hasKey $metering "productChargedContainers")}}
productChargedContainers: {{ $metering.productChargedContainers | quote }}
      {{- end }}
    {{- end }}
  {{- end -}}
{{- end -}}

{{- define "discovery.security.securityContext" -}}
  {{- $params := . }}
  {{- $root := first $params }}
  {{- $securityParams := (index $params 1) }}
{{ toYaml $securityParams }}
{{- end }}

{{- define "discovery.chart.config.values" -}}
discovery:
  chart:
    appName: "{{ .Values.watsonDiscovery.appName }}"
    components:
      operator:
        name: "operator"
      appConfig:
        name: "app-config"
    labelType: prefixed
    metering:
      productName: {{ .Values.watsonDiscovery.metering.productName }}
      productID: {{ .Values.watsonDiscovery.metering.productId }}
      productVersion: {{ .Values.watsonDiscovery.metering.productVersion }}
      productMetric: {{ .Values.watsonDiscovery.metering.productMetric }}
      productChargedContainers: {{ .Values.watsonDiscovery.metering.productChargedContainers }}
      productCloudpakRatio: {{ .Values.watsonDiscovery.metering.productCloudpakRatio }}
      cloudpakName: {{ .Values.watsonDiscovery.metering.cloudpakName }}
      cloudpakId: {{ .Values.watsonDiscovery.metering.cloudpakId }}
    restrictedPodSecurityContext:
      hostNetwork: false
      hostPID: false
      hostIPC: false
      securityContext:
        runAsNonRoot: true
  {{- if not (.Capabilities.APIVersions.Has "security.openshift.io/v1") }}
        runAsUser: 1001
  {{- end }}
    restrictedSecurityContext:
      securityContext:
        allowPrivilegeEscalation: false
        capabilities:
          drop:
          - ALL
        privileged: false
        readOnlyRootFilesystem: false
      {{- if not (.Capabilities.APIVersions.Has "security.openshift.io/v1") }}
        runAsUser: 1001
      {{- end }}
  {{- end }}


{{- define "discovery.affinity.nodeAffinityRequiredDuringScheduling" -}}
    {{- $params := . }}
    {{- $root := first $params }}
    {{- $affinity := last $params -}}
    {{- $operator := $affinity.nodeAffinityRequiredDuringScheduling.operator -}}
    {{- $values := $affinity.nodeAffinityRequiredDuringScheduling.values -}}
    {{- if $root.Values.arch -}}
      {{- $archType := typeOf $root.Values.arch -}}
      {{- if eq $archType "map[string]interface {}" -}}
        {{- /* Helm templating has issues with reassigning variables within a loop in some versions of Helm. */ -}}
        {{- /* It also cannot break from a loop. Using a dictionary in this way is a workaround for this issue. */ -}}
        {{- $firstFound := dict "firstFound" false }}
        {{- range $key, $value := $root.Values.arch }}
          {{- $splitValue := split " " $value }}
          {{- $weight := $splitValue._0 | int64 }}
          {{- if gt $weight 0 }}
            {{- if hasKey $firstFound "firstFound" }}
              {{- $_ := unset $firstFound "firstFound" }}
  requiredDuringSchedulingIgnoredDuringExecution:
    nodeSelectorTerms:
    - matchExpressions:
      - key: {{ default "beta.kubernetes.io/arch" $affinity.nodeAffinityRequiredDuringScheduling.key }}
        operator: {{ $operator }}
        values:
            {{- end }}
        - {{ $key }}
          {{- end }}
        {{- end -}}
      {{- else }}
  requiredDuringSchedulingIgnoredDuringExecution:
    nodeSelectorTerms:
    - matchExpressions:
      - key: {{ default "beta.kubernetes.io/arch" $affinity.nodeAffinityRequiredDuringScheduling.key }}
        operator: {{ $operator }}
        values:
        - {{ $root.Values.arch }}
      {{- end -}}
    {{- else -}}
  requiredDuringSchedulingIgnoredDuringExecution:
    nodeSelectorTerms:
    - matchExpressions:
      - key: {{ default "beta.kubernetes.io/arch" $affinity.nodeAffinityRequiredDuringScheduling.key }}
        operator: {{ $operator }}
        values:
    {{- range $key := $values }}
        - {{ $key }}
    {{- end -}}
    {{- end -}}
{{- end }}

{{- define "discovery.affinity.nodeAffinityPreferredDuringScheduling" -}}
  {{- $params := . }}
  {{- $root := first $params }}
  {{- $nodeAffinity := last $params -}}
  {{- $affinityDefault := $nodeAffinity.nodeAffinityPreferredDuringScheduling -}}
  {{- $affinity := $root.Values.global.arch | default $affinityDefault -}}
  {{- if not $root.Values.global.arch }}
  {{- range $key, $value := $affinity }}
    {{- $weight := $value.weight | int64 }}
    {{- if gt $weight 0 }}
preferredDuringSchedulingIgnoredDuringExecution:
      {{- $operator := $value.operator }}
- weight: {{ $weight }}
  preference:
    matchExpressions:
    - key: {{ default "beta.kubernetes.io/arch" $value.key }}
      operator: {{ default "In" $operator }}
      values:
      - {{ $key }}
    {{ end -}}
  {{ end -}}
  {{- else if and ($root.Values.global.arch) (eq (typeOf $root.Values.global.arch) "map[string]interface {}") }}
    {{- $firstFound := dict "firstFound" false }}
    {{- range $key, $value := $root.Values.global.arch }}
      {{- $splitValue := split " " $value }}
      {{- $weight := $splitValue._0 | int64 }}
      {{- if gt $weight 0 }}
      {{- if hasKey $firstFound "firstFound" }}
        {{- $_ := unset $firstFound "firstFound" }}
preferredDuringSchedulingIgnoredDuringExecution:
      {{- end }}
- weight: {{ $weight }}
  preference:
    matchExpressions:
    - key: "beta.kubernetes.io/arch"
      operator: "In"
      values:
      - {{ $key }}
      {{- end -}}
    {{- end -}}
  {{- end }}
{{- end }}

{{- define "discovery.affinity.nodeAffinity" -}}
  {{- $params := . }}
  {{- $root := first $params }}
  {{- $defaultRoot := fromYaml (include "discovery.chart.default.config.values" .) }}
  {{- $defaultNodeAffinity := $defaultRoot.discovery.chart.nodeAffinity }}
  {{- $nodeAffinity := $root.discovery.chart.nodeAffinity | default $defaultNodeAffinity }}
nodeAffinity:
  {{- if (gt (len $nodeAffinity) 0) -}}
    {{- if or (hasKey $nodeAffinity "nodeAffinityRequiredDuringScheduling") (hasKey $root.Values.global "arch") }}
  {{ include "discovery.affinity.nodeAffinityRequiredDuringScheduling" (list $root $nodeAffinity) -}}
    {{- end }}
    {{- if or (hasKey $nodeAffinity "nodeAffinityPreferredDuringScheduling") (hasKey $root.Values.global "arch") }}
  {{- include "discovery.affinity.nodeAffinityPreferredDuringScheduling" (list $root $nodeAffinity) | indent 2 }}
    {{- end }}
  {{- end }}
{{- end }}

{{- define "discovery.chart.default.config.values" -}}
discovery:
  chart:
    appName: ""
    nodeAffinity:
      nodeAffinityRequiredDuringScheduling:
        key: beta.kubernetes.io/arch
        operator: In
        values:
          - amd64
          - ppc64le
          - s390x
{{- end -}}

{{- define "discovery.config.values" -}}
discovery:
  chart:
    appName: ""
    labelType: non-prefixed
    secretGen:
      suffix: "generated"
      secrets: []
  names:
    fullName:
      maxLength: 63
      releaseNameTruncLength: 42
      appNameTruncLength: 20
    fullCompName:
      maxLength: 63
      releaseNameTruncLength: 36
      appNameTruncLength: 13
      compNameTruncLength: 12
    statefulSetName:
      maxLength: 33
      releaseNameTruncLength: 15
      appNameTruncLength: 7
      compNameTruncLength: 9
    volumeClaimTemplateName:
      maxLength: 63
      possiblePrefix: "glusterfs-dynamic-"
      claimNameTruncLength: 7
    persistentVolumeClaimName:
      maxLength: 63
      possiblePrefix: "glusterfs-dynamic-"
      releaseNameTruncLength: 18
      appNameTruncLength: 13
      claimNameTruncLength: 12
{{- end -}}


{{- define "discovery.config.init" -}}
  {{- $params := . -}}
  {{- $root := first $params -}}
  {{- $schChartConfigName := (include "discovery.utils.getItem" (list $params 1 "discovery.chart.default.config.values")) -}}
  {{- $schChartConfig := fromYaml (include $schChartConfigName $root) -}}
  {{- $schConfig := fromYaml (include "discovery.config.values" $root) -}}
  {{- if not $schChartConfig -}}
  {{- fail (cat "discovery import failure: Unable to merge sch into values as the data passed is <nil>") -}}
  {{- end -}}
  {{- $_ := merge $root $schChartConfig -}}
  {{- $_ := merge $root $schConfig -}}
  {{- /* appName and shortName are in $root by default and need to be forcefully overwritten if they exist */ -}}
  {{- if hasKey $schChartConfig.discovery "chart" }}
    {{- if hasKey $schChartConfig.discovery.chart "appName" }}
      {{- $_ := set $root.discovery.chart "appName" $schChartConfig.discovery.chart.appName }}
    {{- end }}
    {{- if hasKey $schChartConfig.discovery.chart "shortName" }}
      {{- $_ := set $root.discovery.chart "shortName" $schChartConfig.discovery.chart.shortName }}
    {{- end }}
  {{- end }}
{{- end -}}


{{- define "discovery.utils.getItem" -}}
  {{- $params := . -}}
  {{- $list := first $params -}}
  {{- $index := (index $params 1) -}}
  {{- $default := (index $params 2) -}}
  {{- if (gt (add $index 1) (len $list) ) -}}
    {{- $default -}}
  {{- else -}}
    {{- index $list $index -}}
  {{- end -}}
{{- end -}}

{{/*
WATCH_NAMESPACE environment variable template with fallback logic
Priority order:
1. .Values.watsonDiscovery.operator.watchNamespaces (explicit configuration)
2. .Values.global.operatorNamespace + .Values.global.instanceNamespace (global defaults)
3. namespace-scope ConfigMap (fallback)
args: rootContext
*/}}
{{- define "discovery.operator.watchNamespace" -}}
  {{- $root := . -}}
  {{- if $root.Values.watsonDiscovery.operator.watchNamespaces -}}
value: {{ join "," $root.Values.watsonDiscovery.operator.watchNamespaces }}
  {{- else -}}
    {{- $namespaces := compact (list $root.Values.global.operatorNamespace $root.Values.global.instanceNamespace) -}}
    {{- if $namespaces -}}
value: {{ join "," (uniq $namespaces) }}
    {{- else -}}
valueFrom:
  configMapKeyRef:
    key: namespaces
    name: namespace-scope
    optional: true
    {{- end -}}
  {{- end -}}
{{- end -}}