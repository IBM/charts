{{/* Print the configurations */}}
{{- define "k5-user-license-service-configmapentries" -}}
server.servlet.context-path: ${BASE_PATH}
springdoc.swagger-ui.config-url: ${BASE_PATH}/-/k5-user-license-service/api-docs/swagger-config
de.knowis.cp.run.userLicenseService.host.name: "{{ tpl .Values.global.domain . }}{{ .Values.global.k5.ingress.path }}{{ .Values.global.k5.endpoints.userLicenseService.path }}"
de.knowis.cp.run.userLicenseService.host.protocol: {{ .Values.configurations.protocol | quote }}
de.knowis.cp.run.userLicenseService.cors.allowedDomains: {{ include "k5-user-license-service.cors-allowed-domains.builder" . | trimSuffix "," | quote }}
de.knowis.cp.run.userLicenseService.license.dllSOLocation: {{ .Values.license.dllSOLocation | quote }}
de.knowis.cp.run.userLicenseService.license.lksSearchPath: "{{ .Values.rationalLicenseKeyServer.port }}{{ .Values.global.rationalLicenseKeyServer }}"
de.knowis.cp.run.userLicenseService.license.featureNames: {{ join "," .Values.license.featureNames | quote }}
de.knowis.cp.run.userLicenseService.license.featureNameProfessional: {{ .Values.license.featureNameProfessional | quote }}
de.knowis.cp.run.userLicenseService.license.featureNameArchitect: {{ .Values.license.featureNameArchitect | quote }}
de.knowis.cp.run.userLicenseService.license.version: {{ .Values.license.version | quote }}
de.knowis.cp.run.userLicenseService.license.logFileLocation: {{ .Values.license.logFileLocation | quote }}
de.knowis.cp.run.userLicenseService.license.ttl: {{ .Values.license.ttl | quote }}
de.knowis.cp.run.userLicenseService.license.cronEnabled: {{ .Values.license.cronEnabled | quote }}
de.knowis.cp.run.userLicenseService.license.scheduleInMinutes: {{ .Values.license.scheduleInMinutes | quote }}
# Thread pool configuration for license processing
de.knowis.cp.run.userLicenseService.license.corePoolSize: {{ .Values.license.corePoolSize | quote }}
de.knowis.cp.run.userLicenseService.license.maxPoolSize: {{ .Values.license.maxPoolSize | quote }}
de.knowis.cp.run.userLicenseService.license.queueCapacity: {{ .Values.license.queueCapacity | quote }}
# When true, GET /api/userconfig/v1/keycloak/users uses the configured identity provider;
# when false, uses MongoDB
de.knowis.cp.run.userLicenseService.oidc.defaultIdentityProviderEnabled: {{ .Values.defaultIdentityProvider.enabled | quote }}

{{- if .Values.global.platform.enabled }}
de.knowis.cp.run.userLicenseService.keycloakConfig.url: 'https://{{ .Values.global.domain }}/auth'
{{- else }}
de.knowis.cp.run.userLicenseService.keycloakConfig.url: '{{ .Values.global.k5.identity.url }}'
{{- end }}
de.knowis.cp.run.userLicenseService.keycloakConfig.realm: {{ default "devops-automation" .Values.global.k5.identity.realm | quote }}
de.knowis.cp.run.userLicenseService.keycloakConfig.username: {{ default "keycloak" .Values.global.k5.identity.username | quote }}
de.knowis.cp.run.userLicenseService.keycloakConfig.keyCloakTokenURL: {{ tpl .Values.configurations.keycloakConfig.keyCloakTokenURL . | quote }}
de.knowis.cp.run.userLicenseService.keycloakConfig.keyCloakRealmURL: {{ tpl .Values.configurations.keycloakConfig.keyCloakRealmURL . | quote }}

# Spring settings
{{- if .Values.configmap.spring }}
{{ tpl .Values.configmap.spring . }}
{{- end }}

# logging settings
{{- if .Values.configmap.logging }}
{{ tpl .Values.configmap.logging . }}
{{- end }}

# Additional settings
{{- if .Values.configmap.extraConfiguration }}
{{ tpl .Values.configmap.extraConfiguration . }}
{{- end }}

{{- end -}}
