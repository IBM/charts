{{/* Print the configurations */}}
{{- define "k5-design-assistant-configmapentries" -}}
pipelineUrlVersion: ""
{{- end -}}
