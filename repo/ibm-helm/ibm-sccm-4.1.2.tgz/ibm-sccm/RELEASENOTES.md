# Breaking Changes

- Starting with this release, the default value for storageSecurity.runAsUser is left blank. This change does not affect existing configurations during upgrades, ensuring backward compatibility. However, for fresh installations, it is recommended to explicitly set a value if needed; otherwise, a random user ID will be assigned based on the Security Context Constraints (SCC) applied to the pod.

# Fixes

Please refer to [Fix List](https://www.ibm.com/docs/en/control-center/6.4.1?topic=641-sterling-control-center-release-notes)

# Prerequisites

Please refer prerequisites section from [README.md](README.md)

# Documentation

Please refer to [README.md](README.md) provided with chart for detailed installation instruction.

# Version History

| Chart  | Date          | Kubernetes Required | OpenShift Required  | Image(s) Supported           | Details                                    |
| ------ | ------------- | ------------------- | ------------------- | ---------------------------- | ------------------------------------------ |
| 4.1.0  | Jul 07, 2025  | >= 1.30             | >= 4.15             | ibmscc:6.4.1.0_2025-07-07    | IBM Sterling Control Center Monitor 6.4.1.0|
| ------ | ------------- | ------------------- | ------------------- | ---------------------------- | ------------------------------------------ |
| 4.1.1  | Nov 26, 2025  | >= 1.30             | >= 4.15             | ibmscc:6.4.1.0_2025-11-24    | IBM Sterling Control Center Monitor 6.4.1.0|
| ------ | ------------- | ------------------- | ------------------- | ---------------------------- | ------------------------------------------ |
| 4.1.2  | Mar 02, 2026  | >= 1.30             | >= 4.15             | ibmscc:6.4.1.0.iFix01_2026-03-02    | IBM Sterling Control Center Monitor 6.4.1.0|
| ------ | ------------- | ------------------- | ------------------- | ---------------------------- | ------------------------------------------ |
