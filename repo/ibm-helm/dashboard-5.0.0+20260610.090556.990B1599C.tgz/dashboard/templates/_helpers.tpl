{{/*
Returns watch namespaces as comma-seperated values.
*/}}
{{- define "dashboard.watch_namespace" -}}
{{- $watchNamespaces := list -}}
{{- if .Values.global.operatorNamespace -}}
{{- $watchNamespaces = append $watchNamespaces .Values.global.operatorNamespace -}}
{{- end -}}
{{- if .Values.global.instanceNamespace -}}
{{- $watchNamespaces = append $watchNamespaces .Values.global.instanceNamespace -}}
{{- end -}}
{{ uniq $watchNamespaces | join "," | quote }}
{{- end -}}
