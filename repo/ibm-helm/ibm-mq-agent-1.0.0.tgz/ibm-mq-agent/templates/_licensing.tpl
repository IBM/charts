{{/*
  other valid licenses in future can be added here 
*/}}

{{- define "mq-agent.license.validLicenses" }}
- L-JVBD-R9HX59
- L-SJZL-NMUUCT
- L-JNME-56SJTB
{{- end }}