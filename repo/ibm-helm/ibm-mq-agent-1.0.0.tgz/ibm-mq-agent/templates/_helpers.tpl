

{{- define "ibm-mq-agent.image" -}}
{{- if .Values.agent.deployment.tag -}}
{{ default "cp.icr.io" .Values.privateRegistry }}/{{ .Values.agent.deployment.repository }}:{{ .Values.agent.deployment.tag }}
{{- else if .Values.agent.deployment.sha -}}
{{ default "cp.icr.io" .Values.privateRegistry }}/{{ .Values.agent.deployment.repository }}@{{ .Values.agent.deployment.sha }}
{{- end -}}
{{- end -}}

{{- define "ibm-mq-mcpServer.image" -}}
{{- if .Values.mcpServer.deployment.tag -}}
{{ default "cp.icr.io" .Values.privateRegistry }}/{{ .Values.mcpServer.deployment.repository }}:{{ .Values.mcpServer.deployment.tag }}
{{- else if .Values.mcpServer.deployment.sha -}}
{{ default "cp.icr.io" .Values.privateRegistry }}/{{ .Values.mcpServer.deployment.repository }}@{{ .Values.mcpServer.deployment.sha }}
{{- end -}}
{{- end -}}

{{- define "ibm-mq-agent.service.name" -}}
ibm-mq-agent-{{ .Release.Name }}
{{- end -}}

{{- define "ibm-mq-agent.port" -}}
8001
{{- end -}}

{{- define "ibm-mq-agent.selectorLabels" -}}
app.kubernetes.io/name: "ibm-mq-agent"
app.kubernetes.io/instance: "{{ .Release.Name }}"
app.kubernetes.io/managed-by: "Helm"
app.kubernetes.io/component: integration
{{- end -}}

{{- define "ibm-mq-agent.labels" -}}
{{- include "ibm-mq-agent.selectorLabels" . }}
app.kubernetes.io/version: "{{ .Chart.Version | replace "+" "_" }}"
{{- end -}}

{{- define "mq-agent.providers.validProviders" }}
- watsonxService
{{- end -}}

{{- define "mq-agent.provider.defaultProvider.uri" }}
{{- (get .Values.agent.model.providers .Values.agent.model.providerSelection.default).uri -}}
{{- end }}
