{{/*
Expand the name of the chart.
Defaults to openrag-cpd-operator unless nameOverride is provided.
*/}}
{{- define "ibm-openrag-operator.name" -}}
{{- default "openrag-cpd-operator" .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Operator image pull prefix priority:
1. ibmWxdOpenrag.devImagePullPrefix
2. global.imagePullPrefix
3. default: icr.io
*/}}
{{- define "ibm-openrag-operator.operatorImagePullPrefix" -}}
{{- if .Values.ibmWxdOpenrag.devImagePullPrefix -}}
{{- .Values.ibmWxdOpenrag.devImagePullPrefix -}}
{{- else if .Values.global.imagePullPrefix -}}
{{- .Values.global.imagePullPrefix -}}
{{- else -}}
icr.io
{{- end -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
Do not derive from Chart.Name or Release.Name because split packaging
may rename the chart (for example, adding -cluster-scoped), while
Kubernetes resource names must remain canonical.
*/}}
{{- define "ibm-openrag-operator.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- include "ibm-openrag-operator.name" . }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "ibm-openrag-operator.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "ibm-openrag-operator.labels" -}}
helm.sh/chart: {{ include "ibm-openrag-operator.chart" . }}
{{ include "ibm-openrag-operator.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/component: operator
{{- end }}

{{/*
Selector labels
*/}}
{{- define "ibm-openrag-operator.selectorLabels" -}}
app.kubernetes.io/name: {{ include "ibm-openrag-operator.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "ibm-openrag-operator.serviceAccountName" -}}
{{- default "ibm-openrag-serviceaccount" .Values.ibmWxdOpenrag.operator.serviceAccount.name }}
{{- end }}

{{- define "ibm-openrag-oss-operator.serviceAccountName" -}}
{{ .Values.ibmWxdOpenrag.oss.serviceAccount.name | default "openrag-oss-serviceaccount" }}
{{- end }}

{{/*
IBM Product metering annotations
*/}}
{{- define "ibm-openrag-operator.meteringAnnotations" -}}
productName: {{ .Values.ibmWxdOpenrag.productMetering.productName | quote }}
productVersion: {{ .Values.ibmWxdOpenrag.productMetering.productVersion | quote }}
productMetric: {{ .Values.ibmWxdOpenrag.productMetering.productMetric | quote }}
productChargedContainers: {{ .Values.ibmWxdOpenrag.productMetering.productChargedContainers | quote }}
cloudpakId: {{ .Values.ibmWxdOpenrag.productMetering.cloudpakId | quote }}
cloudpakName: {{ .Values.ibmWxdOpenrag.productMetering.cloudpakName | quote }}
cloudpakVersion: {{ .Values.ibmWxdOpenrag.productMetering.cloudpakVersion | quote }}
{{- end }}

{{/*
IBM Cloud Pak for Data required labels (for cluster-scoped resources - no 'name' label)
*/}}
{{- define "ibm-openrag-operator.cpdLabels" -}}
component-id: {{ .Chart.Name }}
icpdsupport/addOnId: {{ .Values.ibmWxdOpenrag.addOnId }}
{{- end }}

{{/*
Namespace for operator deployment
*/}}
{{- define "ibm-openrag-operator.namespace" -}}
{{- if .Values.namespace }}
{{- .Values.ibmWxdOpenrag.namespace }}
{{- else }}
{{- .Release.Namespace }}
{{- end }}
{{- end }}

{{/*
Watch namespace configuration
*/}}
{{- define "ibm-openrag-operator.watchNamespace" -}}
{{- if .Values.ibmWxdOpenrag.watchNamespace }}
{{- .Values.watchNamespace }}
{{- else }}
{{- "" }}
{{- end }}
{{- end }}