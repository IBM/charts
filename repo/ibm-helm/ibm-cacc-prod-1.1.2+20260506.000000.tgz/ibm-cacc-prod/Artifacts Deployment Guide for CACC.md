# Artifacts Deployment Guide for CACC

## Overview
This guide explains how to add artifacts support to your CACC cluster, enabling you to provide JDBC drivers, certificates, fonts, images, and other resources to CACC services.

## Prerequisites
- CACC instance deployed in your cluster
- StorageClass available (e.g., `nfsstorage`)
- kubectl access with appropriate permissions

---

## Step 1: Create Artifacts PVC

Create a PersistentVolumeClaim for artifacts storage:

```bash
cat <<EOF | kubectl apply -f -
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: artifact-pvc
  namespace: <your-namespace>
spec:
  accessModes:
    - ReadWriteOnce
  storageClassName: <your-storage-class>
  resources:
    requests:
      storage: 5Gi
EOF
```

Verify PVC is bound:
```bash
kubectl get pvc artifact-pvc -n <your-namespace>
```

---

## Step 2: Create Artifacts Manager Deployment

Create a deployment to access the PVC:

```bash
cat <<EOF | kubectl apply -f -
apiVersion: apps/v1
kind: Deployment
metadata:
  name: artifacts-manager
  namespace: <your-namespace>
spec:
  replicas: 1
  selector:
    matchLabels:
      app: artifacts-manager
  template:
    metadata:
      labels:
        app: artifacts-manager
    spec:
      containers:
      - name: artifacts-container
        image: registry.access.redhat.com/ubi9/ubi-minimal:latest  ##we may need change the location since Jim already put ubi image in cp.icr.io
        command: ["/bin/sh", "-c", "sleep infinity"]
        volumeMounts:
        - name: artifact-volume
          mountPath: /artifacts
      volumes:
      - name: artifact-volume
        persistentVolumeClaim:
          claimName: artifact-pvc
EOF
```

Wait for pod to be ready:
```bash
kubectl wait --for=condition=ready pod -l app=artifacts-manager -n <your-namespace> --timeout=120s
```

---

## Step 3: Create Artifacts Folder Structure

Get the pod name and create required directories:

```bash
POD_NAME=$(kubectl get pods -n <your-namespace> -l app=artifacts-manager -o jsonpath='{.items[0].metadata.name}')

kubectl exec -ti ${POD_NAME} -n <your-namespace> -- mkdir -p /artifacts/certs
kubectl exec -ti ${POD_NAME} -n <your-namespace> -- mkdir -p /artifacts/csdrivers
kubectl exec -ti ${POD_NAME} -n <your-namespace> -- mkdir -p /artifacts/cjap
kubectl exec -ti ${POD_NAME} -n <your-namespace> -- mkdir -p /artifacts/configuration
kubectl exec -ti ${POD_NAME} -n <your-namespace> -- mkdir -p /artifacts/dsdrivers
kubectl exec -ti ${POD_NAME} -n <your-namespace> -- mkdir -p /artifacts/fonts
kubectl exec -ti ${POD_NAME} -n <your-namespace> -- mkdir -p /artifacts/images
```

Verify structure:
```bash
kubectl exec ${POD_NAME} -n <your-namespace> -- ls -la /artifacts/
```

---

## Step 4: Populate Artifacts (Optional)

Copy files to the appropriate directories:
(Those example we may not need becasue I remeber Greg dont want show those to custer (I maybe wrong))
### JDBC Drivers
```bash
kubectl cp ./drivers/db2jcc4.jar ${POD_NAME}:/artifacts/dsdrivers/db2jcc4.jar -n <your-namespace>
kubectl cp ./drivers/ojdbc8.jar ${POD_NAME}:/artifacts/dsdrivers/ojdbc8.jar -n <your-namespace>
```

### Certificates
```bash
kubectl cp ./certs/ca-cert.pem ${POD_NAME}:/artifacts/certs/ca-cert.pem -n <your-namespace>
```

### Fonts
```bash
kubectl cp ./fonts/custom-font.ttf ${POD_NAME}:/artifacts/fonts/custom-font.ttf -n <your-namespace>
```

### Images
```bash
kubectl cp ./images/logo.png ${POD_NAME}:/artifacts/images/logo.png -n <your-namespace>
```

### Configuration Files
```bash
kubectl cp ./config/custom.properties ${POD_NAME}:/artifacts/configuration/custom.properties -n <your-namespace>
```

---

## Step 5: Register Artifacts with CACC

### 5.1 Update Helm Values File

Edit your CACC Helm values or override file and add the `pvcArtifactsRootFolder` configuration under the `configs` section:

```yaml
configs:
  pvcArtifactsRootFolder: "artifact-pvc"
  # ... other existing configs ...
```



### 5.2 Upgrade CACC Deployment

Run the Helm upgrade command with your updated values file:

```bash
# Find your current release name
helm list -n <your-namespace>

# Upgrade with the updated values
helm upgrade <release-name> <chart-path> \
  -n <your-namespace> \
  -f <your-override-file.yaml>
```



**What happens during upgrade:**
- Helm will update the CACC deployment configuration
- All CACC service pods will restart to apply the new configuration
- The artifact-pvc will be mounted at `/artifacts/` in all service containers
- Services will automatically detect and use artifacts from the PVC

---

## Step 6: Verify Artifacts Access

### 6.1 Verify CM Pod Access

Check that the CM pod can access artifacts:

```bash
# Get CM pod name
kubectl get pods -n <your-namespace> -l app=ca-cpd-cm-primary

# Verify artifacts directory structure
kubectl exec ca-cpd-cm-primary-0 -n <your-namespace> -c ca-cm-container -- ls -la /opt/ibm/cognos/artifacts/
```

**Expected output:**
```
total 0
drwxrwxrwx. 9 root    root 113 Apr  9 19:21 .
drwxrwxr-x. 1 ibmuser root  59 Apr  9 19:43 ..
drwxr-xr-x. 2 default root   6 Apr  9 19:21 certs
drwxr-xr-x. 2 default root   6 Apr  9 19:21 cjap
drwxr-xr-x. 2 default root   6 Apr  9 19:21 configuration
drwxr-xr-x. 2 default root   6 Apr  9 19:21 csdrivers
drwxr-xr-x. 2 default root   6 Apr  9 19:21 dsdrivers
drwxr-xr-x. 2 default root   6 Apr  9 19:21 fonts
drwxr-xr-x. 2 default root   6 Apr  9 19:21 images
```

### 6.2 How Artifacts Are Connected to Pods

When you set `configs.pvcArtifactsRootFolder: "artifact-pvc"` in your Helm values, the following happens automatically:

1. **Helm injects volume mount** into supported service deployments (CM, DSS, Reporting, Smarts)
2. **Volume Mount** is added to each container:
   ```yaml
   volumeMounts:
     - mountPath: /opt/ibm/cognos/artifacts
       name: artifacts-volume
       readOnly: false
   ```
3. **Volume** is defined in the pod spec:
   ```yaml
   volumes:
     - name: artifacts-volume
       persistentVolumeClaim:
         claimName: 'artifact-pvc'
   ```
4. **All supported services** can now access artifacts at `/opt/ibm/cognos/artifacts/`

---

## Artifacts Directory Structure

```
/artifacts/
├── certs/              # Certificates (*.arm, *.cer, *.pem, *.crt)
├── csdrivers/          # Content Store Drivers (*.jar)
├── cjap/               # Custom Java Authentication Provider (*.jar)
├── configuration/      # Configuration files (*.properties, *.json)
├── dsdrivers/          # Data Store Drivers (*.jar)
├── fonts/              # Fonts for Reporting (*.ttf)
└── images/             # Images for Reporting (*.gif, *.jpg, *.jpeg)
```

---

## Troubleshooting

### PVC Not Binding
```bash
kubectl describe pvc artifact-pvc -n <your-namespace>
kubectl get storageclass
```

### Pod Cannot Access Artifacts
```bash
kubectl describe pod <pod-name> -n <your-namespace>
kubectl logs <pod-name> -n <your-namespace>
```

###CACC Services Not Finding Artifacts
1. Verify `pvcArtifactsRootFolder` is set correctly in Helm values
2. Check that Helm upgrade was successful
3. Restart CACC pods if needed

---

## Important Notes

- The artifacts PVC must use `ReadWriteOnce` access mode
- If the PVC doesn't exist, Helm deployment will fail with an error
- Only the specified file extensions are supported in each directory
- All CACC services (Content, Reporting, DSS, Smarts) will mount the artifacts at `/artifacts/`

---

*Author: Wentao Bai*  
*Date: 2026-04-09*
