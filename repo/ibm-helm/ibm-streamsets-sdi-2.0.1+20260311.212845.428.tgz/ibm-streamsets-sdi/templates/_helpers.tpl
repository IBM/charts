{{/*
cpd-cli install-components requires you to supply operator/instance namespace flags,
but the tech spec requires us to be GitOps compliant, so this validation ensures that
we fail fast when install is driven by ArgoCD/Helm and namespaces are not supplied
*/}}
{{- define "ibm-streamsets-sdi.validate" -}}
{{- $opns := required "global.operatorNamespace is required" .Values.global.operatorNamespace -}}
{{- $instns := required "global.instanceNamespace is required" .Values.global.instanceNamespace -}}
{{- end -}}

{{- define "ibm-streamsets-sdi.operatorRegistry" -}}
{{- .Values.global.imagePullPrefix -}}
{{- end -}}

{{- define "ibm-streamsets-sdi.operandRegistry" -}}
{{- if eq .Values.global.imagePullPrefix "icr.io" -}}
cp.icr.io
{{- else -}}
{{- .Values.global.imagePullPrefix -}}
{{- end -}}
{{- end -}}
