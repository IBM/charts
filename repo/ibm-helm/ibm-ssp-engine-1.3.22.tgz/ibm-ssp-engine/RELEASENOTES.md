# Breaking Changes

- None

# What’s new in Helm Charts Version 1.3.22 for IBM Sterling Secure Proxy Engine 6.1.0.5 iFix6.1.0.5-iFixGA-2026-09-15

# Fixes
 
Please refer (FixList.txt) file for new changes and defect fixes 

# Prerequisites

Please refer prerequisites section from [README.md]

# Documentation

Please refer to [README.md](README.md) provided with chart for detailed installation instruction.

# Version History

| Chart   | Date           | Kubernetes Required | OpenShift Required | Image(s) Supported                                | Details                                             |
| ------- | -------------- | ------------------- | -------------------| ------------------------------------------------- | --------------------------------------------------- | 
| 1.1.1   | May 21, 2021   | >= 1.19.0           | = 4.6              | ssp-engine-docker-image:6.0.2.0.01                | Secure Proxy Engine 6.0.2.0 iFix01                  |
| 1.1.2   | June 30, 2021  | >= 1.19.0           | = 4.6              | ssp-engine-docker-image:6.0.2.0.02                | Secure Proxy Engine 6.0.2.0 iFix02                  |
| 1.1.3   | Aug 27, 2021   | >= 1.19.0           | = 4.6              | ssp-engine-docker-image:6.0.2.0.03                | Secure Proxy Engine 6.0.2.0 iFix03                  |
| 1.2.0   | Nov 05, 2021   | >= 1.19.0           | = 4.6              | ssp-engine-docker-image:6.0.3.0                   | Secure Proxy Engine 6.0.3.0                         |
| 1.2.1   | Dec 20, 2021   | >= 1.19.0           | = 4.6              | ssp-engine-docker-image:6.0.3.0.01                | Secure Proxy Engine 6.0.3.0 iFix01                  |
| 1.2.2   | Jan 10, 2022   | >= 1.19.0           | = 4.6              | ssp-engine-docker-image:6.0.3.0.01plus            | Secure Proxy Engine 6.0.3.0 iFix01 plus             |
| 1.2.3   | Feb 14, 2022   | >= 1.19.0           | = 4.6              | ssp-engine-docker-image:6.0.3.0.02                | Secure Proxy Engine 6.0.3.0 iFix02                  |
| 1.2.4   | May 21, 2022   | >= 1.19.0           | >= 4.6 && <=4.8    | ssp-engine-docker-image:6.0.3.0.02plus            | Secure Proxy Engine 6.0.3.0 iFix02 plus             |
| 1.2.5   | Aug 02, 2022   | >= 1.19.0           | >= 4.6 && <=4.8    | ssp-engine-docker-image:6.0.3.0.04                | Secure Proxy Engine 6.0.3.0 iFix04                  |
| 1.2.6   | Dec 13, 2022   | >= 1.19.0           | >= 4.6 && <=4.11   | ssp-engine-docker-image:6.0.3.0.05                | Secure Proxy Engine 6.0.3.0 iFix05                  |
| 1.2.7   | Feb 20, 2023   | >= 1.19.0           | >= 4.6 && <=4.11   | ssp-engine-docker-image:6.0.3.0.06                | Secure Proxy Engine 6.0.3.0 iFix06                  |
| 1.2.8   | May 08, 2023   | >= 1.19.0           | >= 4.6 && <=4.11   | ssp-engine-docker-image:6.0.3.0.07                | Secure Proxy Engine 6.0.3.0 iFix07                  |
| 1.3.0   | Aug 28, 2023   | >= 1.19.0           | >= 4.6 && <=4.11   | ssp-engine-docker-image:6.1.0.0                   | Secure Proxy Engine 6.1.0.0                         |
| 1.3.1   | Nov 10, 2023   | >= 1.19.0           | >= 4.6 && <=4.13   | ssp-engine-docker-image:6.1.0.0.01                | Secure Proxy Engine 6.1.0.0 iFix01                  |
| 1.3.2   | Dec 08, 2023   | >= 1.19.0           | >= 4.6 && <=4.13   | ssp-engine-docker-image:6.1.0.0.01plus            | Secure Proxy Engine 6.1.0.0 iFix01 plus             |
| 1.3.3   | Jan 15, 2024   | >= 1.19.0           | >= 4.6 && <=4.13   | ssp-engine-docker-image:6.1.0.0.02                | Secure Proxy Engine 6.1.0.0 iFix02                  |
| 1.3.4   | Mar 13, 2024   | >= 1.19.0           | >= 4.6 && <=4.13   | ssp-engine-docker-image:6.1.0.0.03                | Secure Proxy Engine 6.1.0.0 iFix03                  |
| 1.3.5   | May 10, 2024   | >= 1.19.0           | >= 4.6 && <=4.13   | ssp-engine-docker-image:6.1.0.0.03plus            | Secure Proxy Engine 6.1.0.0 iFix03 plus             |
| 1.3.6   | Jul 16, 2024   | >= 1.26.0           | >= 4.13 && <=4.15  | ssp-engine-docker-image:6.1.0.0.04                | Secure Proxy Engine 6.1.0.0 iFix04                  |
| 1.3.7   | Aug 28, 2024   | >= 1.26.0           | >= 4.13 && <=4.15  | ssp-engine-docker-image:6.1.0.0.05                | Secure Proxy Engine 6.1.0.0 iFix05                  |
| 1.3.8   | Sep 02, 2024   | >= 1.26.0           | >= 4.13 && <=4.15  | ssp-engine-docker-image:6.1.0.0.05                | Secure Proxy Engine 6.1.0.0 iFix05                  |
| 1.3.9   | Sep 24, 2024   | >=1.26.0 && <=1.30.0| >= 4.13 && <=4.15  | ssp-engine-docker-image:6.1.0.0.05                | Secure Proxy Engine 6.1.0.0 iFix05                  |
| 1.3.11  | Dec 11, 2024   | >=1.26.0 && <=1.30.0| >= 4.13 && <=4.15  | ssp-engine-docker-image:6.1.0.1.01                | Secure Proxy Engine 6.1.0.1 iFix01                  |
| 1.3.12  | Dec 20, 2024   | >=1.26.0 && <=1.30.0| >= 4.13 && <=4.15  | ssp-engine-docker-image:6.1.0.1.01.1              | Secure Proxy Engine 6.1.0.1 iFix01                  |
| 1.3.13  | Feb 07, 2025   | >=1.26.0 && <=1.32.0| >= 4.13 && <=4.16  | ssp-engine-docker-image:6.1.0.1.01plus            | Secure Proxy Engine 6.1.0.1 iFix01 Plus             |
| 1.3.14  | Feb 20, 2025   | >=1.26.0 && <=1.32.0| >= 4.13 && <=4.16  | ssp-engine-docker-image:6.1.0.1.02                | Secure Proxy Engine 6.1.0.1 iFix02                  |
| 1.3.15  | Apr 24, 2025   | >=1.26.0 && <=1.32.0| >= 4.13 && <=4.16  | ssp-engine-docker-image:6.1.0.1.03                | Secure Proxy Engine 6.1.0.1 iFix03                  |
| 1.3.16  | Sep 09, 2025   | >= 1.28.0 && <1.34.0| >= 4.15 && <=4.18  | ssp-engine-docker-image:6.1.0.2-iFix00-2025-08-22 | Secure Proxy Engine 6.1.0.2 GA                      |
| 1.3.17  | Jan 23, 2026   | >= 1.28.0 && <1.34.0| >= 4.18 && <=4.20  | ssp-engine-docker-image:6.1.0.3-iFix00-2026-01-19 | Secure Proxy Engine 6.1.0.3 GA                      |
| 1.3.19  | Mar 30, 2026   | >= 1.32.0 && <1.36.0| >= 4.19 && <=4.21  | ssp-engine-docker-image:6.1.0.4-iFix00-2026-03-25 | Secure Proxy Engine 6.1.0.4 GA                      |
| 1.3.20  | Jun 03, 2026   | >= 1.32.0           | >= 4.18 && <=4.21  | ssp-engine-docker-image:6.1.0.4-iFix01-2026-05-28 | Secure Proxy Engine 6.1.0.4 iFix01                  |
| 1.3.21  | Jul 25, 2026   | >= 1.32.0           | >= 4.18 && <=4.21  | ssp-engine-docker-image:6.1.0.4-iFix01-2026-07-22 | Secure Proxy Engine 6.1.0.4 iFix01                  |
| 1.3.22  | Sep 19, 2026   | >= 1.32.0           | >= 4.19 && <=4.22  | ssp-engine-docker-image:6.1.0.5-iFixGA-2026-09-15 | Secure Proxy Engine 6.1.0.5 iFix6.1.0.5-iFixGA-2026-09-15|
| ------- | -------------- | ------------------- | -------------------| ------------------------------------------------- | --------------------------------------------------- | 

