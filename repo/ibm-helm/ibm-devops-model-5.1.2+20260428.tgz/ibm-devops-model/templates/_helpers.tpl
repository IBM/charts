{{/*
Expand the name of the chart.
*/}}
{{- define "dsw-chart.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "dsw-chart.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "dsw-chart.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "dsw-chart.labels" -}}
app.kubernetes.io/version: {{ .Chart.AppVersion | replace "+" "_"  }}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version | replace "+" "_" }}
app.kubernetes.io/part-of: {{ .Chart.Name }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/name: {{ template "dsw-chart.fullname" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}


{{- define "dsw-chart.global.pod.labels" }}
{{/*set via hub chart*/}}
{{- if .Values.global.k5.pod }}
{{- if .Values.global.k5.pod.labels }}
{{- range $k, $v := .Values.global.k5.pod.labels }}
{{- printf "\n%s: " $k -}}{{- printf "%s" $v | quote -}}
{{- end }}
{{- end }}
{{- end }}
{{- end -}}

