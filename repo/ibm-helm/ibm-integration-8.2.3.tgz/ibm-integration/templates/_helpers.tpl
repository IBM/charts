{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "ibm-integration.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "ibm-integration.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create a namespaced name for a release.
The order of naming is release-namespace-chartname
*/}}
{{- define "ibm-integration.namespacedname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s-%s" .Release.Name .Release.Namespace $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "ibm-integration.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "ibm-integration.labels" -}}
helm.sh/chart: {{ include "ibm-integration.chart" . }}
{{ include "ibm-integration.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{/*
Selector labels
*/}}
{{- define "ibm-integration.selectorLabels" -}}
app.kubernetes.io/name: {{ include "ibm-integration.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/*
Create the name of the service account to use
*/}}
{{- define "ibm-integration.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
    {{ default (include "ibm-integration.fullname" .) .Values.serviceAccount.name }}
{{- else -}}
    {{ default "default" .Values.serviceAccount.name }}
{{- end -}}
{{- end -}}


{{/*
ibm-integration.getWatchNamespace
Handle building the WATCH_NAMESPACE environment variable.
WATCH_NAMESPACE is informed by a scope type and a list of namespaces.
*/}}
{{- define "ibm-integration.getWatchNamespace" -}}
{{- if eq .Values.operator.installMode "OwnNamespace" -}}
valueFrom:
  fieldRef:
    fieldPath: metadata.namespace
{{- else if eq .Values.operator.installMode "SingleNamespace" -}}
value: "{{ index .Values.operator.watchNamespaces 0 }}"
{{- else if eq .Values.operator.installMode "MultiNamespace" -}}
value: "{{ include "ibm-integration.getMulti" . | trimSuffix "," }}"
{{- else if eq .Values.operator.installMode "AllNamespaces" -}}
value: ""
{{- end -}}
{{- end -}}

{{/*
ibm-integration.getSingleNamespaces
Return a whitespace separated list of namespaces for the SingleNamespace installMode
the Operator should install Roles and RoleBindings into. If the top watchNamespace
is not also the installation namespace, this returns a list of the two. Otherwise,
just the installation namespace is returned.
*/}}
{{- define "ibm-integration.getSingleNamespaces" -}}
{{- if eq (index $.Values.operator.watchNamespaces 0) $.Release.Namespace -}}
{{- printf "%s" (index $.Values.operator.watchNamespaces 0) -}}
{{- else -}}
{{- printf "%s %s" (index $.Values.operator.watchNamespaces 0) $.Release.Namespace -}}
{{- end -}}
{{- end -}}

{{- define "ibm-integration.registry" -}}
{{- if eq .Values.operator.privateRegistry "preprod.icr.io" -}}
preprod.icr.io/cpopen 
{{- else if eq .Values.operator.privateRegistry "cp.stg.icr.io" -}}
cp.stg.icr.io/cp
{{- else -}}
{{ default "icr.io" .Values.operator.privateRegistry }}/cpopen
{{- end -}}
{{- end -}}

{{- define "ibm-integration.image" -}}
{{- if .Values.operator.deployment.sha -}}
{{ template "ibm-integration.registry" . }}/{{ .Values.operator.deployment.image }}@{{ .Values.operator.deployment.sha }}
{{- else if .Values.operator.deployment.tag -}}
{{ template "ibm-integration.registry" . }}/{{ .Values.operator.deployment.image }}:{{ .Values.operator.deployment.tag }}
{{- end -}}
{{- end -}}