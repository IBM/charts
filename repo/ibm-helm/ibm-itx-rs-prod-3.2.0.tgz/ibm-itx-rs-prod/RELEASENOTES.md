# Release Notes

This document is release notes for IBM&reg; Sterling Transformation Extender for Red Hat OpenShift 11.0.3
<br>&copy; Copyright IBM Corporation 2024, 2026 All rights reserved.
<br>Program Number : 5724-Q23


## What's new

This container version includes IBM&reg; Sterling Transformation Extender 11.0.3. It targets Red Hat OpenShift 4.20. IBM Sterling Transformation Extender for Red Hat OpenShift 11.0.3 is based on IBM Sterling Transformation Extender 11.0.3 version.

What's new for IBM Sterling Transformation Extender 11.0.3 version is as follows:
https://www.ibm.com/docs/en/ste/11.0.3?topic=new-whats-in-v1103

### Metrics

Metrics are collected and exposed to provide visibility into the current state and behavior of the deployment. Available metric categories include CPU utilization, memory usage, worker thread saturation, service-level response percentiles, request duration histograms, and overall readiness status.

All metrics can be retrieved from the `/tx-rest/metrics` endpoint. A consolidated readiness assessment is also available through the readiness probe endpoint: `/tx-rest/metrics?readiness=true`. The readiness probe evaluates key operational metrics and reports whether the deployment is ready to accept requests.

### Service Mesh

Deployments can seamlessly integrate with an Istio service mesh to provide service-to-service communication. When either the `istioV1.enabled` or `istio.enabled` setting in the `values.yaml` is `true`, the deployed pods are configured to automatically get injected with an Istio sidecar proxy that transparently intercepts inbound and outbound traffic. 

This integration provides consistent routing, load balancing, observability metrics, and security enforcement across the service mesh without requiring application-specific changes.

### Examples

The Examples section includes new content for Metrics, Monitoring, and Service Mesh.

The Metrics section describes the types of measurements tracked by the deployment. The Monitoring section demonstrates how a Prometheus server can scrape and collect metrics. The Service Mesh section provides an example of integrating a deployment with Istio.

## Fixes

Release notes for IBM Sterling Transformation Extender 11.0.3 follows:
https://www.ibm.com/support/pages/node/7234069

See `RESOLVED AUTHORIZED PROGRAM ANALYSIS REPORTS (APARs)` section for details.
<br>NOTE: Not all listed APARs are applicable for this container release.


## Prerequisites

Refer to the main `README` document.

## Version History

1.0.x - IBM Sterling Transformation Extender Runtime Server 10.0.3
<br>2.0.x - IBM Sterling Transformation Extender for Red Hat OpenShift 10.1.1
<br>2.1.x - IBM Sterling Transformation Extender for Red Hat OpenShift 10.1.2
<br>3.0.x - IBM Sterling Transformation Extender for Red Hat OpenShift 11.0.1
<br>3.1.x - IBM Sterling Transformation Extender for Red Hat OpenShift 11.0.2
<br>3.2.x - IBM Sterling Transformation Extender for Red Hat OpenShift 11.0.3
* 3.2.0 - 20260625 : The image with ID 04de9e2bc047 includes security patches and fixes applied through 11.0.3.0 build 46.

## Breaking Changes

Refer to the `Migration` section in the documentation.

## Documentation

For general IBM Sterling Transformation Extender documentation, refer to the product's [knowledge center](https://www.ibm.com/docs/en/ste/11.0.3).
