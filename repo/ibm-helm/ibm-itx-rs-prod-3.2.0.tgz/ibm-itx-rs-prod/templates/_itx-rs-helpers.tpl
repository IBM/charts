{{/*
Route name
*/}}
{{- define "itx.rs.routeName" }}
  {{- "itx-rs-route" }}
{{- end }}

{{/*
Service name
*/}}
{{- define "itx.rs.serviceName" }}
  {{- "itx-rs-svc" }}
{{- end }}

{{/*
Application name
*/}}
{{- define "itx.rs.appName" }}
  {{- "itx-rs" }}
{{- end }}

{{/*
Node affinity settings
*/}}
{{- define "itx.rs.affinity" -}}
nodeAffinity:
  preferredDuringSchedulingIgnoredDuringExecution:
  - preference:
      matchExpressions:
      - key: kubernetes.io/arch
        operator: In
        values:
        - amd64
    weight: 3
  requiredDuringSchedulingIgnoredDuringExecution:
    nodeSelectorTerms:
    - matchExpressions:
      - key: kubernetes.io/arch
        operator: In
        values:
        - amd64
{{- end -}}

{{- /* This template provides the pod termination grace period if
       .Values.shutdownTimeSeconds is non-zero. It should be included in a pod
       specification scope.

       The root context should be provided. */}}
{{- define "itx.rs.gracePeriod" }}
  {{- if .Values.shutdownTimeSeconds }}
terminationGracePeriodSeconds: {{ add .Values.shutdownTimeSeconds 30 }}
  {{- end }}
{{- end }}

{{- /* This template provides a PreStop hook when .Values.shutdownTimeSeconds
       is non-zero. It should be included in the lifecycle mapping of a
       container description. An empty lifecycle mapping is valid.

       The root context should be provided.

       The hook sleeps for .Values.shutdownTimeSeconds. The intent is to allow
       map and flow executions a configurable amount of time to finish
       execution before the stop signal SIGTERM is sent to the primary
       process of the container. */}}
{{- define "itx.rs.gracefulTerminationPreStop" }}
  {{- if .Values.shutdownTimeSeconds }}
preStop:
  exec:
    command:
    - /bin/sh
    - -c
    - sleep {{ .Values.shutdownTimeSeconds }}
  {{- end }}
{{- end }}

{{- define "itx.rs.redis.password.vol" }}
{{- if and .Values.itxRedis.password.secret .Values.itxRedis.password.key }}
- name: redis-password
  secret:
    secretName: {{ .Values.itxRedis.password.secret }}
    defaultMode: 288
{{- end }}
{{- end }}

{{- define "itx.rs.redis.password.file" -}}
/opt/runtime/restapi/redis/certs/pswd.txt
{{- end }}

{{- define "itx.rs.redis.password.volmnt" }}
{{- if and .Values.itxRedis.password.secret .Values.itxRedis.password.key }}
- name: redis-password
  mountPath: {{ include "itx.rs.redis.password.file" . }}
  subPath: {{ .Values.itxRedis.password.key }}
  readOnly: true
{{- end }}
{{- end }}

{{- define "itx.rs.redis.tls.vol" }}
{{- if .Values.itxRedis.tls.enabled }}
- name: redis-tls-ca-cert
  configMap:
    name: {{ .Values.itxRedis.tls.clientCaConfigMap }}
  {{- if .Values.itxRedis.tls.clientSecret }}
- name: redis-tls-client-cert
  secret:
    secretName: {{ .Values.itxRedis.tls.clientSecret }}
  {{- end }}
{{- end }}
{{- end}}

{{- define "itx.rs.redis.tls.volmnt" }}
{{- if .Values.itxRedis.tls.enabled }}
- name: redis-tls-ca-cert
  mountPath: /opt/runtime/restapi/redis/certs/ca.crt
  subPath: {{ .Values.itxRedis.tls.certCAFilename }}
  {{- if .Values.itxRedis.tls.clientSecret }}
- name: redis-tls-client-cert
  mountPath: /opt/runtime/restapi/redis/certs/client.crt
  subPath: {{ .Values.itxRedis.tls.certFilename }}
- name: redis-tls-client-cert
  mountPath: /opt/runtime/restapi/redis/certs/client.key
  subPath: {{ .Values.itxRedis.tls.certKeyFilename }}
  {{- end }}
{{- end }}
{{- end }}

{{- /* This template should be included with the root context.

       It assumes that a Redis server is needed by the ITX RS application.

       If a password is used by the Redis server, then the REDISCLI_AUTH
       environment variable must be set when the returned command is executed.
       Provision of ACL-style credentials is not supported. */}}
{{- define "itx.rs.redis.initContainerSubcommand" }}
{{- $cliCommand     := "/opt/runtime/restapi/redis/bin/redis-cli" }}
{{- $hostString     := "-h" }}
{{- $portString     := "-p" }}
{{- $databaseString := "" }}
{{- $tlsString      := "" }}
{{- $mtlsString     := "" }}
{{- $sniString      := "" }}

{{- $hostString = cat $hostString .Values.itxRedis.host }}
{{- $portString = print .Values.itxRedis.port | cat $portString }}
{{- if .Values.itxRedis.database }}
  {{- $databaseString = print .Values.itxRedis.database | cat "-n" }}
{{- end }}
{{- if .Values.itxRedis.tls.enabled }}
  {{- $tlsString = "--tls --cacert /opt/runtime/restapi/redis/certs/ca.crt" }}
  {{- if .Values.itxRedis.tls.clientSecret }}
    {{- $mtlsString = "--cert /opt/runtime/restapi/redis/certs/client.crt --key /opt/runtime/restapi/redis/certs/client.key" }}
  {{- end }}
  {{- if .Values.itxRedis.tls.sni }}
    {{- $sniString = cat "--sni" .Values.itxRedis.tls.sni }}
  {{- end }}
{{- end }}
{{- cat $cliCommand $hostString $portString $databaseString $tlsString $mtlsString $sniString }}
{{- end }}

{{- /* This template should be included with the root context.
       It provides an init container for a component which depends on Redis.*/}}
{{- define "itx.rs.redis.initContainerForDeployed" }}
- name: {{ .Chart.Name }}-init-redis
  image: {{ include "itx-rs.image.repository" . -}}{{- include "itx-rs.image.tag" . }}
  imagePullPolicy: {{ include "itx.rs.image.pull.policy" . }}
  resources:
    requests:
      cpu: 125m
      memory: 500Mi
    limits:
      cpu: 500m
      memory: 1Gi
  command:
  - /bin/bash
  - -c
  - |
    . /opt/runtime/setup;
    REDIS_POLL_COUNT=0;
    if [[ -f {{ include "itx.rs.redis.password.file" . }} ]] ; then
      echo -e "AUTH `cat {{ include "itx.rs.redis.password.file" . }}`\nPING" > /tmp/redis.cmd;
    else
      echo PING > /tmp/redis.cmd;
    fi
    echo "Starting to poll for Redis readiness at: `date`";
    until cat /tmp/redis.cmd | {{ include "itx.rs.redis.initContainerSubcommand" . }} | grep PONG ; do
      (( REDIS_POLL_COUNT++ ));
      if [[ REDIS_POLL_COUNT -ge 60 ]]; then
        echo "Polling for Redis readiness timed out at: `date`";
        exit 1;
      fi
      echo Waiting for Redis after attempt number ${REDIS_POLL_COUNT} ...;
      sleep 2;
    done
  volumeMounts:
  {{- include "itx.rs.redis.tls.volmnt" . | indent 2 }}
  {{- include "itx.rs.redis.password.volmnt" . | indent 2 }}
{{- end }}

{{/*
The 'setup' initContainer that is used for configuration of deployments.
*/}}
{{- define "itx.rs.setup.initContainerForDeployed" }}
{{- if ne .Values.external.mq.dataPath "/tmp" }}
- name: {{ .Chart.Name }}-setup
  image: {{ include "itx-rs.image.repository" . }}{{ include "itx-rs.image.tag" . }}
  imagePullPolicy: {{ include "itx.rs.image.pull.policy" . }}
  volumeMounts:
    - name: rest-data
      mountPath: /data
    - name: rest-logs
      mountPath: /logs
  command:
    - /bin/bash
    - -c
    - |
      mkdir -p {{ default "/tmp" .Values.external.mq.dataPath }}
{{- end }}
{{- end }}

{{/*
The readiness probe command.
*/}}
{{- define "itx.rs.readiness.probe.command" }}
{{- if and .Values.metrics.enabled .Values.metrics.readinessProbeEnabled }}
ENDPOINT="tx-rest/metrics?readiness=true"
{{- else }}
ENDPOINT="tx-rest"
{{- end }}
{{- if .component.inbound.http.enabled }}
URL="http://localhost:8080/$ENDPOINT"
OPT="-fsS"
{{- else }}
URL="https://localhost:8443/$ENDPOINT"
OPT="-fsS -k --cacert /opt/server/ssl/ca.pem"
{{- if .component.inbound.https.clientAuth }}
OPT="$OPT --cert /opt/server/ssl/cert.pem --key /opt/server/ssl/key.pem"
{{- end }}
{{- end }}
LOG_FAIL="{{ default "false" .component.probes.readiness.logFailure }}"
LOG_FILE="{{ default "/logs/$POD_NAME.readiness.log" .component.probes.readiness.logFile }}"
curl $OPT "$URL" >/dev/null 
rc=$?
if [ $rc -ne 0 ]; then
  if [ "$LOG_FAIL" = "false" ]; then
    echo "readiness failed for $URL at $(date -u '+%Y-%m-%dT%H:%M:%SZ')" >&2
  else
    {
    echo "===== $(date -u '+%Y-%m-%dT%H:%M:%SZ') ====="
    echo "Readiness URL: $URL"
    RESPONSE=$(curl -sS -w '\n%{http_code}' "$URL")
    rc=$?
    CODE=$(printf '%s\n' "$RESPONSE" | tail -n1)
    BODY=$(printf '%s\n' "$RESPONSE" | sed '$d')
    if [ $rc -ne 0 ]; then
      echo "Failure response: $BODY"
    else
      case "$CODE" in
      2??) 
        rc=0 ;;
      *)
        echo "Failure response: $BODY"
        rc=-1
        ;;
      esac
    fi
    } 2>&1 | tee -a "$LOG_FILE" >&2
  fi
  if [ $rc -ne 0 ]; then
    exit 1
  fi
fi
{{- end }}

{{/*
The text for setting the LD_PRELOAD environment variable to use tcmalloc.

The argument should be the root context.
*/}}
{{- define "itx.rs.allocator.alternate" }}
{{- if .Values.allocator.alternateNativeAllocator }}
  {{- /* This sets LD_PRELOAD to allow the alternate allocator to
        interpose on the C and C++ standard library native memory
        allocation functions. Setting LD_PRELOAD here will override
        LD_PRELOAD from an envFrom property. If a customer needs
        to use LD_PRELOAD, then they will need to disable this
        setting and set LD_PRELOAD in a ConfigMap which is used to
        set environment variables. */}}
  {{- if eq .Values.allocator.alternateNativeAllocator "tcmalloc" }}
- name: "LD_PRELOAD"
  value: "/opt/runtime/libs/allocators/libtcmalloc.so"
    {{- if .Values.allocator.heapProfile }}
      {{- /* This prefix is used by start.sh and setenv.sh to set HEAPPROFILE. */}}
- name: "_HEAPPROFILE_PREFIX"
  value: "/logs/tx_tcmalloc_heap_profile"
    {{- end }}
  {{- else }}
    {{- fail "An unknown alternate native memory allocator name was provided." }}
  {{- end }}
{{- end }}
{{- end }}
