{{/*
Expand the name of the chart.
*/}}
{{- define "itx.rs.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Annotations for metering
*/}}
{{- define "itx.rs.metering" -}}
productID: "e3ea97bcc2ae4e39b9a0ac4fe309f546"
productName: "IBM Sterling Transformation Extender for Red Hat OpenShift"
productVersion: "11.0.3"
productMetric: "VIRTUAL_PROCESSOR_CORE"
productChargedContainers: "All"
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "itx.rs.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "itx.rs.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
License accept value
*/}}
{{- define "itx.rs.license-accept" -}}
{{- if .Values.license -}}
"true"
{{- else -}}
"false"
{{- end -}}
{{- end }}

{{/*
Image (Container) Repository
*/}}
{{- define "itx-rs.image.repository" -}}
  {{- if $.Values.rest.image.repository -}}
  {{- $.Values.rest.image.repository -}}
  {{- else if $.Values.global.itxImageRegistry -}}
  {{- print $.Values.global.itxImageRegistry "/ibm-itx-rs" -}}
  {{- else if $.Values.itxImageRegistry -}}
  {{- print $.Values.itxImageRegistry "/ibm-itx-rs" -}}
  {{- else -}}
  {{- fail "Unable to determine the rest image repository" }}
  {{- end -}}
{{- end -}}

{{/*
Image (Container) Tag
*/}}
{{- define "itx-rs.image.tag" -}}
  {{- if $.Values.rest.image.digest -}}
  @{{ $.Values.rest.image.digest }}
  {{- else if $.Values.rest.image.tag -}}
  :{{ $.Values.rest.image.tag }}
  {{- else }}
  {{- fail "Unable to determine the rest image tag" }}
  {{- end -}}
{{- end -}}

{{/*
Image (Container) Registry Pull Secret
*/}}
{{- define "itx.rs.image.pull.secret" -}}
{{- if .Values.itxImagePullSecret -}}
{{ tpl .Values.itxImagePullSecret . }}
{{- else if .Values.global.itxImagePullSecret -}}
{{ tpl .Values.global.itxImagePullSecret . }}
{{- end -}}
{{- end -}}

{{/*
Deployment strategy type of REST V1 server
*/}}
{{- define "itx.rs.deployment.type.v1" -}}
RollingUpdate
{{- end -}}

{{/*
Deployment strategy type of REST V2 server
*/}}
{{- define "itx.rs.deployment.type.v2" -}}
{{- if and .Values.rest.deploy ( and .Values.restV1.deploy ( eq .Values.restV1.runMode "fenced" ) ) -}}
{{- required "The REST V1 server that runs in 'fenced' mode cannot be deployed with a REST V2 server." .Values.unDefined -}} 
{{- else if and .Values.restV1.deploy ( and ( ne .Values.restV1.runMode "fenced" ) ( ne .Values.restV1.runMode "unfenced" ) ) -}}
{{- required "The 'runMode' setting of the REST V1 server must be set to 'fenced' or 'unfenced'." .Values.unDefined -}}
{{- else -}}
Recreate
{{- end -}}
{{- end -}}

{{/*
Image (Container) Pull Policy
*/}}
{{- define "itx.rs.image.pull.policy" -}}
{{- if and .Values.rest.image.digest .Values.rest.image.pullPolicy -}}
{{ .Values.rest.image.pullPolicy }}
{{- else if .Values.rest.image.pullPolicyOverride -}}
{{ .Values.rest.image.pullPolicy }}
{{- else -}}
Always
{{- end -}}
{{- end -}}

{{/*
Selector labels
*/}}
{{- define "itx.rs.selectorLabels" -}}
app.kubernetes.io/name: {{ include "itx.rs.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "itx.rs.labels" -}}
{{ include "itx.rs.selectorLabels" . }}
app.kubernetes.io/managed-by: {{ .Release.Service | quote }}
helm.sh/chart: {{ include "itx.rs.chart" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
{{- end }}

{{/*
Component labels
*/}}
{{- define "itx.rs.component.executor" -}}
executor
{{- end -}}

{{- define "itx.rs.component.rest" -}}
rest
{{- end -}}

{{- define "itx.rs.component.restV1" -}}
rest-v1
{{- end -}}

{{/*
Directory path of files used for external integrations 
*/}}
{{- define "itx.external.volume.path" -}}
{{- default "/xdata" .Values.external.data.volume.path }}
{{- end -}}

{{/* Directory path of secret files */}}
{{- define "itx.external.volume.path.secrets" -}}
{{- printf "%s/%s" (include "itx.external.volume.path" . ) .Values.external.data.secret.subpath }}
{{- end -}}

{{/* Directory path of COS files */}}
{{- define "itx.external.volume.path.cos" -}}
{{- "/setup" }}
{{- end -}}

{{/*
COS-based map download and unzip command line options 
*/}}
{{- define "itx.cos.gcp.options" -}}
{{- with $.Values.external.cos -}}
{{- $MAP := "/tmp/cosdownload.mmc" -}}
{{- $CF  := print (include "itx.external.volume.path.secrets" $) "/" .gcp.cf -}}
{{- $INP := print "-IAGCSTORAGE1 '-TV /tmp/m4cos.log -O " .name " -LSN 0 -QTY S -RCS 8000000 -B " .bucket " -CF " $CF "'" -}}
{{- $OUT := "-OF1 /tmp/maps.zip" -}}
{{- $AUD := "-AE=/tmp/cosdownload.log" -}}
{{- printf "%s %s %s %s" $MAP $INP $OUT $AUD }}
{{- end -}}
{{- end -}}

{{- define "itx.cos.s3.options" -}}
{{- $AKF := print (include "itx.external.volume.path.secrets" $) "/" .Values.external.cos.s3.accessKey -}}
{{- $SKF := print (include "itx.external.volume.path.secrets" $) "/" .Values.external.cos.s3.secretKey -}}
{{- with $.Values.external.cos -}}
{{- $MAP := print "/tmp/s3cosdownload.mmc" -}}
{{- $REG := print " " -}}
{{- if .s3.region -}}
{{- $REG = print " -R " .s3.region -}}
{{- end -}}
{{- $END := print " " -}}
{{- if .s3.endpoint -}}
{{- $END = print " -EP " $.Values.external.cos.s3.endpoint -}}
{{- end -}}
{{- $OPT := print "-TV /tmp/m4cos.log -K " .name " -LSN 0 -QTY S -RCS 8000000 -B " .bucket $REG $END -}}
{{- $LEN := len $OPT -}}
{{- $INP := print "-IF1 " $AKF " -IF2 " $SKF " -IE3S" $LEN " " $OPT -}}
{{- $OUT := "-OF1 /tmp/maps.zip" -}}
{{- $AUD := "-AE=/tmp/cosdownload.log" -}}
{{- printf "%s %s %s %s" $MAP $INP $OUT $AUD }}
{{- end -}}
{{- end -}}

{{- define "itx.cos.zip.options" -}}
{{- printf "-u -o -d %s /tmp/maps.zip" $.Values.external.cos.targetDir }}
{{- end -}}

{{/*
Secret volume
*/}}
{{- define "itx-rs.secretvol" -}}
{{- $extsecrets := $.Values.external.secrets }}
{{- range $extsecret := $extsecrets }}
- name: {{ print $extsecret.name "-" $extsecret.data "-volume" | replace "." "-" | replace "_" "-" | lower | trunc 63 }}
  secret:
    secretName: {{ $extsecret.name }}
    defaultMode: {{ default "288" $extsecret.mode }}
{{- end -}}
{{- end -}}

{{/*
Secret volume mounts
*/}}
{{- define "itx-rs.secretvolmnt" -}}
{{- $extsecrets := $.Values.external.secrets }}
{{- range $extsecret := $extsecrets }}
- name: {{ print $extsecret.name "-" $extsecret.data "-volume" | replace "." "-" | replace "_" "-" | lower | trunc 63 }}
  mountPath: {{ printf "%s/%s/%s" $.Values.external.data.volume.path $.Values.external.data.secret.subpath $extsecret.data }}
  subPath: {{ $extsecret.data }}
  readOnly: true
{{- end -}}
{{- end -}}

{{/*
ConfigMap volume
*/}}
{{- define "itx-rs.configmap.vol" -}}
{{- $extcfgs := .Values.external.configMaps }}
{{- range $extcfg := $extcfgs }}
- name: {{ print $extcfg.name "-" $extcfg.key "-volume" | replace "." "-" | replace "_" "-" | lower | trunc 63 }}
  configMap:
    name: {{ $extcfg.name }}
    items:
    - key: {{ $extcfg.key }}
      path: {{ $extcfg.path }}
{{- end -}}
{{- end -}}

{{/*
ConfigMap volume mounts
*/}}
{{- define "itx-rs.configmap.volmnt" -}}
{{- $extcfgs := .Values.external.configMaps }}
{{- range $extcfg := $extcfgs }}
- name: {{ print $extcfg.name "-" $extcfg.key "-volume" | replace "." "-" | replace "." "_" | replace "_" "-" | lower | trunc 63 }}
  mountPath: {{ printf "%s/%s/%s" $.Values.external.data.volume.path $.Values.external.data.configMap.subpath $extcfg.path }}
  subPath: {{ $extcfg.path }}
  readOnly: true
{{- end -}}
{{- end -}}

{{/*
Map volume
*/}}
{{- define "itx-rs.map.vol" -}}
{{- $extmaps := .Values.external.maps }}
{{- range $extmap := $extmaps }}
- name: {{ print $extmap.name "-map-" $extmap.key "-volume" | replace "." "-" | replace "_" "-" | lower | trunc 63 }}
  configMap:
    name: {{ $extmap.name }}
    items:
    - key: {{ $extmap.key }}
      path: {{ $extmap.path }}
{{- end -}}
{{- end -}}

{{/*
Map volume mounts
$.Values.external.data.volume.path $.Values.external.data.map.subpath
*/}}
{{- define "itx-rs.map.volmnt" -}}
{{- $extmaps := .Values.external.maps }}
{{- range $extmap := $extmaps }}
- name: {{ print $extmap.name "-map-" $extmap.key "-volume" | replace "." "-" | replace "_" "-" | lower | trunc 63 }}
  mountPath: {{ printf "%s/%s/%s" $.Values.external.data.volume.path $.Values.external.data.map.subpath $extmap.path }}
  subPath: {{ printf "%s" $extmap.path }}
  readOnly: false
{{- end -}}
{{- end -}}
