# Examples Readme

Examples of IBM&reg; Sterling Transformation Extender for Red Hat OpenShift 11.0.3
<br>&copy; Copyright IBM Corporation 2024, 2026 All rights reserved.
<br>Program Number : 5724-Q23 

# Table of Contents
1. [Introduction](#introduction)
2. [Installation](#installation)
3. [Requirements](#requirements)
4. [Configuration](#configuration)
   - [Kubernetes](#kubernetes)
   - [ITX-RS](#itx-rs)
   - [Design Studio](#design-studio)
   - [Design Server](#design-server)
   - [Redis](#redis)
5. [Starter](#starter)
6. [Flow](#flow)
7. [File Listener](#file-listener)
8. [Kafka Listener](#kafka-listener)
9. [MQ Listener](#mq-listener)
10. [Security](#security)
    - [Certificates](#certificates)
    - [Zero Trust](#zero-trust)
11. [Storage](#storage)
    - [PVC](#pvc)
    - [NFS](#nfs)
    - [COS](#cos)
    - [V1 Example](#v1-example)
    - [V2 Example](#v2-example)
    - [Ephemeral](#ephemeral)
12. [Patching](#patching)
13. [Metrics](#metrics)
14. [Monitoring](#monitoring)
15. [Istio](#istio)

# Introduction

IBM&reg; Sterling Transformation Extender for Red Hat OpenShift (ITX-RS) can be deployed to any [Kubernetes](https://kubernetes.io/) platform via a [Helm](https://helm.sh/docs/) chart installation. The ITX-RS Helm chart defines all the necessary ITX containers (or processes) that must be started under Kubernetes. Kubernetes automatically monitors the ITX containers for their readiness to satisfy the most demanding of workloads. While the current examples primarily target the Minikube implementation of Kubernetes, the same set of steps work with any enterprise version of Kubernetes, particularly Red Hat OpenShift (RHOS).     

Maps and flows from ITX Design Studio and Design Server can be deployed on demand to the running ITX containers on Kubernetes. While the Design Studio is the classic way of developing maps, the Design Server provides advanced capabilities for developing, deploying and reporting on map and flow executions that run within Kubernetes. Since deployment and reporting is implemented with a REST-based API, tools such as "curl" can also be used for deployment, execution and reporting purposes.

# Installation

ITX-RS must first get installed on the Kubernetes platform before any maps or flows are executed there. The ITX-RS Helm chart provides the necessary Kubernetes definitions to accomplish this task in a user-friendly and customized way. The input needed from the user is documented in the "values.yaml" file. Examples are provided to assist with the Helm-based ITX-RS installation. Once installation occurs, all the necessary ITX containers are created on the cluster for map and flow execution.

While the ITX-RS Helm chart is used for installation, other ITX software is required for the development and deployment of maps and flows to the running ITX containers. The ITX Design Studio operates within a standalone and graphically rich environment for the development of maps. The ITX Design Server adds new mapping capabilities and flow definitions to that graphical development environment, which is accessible locally or over a network via a browser. All mapping artifacts and flow definitions are stored in a MongoDB database for subsequent access by authorized users.

In order to install the ITX-RS Helm chart, a number of Kubernetes applications are needed. First, RHOS is recommended for production purposes, but Minikube is used in most of these examples as a lighter alternative that is capable of spinning up all the necessary ITX containers that are defined in the ITX-RS Helm chart. Secondly, the Helm application is needed to actually read the ITX-RS Helm chart and deploy it to the running instance of Kubernetes. Lastly, the Kubernetes command line tool, kubectl, is used to display and control the status of all the deployed ITX containers, which are now running under Minikube after having installed the ITX-RS Helm chart.   

# Requirements
All the necessary software requirements for running the current set of examples is listed in the table below.

When installing both the ITX Design Studio and Design Server, choose the "Custom" setup type. For the ITX Design Server installation, select the "REST API" and "Design Server" options, as found under the "Runtime" feature. The MongoDB instance needs to be accessible for the Design Server installation to complete successfully.

| Name                   | Version <sup>1</sup>             | Platform/Package |  URL    |
| ------------------- | ----------------- |------------- |----------|
| `ITX-RS` Helm Chart    | 3.2.0          | Helm | https://github.com/IBM/charts/blob/master/repo/ibm-helm/ibm-itx-rs-prod-3.2.0.tgz |
| `ITX-RS` image         | 11.0.3.0       | Container | https://myibm.ibm.com/products-services/containerlibrary |
| `ITX Design Studio`<sup>2</sup> | 11.0.3.0 | Windows      |https://www.ibm.com/software/passportadvantage/pao_customer.html |
| `ITX Design Server`<sup>3</sup> | 11.0.3.0 | Windows      |https://www.ibm.com/software/passportadvantage/pao_customer.html |
| `MongoDB`<sup>4</sup>  | 7.0.14    | Windows      |https://www.mongodb.com/try/download/community |
| `Redis` Helm Chart     | 19.1.5            | Helm |https://bitnami.com/kubernetes |
| `Helm`                 | 3.16.1            | Windows      |https://github.com/helm/helm/releases |
| `Kubernetes`           | Minikube 1.34     | Windows      |https://minikube.sigs.k8s.io/docs/start/?arch=%2Fwindows%2Fx86-64%2Fstable%2F.exe+download |
| `Kubernetes API tool`  | kubectl 1.31.1    | Windows      |https://kubernetes.io/docs/tasks/tools/install-kubectl-windows/ |
| `curl`                 | 8.9.1             | Windows   |https://curl.se/download.html |

<sup>1</sup> Minimum Version\
<sup>2</sup> IBM Sterling Transformation Extender Design Studio\
<sup>3</sup> IBM Sterling Transformation Extender Runtime and Monitoring\
<sup>4</sup> Design Server Requirement

# Configuration
Before running the examples, some preliminary configuration steps are required.   

## Kubernetes
All examples require access to a running version of Kubernetes and to a container registry, which needs to include the ITX-RS image.

1. Start the Kubernetes cluster if not done already.<sup>1</sup>\
`> minikube start`
2. Load the ITX-RS container image into the container registry.\
`> minikube image load ibm-itx-rs_11.0.3.0.20260625.tar.gz`<sup>2</sup>
3. Identify the ITX-RS container image and tag name.\
`> minikube image ls --format=table`
4. Tag the ITX-RS container image with the name, "localhost/ibm-itx-rs:11.0.3", which is referenced in subsequent steps.\
`> minikube image tag < image-name-from-prior-step >:11.0.3.0.20260625 localhost/ibm-itx-rs:11.0.3`

<sup>1</sup> Run the command from an Administrator window.\
<sup>2</sup> Change "ibm-itx-rs_11.0.3.0.20260625.tar.gz" to appropriate image name, if different.

## ITX-RS
An instance of ITX-RS is installed and started on a Kubernetes cluster by using a helm chart. The ITX-RS helm chart comes packaged in a compressed tar format - which can be uncompressed and extracted into a local directory. For example, the following command may be used for extracting the ITX-RS helm chart: `tar -xvzf ibm-itx-rs.3.1.0.tgz -C < your-target-dir >`.
After the ITX-RS helm chart is extracted to a local directory, each of the examples will appear in a separate directory under the "examples" folder. The necessary values for installation are stored in a "YAML" file with the prefix of "my< example-name >_values.yaml". These values serve as an override to the base set of configuration values, as contained in the "values.yaml" file of the ITX-RS helm chart. 

Each example provides the "helm" command that installs the running version of ITX-RS. The first [Starter](#starter) example specifies the following: `helm install v11 . -f mystarter_values.yaml`. The "v11" identifies the release name of the ITX-RS instance that will get deployed to the Kubernetes cluster. The "." points to the root directory of the extracted "tgz" file. If the helm command is executed from the "starter" subdirectory, then the following command syntax could be used, `helm install v11 ..\.. -f mystarter_values.yaml`, since the ITX-RS helm chart's root directory is two sub-directories above. If the helm command is executed from the base folder of the helm chart, then the following command syntax could be used, `helm install v11 . -f examples\starter\mystarter_values.yaml`. This directory syntax applies for all helm commands that are listed in the "Install" section of the examples.  

After using the Helm install command, the ITX-RS REST service can be accessed through any available HTTP port on your Windows machine, which defaults to 9080 in these examples.  This port ensures proper communication between ITX-RS and other REST-based applications, such as a browser, "curl" or the [Design Server](#design-server). If a different HTTP port is needed, then use that port number instead of 9080 wherever specified in this document. The [Design Server](#design-server) section describes how this port must be defined in the "config.yaml" file to enable communication with ITX-RS.  

Before running the V2 examples, [Storage](#storage) must be provisioned as per the [PVC](#pvc) section.
 
## Design Studio
The Design Studio defines maps that can be imported into the Design Server. Both source and compiled maps can be imported. When working solely with compiled maps, the compilation needs to be done for both Windows and Linux platforms. In this way, map execution can be tested on Windows and run on the ITX-RS RHOS platform. 

1. Start Design Studio.
2. Set the ITX Design Studio build options to compile for both Windows and Linux platforms.
3. Select menu item "Window->Preferences", navigate to "Transformation Extender->Map->Build Options", select the "Microsoft Windows" and "Linux (INTEL processor)" boxes, and then press "Apply and Close".

## Design Server
The Design Server defines both maps and flows - all of which are stored in a specific project file. The current examples have pre-defined projects that include all of the necessary flows and maps. The steps involved for running the example flows is to import the project, deploy to the server and then monitor runtime execution.

The deployment and monitoring of ITX-RS is done through a selected HTTP port, which defaults to 9080 in these examples, as described in [ITX-RS](#itx-rs). The "/server/runtime/servers" section in the "config.yaml" must include a "- localhost:9080" entry, otherwise, any server that is defined under the [Monitor](#monitor) section will not properly connect to the running instance of ITX-RS.

### Import
1. Select the "Import Project" button from the Design Server "Projects" screen.
2. Use the "browse" icon to select the example project.
3. After providing a unique name, select the "Import Project" button.
      
### Deploy
1. By pressing the "Create New Package" button in the "Packages" screen, a new package is defined and used to deploy a project to the ITX-RS installation.
2. After entering a unique package name, select the appropriate project and flow as well as any required maps and files, as described under each example. Then select the "Add" button.
3. On the "Packages" screen, select the package to get deployed and then press the "Deploy" icon. Once the server is [defined](#monitor) and selected, the "Deploy" button can be pressed.

### Monitor
1. After [installing](#itx-rs) ITX-RS, define a new server for deploying and monitoring flow executions. By pressing the "Create New Server" button in the "Servers" screen, you can provide the name of the new server that is connected to the ITX-RS installation.
2. Make sure the "Server Type" is set to "Web" and the "Base URL" is as follows:\
`http://localhost:9080/tx-rest`<sup>1</sup>
3. After [deploying](#deploy) an example from the "Packages" screen, the "Status History" and "Endpoints" will display run results. Note that this monitoring does not apply to version 1 REST API invocations, as done in the [Starter](#starter) example.

<sup>1</sup> The "9080" HTTP port can be changed as documented in the [ITX-RS](#itx-rs) section.

## Redis
Redis is a fast in-memory database that is used to track asynchronous REST requests, V2-based deployments and map results. The examples that involve flows can only be deployed if a Redis instance is reachable from within the Kubernetes cluster. Any recent version of Redis can be used, preferably version 7.0.11 or above. For the sake of these examples, a particular version has been selected for illustration and runtime purposes. 

1. Initialize the Helm repository with the Bitnami<sup>1</sup> library.\
`> helm repo add bitnami https://charts.bitnami.com/bitnami`
2. Download a Redis Helm chart.<sup>2</sup>\
`> helm pull bitnami/redis --version 19.1.5`
3. Install Redis.\
`> helm install redis redis-19.1.5.tgz --set architecture=standalone --set auth.enabled=false`
   
<sup>1</sup> See [Bitnami Website](https://bitnami.com/kubernetes).\
<sup>2</sup> Downloads a compressed tar file, "redis-19.1.5.tgz".

## Cleanup (Optional)
1. Pause Kubernetes.<sup>1</sup>\
`> minkube pause`
2. Resume Kubernetes.\
`> minkube resume`
3. Stop Kubernetes.\
`> minkube stop`

<sup>1</sup> Pausing and resuming the cluster is a convenient way to temporarily pause system processing without a complete cluster shutdown.

# Starter

The Starter example illustrates how existing maps can be deployed to Kubernetes. For users who only need basic map execution, this is the simplest and most straight-forward approach. It aims to lift on-premise map executions and shift them to the cloud. Version 1 of the ITX REST API is employed here, but subsequent examples make use of the more advanced version 2 of the ITX REST API.  

The V1-based mode of execution enables maps to be run directly from a specific location of the Kubernetes mounted file system. Both V1 maps as well as V2 maps and flows can be deployed and run simultaneously within the same ITX-RS installation. The V1-based map services are enabled with the "restV1.deploy" setting, which is set to 'true' by default. The V2-based map and flow executions are controlled by the "rest.deploy" setting, which is disabled by default.  

Any pre-existing maps must be compiled for the "Linux" platform, as described in the [Design Studio](#design-studio) configuration section. This example makes use of an existing example map, "OneInOneOut.mmc", which is found under the ITX Design Studio examples.  The Design Studio's "Custom" install enables the examples to get installed in the default data directory, 'C:\ProgramData\IBM\TransformationExtender_11.0.3\examples\restapi\samples\maps'.

## Install
1. Change to the ITX-RS Helm chart directory/file location and use the "mystarter_values.yaml" file<sup>1</sup>, which contains the following content:
``` { .yaml }
license: true
rest:
  image:
    repository: localhost/ibm-itx-rs
    tag: 11.0.3
    digest: ""
    pullPolicyOverride: true 
```
2. Install ITX-RS.\
`> helm install v11 . -f mystarter_values.yaml`<sup>2</sup>
3. Expose the ITX-RS REST API port.\
`> kubectl port-forward service/v11-ibm-itx-rs-prod-rest-v1 9080:8080`

<sup>1</sup> The "license" field must be set to true for IBM license acceptance. The "repository" and "tag" values must match the name listed in [Step #4 of the Configuration:Kubernetes section](#kubernetes).\
<sup>2</sup> The "v11" is the release name, which marks this ITX-RS instance and can be changed accordingly.\

## Deploy
1. List the name of the ITX container.\
`> kubectl get pods -l app.kubernetes.io/component=rest-v1`
2. Copy the sample map to the container's default map location.\
`> kubectl cp OneInOneOut.mmc < name-from-prior-step >:/data/maps`

## Execute
1. Make a REST API request to execute the map.\
`> curl.exe -X PUT -d "hello itx-rs!" "http://localhost:9080/tx-rest/v1/itx/maps/direct/OneInOneOut?input=1&output=1"`
2. Examine the upper-case results.

## Cleanup
1. Uninstall ITX-RS.\
`> helm uninstall v11`
   
# Flow 
This example illustrates how to run existing maps as a flow in the ITX-RS deployment. Since flow executions require the REST API and the Flow Server to communicate across the Kubernetes cluster, Redis must get deployed, as described under the [Redis](#redis) configuration section. Also, [Storage](#storage) must be provisioned as per the [PVC](#pvc) section.

As with all V2-based examples, map and flow definitions must first be packaged up and deployed in a separate step as explained in the [Design Server](#design-server) configuration section. Note that V2-based examples require the "rest.deploy" setting to be 'true', which enables a REST service to get deployed. In this example, the V1-based setting, "restV1.deploy", is set to 'false' to avoid starting up another REST service deployment, which would execute maps from the file system, but is not needed for this example.  

## Install
1. Change to the ITX-RS Helm chart directory/file location and use the "myflow_values.yaml" file, which contains the following content:
``` { .yaml }
license: true
rest:
  deploy: true
  image:
    repository: localhost/ibm-itx-rs
    tag: 11.0.3
    digest: ""
    pullPolicyOverride: true 
restV1:
  deploy: false
itxRedis:
  host: redis-master
```
2. Install ITX-RS.\
`> helm install v11flow . -f myflow_values.yaml`
3. Expose the ITX-RS REST API port.\
`> kubectl port-forward service/v11flow-ibm-itx-rs-prod-rest 9080:8080`

## Deploy
1. [Import](#import) the "Timesheet" project from the "examples\flow\Timesheet.zip" file.<sup>1</sup>
2. [Create](#deploy) a Design Server package and then select all maps, files and flows from the "Timesheet" project.<sup>2</sup>
3. [Deploy](#deploy) the package to the running instance of ITX-RS. As an alternative to Design Server, the 'curl' command can be used.\
`> curl -X POST "http://localhost:9080/tx-rest/v2/packages" -H "accept: */*"  -H "Content-Type: application/octet-stream"  --data-binary @Timesheet_linux.sqlite`

<sup>1</sup>This creates the "WorkHours" flow, which is based on the "flowengine\mmc_import\readme.txt" file.\
<sup>2</sup>The package is already created and downloaded in the "Timesheet_linux.sqlite" file.

## Execute
1. Make a REST API request to execute the map.\
`> curl -X PUT "http://localhost:9080/tx-rest/v2/run/WorkHours"`
2. Examine the results.  If a map failure occurs due to invalid input, make sure to deploy the "allempslf.txt" file, which uses UNIX "\<LF\>" versus Windows "\<CR\>\<LF\>" line endings.
3. Make a REST API request to execute the map with an override of the first input card, "allempslf.txt", which has the list of employee timesheets with the proper UNIX "\<LF\>" line endings.  A second input card specifies the employee whose workhours need to be returned.\
`> curl -X PUT -F "1=@allempslf.txt" -F "2=@employee1.txt" "http://localhost:9080/tx-rest/v2/run/WorkHours"`\
`> curl -X PUT -F "1=@allempslf.txt" -F "2=@employee2.txt" "http://localhost:9080/tx-rest/v2/run/WorkHours"`

## Cleanup
1. Uninstall ITX-RS.\
`> helm uninstall v11flow`

# File Listener
This example illustrates how flows can get executed by watching for new files. Since each file trigger is load balanced across all Executor instances (e.g. executor:replicas), Redis must get deployed, as described under the [Redis](#redis) section. Also, [Storage](#storage) must be provisioned as per the [PVC](#pvc) section.

## Install
1. Change to the ITX-RS Helm chart directory/file location and use the "myfile_values.yaml" file, which contains the following content:
``` { .yaml }
license: true
rest:
  deploy: true
  image:
    repository: localhost/ibm-itx-rs
    tag: 11.0.3
    digest: ""
    pullPolicyOverride: true 
restV1:
  deploy: false
itxRedis:
  host: redis-master
executor:
  replicas: 2
```
2. Install ITX-RS.\
`> helm install v11file . -f myfile_values.yaml`
3. Expose the ITX-RS REST API port.\
`> kubectl port-forward service/v11file-ibm-itx-rs-prod-rest 9080:8080`

## Deploy
1. Import the project that is located under the examples subdirectory, "flowengine\file_listener\FileListenerExample.zip".<sup>1</sup>
2. Edit the "FlowListenerExample" flow settings, select all "Variables", change each value to "/data/tmp/" and then Save. 
3. [Create](#deploy) a Design Server package, select only the "FileListenerExample" flow, and then deploy.

<sup>1</sup>Steps 1 and 2 can be skipped by importing the "FileListenerExample.zip" project from under the ITX-RS "examples\filelistener" folder.

## Execute
1. Get the name of the 'REST' pod by running this command:\
`> kubectl get pods -l app.kubernetes.io/component=rest"`
2. Copy trigger file into the watch folder of the pod name listed above.\
`> kubectl cp myfile_values.yaml <name-from-prior-step>:/data/tmp/myfile.in"`
3. Examine the execution results from the Servers screen. 

## Cleanup
1. Uninstall ITX-RS.\
`> helm uninstall v11file`

# Kafka Listener
The Kafka Listener example illustrates how Kafka messages can be watched for and processed by any one of the Executor replicas. The "SASL" authentication protocol is used to show how secret passwords can be defined for specific users. The secret can be changed across K8S deployments without any changes to the maps or helm charts. The "external" section of the "values.yaml" file has more detailed information on how secrets are defined and automatically mounted into the file system at runtime for subsequent access by maps.

As with all flow-based deployments, Redis must be started as described under the [Redis](#redis) section and [Storage](#storage) must be provisioned as per the [PVC](#pvc) section. In addition, a Kafka installation must get deployed as described under the [setup](#setup) section below. 

## Setup
1. Navigate to the folder, examples/kafkalistener, and then create a secret, as follows:\
`> kubectl create secret generic kafka-user-secret --from-file=user1-conn-prop=client.propitx` 
2. Download a Kafka Helm chart.\
`> helm pull bitnami/kafka --version 26.4.0`<sup>1</sup>
3. Install Kafka.<sup>2</sup>\
`> helm install kafka kafka-26.4.0.tgz -f kafka.yaml`

<sup>1</sup> Downloads a compressed tar file, "kafka-26.4.0.tgz". Alternatively, issue command, "helm search repo bitnami/kafka", and then use the listed version in place of "26.4.0".\
<sup>2</sup> If the Kafka installation deploys to a namespace other than default, then the "Server" name in the map's input and output connection properties will need to be updated with those broker names listed in the installation's console output.

## Install
1. Change to the ITX-RS Helm chart directory/file location and use the "mykafka_values.yaml" file, which contains the following content:
``` { .yaml }
license: true
rest:
  deploy: true
  image:
    repository: localhost/ibm-itx-rs
    tag: 11.0.3
    digest: ""
    pullPolicyOverride: true 
restV1:
  deploy: false
itxRedis:
  host: redis-master
external:
  secrets:
  - name: kafka-user-secret
    data: user1-conn-prop
config:
  rest:
    listeners:
      adapter:
        jvmOptions: "-Djava.security.auth.login.config=/xdata/sec/user1-conn-prop"
  runtime:
    jvmOptions:
    - -Djava.security.auth.login.config=/xdata/sec/user1-conn-prop
```
2. Install ITX-RS.\
`> helm install v11kafka . -f mykafka_values.yaml`
3. Expose the ITX-RS REST API port.\
`> kubectl port-forward service/v11kafka-ibm-itx-rs-prod-rest 9080:8080`

## Deploy
1. [Import](#import) the project that is located under the ITX-RS "examples\kafkalistener" subdirectory, namely "KafkaListener.zip".
2. [Create](#deploy) a Design Server package, which includes the "kafka_testtopic_consumer" flow and the "kafka_producer" map. 
3. [Deploy](#deploy) the package to the ITX-RS REST server.
   
## Execute
1. Produce a message by running a REST request as follows:\
`> curl -X PUT -F "1=This is test message 1" "http://localhost:9080/tx-rest/v2/run/kafka_producer"`
2. The actual message is stored on the file system, under the "/data/tmp/" folder with a file name format as follows: "kafka_outputpayload_topic-test_partition-0_offset-< offset-id >.txt".
3. Examine the execution results from the Servers screen. 

## Logs
1. The Kafka adapter's listener logs are located under the "/logs" directory. See the "kafkalistener*.log" and "m4kafka_consumer.log", which contains a "verbose" output for diagnostic purposes.
2. The Kafka producer logs are stored under the "/logs" directory. For each invocation of the producer map, a log file will appear with a prefix of "kafka_producer_" that is followed by a unique id.

## Cleanup
1. Uninstall ITX-RS.\
`> helm uninstall v11kafka`
2. Uninstall Kafka.\
`> helm uninstall kafka`
3. Delete secret.\
`> kubectl delete secret kafka-user-secret`

# MQ Listener
The MQ Listener example runs on the RHOS platform and requires IBM MQ. Once you have remotely logged into the RHOS cluster, the login command can be copied and run locally so that your kubernetes context now points to the RHOS cluster. In this way, both "oc" and/or "kubectl" commands can be issued in a local command line session while returning information about the remote RHOS cluster.  

## Software
The current example employs the IBM MQ Operator for MQ setup and configuration purposes.  

| Name                   | Version <sup>1</sup>             | Platform |  Access  |
| ---------------------- | ----------------- |------------- |----------|
| `Red Hat OpenShift` | 4.20 | Multiple   | RHOS Administrator provides URL and login credentials |
| `IBM MQ Operator`   | 2.4.4          | RHOS | RHOS Administrator downloads and installs |
| `oc`<sup>2</sup> | 4.12 | Windows      | RHOS user account enables [download](https://console.redhat.com/openshift/downloads)  |

<sup>1</sup> Minimum Version\
<sup>2</sup> OpenShift Command Line Interface that is equivalent to kubectl

## Configuration
The Kubernetes configuration context needs to switch to RHOS. This requires a login to the RHOS cluster. By using the browser, navigate to your online profile, pull down the menu bar item that displays the user id and then select the "Copy login command" menu item.  

The following is an example of a command that was copied from a RHOS user's login session, `oc login --token=sha256~IQItazTIhYvg1cTZ5NANYTIkn1uxqRvvIdj3uR1HWOQ --server=https://api.os4.actian.fans:6443`. Once run locally, the Kubernetes context is changed and will point to the RHOS cluster. 

Here are "kubectl" and "oc" commands that can be used to switch back and forth from the local "minikube" context to the remote "RHOS" Kubernetes context:
1. Examine the current Kubernetes context.\
`kubectl config current-context`
2. List all Kubernetes contexts.\
`kubectl config get-contexts`
3. Switch to the RHOS or Minikube context.\
`kubectl config use-context < RHOS-context-as-created-by-oc-login | minikube >`

## Setup
The MQ Server must be setup with local queues and a listener for ITX MQ triggering purposes. Since this example listens and triggers from a flow, the Redis server must be deployed as already described in the [Redis](#redis) section. Also, [Storage](#storage) must be provisioned as per the [PVC](#pvc) section.

### Queue
After the cluster administrator installs the IBM MQ Operator, the IBM MQ administrator can navigate to the 'Admin UI' for setting up the "TEST" queue. The URL for accessing the 'Admin UI' is listed under the installed MQ Server's "Details" screen. The "TEST" queue can be defined from the MQ "Admin UI" console.  

### Channels
The IBM MQ adminstrator also defines the channels necessary for listening to the "TEST" queue.

For example, the commands below need to be run from the IBM MQ Queue Manager pod via the "runmqsc" utility:
1. `DEFINE CHANNEL(MQ.QS.CHAN) CHLTYPE(SVRCONN) TRPTYPE(TCP) DESCR('Server-connection for MQ Client')`
2. `DEFINE CHANNEL(MQ.QS.CHAN) CHLTYPE(CLNTCONN) TRPTYPE(TCP) CONNAME('quickstart-cp4i-ibm-mq.cshdev.svc.cluster.local') QMNAME(QUICKSTART) DESCR('Client-connection to QUICKSTART QMgr')`<sup>1</sup>
3. `start channel(MQ.QS.CHAN)`

<sup>1</sup> Change the CONNNAME and QMNAME fields accordingly. CONNNAME is the service name of the MQ Server and QMNAME is the Queue Manager name.

### Secret
The ITX MQ client adapter must use the queue credentials and connectivity parameters that were defined on the MQ Server when creating and configuring the channels. The location is specified here:
/var/mqm/qmgrs/< Queue-Manager-name >/@ipcc/AMQCLCHL.TAB.  For the purposes of this example, the Queue Manager name is "QUICKSTART".

When no security credentials are needed for simplicity and testing purposes, the "runmqsc" command that disables channel authentication is: `alter QMGR CHLAUTH(DISABLED)`.

The following commands can be run to retrieve the MQ client channel definition and then define them in the cluster:
1. Copy the MQ Client channel definition file.\
`oc cp < pod-name >:/var/mqm/qmgrs/QUICKSTART/@ipcc/AMQCLCHL.TAB AMQCLCHL.TAB`
2. Define the secret, as follows:\
`oc create secret generic mq-secret --from-file=AMQCLCHL.TAB=AMQCLCHL.TAB`
3. Describe the secret:\
`oc describe secret/mq-secret`

## Install
1. Change to the ITX-RS Helm chart directory/file location and use the "mymq_values.yaml" file, which contains the following content:
``` { .yaml }
license: true
rest:
  deploy: true
  image:
    tag: 11.0.3
    digest: ""
    pullPolicyOverride: true 
restV1:
  deploy: false
itxRedis:
  host: redis-master
external:
  mq:
    chlLib: /xdata/sec
    chlTab: AMQCLCHL.TAB
    secret: mq-secret
```
2. Install ITX-RS.  For example:\
`> helm install v11 . -f mymq_values.yaml --set itxImagePullSecret="yoursecret" --set rest.image.repository="registy/yourpath/ibm-itx-rs"`

## Deploy
1. [Import](#import) the project that is located under the ITX-RS "examples\mqlistener" subdirectory, namely "MqListener.zip".
2. [Create](#deploy) a Design Server package, which includes the "mq_testq_listener" flow and the "mq_put_text" map. 
3. [Deploy](#deploy) the package to the ITX-RS REST server.
   
## Execute
1. Produce a message by running a REST request as follows:\
`> curl -X PUT -F "1=This is test message 1" "http://v11-ibm-itx-rs-prod-rest-route-namespace.apps.os4.corp.id:80/tx-rest/v2/run/mq_put_text"`<sup>1</sup>
2. The actual message is stored on the file system, under the "/data/tmp/" folder with a file name format as follows: "msg_hdr_info.out".
3. Examine the execution and log results from the Servers screen. 

<sup>1</sup> RHOS Host Server is gotten from this command: `oc get routes -l app.kubernetes.io/instance=v11`

## Logs
1. The MQ adapter's listener log is located under the "/logs" directory. See the "listenerexecutor_*.log" file. 
2. The MQ adapter producer log is stored under the "/logs" directory with the file name, "m4mq_put_text.log".

## Cleanup
1. Uninstall ITX-RS.\
`> helm uninstall v11`
2. Delete secret.\
`> kubectl delete secret mq-secret`

# Security
The security section describes how various ITX-RS integrations can be properly secured. Specific settings in the "values.yaml" file can be overridden for securing ITX-RS communications. The three main integrations that may require security are the REST Server, the Design Server and Redis.

First of all, the ITX-RS REST Server must be secured whenever there are non-secure external connections. The TLS protocol is used to secure communication with the REST Server by using public [certificates](#certificates) and private keys as specified in the "values.yaml" file. This ensures that sensitive data is kept uncompromised, particularly in a production environment.  

Secondly, if the Design Server is deploying and monitoring the REST Server in a secure way, the appropriate "config.yaml" configuration values can be set as explained in the ITX-RS "Install" section below.

Thirdly, Redis connections may also require security. If the Redis server is external to the cluster, then security is necessary. If the Redis server is deployed within the ITX-RS Kubernetes cluster, security may not be required - depending on whether the cluster itself is already secure. Consult the Redis documentation and/or administrator for further details on TLS configuration.

## Certificates
A set of sample certificates and private keys have been defined for this security example. The commands that were used to generate them are included in the "mysec.sh" file. Another set of these certificates and private keys may be re-generated, but is not required. If necessary, the "mysec.sh" commands can be executed again after establishing and connecting to a running pod, as per the following command:\
`> kubectl run -i -t itx-cmd --image localhost/ibm-itx-rs:11.0.3 --restart=Never --rm --command -- /bin/bash` 

By using the pre-generated certificates as found under the folder, "examples/security", a Kubernetes secret can be created for the REST Server, as follows:\
`> kubectl create secret generic itx-rest-server --from-file=ca.crt=my_ca.cer --from-file=tls.crt=my_server.cer --from-file=tls.key=my_server.key`\
This secret will be referenced in the following section.

## Install
1. Change to the ITX-RS Helm chart directory/file location and use the "mysec_values.yaml" file, which contains the following content:
``` { .yaml }
license: true
itxRedis:
  host: redis-master
restV1:
  deploy: false
rest:
  image:
    repository: localhost/ibm-itx-rs
    tag: 11.0.3
    digest: ""
    pullPolicyOverride: true
  inbound:
    http:
      enabled: false
    https:
      enabled: true
      secret: itx-rest-server
      clientAuth: false
```  
2. Install ITX-RS.\
`> helm install v11sec . -f mysec_values.yaml`
3. Expose the ITX-RS REST API port.\
`> kubectl port-forward service/v11sec-ibm-itx-rs-prod-rest 9443:8443`

Note that if "clientAuth" is set to true for client authentication, then any ITX-RS clients must include the "my_ca.cer" as part of the truststore and specify the client certificate, "my_client.cer", and key, "my_client.key" as part of the TLS configuration. In the case of the Design Server, which connects to ITX-RS as a client during deployment, the "config.yaml" file would need to get modified, as follows:
``` { .yaml }
server:
  runtime:
    servers:
      - localhost:9443
  outbound:
    ssl:
      certFile: "my_client.cer"
      keyFile: "my_client.key"
      caFile: "my_ca.key"
```
Note that the "localhost" would get replaced with whatever host name that was used to generate the REST Server certificate. The pre-generated certificates use "localhost" as the host name. Also, all file references should be replaced with the fully qualified path that contains the certificates.

## Deploy<sup>1</sup>
1. [Import](#import) any of the previously defined projects, if not already done.
2. [Create](#deploy) a Design Server package, which includes any specific flow and/or map. 
3. [Deploy](#deploy) the package to the ITX-RS REST server.  The "server" must be defined with the "https://localhost:9443/tx-rest" URL.

<sup>1</sup> Alternatively, enter the "https://localhost:9443/tx-rest" URL into a browser to confirm that the ITX-RS is up and running.

## Cleanup
1. Uninstall ITX-RS.\
`> helm uninstall v11sec`
2. Delete secret.\
`> kubectl delete secret itx-rest-server`

## Zero Trust
Any given ITX-RS installation can be locked down within a zero trust framework, whereby all client access and server communication can be fully authenticated and secured via TLS. 

When running on RHOS, the 'mysec4rhos.sh' script provides an example of how to generate the certificates. The script contains 3 parameters which must be edited according to the user's current RHOS configuration. Once the appropriate and user-specific parameters are changed, the script can be run as documented in the [Certificates](#certificates) section. 

The server certificate is generated with two "Subject Alternative Names" that enable access from outside and inside the cluster. By installing with the "clientAuth" field set to "true", all client connections will be authenticated before getting access to the ITX-RS.

### Setup
1. Configure the certificates by editing each of the 3 parameters listed in "mysec4rhos.sh" script under the "Parameters" section.
2. Generate the certificates by executing the "mysec4rhos.sh" script on any running ITX-RS container.
3. After copying the generated certificates and keys to your local system, define the server secret.\
`> kubectl create secret generic itx-rest-server --from-file=ca.crt=my_ca.cer --from-file=tls.crt=my_server.cer --from-file=tls.key=my_server.key`

### Install
Install ITX-RS.\
`> helm install v11sec . -f mysec_values_4pass.yaml --set itxImagePullSecret=<your-secret> --set rest.image.repository=<registry>/<repo>/ibm-itx-rs`

### Monitor
1. Record the RHOS host and port that is listed in the output of the 'oc get routes' command.
2. Authorize access to ITX-RS by editing the "config.yaml" in your local Design Server. First, add this entry, "- v11sec-ibm-itx-rs-prod-rest-route-< your-rhos-project-name >.< your-rhos-dns-suffix:443 >", under the "server/runtime/servers" field. Secondly, modify the "certFile", "keyFile" and "caFile" entries under the "server/runtime/outbound/ssl" field to reference the previously generated client certificate, client key and certificate authority, respectively. Lastly, set the "verifyHostName" to "true".
3. A new server can be defined on the Design Server's "Server" screen so that monitoring can be done within a secure and authenticated zero trust framework. For example, a "Base URL", such as "https://v11sec-ibm-itx-rs-prod-rest-route-cshdev.apps.os4.actian.fans:443/tx-rest", would properly connect if "cshdev" is your RHOS project name and "apps.os4.actian.fans" is your RHOS DNS suffix, as per the output shown under the "HOST/PORT" column from the first step. 

# Storage
The ITX-RS storage requirements depend on the type of deployment. For REST V1-based deployments that only execute maps, a persistent volume claim (PVC) or Cloud Object Storage (COS) is necessary. For REST V2-based deployments that execute both maps and flows, a PVC is mandatory for deployment, execution, and monitoring purposes. The REST V1 and V2 deployments may co-exist at the same time, depending on the installation's configuration, as defined by the "values.yaml" settings. The V1 and V2 deployments are enabled or disabled by the "restV1.deploy" and "rest.deploy" settings, respectively.

The REST V2-based deployments leverage persistent PVC storage to retain map and flow definitions as well as to process incoming data and generated output. During map and flow execution, input, output and audit files pass across the PVC to ensure all V2-based processing is synchronized between the REST and Executor pods.  Since deployment, execution and logging all require storage that persists after a helm uninstall, the PVC needs to be [retained](#retain). Otherwise, all the deployed artifacts and generated output will get deleted after the ITX-RS helm uninstall command. 

The REST V1-based deployments may forgo the use of a PVC by making use of COS, which can be used as the central staging area for all map deployments. If log files and other runtime-based output is not needed across installations, as may be the case for synchronous-based map invocations, then COS enables V1 deployments to be decoupled from PVC storage and to readily scale in a cloud native way across all available worker nodes in the cluster.   

The following sections describe how to setup [PVCs](#pvc) and [COS](#cos) for both V1 and V2-based deployments. Refer to the ITX-RS chart's "README.md" notes and "values.yaml" file for further details. In the case of V1-based deployments that use the default "unfenced" runtime mode (restV1.runmode=unfenced), PVCs are not required. The maps are automatically downloaded from COS before the V1-based REST API accepts any requests for map execution. Even though V2-based deployments always require a PVC, it can also benefit from the use of COS, whereby "packages" can be included in the downloaded zip file for automatic deployment. In this way, administrators can securely automate the installation and deployment of maps and flows without manual intervention or end user involvement.  

## PVC
The typical and default ITX-RS installation requires two PVCs. One is mainly for map-related data, with a "rest-data" name suffix, and another for process-related logs, with a "rest-logs" name suffix. The size and storage attributes of both PVCs are specified under the "rest.persistence.data" and "rest.persistence.logs" sections of the "values.yaml" file.  

Before the ITX-RS installation, the storage class of the PVC can be identified and specified as an override setting. The "rest.persistence.data.storageClass" setting is used for the "rest-data" PVC and "rest.persistence.logs.storageClass" for the "rest-logs" PVC. If not specified directly, a default class is selected and will be different for each Kubernetes cluster.  

The following command can be used to determine the different PVC storage classes: 
`kubectl get sc`.
The output of this command will indicate the "RECLAIMPOLICY", which determines whether the data on the storage device is "Retained" or "Deleted" after the ITX-RS helm uninstall. The recommended storage class will have a "Retained" reclaim policy. In this way, both map and log data will be saved across ITX-RS installations.

If the available storage classes do not have a "Retained" reclaim policy, a PVC may still be created that is retained across installations. This can be done by first [defining and provisioning](#define) each PVC before the ITX-RS install. Each provisioned PVC can then have its reclaim policy changed by following the [retain](#retain) steps. 

### Define
1. Change to the ITX-RS "example\storage" folder to examine the "mydata.yaml" and "mylogs.yaml" files. The "data" PVC definition follows:
``` { .yaml }
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: rest-data
spec:
  accessModes:
  - ReadWriteMany
  resources:
    requests:
      storage: 10Gi
``` 
2. Provision both PVCs with the following command:\
`> kubectl apply -f mydata.yaml`\
`> kubectl apply -f mylogs.yaml`
3. View the PVCs with the following command:\
`> kubectl get pvc rest-data rest-logs`

### Retain
1. Capture volume names associated with both PVCs with the following command:\
`> kubectl get pvc rest-data -o template --template={{.spec.volumeName}}`\
`> kubectl get pvc rest-logs -o template --template={{.spec.volumeName}}`
2. Change the reclaim policy for each PV listed above from `Delete` to `Retain` by running the commands:\
`> kubectl patch pv < PV-name-1-from-step-1 > -p "{\"spec\":{\"persistentVolumeReclaimPolicy\":\"Retain\"}}"`\
`> kubectl patch pv < PV-name-2-from-step-1 > -p "{\"spec\":{\"persistentVolumeReclaimPolicy\":\"Retain\"}}"`
3. View all the PVs and confirm that the "RECLAIMPOLICY" is now set to "Retained":\
`> kubectl get pv`

The "rest-data" and "rest-logs" PVCs (which retain data across installations) can now be referenced in a new ITX-RS installation with override settings specified in the "myclaim.yaml" file and illustrated below:
``` { .yaml }
license: true
restV1:
  deploy: false
rest:
  image:
    repository: localhost/ibm-itx-rs
    tag: 11.0.3
    digest: ""
    pullPolicyOverride: true
  persistence:
    data:
      existingClaim: rest-data
    logs:
      existingClaim: rest-logs
```  

After the ITX-RS installation is uninstalled, all deployed packages and execution logs will be saved and not deleted. So, subsequent installations will restart with the same set of installed maps and flows as well as logs.

### NFS
The V2-based deployments are geared for a traditional NFS-based storage medium. In this way, horizontal scaling across all available worker nodes may take place since the same storage is accessible no matter what worker node is used for map and flow execution. Note that horizontal scaling is not currently supported by the MQ Listener, which can only scale vertically via the amount of CPUs specified in the "rest.resources.requests.cpu" setting. All other listeners and map executions directly benefit from additional worker nodes, as specified in the "executor.replicas" settings.

Cloud providers do offer NFS-based storage classes, which may automatically get created with the "Retain" reclaim policy. If so, the PVC can be defined as described above in the [Define](#define) section and then referenced with the ITX-RS "existingClaim" setting without having to go through the [Retain](#retain) steps. Alternatively, the [Define](#define) steps can be skipped by enabling dynamic provisioning via the "rest.persistence.data.dynamicProvisioning" setting, specifying the appropriate "storageClass" setting and then using "ReadWriteMany" as the "accessMode" setting. Just remember that the PVC that is manually or dynamically provisioned must have a "retained" reclaim policy.   

Here is an example of a PVC definition that could be used to create NFS-based storage that is retained over multiple installs:  
``` { .yaml }
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: rest-data-nfs
spec:
  accessModes:
  - ReadWriteMany
  storageClassName: nfs
  resources:
    requests:
      storage: 10Gi
``` 
Take note of the "nfs" storage class name, which presumes this type of storage class is offered by the cloud provider. This definition could be used by Kubernetes (e.g. kubectl apply -f < file containing the above definition >) to define storage for a V2-based deployment that scales across multiple nodes in the cluster.

The V1-based deployments may also need to use an NFS-based or "ReadWriteMany" storage class so that each replica accesses the same set of deployed maps. However, no PVCs would be required if you have access to COS, as explained in the following [COS](#cos) section.    

## COS
Cloud Object Storage (COS) is supported during an ITX-RS installation for both V1 and V2-based deployments. As long as S3-based or Google-based cloud storage is accessible, the ITX-RS install will automatically download a user-specified "zip" file and then proceed to unzip it under the pre-defined "/data/maps" folder. In this way, the V1 and V2 REST API is automatically ready to execute map and flow requests without manual intervention.   

Refer to the "external.cos" section of the "values.yaml" file for setup of this capability. Once activated, the REST API will automatically be initialized and ready to accept map and flow requests after the successful download and deployment of the zip file contents. A COS status report can be viewed by examining the Kubernetes log file, as the following command illustrates for a V1-based deployment: `kubectl logs < your-pod-name > -c ibm-itx-rs-prod-rest-v1-cos-download`. For a V2-based deployment, the pod name would be different and the value following the container parameter, "-c", would remove the "-v1" suffix as follows: "ibm-itx-rs-prod-rest-cos-download". 

Unlike V1-based deployments that only execute maps, V2-based deployments can execute both maps and flows. This capability requires the maps and flows to be packaged up and [deployed](#deploy). When running in a production-like system, the packages can even be exported to a file, zipped up and then uploaded to COS. Once any set of packages are uploaded to COS in a zipped up format, the V2-based installation can automatically download the appropriate file, unzip all its content, and then securely deploy each and every package to the REST API. See the "rest.deployPackages" section in the "values.yaml" file for further guidance.   

### IBM
Here is a sample of what a "values.yaml" override file would look like for an IBM S3-based COS integration:
 ``` { .yaml }
license: true
rest:
  deploy: false
  image:
    repository: localhost/ibm-itx-rs
    tag: 11.0.3
    digest: ""
    pullPolicyOverride: true
external:
  secrets:
    - data: ibm_secretkey
      name: ibm-secret
    - data: ibm_accesskey
      name: ibm-secret
  cos:
    enabled: true
    name: maps.zip
    bucket: itx
    platform: s3
    s3:
      secretKey: ibm_secretkey
      accessKey: ibm_accesskey
      endpoint: s3.us-east.cloud-object-storage.appdomain.cloud
      region: us-east
```  
There is one secret defined, namely "ibm-secret", but with references to two keys. One key is for the secret and another for the access key, as defined by the following command:\
`> kubectl create secret generic ibm-secret --from-literal=ibm_accesskey=< your-access-key > --from-literal=ibm_secretkey=< your-secret-key >`\
The V1 and/or V2 REST initialization will access both the secret and access keys along with the other values to ensure a successful COS connection and download operation.

### AWS
Here is a sample of what a "values.yaml" override file would look like for an AWS S3-based integration:
 ``` { .yaml }
license: true
rest:
  deploy: false
  image:
    repository: localhost/ibm-itx-rs
    tag: 11.0.3
    digest: ""
    pullPolicyOverride: true
external:
  secrets:
    - data: s3_secretkey
      name: s3-secret
    - data: s3_accesskey
      name: s3-secret
  cos:
    enabled: true
    name: myUser/maps.zip
    bucket: lnk-itx-bucket
    platform: s3
    s3:
      secretKey: s3_secretkey
      accessKey: s3_accesskey
      region: us-east-1
```  
There is one secret defined, namely "s3-secret", but with references to two keys. One key is for the secret and another for the access key, as defined by the following command:\
`> kubectl create secret generic s3-secret --from-literal=s3_accesskey=< your-access-key > --from-literal=s3_secretkey=< your-secret-key >`\
The V1 and/or V2 REST initialization will access both the secret and access keys along with the other values to ensure a successful COS connection and download operation.

### GCP
A Google cloud platform storage integration would look similar, as per the following "values.yaml" override:
 ``` { .yaml }
license: true
rest:
  deploy: false
  image:
    repository: localhost/ibm-itx-rs
    tag: 11.0.3
    digest: ""
    pullPolicyOverride: true
external:
  secrets:
    - data: cf.json
      name: gcp-secret
  cos:
    enabled: true
    name: myUser/maps.zip
    bucket: lnk-itx-bucket
    platform: gcp
    gcp:
      cf: cf.json
```
There is one secret defined, namely "gcp-secret", which contains the contents of the Google Cloud Platform credentials file, as defined by the following command:\
`> kubectl create secret generic gcp-secret --from-file=cf.json=< name-of-your-gcp-downloaded-credentials-file >`\
The V1 and/or V2 REST initialization will access the credentials file along with the other values to ensure a successful COS connection and download operation.

Currently, only one zip file is supported. The zip file needs to contain all the maps, files and/or packages that are required for invocation and execution purposes.  

### V1 Example

A V1-based installation can automatically download maps from AWS COS by following the "Setup" and "Install" sections below. Once ITX-RS starts up, any of the maps that were included in the zip file are invoked by following the "Execute" section. If ITX-RS does not startup successfully<sup>1</sup>, then the zip file download may be encountering a problem, which can be examined by running the "kubectl get logs" command that is documented in the last step of the "Execute" section.

<sup>1</sup> The "kubectl get pods -l app.kubernetes.io/component=rest-v1" command does not display a "Running" status.

#### Setup
1. Zip up all map files with an extension of ".mmc".
2. Upload zip file to COS.  During login and upload, take note of the "region", "bucket" and "name" (including the folder) that is used.
3. Create your Kubernetes secret so that the ITX-RS deployment has permissions to connect to COS.\
`> kubectl create secret generic s3-secret --from-literal=s3_accesskey=< your-access-key > --from-literal=s3_secretkey=< your-secret-key >`
#### Install
1. Edit the "awscos.yaml" in the "Storage" subdirectory. Change the "region", "bucket", and "name" to match your COS account and uploaded zip file name.
2. Install ITX-RS.\
`> helm install v11cos . -f awscos.yaml`
3. Expose the ITX-RS REST API port.\
`> kubectl port-forward service/v11cos-ibm-itx-rs-prod-rest-v1 9080:8080`
#### Execute
1. Run your map by making a REST API request. If the "OneInOneOut.mmc" map was zipped up, as used in the [Starter](#starter) section, then run this command:\
`> curl.exe -X PUT -d "hello itx-rs COS!" "http://localhost:9080/tx-rest/v1/itx/maps/direct/OneInOneOut?input=1&output=1"`
2. Examine the results depending on your map's API invocation.
3. If the map does not complete as expected, verify that the map was extracted by looking at the following log file results:\
`> kubectl logs < your-pod-name > -c ibm-itx-rs-prod-rest-v1-cos-download`
#### Cleanup
1. Uninstall ITX-RS.\
`> helm uninstall v11cos`
2. Delete secret.\
`> kubectl delete secret s3-secret`

The "Setup" and "Install" steps are only needed to be done once. After those steps are completed, any new replicas of ITX-RS that are provisioned by an Administrator or by Horizontal Pod Autoscaling will automatically download the zipped up maps and be ready to accept REST API requests. This effectively makes the ITX-RS installation a cloud-native application - without the need for any kind of PVC storage or manual map uploads.

### V2 Example
This V2 example illustrates how ITX-RS supports the auto-deployment of packaged maps and flows. Once a specific set of maps and packages are defined, zipped up, and uploaded to Cloud Object Storage (COS), ITX-RS can be installed and configured in one atomic step. In this way, the ITX-RS is fully configured before being made available for the handling of REST requests. 

In production environments, cloud administrators can ensure that installation and deployment is not only integrated and automated but also fully secured. This example employs both COS and mutual TLS to ensure that ITX-RS is running within a [zero trust](#zero-trust) framework on RHOS. Both the installation and deployment are fully secured and authenticated before users start to access ITX-RS.

#### Setup
1. Run the "Setup" steps that are defined in the [Zero Trust](#zero-trust) section and then create a client secret, which will be used during auto-deployment.\
`> kubectl create secret generic itx-rest-client --from-file=my_client.cer=my_client.cer --from-file=my_client.key=my_client.key`
2. Zip up any of the previously defined and downloaded packages, such as "Timesheet_linux.sqlite", which is under the "flow" subdirectory.
3. Copy the zipped up package, "Timesheet_linux.zip", to IBM Cloud Object Storage. 

#### Install
Install ITX-RS with auto-deployment enabled, as follows:\
`> helm install v11sec . -f ibmcos4autodeploy.yaml --set itxImagePullSecret=<your-secret> --set rest.image.repository=<registry>/<repo>/ibm-itx-rs`

#### Execute
Execute a flow from the "flow" directory, as follows:\
`> curl --cacert my_ca.cer --cert my_client.cer --key my_client.key -X PUT -F "1=@allempslf.txt" -F "2=@employee1.txt" "https://<your-itx-rest-route-host-name>/tx-rest/v2/run/WorkHours"`<sup>1</sup>

<sup>1</sup> Use a downloaded version of "curl" as indicated in the [Requirements](#requirements) section to ensure that certificates can be loaded from your local drive.

#### Monitor
Observe the auto-deployed packages and executed flows in the "Servers" screen of the [Design Server](#design-server). Alternatively, view the auto-deployed package by running the following command and using a host name from the 'oc get routes' command:\
`> curl --cacert my_ca.cer --cert my_client.cer --key my_client.key -X GET https://<your-itx-rest-route-host-name>/tx-rest/v2/packages`

#### Troubleshooting
The auto-deployment occurs in two distinct phases. The first phase downloads and unpacks the zip file. The results of this operation can be viewed via the [OpenShift "oc logs"](https://console.redhat.com/openshift/downloads) command.<sup>1</sup> The second phase runs after the ITX-RS container starts but before it is made ready for external access. These results are saved to the "/logs/deploy.log" file in the container.<sup>2</sup> 

<sup>1</sup> `> oc logs v11sec-ibm-itx-rs-prod-rest-<pod-id> -c ibm-itx-rs-prod-rest-cos-download`\
<sup>2</sup> `> oc exec -it v11sec-ibm-itx-rs-prod-rest-<pod-id> -- bash -c "cat /logs/deploy.log"`

## Ephemeral
Any V1 or V2-based deployment can specify ephemeral storage requirements by setting the appropriate size limits with the "ephemeral-storage" settings under the "requests:" and "limits:" sections in the "values.yaml" file. The "ephemeral-storage" setting is particularly important for V1-based deployments which are utilizing COS.     

When COS is used for V1-based map deployments, the "rest-data" PVC can be eliminated by setting the override setting, "rest.persistence.data.enabled=false". Similarly, if logging is not needed to be retained across installations, then the "rest-logs" PVC can be removed by setting the override setting, "rest.persistence.logs.enabled=false". Once both PVCs are disabled, all map-based and log-related storage becomes ephemeral, which decouples the deployment from having to define persistent storage claims.

Here is a sample of a "values.yaml" override file for any COS-based V1 integration, which makes use of ephemeral storage:
 ``` { .yaml }
rest:
  persistence:
    data:
      enabled: false
      limit: 10Gi
    logs:
      enabled: false
      limit: 100Mi
restV1:
  resources:
    requests: 
      ephemeral-storage: 11Gi
    limits:
      ephemeral-storage: 20Gi
```
The overall ephemeral storage requirements for each replica in the ITX-RS deployment is specified under the "resources" section. The two mounted directories, "/data" and "/logs", are each limited in size, as per the "/rest/persistence/data/limit" and "/rest/persistence/logs/limit" settings, respectively. The combined size of both "data" and "logs" should not exceed the "restV1.resources.limits" setting.

By changing Step 2 in the "Install" section of the prior [V1 Example](#v1-example), the following command installs ITX-RS with ephemeral, non-PVC, storage:\
`> helm install v11cos . -f awscos.yaml -f nopvc.yaml`

Once the PVC requirement is eliminated by using COS, the V1-based REST API pod can be started on demand and readily scaled in a cloud native way without the need for preconfigured storage and manual uploads.

# Patching
The typical way to provide an ITX-RS software patch is via an officially published container image, which will include a cumulative set of changes across all runtime components.

Another option is to apply a hotfix, which constitutes an urgent and critically important software patch that is provided outside the normal delivery cycle. This enables a specific set of object modules to get applied to an existing ITX-RS container image. 

The fixes associated with the hotfix are copied onto the container image right before runtime processes are started. This approach enables the same container image to be used along with the patch updates while eliminating the management and rollout of a completely new image.

## Settings
The hotfix capability is activated with the "values.yaml" setting, "config.patch.directory", which is referred to as the patch directory. The value of the setting points to the directory location of the modules that need to get applied to the ITX-RS image. 

In order to ensure that only the correct set of fixes get applied, another setting describes the list of expected updates, namely "config.patch.manifest", which is referred to as the patch manifest and defaults to the file name, "/xdata/cfg/patchmanifest.txt".

## Manifest
The patch manifest contains an entry for each ITX-RS runtime module that will be updated from the patch directory. This file needs to be defined as a "ConfigMap" before ITX-RS is installed. A "ConfigMap" example is shown below and could be defined with this command, `kubectl apply -f mypatch_configmap.yaml`.

The sample contents of the "mypatch_configmap.yaml" file is as follows:
``` { .yaml }
apiVersion: v1
kind: ConfigMap
metadata:
  name: itx-rs-patch-manifest
data:
  patchmanifest.txt: |
    2683702579 5142656 libcoreapi.so
    511659562 11132360 listenerexecredis
```
Each fix to be applied is listed in a "cksum" format, which uniquely identifies the patch. The "cksum" utility is part of the ITX-RS container image and can be run on any of the patches. Based on the above "ConfigMap", the target patch directory should only contain two files, namely "libcoreapi.so" and "listenerexecredis". Those files could be located in any subdirectory of the target patch directory. If using the patch directory, "/data/patches", the following "find" command confirms the "cksum" values that are used in the "itx-rs-patch-manifest" ConfigMap:

```
$ find /data/patches -type f -exec cksum {} \;
511659562 11132360 /data/patches/listenerexecredis
2683702579 5142656 /data/patches/libcoreapi.so
```
## Install 
With the patch directory and manifest defined, the following helm install command from the [Starter](#starter) example could be used along with overridden settings in order to apply a patch: 
`> helm install v11 . -f mystarter_values.yaml -f mypatch_values.yaml`

The "mypatch_values.yaml" is defined as follows:
``` { .yaml }
rest:
  persistence:
    data:
      existingClaim: rest-data
external:
  configMaps:
    - name: itx-rs-patch-manifest
      key: patchmanifest.txt
      path: patchmanifest.txt
config:
  patch:
    directory: /data/patches
``` 
The fixes under the "/data/patches" directory need to be retained across container restarts. By using an "existingClaim", the "rest-data" PVC can be configured with the "retain" reclaim policy, as described in the [PVC section](#pvc).  

The "itx-rs-patch-manifest" ConfigMap makes sure that only specifically listed runtime modules are updated. So, if another update is made to the patch directory without first updating the patch manifest, the helm install will fail. Such a failure is by design and serves as a secure guarantee that only fixes which are identified in the patch manifest are applied. 

The "path" value of any listed "configMaps" are prepended by default with the "/xdata/cfg" subdirectory path, as specified in the "values.yaml" file under the "external.data" section. As a result of the helm install, the "patchmanifest.txt" file name automatically becomes "/xdata/cfg/patchmanifest.txt", which matches the default [setting](#settings) of the patch manifest.  

## Results
The command, `kubectl logs <pod-name>`, can be used to see how each of the runtime modules were patched. Here is a snippet of the output log after a successful helm installation with patches applied from the patch directory and validated against the patch manifest:
```
2025-08-29 12:26:38: Patch Application Script
  Directories: patch = /data/patches, runtime = /opt/runtime, backups = /tmp/original, manifest = /xdata/cfg/patchmanifest.txt
Patch file # 1: /data/patches/listenerexecredis
  Target path: /opt/runtime/bin/listenerexecredis
  Backup path: /tmp/original/opt/runtime/bin/listenerexecredis
  Original dtxver: /opt/runtime/bin/listenerexecredis -->  11.0.3.0(24)     <-- Tue Jun 02 20:02:11 2025 - 10776384 bytes
  Patch dtxver:    /data/patches/listenerexecredis -->     11.0.3.0(24)     <-- Tue Jun 02 20:02:11 2025 - 10776384 bytes
  Original cksum:  4239651096 10776384 /opt/runtime/bin/listenerexecredis
  Patch cksum:     4239651096 10776384 /data/patches/listenerexecredis
  Successfully patched /opt/runtime/bin/listenerexecredis.
Patch file # 2: /data/patches/libcoreapi.so
  Target path: /opt/runtime/libs/libcoreapi.so
  Backup path: /tmp/original/opt/runtime/libs/libcoreapi.so
  Original dtxver: /opt/runtime/libs/libcoreapi.so -->  11.0.3.0(24)     <-- Tue Jun 02 19:52:59 2025 - 5115392 bytes
  Patch dtxver:    /data/patches/libcoreapi.so -->      11.0.3.0(24)     <-- Tue Jun 02 19:52:59 2025 - 5115392 bytes
  Original cksum:  3813007982 5115392 /opt/runtime/libs/libcoreapi.so
  Patch cksum:     3813007982 5115392 /data/patches/libcoreapi.so
  Successfully patched /opt/runtime/libs/libcoreapi.so.
2025-08-29 12:26:38: Patch succeeded (return code = 0, successes = 2, failures = 0, missing = 0).
```
In the above case, the two patches applied were the same files as the originals. Once an official patch is made available by support, the "cksum" values between the original and the replacement files will differ. The log describes both the "dtxver" and "cksum" results of the original and patched files for auditing purposes. The original files are moved under the "/tmp/original" folder for future reference and tracking purposes.

# Metrics
Metrics are numerical measurements representing the current state and behavior of the deployment. There are several categories of metrics, which include core CPU percentages, memory usage amounts, worker thread saturation levels, service level response percentiles, timed histogram completions and overall readiness checks. All metrics can be retrieved via the URI path, "/tx-rest/metrics".

The [core](#core) metric tracks the memory consumption and CPU usage of the main Java ITX REST process. The [thread saturation](#thread-saturation) monitors the actual number of REST request worker threads that are active at a specific moment in time in the main process. The service level indicator (or [SLI](#sli)) measures REST response times against a user defined threshold. Timed [histograms](#histogram) track performance and throughput of map and flow execution requests across any combination of HTTP methods, status codes and URI endpoints. 

This [readiness](#readiness) metric uses a subset of the above metrics to determine whether the service is available to receive more requests or should be marked unready because of processing overload. The readiness metric is accessible via the URI, "/tx-rest/metrics?readiness=true". It is not only enabled when the "metrics.enabled" is set to "true" but also included as part of the Kubernetes readiness probe via the "metrics.readinessProbeEnabled" setting.

## Core
The core metrics include CPU and memory usage. The CPU metric is named "core_process_cpu_usage", which is a fractional representation of how many CPUs are currently in use by all processes in the container. If the CPU limit of the deployment is set to 4, then a ".50" percentage would indicate usage of about 2 CPUs. The core memory usage metric is named "core_jvm_memory_rss_bytes" and "core_jvm_memory_virtual_bytes", each of which represents the main process' resident set and virtual size in bytes, respectively.

| Name                             | Setting                 | Description                                           |
| -------------------------------- | ----------------------- |-------------------------------------------------------|
| `core_process_cpu_usage`         | metrics.enabled         | Fractional usage of CPUs, ranging from 0.0-1.0        |
| `core_jvm_memory_rss_bytes`      | metrics.enabled         | RSS bytes in use by JVM                               |
| `core_jvm_memory_virtual_bytes`  | metrics.enabled         | Virtual bytes in use by JVM                           |

## Thread Saturation
The thread saturation metric tracks the number of actively running worker threads that are serving REST requests. This measurement targets any invocation of the V1 or V2 REST API. The thread saturation is calculated by dividing the active number of requests by the total number of possible worker threads, as set by the "tomcat.connector.maxThreads" value.

| Name                             | Setting                            | Description                                              |
| -------------------------------- | ---------------------------------- |----------------------------------------------------------|
| `thread_saturation`              | metrics.threadSaturationThreshold  | Fractional usage of worker threads ranging from 0.0-1.0  |

## SLI
The Service Level Indicator (SLI) metric calculates REST request completion times. The times are statistically approximated from sampled timing distributions over a rolling window and should be treated as estimates rather than exact timings. The calculated response times help to indicate whether the overall service is handling a certain percentile of requests, as set by the `sli.percentile`, within a specified time frame, as set by the threshold value, `sli.thresholdMs`. 

The "sli" metric is a reactive measure of events that have recently taken place, as defined by the rolling window settings, namely "sli.rollingWindowsMs" and "sli.rollingWindowSize". The SLI metric encompasses a time frame that ranges from the "rollingWindowMs" multiplied by the "rollingWindowSize". For example, a rolling window time of 10,000ms with a window size of 3 defines a 30 second time range that includes 3 10-second buckets - with each bucket getting aged out in 10-second increments as time passes. 

The SLI metrics which are returned from a query are named `http_requests_sli_seconds`, `http_requests_sli_count` and `http_requests_sli_seconds_max`. The first represents the number of seconds for the percentile setting, as set by the "metrics.sli.percentile" in the "values.yaml" file. The percentile tracks the overall response time of a percentage of the REST requests. The count is the total number of requests processed and the max is the cumulative value in seconds for all requests from the start of the service. As a result, the "count" and "total" metrics are relative to the beginning of the deployment while the "seconds" is relative to a rolling window of time.

The following settings enable the SLI to be customized according to each deployment's time processing requirements.

| Setting                       | Description                                                         |
| ----------------------------- |---------------------------------------------------------------------|
| metrics.sli.percentile        | Percentile of all requests that are getting timed                   |
| metrics.sli.thresholdMs       | Target time that percentile of requests should not exceed           |
| metrics.sli.rollingWindowMs   | Rolling window slice in milliseconds of monitored HTTP requests     |
| metrics.sli.rollingWindowSize | Number of rolling window slices to keep                             |

## Readiness
The readiness metric incorporates three areas of processing performance, which includes SLI, thread saturation and CPU usage. As long as each metric falls within its defined threshold, then the service is reported as ready to service new requests. 

The query URI, "/tx-rest/metrics?readiness=true", will return a JSON formated response, as illustrated below. A "200" status code is returned if all metrics are within their respective thresholds or "503" otherwise.

The following content is an example of what the readiness query would return when the deployment is idle:
``` { .yaml }
{
    "ready": true,
    "timestamp": "2026-05-18T22:05:33.367Z",
    "checks": {
        "sli": {
            "status": "INFO",
            "message": "Pending calculation: 1335189 count for 95th percentile returned 0.000"
        },
        "threads": {
            "status": "PASS",
            "active": 0,
            "max": 20,
            "utilizationPercent": 0.0,
            "utilizationRawValue": 0.0,
            "thresholdPercent": 95.0,
            "percentOfThreshold": 0.0
        },
        "cpu": {
            "status": "PASS",
            "utilizationPercent": 0.0,
            "utilizationRawValue": 4.9095704473674345E-5,
            "thresholdPercent": 95.0,
            "percentOfThreshold": 0.01
        }
    }
}
```

Here is an example of the returned content when the readiness probe queries the service under heavy load:
``` { .yaml }
{
    "ready": true,
    "timestamp": "2026-05-18T22:09:52.285Z",
    "checks": {
        "sli": {
            "status": "PASS",
            "percentile": 0.95,
            "percentileValueMs": 13.615104,
            "thresholdMs": 4000.0,
            "percentOfThreshold": 0.34
        },
        "threads": {
            "status": "PASS",
            "active": 19,
            "max": 20,
            "utilizationPercent": 95.0,
            "utilizationRawValue": 0.95,
            "thresholdPercent": 95.0,
            "percentOfThreshold": 100.0
        },
        "cpu": {
            "status": "PASS",
            "utilizationPercent": 48.13,
            "utilizationRawValue": 0.4813016544851085,
            "thresholdPercent": 95.0,
            "percentOfThreshold": 50.66
        }
    }
}
```
Once the "percentOfThreshold" exceeds 100 for any given "sli", "threads" or "cpu" metric, then the "ready" field value is marked "false" and a "503" service unavailable HTTP status code is returned.

## Histogram
The histogram metric defines the main buckets of time that help quantify the duration of REST responses across both map and flow execution requests. A separate set of times is kept for each combination of HTTP endpoint, status code and method. These times can be scraped by a Prometheus service so that throughput and quantile measurements can be queried over a time range for monitoring and alerting purposes.

Here is a snippet of the histogram metrics that can be viewed and scraped by Prometheus for display purposes:
```
http_requests_duration_seconds_bucket{application="tx-rest",method="PUT",status="200",uri="/tx-rest/v1/itx/maps/direct/OneInOneOut",le="0.005",} 1473101.0
http_requests_duration_seconds_bucket{application="tx-rest",method="PUT",status="200",uri="/tx-rest/v1/itx/maps/direct/OneInOneOut",le="0.005592405",} 1483102.0
http_requests_duration_seconds_bucket{application="tx-rest",method="PUT",status="200",uri="/tx-rest/v1/itx/maps/direct/OneInOneOut",le="0.006990506",} 1497295.0
http_requests_duration_seconds_bucket{application="tx-rest",method="PUT",status="200",uri="/tx-rest/v1/itx/maps/direct/OneInOneOut",le="0.008388607",} 1503520.0
http_requests_duration_seconds_bucket{application="tx-rest",method="PUT",status="200",uri="/tx-rest/v1/itx/maps/direct/OneInOneOut",le="0.009786708",} 1506267.0
http_requests_duration_seconds_bucket{application="tx-rest",method="PUT",status="200",uri="/tx-rest/v1/itx/maps/direct/OneInOneOut",le="0.01",} 1506532.0
```
Note that the "le" stands for less than or equal to a specified time in seconds. These values are based on the ones set in the "values.yaml" file as shown below.

| Setting                       | Description                                                                  |
| ----------------------------- |------------------------------------------------------------------------------|
| metrics.sli.buckets           | Buckets of time in milliseconds that contain counts of HTTP response times   |

While the buckets are specified in milliseconds, the actual metric gets returned as seconds. So fast map and flow completion times will show up in fractions of a second. The metric monotonically increases over time. By constant scraping from a Prometheus probe, the throughput rate of any specific map or flow execution request can be charted over time and aggregated across multiple pods.  

## JVM
Various kinds of JVM metrics can be enabled for monitoring purposes. These metrics describe details about thread states, memory usage, and GC activity. The relevant "values.yaml" settings that can activate these metrics are listed below.

| Setting                       | Description                     |
| ----------------------------- |---------------------------------|
| metrics.jvm.memory            | JVM memory metrics              |
| metrics.jvm.gc                | JVM Garbage Collection metrics  |
| metrics.jvm.threads           | JVM thread metrics              |

A snippet of the thread states is shown below when the system was inactive:
```
# HELP jvm_threads_states_threads The current number of threads
# TYPE jvm_threads_states_threads gauge
jvm_threads_states_threads{application="tx-rest",state="new",} 0.0
jvm_threads_states_threads{application="tx-rest",state="runnable",} 20.0
jvm_threads_states_threads{application="tx-rest",state="terminated",} 0.0
jvm_threads_states_threads{application="tx-rest",state="timed-waiting",} 25.0
jvm_threads_states_threads{application="tx-rest",state="waiting",} 2.0
jvm_threads_states_threads{application="tx-rest",state="blocked",} 0.0
```

## System
By enabling the system metric, details about CPU counts, load and usage are available. The system metrics are activated by the following setting in the "values.yaml" file:

| Setting                       | Description                     |
| ----------------------------- |---------------------------------|
| metrics.system.cpu            | System CPU metrics              |

Here is a view of these metrics under heavy load in a deployment with a 4 CPU limit and on a 8-core worker node: 

```
# HELP system_cpu_count The number of processors available to the Java virtual machine
# TYPE system_cpu_count gauge
system_cpu_count{application="tx-rest",} 4.0
# HELP system_load_average_1m The sum of the number of runnable entities queued to available processors and the number of runnable entities running on the available processors averaged over a period of time
# TYPE system_load_average_1m gauge
system_load_average_1m{application="tx-rest",} 4.52
# HELP system_cpu_usage The "recent cpu usage" of the system the application is running in
# TYPE system_cpu_usage gauge
system_cpu_usage{application="tx-rest",} 0.5406478473361528
```
In the above case, the CPU count references the deployment limit of 4, however, the CPU usage percentage reflects the system node's 8-core limit. Be aware that the cpu count metric is relative to the deployment while the others reference the total cores available on the host system. So a load average of 12 on a 8-core host would indicate about 1.5 REST runnable tasks per core, which in turn indicates high contention for available cpu resources on the worker node. 

# Monitoring
The monitoring section highlights how map processing and system wide metrics can be readily queried and regularly monitored. The metrics are tracked for readiness reporting, resource availability and pod scaling purposes. The [Starter](#starter) deployment will serve as a simple example of how the metrics can get defined, generated and queried.

As an optional exercise, the Prometheus stack can get deployed on the Minikube cluster to illustrate how metrics are graphically charted over time. 
1. Configure Helm repository.\
`> helm repo add prometheus-community https://prometheus-community.github.io/helm-charts`\
`> helm repo update`
2. Deploy Prometheus stack.\
`> helm install monitoring prometheus-community/kube-prometheus-stack --namespace monitoring --create-namespace`
3. Verify Prometheus deployment.<sup>1</sup>\
`> helm list -n monitoring`

Another optional exercise enables transport security during installation.<sup>2</sup> By using mytls_values.yaml, mymtls_values.yaml, or mymtlsbypass_values.yaml, REST API invocations are secured over HTTPS. The mymtls_values.yaml configuration additionally requires client certificate authentication (mTLS). The mymtlsbypass_values.yaml configuration demonstrates how map execution requests can be secured with TLS while allowing metrics API requests to continue using HTTP. This approach enables lightweight readiness probes access to the metrics endpoint while maintaining TLS protection for V1 and V2 API requests. Simply append the Helm install command with the `-f mytls_values.yaml` option (or an equivalent values file) to activate the desired security configuration.      

<sup>1</sup> Minimum chart version: kube-prometheus-stack-84.0.1, App version: v0.90.1\
<sup>2</sup> Expose the "itx-rest-server" certificate before installation by running the [kubectl create secret](#certificates) command.

## Install
1. Change to the ITX-RS Helm chart "metrics" directory and use the "mymetrics_values.yaml" file, which contains the following content:
``` { .yaml }
# Metric thresholds for readiness and monitoring
# Readiness = thread saturation, cpu usage and sli percentile thresholds
# Prometheus = histogram buckets and process-related metrics
metrics:
  # Metrics enabled for scraping and monitoring
  enabled: true
  # Readiness probe checks the 3 gauges
  readinessProbeEnabled: true
  # Thread saturation gauge
  threadSaturationThreshold: 0.95
  # CPU usage gauge
  cpuUsageThreshold: 0.95
  sli:
    # Readiness gauge percentile
    percentile: 0.95
    # Readiness gauge threshold 
    thresholdMs: 4000
    # Readiness gauge sample count
    minSampleCount: 50
    # Readiness gauge over a 30 second window
    rollingWindowMs: 10000
    rollingWindowSize: 3
    # Histogram cardinality = bucket-count X http-uri X http-status-code X http-method 
    # Choose bucket values based on expected map completion times 
    buckets: "1,3,5,7,10,13,16,20,25,30,40,50,60,75,100,250,500,750,1000,2000"
  # JVM processing details
  jvm:
    memory: true
    gc: true
    threads: true
  # System processing details
  system:
    cpu: true
```
2. Install ITX-RS.\
`> helm install v11 ..\.. -f ..\starter\mystarter_values.yaml -f ..\storage\nopvc.yaml -f mymetric_values.yaml`
3. Activate Prometheus scraping.<sup>1</sup>\
`> kubectl apply -f service_monitor.yaml`

<sup>1</sup> Optional, depending if Prometheus stack is deployed. 

## Deploy
1. List the name of the ITX-RS container.\
`> kubectl get pods -l app.kubernetes.io/component=rest-v1`
2. Copy the sample map to the container's default map location.\
`> kubectl cp ..\starter\OneInOneOut.mmc < name-from-prior-step >:/data/maps`
3. Expose the ITX-RS REST API port.\
`> kubectl port-forward service/v11-ibm-itx-rs-prod-rest-v1 9080:8080`

## Execute
1. Make a REST API request to execute the map.\
`> curl.exe -X PUT -d "hello itx-rs!" "http://localhost:9080/tx-rest/v1/itx/maps/direct/OneInOneOut?input=1&output=1"`
2. Examine the [readiness](#readiness) metric.\
`> curl.exe "http://localhost:9080/tx-rest/metrics?readiness=true"`
3. Query all [metrics](#metrics).\
`> curl.exe "http://localhost:9080/tx-rest/metrics"`

## Prometheus
If the Prometheus stack was successfully deployed, any of the metrics can be queried and graphically charted by Prometheus. A constant stream of service requests need to get generated for the graphing to become illustrative.

Follow the steps below to simulate a constant load of service requests:
1. Attach to the container.\
`> kubectl exec -it <pod-name> -- bash`
2. Setup environment.\
`> . /opt/runtime/setup`
3. Simulate load.<sup>1</sup>\
`> while true; do seq 1 10 | xargs -P 10 -I {} curl -s -X PUT -d "hello world {}!" "http://localhost:8080/tx-rest/v1/itx/maps/direct/OneInOneOut?input=1&output=1"; sleep 0.25; done`

<sup>1</sup> Paste the bash shell script into the terminal session. Exit by entering CTRL-C.

### GUI
The Prometheus Graphical User Inteface (GUI) illustrates how to graph the scraped metrics. The following set of steps will activate the Prometheus "Query" window.

1. Expose Prometheus port.\
`> kubectl port-forward svc/monitoring-kube-prometheus-prometheus 9090:9090 -n monitoring`
2. Open console to confirm that the service is getting monitored.\
`> http://localhost:9090/query`
3. Confirm service with query.<sup>1</sup>\
`up{service="v11-ibm-itx-rs-prod-rest-v1"}`

<sup>1</sup>A value of 1 is returned for a healthy scrape. 

### Queries

The following basic queries can be entered and executed after you select the "Graph" tab from the "Query" screen.

1. Map requests per second over the last minute or 30 seconds.\
`rate(http_requests_duration_seconds_count[1m])`\
`rate(http_requests_duration_seconds_count{uri="/tx-rest/v1/itx/maps/direct/OneInOneOut"}[30s])`\
2. Latency over the last minute.\
`histogram_quantile(0.95, sum(rate(http_requests_duration_seconds_bucket{uri="/tx-rest/v1/itx/maps/direct/OneInOneOut"}[1m])) by (le,uri))`
3. Total map requests.<sup>1</sup>\
`http_requests_duration_seconds_count{uri="/tx-rest/v1/itx/maps/direct/OneInOneOut"}`

<sup>1</sup> The "Table" tab plainly displays the exact numerical value change after each scrape.  

## Cleanup
1. Delete service monitor.\
`> kubectl delete -f service_monitor.yaml`
2. Uninstall ITX-RS.\
`> helm uninstall v11`

# Istio
This section demonstrates integration with an Istio service mesh. The deployment seamlessly integrates with Istio to provide service-to-service communication within a Kubernetes-based service mesh environment. When the "istioV1.enabled" or "istio.enabled" setting in the "values.yaml" is true, the deployed pods are automatically injected with an Istio sidecar proxy, which transparently intercepts inbound and outbound traffic. This enables consistent routing, load balancing, observability metrics, and security enforcement across the service mesh without requiring any application-specific changes. 

Before proceeding with this section, the Prometheus stack needs to be installed for telemetry purposes. See the [Monitoring](#monitoring) section for installation details.

## Prerequisite
The Istio service mesh is installed by following the steps below. 
1. Navigate to the Istio download site.\
`https://istio.io/latest/docs/setup/getting-started/#download`
2. Download the software by selecting the "Istio release" link and then clicking on the appropriate zip file.\
`e.g. https://github.com/istio/istio/releases/download/<latest-version>/istio-<latest-version>-win.zip`<sup>1</sup>
3. Unzip the software into a local directory and run the install from the 'bin' directory.\
`> istioctl install --set profile=demo -y`

<sup>1</sup> Minimum version: 1.29.2 or above

Verify the Istio system installation.
1. Confirm version of Istio.\
`istioctl version`
2. Query status of Istio control plane.\
`kubectl get pods -n istio-system`
3. Confirm "istiod" container and ingress/egress gateways are in "Running" state.
```
NAME                                    READY   STATUS 
istio-egressgateway-5bd755b557-5n8h9    1/1     Running
istio-ingressgateway-6497cf79bc-9llfq   1/1     Running
istiod-75659b6dd4-fr58n                 1/1     Running
```

Define a new project or namespace with Istio injection.
1. Create the namespace.\
`> kubectl create namespace istio-test`
2. Label the namespace.\
`> kubectl label namespace istio-test istio-injection=enabled`
3. Confirm the namesapce label configuration in the namespace.\
`> kubectl get namespace istio-test --show-labels`

## Install
1. Change to the ITX-RS Helm chart "istio" directory and use the "myistio_values.yaml" file, which contains the following content:
``` { .yaml }
istioV1:
  enabled: true
```
2. Install ITX-RS and Istio Prometheus monitoring.\
`> helm install v11 ..\.. -f ..\starter\mystarter_values.yaml -f ..\storage\nopvc.yaml -f myistio_values.yaml`\
`> kubectl apply -f pod_monitor.yaml`
3. Confirm that two out of two containers are listed as ready.\
`> kubectl get pods -n istio-test` 

## Deploy
1. List the name of the ITX-RS container.\
`> kubectl get pods -l app.kubernetes.io/component=rest-v1 -n istio-test`
2. Copy the sample map to the container's default map location.\
`> kubectl cp ..\starter\OneInOneOut.mmc -n istio-test < name-from-prior-step >:/data/maps`
3. Expose the Prometheus port.\
`> kubectl port-forward svc/monitoring-kube-prometheus-prometheus 9090:9090 -n monitoring`

## Execute
1. Attach to the pod.\
`> kubectl exec -it -n istio-test <pod-name-from-Deploy-step-1> -- bash`
2. Make a REST API request.\
`> curl -X PUT -d "hello itx-rs!" "http://v11-ibm-itx-rs-prod-rest-v1.istio-test.svc.cluster.local/tx-rest/v1/itx/maps/direct/OneInOneOut?input=1&output=1"`
3. Open Prometheus dashboard to confirm that the istio service mesh is getting monitored.\
`http://localhost:9090/query`

## Queries

The following Prometheus queries illustrate Istio telemetry metrics that are scraped and exposed by the service mesh.

1. Count requests.<sup>1</sup>\
`sum(istio_request_duration_milliseconds_count{destination_service="v11-ibm-itx-rs-prod-rest-v1.istio-test.svc.cluster.local",reporter="destination"})`
2. Get p95 latency.<sup>2</sup>\
`histogram_quantile(0.95, sum(rate(istio_request_duration_milliseconds_bucket{destination_service="v11-ibm-itx-rs-prod-rest-v1.istio-test.svc.cluster.local",reporter="destination"}[1m])) by (le))`
3. Calculate rate of requests per second.<sup>3</sup>\
`sum(rate(istio_requests_total{destination_service="v11-ibm-itx-rs-prod-rest-v1.istio-test.svc.cluster.local",reporter="destination"}[1m]))`

<sup>1</sup>The count value starts at 1 and increments after each new request is made in Step 2 of Execute.\
<sup>2</sup>Simulate traffic with this command:\
`> while true; do seq 1 10 | xargs -P 10 -I {} curl -s -X PUT -d "hello world {}!" "http://v11-ibm-itx-rs-prod-rest-v1.istio-test.svc.cluster.local/tx-rest/v1/itx/maps/direct/OneInOneOut?input=1&output=1"; sleep 1; echo "Enter CTRL-C to stop."; done`\
<sup>3</sup>Select the "Graph" tab.

## Cleanup
1. Delete pod monitor.\
`> kubectl delete -f pod_monitor.yaml`
2. Uninstall ITX-RS.\
`> helm uninstall v11`
