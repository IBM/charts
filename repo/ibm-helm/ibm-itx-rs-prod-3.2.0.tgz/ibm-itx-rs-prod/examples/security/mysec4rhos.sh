#!/bin/sh
# 
# Example TLS Certificate generation for Red Hat OpenShift (RHOS)
#
# This script runs IBM GSKit commands to generate certificates and
# "openssl" commands to extract the relevant keys. One self-signed
# certificate authority is created as "my_ca.cer", which in turn 
# signs a server and client certificate generation request.
#
# The server certificate uses two Subject Alternative Names, "SAN",
# so that the REST service can be authenticated externally and 
# internally to the RHOS cluster.
#
# The script is intended to run within the ITX-RS container, which 
# contains the relevant utilities for certificate generation.
#
# The generated certificates are as follows:
# my_ca.cer     - CA certificate
# my_ca.cer     - CA key
# my_server.cer - Server certificate
# my_server.cer - Server key
# my_client.cer - Client certificate
# my_client.cer - Client key
# 
# Steps:
# 1. Edit the 'Parameters' section in this file, as follows:
#    relname  = use your release name from 'helm install <your-release-name>'
#    projname = RHOS project name, see namespace field in this command: 
#               'oc config view --minify'
#    rhdns    = DNS suffix, as per the HOST column of the 'oc get routes'
#               command. Retrieve your DNS suffix from the HOST name format: 
#               <release-name>-<route-name>-<project-name>.<your-DNS-suffix>
# 2. Copy the edited file to the ITX-RS container.
#    e.g. 
#    oc cp mysec4rhop.sh <podname>:/tmp/mysec4rhos.sh
# 3. Generate the certificates and keys
#    e.g.
#    . /tmp/mysec4rhos.sh
# 4. Retrieve the CA, Server and Client certificates and keys.
#    e.g.
#    oc cp <podname>:/tmp/my_ca.cer my_ca.cer
#    oc cp <podname>:/tmp/my_server.cer my_server.cer
#    oc cp <podname>:/tmp/my_client.cer my_client.cer
#    oc cp <podname>:/tmp/my_ca.key my_ca.key
#    oc cp <podname>:/tmp/my_server.key my_server.key
#    oc cp <podname>:/tmp/my_client.key my_client.key
#

# Initialize
source /opt/runtime/setup

# Parameters
export relname=v11sec
export projname=cshdev
export rhdns=apps.os4.actian.fans

# Password that is temporarily used during certificate generation.
export pswd=changeit

# SAN
export DNS1=$relname-ibm-itx-rs-prod-rest-route-$projname.$rhdns
export DNS2=$relname-ibm-itx-rs-prod-rest.$projname.svc.cluster.local

# Working directory
cd /tmp

# Generate certificates
gsk8capicmd_64 -keydb -create -db dtx_keys.p12 -pw $pswd -type pkcs12 -stash
gsk8capicmd_64 -cert -create -db dtx_keys.p12 -stashed -type pkcs12 -label "my_ca"  -size 2048 -x509version 3 -ca true -expire 3650 -sigalg SHA512WithRSA -dn CN=mysigner,O=HCLTech,OU=Engineering,L=Boca,ST=FL,C=US
gsk8capicmd_64 -cert -extract -db dtx_keys.p12 -stashed -type pkcs12 -label "my_ca"  -target my_ca.cer
gsk8capicmd_64 -certreq -create -db dtx_keys.p12 -stashed -type pkcs12 -label "my_server" -target my_server_req.arm -size 2048 -sigalg SHA512WithRSA -dn CN=myserver,O=HCLTech,OU=Engineering,L=Boca,ST=FL,C=US -ca false -san_dnsname "$DNS1, $DNS2"
gsk8capicmd_64 -certreq -create -db dtx_keys.p12 -stashed -type pkcs12 -label "my_client" -target my_client_req.arm -size 2048 -sigalg SHA512WithRSA -dn CN=myclient,O=HCLTech,OU=Engineering,L=Boca,ST=FL,C=US -ca false
gsk8capicmd_64 -cert -sign -db dtx_keys.p12 -stashed -type pkcs12 -label "my_ca" -target my_server.cer -file my_server_req.arm -sigalg SHA512WithRSA -expire 3650 -sernum 1 -ca false -san_dnsname "$DNS1, $DNS2"
gsk8capicmd_64 -cert -sign -db dtx_keys.p12 -stashed -type pkcs12 -label "my_ca" -target my_client.cer -file my_client_req.arm -sigalg SHA512WithRSA -expire 3650 -sernum 2 -ca false 
gsk8capicmd_64 -cert -receive -file my_server.cer  -db dtx_keys.p12 -stashed -type pkcs12
gsk8capicmd_64 -cert -receive -file my_client.cer  -db dtx_keys.p12 -stashed -type pkcs12

# Get private keys of CA, server and client
openssl pkcs12 -info -in dtx_keys.p12 -passin pass:$pswd -noenc -nocerts --nomacver  > mykeys.txt
awk '$2=="my_ca"     {on=1} $1~/BEGIN$/ && on==1 {prn=1} prn==1 {print} $1~/END$/ && on==1 {on=0;prn=0}' mykeys.txt > my_ca.key
awk '$2=="my_server" {on=1} $1~/BEGIN$/ && on==1 {prn=1} prn==1 {print} $1~/END$/ && on==1 {on=0;prn=0}' mykeys.txt > my_server.key
awk '$2=="my_client" {on=1} $1~/BEGIN$/ && on==1 {prn=1} prn==1 {print} $1~/END$/ && on==1 {on=0;prn=0}' mykeys.txt > my_client.key

# Cleanup non-PEM files
rm dtx_keys* my_*arm mykeys.txt
