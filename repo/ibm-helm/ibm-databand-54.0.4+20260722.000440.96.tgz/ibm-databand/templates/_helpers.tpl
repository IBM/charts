{{- define "ibm-databand.validate" -}}
{{- $operatorNs := required "global.operatorNamespace is required" .Values.global.operatorNamespace -}}
{{- $instanceNs := required "global.instanceNamespace is required" .Values.global.instanceNamespace -}}
{{- end -}}

{{- define "ibm-databand.addonId" -}}
{{- .Values.ibmDataband.addonId | default "databand" -}}
{{- end -}}

{{- define "ibm-databand.serviceAccountName" -}}
{{- .Values.ibmDataband.serviceAccount.name | default .Values.ibmDataband.serviceAccountName -}}
{{- end -}}

{{- define "ibm-databand.operatorName" -}}
{{- .Values.ibmDataband.operatorName | default (printf "%s-operator" .Chart.Name) -}}
{{- end -}}

{{- define "ibm-databand.operatorImage" -}}
{{- $arch := required "global.arch is required" .Values.global.arch -}}
{{- $digest := index .Values.ibmDataband.operatorImageDigest $arch -}}
{{- if $digest -}}
{{- printf "%s/%s@%s" .Values.global.imagePullPrefix .Values.ibmDataband.operatorImageName $digest -}}
{{- else -}}
{{- $tag := .Values.ibmDataband.operatorImageTag -}}
{{- if not $tag -}}
{{- fail (printf "Missing ibmDataband.operatorImageDigest.%s (or set ibmDataband.operatorImageTag for dev/testing)" $arch) -}}
{{- end -}}
{{- printf "%s/%s:%s" .Values.global.imagePullPrefix .Values.ibmDataband.operatorImageName $tag -}}
{{- end -}}
{{- end -}}

{{- define "ibm-databand.watchNamespaces" -}}
{{- $watchNamespaces := concat (list .Values.global.operatorNamespace .Values.global.instanceNamespace) (.Values.global.tetheredNamespaces | default (list)) | compact | uniq -}}
{{- toYaml $watchNamespaces -}}
{{- end -}}

{{- define "ibm-databand.standardLabels" -}}
app.kubernetes.io/managed-by: kustomize
app.kubernetes.io/name: ibm-databand-operator
control-plane: controller-manager
icpdsupport/addOnId: {{ include "ibm-databand.addonId" . }}
icpdsupport/app: databand
icpdsupport/module: databand
component-id: {{ .Chart.Name }}
{{- end -}}

{{- define "ibm-databand.charts" -}}
{{- $charts := .Values.ibmDataband.charts | default dict -}}
{{- if $charts -}}
  {{- $databand := $charts.databand | default dict -}}
  {{- $values := $databand.values | default dict -}}
  {{- $global := $values.global | default dict -}}

  {{- /* Merge global imagePullPrefix and imagePullSecret */ -}}
  {{- $_ := set $global "imagePullPrefix" .Values.global.imagePullPrefix -}}
  {{- $_ := set $global "imagePullSecret" .Values.global.imagePullSecret -}}
  {{- $_ := set $values "global" $global -}}
  {{- $_ := set $databand "values" $values -}}
  {{- $_ := set $charts "databand" $databand -}}
{{- end -}}
{{- toYaml $charts -}}
{{- end -}}
