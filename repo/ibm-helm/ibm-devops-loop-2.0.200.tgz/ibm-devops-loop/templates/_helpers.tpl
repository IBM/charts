{{/*
Check required global values
*/}}
{{- define "devops-platform.checkRequiredValues" -}}
{{- if not .Values.license -}}
    {{- fail "The license agreement must be accepted by setting .Values.license=true." -}}
{{- end -}}
{{- if not .Values.global.domain -}}
    {{- fail "A valid .Values.global.domain is required." -}}
{{- end -}}
{{- if not .Values.global.passwordSeed -}}
    {{- fail "A valid .Values.global.passwordSeed is required." -}}
{{- end -}}


{{- $selfSigned := false -}}
{{- if hasKey .Values "ibm-devops-prod" -}}
{{- $selfSigned = index .Values "ibm-devops-prod" "ingress" "cert" "selfSigned" -}}
{{- end -}}

{{- if hasKey .Values "hcl-devops" -}}
{{- $selfSigned = index .Values "hcl-devops" "ingress" "cert" "selfSigned" -}}
{{- end -}}

{{- if $selfSigned }}
  {{- $certSecretName := .Values.global.ibmCertSecretName | default .Values.global.hclCertSecretName }}
  {{- if not $certSecretName }}
    {{- fail "A valid .Values.global.ibmCertSecretName or .Values.global.hclCertSecretName is required if selfSigned is enabled." -}}
  {{- end }}
{{- end }}

{{- if semverCompare "<3.17" .Capabilities.HelmVersion.Version }}
    {{- fail "Helm CLI version 3.17 or later is required." -}}
{{- end }}

{{- end -}}

{{/*
Return OAuth scopes as JSON, supporting either:
- global.oauth (grouped by audience + scope suffixes)
- global.scopes (legacy flat list)

EXAMPLE INPUT (global.oauth):
global:
  oauth:
    - audience: "api"
      scopes: ["read", "write"]
      description: "API access"
      mapAudience: true
      audienceClients: ["web-app"]
    - audience: "admin"
      # No scopes specified - defaults to ["all"]

EXAMPLE OUTPUT:
[
  {
    "name": "api:read",
    "description": "API access",
    "mapAudience": true,
    "audience": "api",
    "audienceClients": ["web-app"]
  },
  {
    "name": "api:write",
    "description": "API access",
    "mapAudience": true,
    "audience": "api",
    "audienceClients": ["web-app"]
  },
  {
    "name": "admin:all",
    "description": "admin:all",
    "mapAudience": false,
    "audience": "admin"
  }
]

LEGACY INPUT (global.scopes):
global:
  scopes:
    - "users:all"
    - name: "orders:read"
      description: "Read orders"
      mapAudience: true
      audience: "orders"
*/}}
{{- define "devops-platform.oauthScopesJson" -}}
{{- $scopes := list -}}
{{- $oauthEntries := .Values.global.oauth | default .Values.oauth -}}
{{- if $oauthEntries -}}
{{- range $entry := $oauthEntries -}}
{{- if kindIs "map" $entry -}}
{{- $audience := $entry.audience | default "" -}}
{{- $entryScopes := list "all" -}}
{{- if hasKey $entry "scopes" -}}
{{- if kindIs "slice" $entry.scopes -}}
{{- $entryScopes = $entry.scopes -}}
{{- else if $entry.scopes -}}
{{- $entryScopes = list $entry.scopes -}}
{{- end -}}
{{- end -}}
{{- range $scopeSuffix := $entryScopes -}}
{{- if and $audience $scopeSuffix -}}
{{- $name := printf "%s:%s" $audience $scopeSuffix -}}
{{- $scope := dict "name" $name "description" ($entry.description | default $name) "mapAudience" ($entry.mapAudience | default false) "audience" $audience -}}
{{- if hasKey $entry "audienceClients" -}}
{{- $_ := set $scope "audienceClients" ($entry.audienceClients | default (list)) -}}
{{- end -}}
{{- $scopes = append $scopes $scope -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- else -}}
{{- $legacyScopes := .Values.global.scopes | default (list) -}}
{{- range $legacy := $legacyScopes -}}
{{- if kindIs "map" $legacy -}}
{{- $scopes = append $scopes $legacy -}}
{{- else if kindIs "string" $legacy -}}
{{- $legacyAudience := regexReplaceAll ":all$" $legacy "" -}}
{{- $scopes = append $scopes (dict "name" $legacy "description" $legacy "mapAudience" false "audience" $legacyAudience) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- toJson $scopes -}}
{{- end -}}

{{/*
Generate global API/MCP scopes for client optional scope assignment
Usage: {{ include "devops-platform.apiScopes" (dict "context" . "format" "json") }}
Format options: "json" (default) outputs ["scope1","scope2"], "space" outputs space-separated list
Behavior: derived from global scope definitions, including any scopes starting with api:* or mcp:* (not per-client filtering)
NOTE: Shared-helper candidate. Move to a library chart for subchart reuse.
*/}}
{{- define "devops-platform.apiScopes" -}}
{{- $context := .context -}}
{{- $format := .format | default "json" -}}
{{- $scopes := list -}}
{{- $scopeDefs := include "devops-platform.oauthScopesJson" $context | fromJsonArray -}}
{{- range $scope := $scopeDefs -}}
{{- $scopeName := "" -}}
{{- if and (kindIs "map" $scope) (hasKey $scope "name") -}}
{{- $scopeName = index $scope "name" | default "" -}}
{{- else if kindIs "string" $scope -}}
{{- $scopeName = $scope -}}
{{- end -}}
{{- if and $scopeName (or (hasPrefix "api:" $scopeName) (hasPrefix "mcp:" $scopeName)) -}}
{{- $scopes = append $scopes $scopeName -}}
{{- end -}}
{{- end -}}

{{- if $scopes -}}
{{- if eq $format "space" -}}
{{- join " " $scopes -}}
{{- else -}}
{{- $first := true -}}
[{{- range $scope := $scopes -}}
{{- if not $first }},{{- end -}}
"{{ $scope }}"
{{- $first = false -}}
{{- end }}]
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Generate client-level audience mapper configuration for a specific client ID
This generates the CLIENT_AUDIENCE_SCOPES environment variable value
Usage: {{ include "devops-platform.clientAudienceScopes" (dict "clientId" "mcp:loop" "context" .) }}
Output format: "scope1->audience1,scope2->audience2" or empty string if no mappers needed
Behavior:
- For API scopes (`api:*`), derive audience mapping targets from `scope.audienceClients`
NOTE: Shared-helper candidate. Move to a library chart for subchart reuse.
*/}}
{{- define "devops-platform.clientAudienceScopes" -}}
{{- $clientId := .clientId -}}
{{- $context := .context -}}
{{- $mappings := list -}}
{{- $scopeDefs := include "devops-platform.oauthScopesJson" $context | fromJsonArray -}}
{{- range $scope := $scopeDefs -}}
{{- $scopeName := "" -}}
{{- if and (kindIs "map" $scope) (hasKey $scope "name") -}}
{{- $scopeName = index $scope "name" | default "" -}}
{{- else if kindIs "string" $scope -}}
{{- $scopeName = $scope -}}
{{- end -}}
{{- if not $scopeName -}}
{{- continue -}}
{{- end -}}
{{- $audience := "" -}}
{{- if and (kindIs "map" $scope) (hasKey $scope "audience") -}}
{{- $audience = index $scope "audience" | default "" -}}
{{- else -}}
{{- $audience = regexReplaceAll ":all$" $scopeName "" -}}
{{- end -}}
{{- $isApiScope := hasPrefix "api:" $scopeName -}}
{{- if not $isApiScope -}}
{{- $isApiScope = hasPrefix "api:" $audience -}}
{{- end -}}
{{- $audienceClients := list -}}
{{- if and (kindIs "map" $scope) (hasKey $scope "audienceClients") -}}
{{- $audienceClients = index $scope "audienceClients" | default (list) -}}
{{- end -}}
{{- if and $isApiScope (has $clientId $audienceClients) $audience -}}
{{- $mappings = append $mappings (printf "%s->%s" $scopeName $audience) -}}
{{- end -}}
{{- end -}}
{{- if $mappings -}}
{{- join "," $mappings -}}
{{- end -}}
{{- end -}}

{{/*
Return all global scope names as a JSON array string
Usage: {{ include "devops-platform.scopeNamesJson" . }}
NOTE: Shared-helper candidate. Move to a library chart for subchart reuse.
*/}}
{{- define "devops-platform.scopeNamesJson" -}}
{{- $names := list -}}
{{- $scopeDefs := include "devops-platform.oauthScopesJson" . | fromJsonArray -}}
{{- range $scope := $scopeDefs -}}
{{- if and (kindIs "map" $scope) (hasKey $scope "name") -}}
{{- $names = append $names (index $scope "name") -}}
{{- else if kindIs "string" $scope -}}
{{- $names = append $names $scope -}}
{{- end -}}
{{- end -}}
{{- toJson $names -}}
{{- end -}}

{{/*
Generate the list of default scopes from global.defaultScopes
Usage: {{ include "devops-platform.defaultClientScopes" (dict "context" . "format" "json") }}
Format options: "json" (default) outputs ["scope1","scope2"], "space" outputs space-separated list
Behavior: derived from global defaultScopes definitions (not per-client filtering)
NOTE: Shared-helper candidate. Move to a library chart for subchart reuse.
*/}}
{{- define "devops-platform.defaultClientScopes" -}}
{{- $context := .context -}}
{{- $format := .format | default "json" -}}
{{- $scopes := list -}}
{{- range $scope := $context.Values.global.defaultScopes -}}
{{- if $scope.name -}}
{{- $scopes = append $scopes $scope.name -}}
{{- end -}}
{{- end -}}
{{- if $scopes -}}
{{- if eq $format "space" -}}
{{- join " " $scopes -}}
{{- else -}}
{{- $first := true -}}
[{{- range $scope := $scopes -}}
{{- if not $first }},{{- end -}}
"{{ $scope }}"
{{- $first = false -}}
{{- end }}]
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Return AnalyticsAI configuration override settings from values.

Source:
- analyticsai.configOverrides

Returns a JSON object so templates can consume via `fromJson`.
*/}}
{{- define "devops-platform.analyticsaiConfigOverridesJson" -}}
{{- $analyticsai := .Values.analyticsai | default dict -}}
{{- $configOverrides := $analyticsai.configOverrides | default dict -}}
{{- toJson $configOverrides -}}
{{- end -}}

{{/*
Expand the name of the chart.
*/}}
{{- define "devops-platform.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name with intentional redundancy.
*/}}
{{- define "devops-platform.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "devops-platform.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create component full name for use in metadata resource names that cannot exceed 63 characters
*/}}
{{- define "devops-platform.componentFullname" -}}
{{- $context := .context | default . -}}
{{- if not .componentName -}}
{{- fail "No componentName provided. componentName is required." -}}
{{- end -}}
{{- $componentName := .componentName -}}
{{- $fullName := include "devops-platform.fullname" $context -}}
{{- $componentFullName := printf "%s-%s" $fullName $componentName | trimSuffix "-" }}
{{- if gt (len $componentFullName) 63 -}}
{{- fail "Component name is too long.  The full name cannot be greater than 63 characters" -}}
{{- else -}}
{{- print $componentFullName -}}
{{- end -}}
{{- end }}


{{/*
Apply common labels
*/}}
{{- define "devops-platform.labels" -}}
{{- $context := .context -}}
{{- $componentName := .componentName -}}
{{- with $context -}}
helm.sh/chart: {{ include "devops-platform.chart" $context }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/component: {{ $componentName }}
{{ include "devops-platform.selectorLabels" (dict "componentName" $componentName "context" $context) }}
{{- end }}
{{- end }}


{{/*
Apply common selector labels
*/}}
{{- define "devops-platform.selectorLabels" -}}
{{- $componentName := .componentName -}}
{{- with .context -}}
app.kubernetes.io/name: {{ include "devops-platform.componentFullname" (dict "componentName" $componentName "context" .) }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "devops-platform.serviceAccountName" -}}
{{- $context := .context -}}
{{- $componentName := .componentName -}}
{{- with $context -}}
{{- if (index .Values $componentName "serviceAccount" "create") }}
{{- default (printf "%s-%s" (include "devops-platform.fullname" $context) $componentName) (index .Values $componentName "serviceAccount" "name") }}
{{- else }}
{{- default "default" (index .Values $componentName "serviceAccount" "name") }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Image to use for a component
*/}}
{{- define "devops-platform.image" -}}
{{- $context := .context -}}
{{- $componentName := .componentName -}}
{{- with $context -}}
{{- $imageRegistry := .Values.platform.imageRegistry | default .Values.global.imageRegistry -}}
{{- if empty $imageRegistry -}}
{{- $brand := .Values.global.platform.brand -}}
{{- $imageRegistry = ternary "cp.icr.io/cp" "hclcr.io/devops-automation" (eq $brand "IBM") -}}
{{- else if eq $imageRegistry "hclcr.io" -}}
{{- $imageRegistry = "hclcr.io/devops-automation" -}}
{{- end -}}
{{- $image := index .Values $componentName "image" -}}
{{- if index .Values $componentName "localImage" | default false -}}
{{- printf "%s" (trimPrefix "/" $image) -}}
{{- else -}}
{{- printf "%s/%s" (trimSuffix "/" $imageRegistry) (trimPrefix "/" $image) -}}
{{- end }}
{{- end }}
{{- end }}


{{- define "devops-platform.container.keycloak-init-sh-env" }}
{{- if or (.Values.global.privateCaBundleSecretName) (index .Values "ibm-devops-prod" "ingress" "cert" "selfSigned") }}
- name: CAFILE
  value: '--cacert /usr/share/pki/ingress/ca.crt'
{{- end }}
- name: INGRESS_DOMAIN
  value: '{{ .Values.global.domain }}'
- name: KEYCLOAK_URL
  value: https://$(INGRESS_DOMAIN){{ index .Values "ibm-devops-prod" "keycloak" "path" }}
- name: REALM_NAME
  value: {{ index .Values "ibm-devops-prod" "keycloak" "realm" }}
- name: ADMIN_NAME
  value: {{ index .Values "ibm-devops-prod" "keycloak" "username" }}
- name: ADMIN_PASS
  valueFrom:
    secretKeyRef:
      key: password
      name: '{{ .Release.Name }}-keycloak'
- name: OPTIONAL_SCOPES
  value: '{{ include "devops-platform.scopeNamesJson" . }}'
{{- end }}

{{- define "devops-platform.container.keycloak-init-sh-trailer" }}
image: {{ include "devops-platform.image" (dict "componentName" "init" "context" .) }}
workingDir: /usr/local/bin
imagePullPolicy: {{ .Values.init.imagePullPolicy | default .Values.platform.imagePullPolicy }}
{{- with .Values.platform.securityContext }}
securityContext:
{{ toYaml . | indent 2 }}
{{- end }}
volumeMounts:
{{- if or (.Values.global.privateCaBundleSecretName) (index .Values "ibm-devops-prod" "ingress" "cert" "selfSigned") }}
- name: ingress
  mountPath: /usr/share/pki/ingress
{{- end }}
- name: keycloak-sh
  mountPath: /usr/local/bin
- name: tmp
  mountPath: /tmp
{{- end }}

{{/*
Keycloak API client init container (bearer-only, no direct access grants).
Expects a dict with keys: name, clientId, baseUrl, clientAudienceScopes, context (root $).
*/}}
{{- define "devops-platform.initContainer.keycloak-api-client" }}
- name: keycloak-{{ .name }}-api-client-create
  command:
  - sh
  - -ec
  - |
    ./wait.sh $KEYCLOAK_URL/realms/$REALM_NAME/
    ./client-create.sh
  env:
{{ include "devops-platform.container.keycloak-init-sh-env" .context | nindent 4 }}
    - name: CLIENT_ID
      value: {{ .clientId }}
    - name: BASE_URL
      value: '{{ .baseUrl }}'
    - name: STANDARD_FLOW
      value: 'false'
    {{- if .clientAudienceScopes }}
    - name: CLIENT_AUDIENCE_SCOPES
      value: '{{ .clientAudienceScopes }}'
    {{- end }}
{{ include "devops-platform.container.keycloak-init-sh-trailer" .context | nindent 2 }}
{{- end }}

{{/*
Keycloak MCP client init container (token-exchange enabled, with client secret).
Expects a dict with keys: name, clientId, baseUrl, clientSecret, clientAudienceScopes, context (root $).
*/}}
{{- define "devops-platform.initContainer.keycloak-mcp-client" }}
- name: keycloak-{{ .name }}-mcp-client-create
  command:
  - sh
  - -ec
  - |
    ./wait.sh $KEYCLOAK_URL/realms/$REALM_NAME/
    ./client-create.sh
  env:
{{ include "devops-platform.container.keycloak-init-sh-env" .context | nindent 4 }}
    - name: CLIENT_ID
      value: {{ .clientId }}
    - name: BASE_URL
      value: '{{ .baseUrl }}'
    - name: STANDARD_TOKEN_EXCHANGE
      value: 'true'
    - name: CLIENT_SECRET
      valueFrom:
        secretKeyRef:
          key: oauth-client-secret
          name: '{{ .clientSecret }}'
    {{- if .clientAudienceScopes }}
    - name: CLIENT_AUDIENCE_SCOPES
      value: '{{ .clientAudienceScopes }}'
    {{- end }}
{{ include "devops-platform.container.keycloak-init-sh-trailer" .context | nindent 2 }}
{{- end }}

{{- define "devops-platform.volumes.keycloak-init-sh" }}
        - name: keycloak-sh
          configMap:
            defaultMode: 365
            name: {{ include "devops-platform.componentFullname" (dict "componentName" "keycloak-init-sh" "context" .) }}
        - name: tmp
          emptyDir: {}
{{- end }}

{{- define "devops-platform.volumes.tmp-volume" }}
        - name: tmp-volume
          emptyDir: {}
{{- end }}

{{- define "devops-platform.path.trust-store" -}}
/opt/java/openjdk/lib/security/cacerts
{{- end }}

{{- define "devops-platform.initContainers.trust-store" }}
{{- $isSelfSigned := index .Values "ibm-devops-prod" "ingress" "cert" "selfSigned" }}
{{- $image := .image }}
{{- $myDict := dict "image" $image -}}
{{- $_ := set $myDict "path" (include "devops-platform.path.trust-store" .) -}}
{{- if .Values.global.privateCaBundleSecretName }}
  {{- $_ := set $myDict "ingressSecret" .Values.global.privateCaBundleSecretName -}}
{{- else if eq .Chart.Name "hcl-devops-loop" }}
  {{- $_ := set $myDict "ingressSecret" (ternary .Values.global.hclCertSecretName "" $isSelfSigned) -}}
{{- else }}
  {{- $_ := set $myDict "ingressSecret" (ternary .Values.global.ibmCertSecretName "" $isSelfSigned) -}}
{{- end }}
{{- $_ := set $myDict "resources" .Values.init.resources -}}
{{- $_ := set $myDict "extras" .extras -}}
{{- include "devops-platform.cacerts.container" $myDict | indent 6 }}
{{- end }}

{{- define "devops-platform.volumes.trust-store" }}
{{- $isSelfSigned := index .Values "ibm-devops-prod" "ingress" "cert" "selfSigned" }}
{{- $myDict := dict -}}
{{- if .Values.global.privateCaBundleSecretName }}
  {{- $_ := set $myDict "ingressSecret" .Values.global.privateCaBundleSecretName -}}
{{- else if eq .Chart.Name "hcl-devops-loop" }}
  {{- $_ := set $myDict "ingressSecret" (ternary .Values.global.hclCertSecretName "" $isSelfSigned) -}}
{{- else }}
  {{- $_ := set $myDict "ingressSecret" (ternary .Values.global.ibmCertSecretName "" $isSelfSigned) -}}
{{- end }}
{{- include "devops-platform.cacerts.volumes" $myDict | indent 6 }}
{{- end }}


{{- define "devops-platform.volumeMounts.trust-store" }}
{{- include "devops-platform.cacerts.volumeMount" (dict "path" (include "devops-platform.path.trust-store" .)) | indent 12 }}
{{- end }}


{{- define "devops-platform.cacerts.container" }}
- command:
  - /bin/bash
  - -ec
  - |
    import() {
      keytool -import -noprompt -alias "$1" -keystore /var/pki/java/combined/cacerts -storepass changeit -file "$2"
    }

    cp -L -f "{{ .path }}" /var/pki/java/combined/cacerts
    ls -l /var/pki/java/combined/cacerts
    chmod +w /var/pki/java/combined/cacerts; echo "chmod"
    ls -l /var/pki/java/combined/cacerts

    if [ -s /usr/share/pki/ingress/ca.crt ]; then
      import ingress /usr/share/pki/ingress/ca.crt
    fi
{{- range .extras }}
    if [ -s /usr/share/pki/{{ . }}/ca.crt ]; then
      import {{ . }} /usr/share/pki/{{ . }}/ca.crt
    fi
{{- end }}
    keytool -list -keystore "{{ .path }}" -storepass changeit | grep entries
    keytool -list -keystore /var/pki/java/combined/cacerts -storepass changeit
  image: '{{ .image }}'
  imagePullPolicy: IfNotPresent
  name: trust-store
{{- if .resources }}
  resources: {{- toYaml .resources | nindent 4 }}
{{- end }}
  securityContext:
    privileged: false
    readOnlyRootFilesystem: true
    allowPrivilegeEscalation: false
    capabilities:
      drop:
      - ALL
    seccompProfile:
      type: RuntimeDefault
  volumeMounts:
  - name: trust-store
    mountPath: /var/pki/java/combined
  - name: tmp-volume
    mountPath: /tmp
{{- if .ingressSecret }}
  - name: ingress
    mountPath: /usr/share/pki/ingress
    readOnly: true
{{- end }}
{{- range .extras }}
  - name: {{ . }}
    mountPath: /usr/share/pki/{{ . }}
    readOnly: true
{{- end }}
{{- end }}


{{- define "devops-platform.volumes.update-ca-trust" }}
{{- if .Values.global.privateCaBundleSecretName }}
  - name: update-ca-trust
    emptyDir: {}
{{- end }}
{{- end }}

{{- define "devops-platform.volumeMounts.update-ca-trust" }}
{{- if .Values.global.privateCaBundleSecretName }}
  - name: update-ca-trust
    mountPath: /etc/pki/ca-trust
{{- end }}
{{- end }}

{{- define "devops-platform.cacerts.volumes" }}
  - name: trust-store
    emptyDir: {}
{{- if .ingressSecret }}
  - name: ingress
    secret:
      secretName: '{{ .ingressSecret }}'
{{- end }}
{{- end }}

{{- define "devops-platform.cacerts.volumeMount" }}
- name: trust-store
  mountPath: {{ .path }}
  readOnly: true
  subPath: cacerts
- name: tmp-volume
  mountPath: /tmp
{{- end }}

{{/*
Generate a password for postgresql
*/}}
{{- define "devops-platform.postgresql-password" -}}
{{- $context := .context -}}
{{- $pwseed := .passwordSeed -}}
{{- $cname := .componentName -}}
{{- $epwd := .existingPwd -}}
{{- with $context -}}
{{- if $epwd }}
{{- print $epwd }}
{{- else }}
{{- printf "%s%s-%s" (default .Release.Name $pwseed) $cname "postgresql" | sha256sum }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Generate a base64 password for postgresql
*/}}
{{- define "devops-platform.postgresql-password-b64" -}}
{{ printf "  %s: %s" "postgresql-password" ( include "devops-platform.postgresql-password" . | b64enc | quote )}}
{{- end }}

{{- define "devops-platform.initContainers.pg-isready" }}
      - command:
        - sh
        - -c
        - |
          until pg_isready -U {{ .dbName }} -h {{ include "devops-platform.postgresql.hostname" . }} -p {{ include "devops-platform.postgresql.port" . }} \
            && echo "SELECT FROM pg_database WHERE datname = '{{ .dbName }}'" |
               psql -h {{ include "devops-platform.postgresql.hostname" . }} -p {{ include "devops-platform.postgresql.port" . }} -U {{ .dbName }} |
               grep '1 row'
          do
            sleep 15
          done
        env:
        - name: PGPASSWORD
          valueFrom:
            secretKeyRef:
              key: postgresql-password
              name: '{{ .secret | default (include "devops-platform.componentFullname" (dict "componentName" .dbName "context" .)) }}'
{{- if index .Values "ibm-devops-prod" "postgresql" "external" }}
        - name: PGSSLMODE
          value: '{{ tpl (index .Values "ibm-devops-prod" "postgresql" "params" "sslmode") . }}'
        - name: PGSSLROOTCERT
          value: /usr/share/pki/ingress/ca.crt
{{- end }}
{{- if .Values.global.imageRegistry }}
        image: '{{ .Values.global.imageRegistry | clean }}/{{ regexReplaceAll (index .Values "ibm-devops-prod" "imageRepoRegex") (index .Values "ibm-devops-prod" "postgresql" "image") (index .Values "ibm-devops-prod" "imageRepoRepl") }}'
{{- else }}
        image: '{{ (default (index .Values "ibm-devops-prod" "imageRegistry") (index .Values "ibm-devops-prod" "postgresql" "registry")) }}/{{ regexReplaceAll (index .Values "ibm-devops-prod" "imageRepoRegex") (index .Values "ibm-devops-prod" "postgresql" "image") (index .Values "ibm-devops-prod" "imageRepoRepl") }}'
{{- end }}
        imagePullPolicy: IfNotPresent
        name: pg-isready
{{- if index .Values "ibm-devops-prod" "init" "resources" }}
        resources: {{- toYaml (index .Values "ibm-devops-prod" "init" "resources") | nindent 10 }}
{{- end }}
        securityContext:
{{- if index .Values "ibm-devops-prod" "containerSecurityContext" }}
{{ toYaml (index .Values "ibm-devops-prod" "containerSecurityContext") | nindent 10 }}
{{- end }}
{{- if index .Values "ibm-devops-prod" "postgresql" "external" }}
        volumeMounts:
        - name: pg-ca-bundle
          mountPath: /usr/share/pki/ingress
{{- end }}
{{- end }}

{{- define "devops-platform.initContainers.liquibase-update" }}
      - command:
        - /liquibase/liquibase-update.sh
        env:
        - name: URL
          value: "jdbc:postgresql://{{ include "devops-platform.postgresql.hostname" . }}:{{ include "devops-platform.postgresql.port" . }}/{{ .dbName }}{{ include "devops-platform.postgresql.jdbcTrailer" . }}"
        - name: USERNAME
          value: "{{ .dbName }}"
        - name: PASSWORD
          valueFrom:
            secretKeyRef:
              key: postgresql-password
              name: '{{ .secret | default (include "devops-platform.componentFullname" (dict "componentName" .svc "context" .)) }}'
        image: {{ .image }}
        imagePullPolicy: IfNotPresent
        name: liquibase-update
{{- if index .Values "ibm-devops-prod" "init" "liquibase" "resources" }}
        resources: {{- toYaml (index .Values "ibm-devops-prod" "init" "liquibase" "resources") | nindent 10 }}
{{- end }}
        securityContext:
{{- if index .Values "ibm-devops-prod" "containerSecurityContext" }}
{{ toYaml (index .Values "ibm-devops-prod" "containerSecurityContext") | nindent 10 }}
{{- end }}
{{- end }}

{{- define "devops-platform.initContainers.keycloak-add-realm-roles-groups" }}
- name: add-realm-roles-groups
  command:
  - sh
  - -ec
  - |
    ./wait.sh $KEYCLOAK_URL/realms/master/
    ./add-realm-roles-groups.sh
  env:
{{ include "devops-platform.container.keycloak-init-sh-env" . | nindent 4 }}
    - name: REALM_ROLES
      value: {{ index .Values "keycloak" "realmRoles" | quote }}
    - name: REALM_GROUPS
      value: {{ index .Values "keycloak" "realmGroups" | quote }}
{{ include "devops-platform.container.keycloak-init-sh-trailer" . | nindent 2 }}
{{- end }}

{{/*
Specify env variable holding contents of global.privateCaBundleSecretName,
if specified.
*/}}
{{- define "devops-platform.container.private-ca-env" }}
{{- if .Values.global.privateCaBundleSecretName }}
{{- $privateCaCert := index (lookup "v1" "Secret" .Release.Namespace .Values.global.privateCaBundleSecretName).data "ca.crt" -}}
{{- if $privateCaCert }}
  - name: LOOP_PRIVATE_CACERT
    value: {{ $privateCaCert | b64dec | quote }}
{{- end }}
{{- end }}
{{- end }}

{{- define "devops-platform.initContainers.update-ca-trust" }}
{{- $image := .image }}
- name: update-ca-trust
  command:
  - sh
  - -ec
  - |
    if [ ! -z "${LOOP_PRIVATE_CACERT}" ] ; then
      echo "${LOOP_PRIVATE_CACERT}" > /etc/pki/ca-trust/source/anchors/LoopPrivateCA.pem
      update-ca-trust
      cp -a /etc/pki/ca-trust/* /tmp/ca-trust
    fi
  env:
{{ include "devops-platform.container.private-ca-env" . | nindent 2 }}
  image: {{ $image }}
  imagePullPolicy: {{ .Values.init.imagePullPolicy | default .Values.platform.imagePullPolicy }}
  securityContext:
    capabilities:
      drop:
      - ALL
    readOnlyRootFilesystem: false
    allowPrivilegeEscalation: false
    seccompProfile:
      type: RuntimeDefault
  volumeMounts:
    - name: update-ca-trust
      mountPath: /tmp/ca-trust
{{- end }}

{{/* Return the correctly-scoped Velocity-plugin image.
     .plugin   – string: plan | control | test | deploy
     .context  – the main dot (.)
*/}}
{{- define "devops-platform.velocityPluginImage" -}}
{{- $ctx      := .context -}}            {{/* Keep access to .Values via $ctx */}}
{{- $plugin   := .plugin  -}}            {{/* Which plugin (plan/control/test/deploy) */}}
{{- $registry := trimSuffix "/" $ctx.Values.global.externalImageRegistry -}}
{{- $image    := index $ctx.Values.platform.velocity.plugins $plugin "image" -}}
{{- if $registry }}
  {{- /* Keep only the final path segment of the image (name:tag) */ -}}
  {{- $repoParts := splitList "/" $image -}}
  {{- $nameTag   := last $repoParts -}}
  {{- printf "%s/%s" $registry $nameTag | clean -}}
{{- else }}
  {{- $image -}}
{{- end -}}
{{- end -}}


{{/*
Return the brand of the install
*/}}
{{- define "devops-platform.brand" -}}
{{- if eq .Chart.Name "ibm-devops-loop" -}}
IBM
{{- else -}}
HCL
{{- end -}}
{{- end }}

{{/*
Define environment variables wiring in product info such as base URLs
*/}}
{{- define "devops-platform.container.product-env" }}
            - name: AUTOMATION_LEARNINGSERVER_URL
              value: 'https://{{ .Values.global.domain }}{{ index .Values "learning-webserver" "ingress" "path" }}'
            - name: AUTOMATION_TENANT_URL
              value: 'https://{{ .Values.global.domain }}{{ index .Values "tenant" "ingress" "path" }}'
            - name: AUTOMATION_LOOP_URL
              value: 'https://{{ .Values.global.domain }}{{ index .Values "loop" "ingress" "path" }}'
            - name: AUTOMATION_PRODUCT_LOOP_GENIE_URL
              value: 'https://{{ .Values.global.domain }}{{ index .Values "analyticsai" "ingress" "path" }}{{ index .Values "analyticsai" "apiPath" }}'
            - name: AUTOMATION_MCPLOOP_URL
              value: 'https://{{ .Values.global.domain }}{{ index .Values "mcploop" "ingress" "path" }}'
            - name: AUTOMATION_LICENSING_URL
              value: 'https://{{ .Values.global.domain }}{{ index .Values "licensing" "ingress" "path" }}'
            - name: AUTOMATION_PRODUCT_TEST_ENABLED
              value: 'true'
            - name: AUTOMATION_PRODUCT_TEST_URL
              value: 'https://{{ .Values.global.domain }}{{ index .Values "ibm-devops-prod" "ingress" "path" }}'
            - name: AUTOMATION_PRODUCT_PLAN_ENABLED
              value: '{{ .Values.platform.plan.enabled }}'
            - name: AUTOMATION_PRODUCT_PLAN_URL
              value: 'https://{{ .Values.global.domain }}{{ index .Values "ibm-devopsplan-prod" "ingress" "path" }}'
            - name: AUTOMATION_PRODUCT_CONTROL_ENABLED
              value: '{{ .Values.platform.plan.enabled }}'
            - name: AUTOMATION_PRODUCT_CONTROL_URL
              value: 'https://{{ .Values.global.domain }}{{ index .Values "ibm-devopsplan-prod" "control" "ingress" "path" }}'
            - name: AUTOMATION_PRODUCT_VELOCITY_ENABLED
              value: '{{ .Values.platform.velocity.enabled }}'
            - name: AUTOMATION_PRODUCT_VELOCITY_URL
              value: 'https://{{ .Values.global.domain }}{{ index .Values "ibm-ucv-prod" "ingress" "path" }}'
            - name: AUTOMATION_PRODUCT_MEASURE_URL
              value: 'https://{{ .Values.global.domain }}{{ index .Values "ibm-ucv-prod" "ingress" "path" }}/valuestreams'
            - name: AUTOMATION_PRODUCT_RELEASE_URL
              value: 'https://{{ .Values.global.domain }}{{ index .Values "ibm-ucv-prod" "ingress" "path" }}/releases'
            - name: AUTOMATION_PRODUCT_DEPLOY_ENABLED
              value: '{{ .Values.platform.deploy.enabled }}'
            - name: AUTOMATION_PRODUCT_DEPLOY_URL
              value: 'https://{{ .Values.global.domain }}{{ index .Values "ibm-ucd-prod" "ingress" "path" }}'
            - name: AUTOMATION_PRODUCT_BUILD_URL
              value: 'https://{{ .Values.global.domain }}{{ index .Values "ibm-devops-build" "ingress" "path" }}'
            - name: AUTOMATION_PRODUCT_CODE_ENABLED
              value: '{{ .Values.platform.code.enabled }}'
            - name: AUTOMATION_PRODUCT_CODE_URL
              value: 'https://{{ .Values.global.domain }}{{ index .Values "ibm-devopscode" "ingress" "path" }}'
            - name: AUTOMATION_PRODUCT_BUILD_ENABLED
              value: '{{ .Values.platform.build.enabled }}'
{{- end }}

{{/* OpenTelemetry sidecar helpers. */}}
{{/*
Check if OpenTelemetry observability is enabled.
Usage: {{ include "otel.enabled" . }}
*/}}
{{- define "otel.enabled" -}}
{{- $enabled := false -}}
{{- if hasKey .Values "global" -}}
  {{- if hasKey .Values.global "observability" -}}
    {{- if hasKey .Values.global.observability "enabled" -}}
      {{- $enabled = .Values.global.observability.enabled -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- $enabled -}}
{{- end -}}
{{/*
Return whether the OTel sidecar is enabled for the current context.
Uses .Values.otel.sidecar.enabled if present, otherwise global.observability.sidecar.enabled.
*/}}
{{- define "otel.sidecar.enabled" -}}
{{- $localOtel := .Values.otel | default dict -}}
{{- $localSidecar := $localOtel.sidecar | default dict -}}
{{- if hasKey $localSidecar "enabled" -}}
  {{- ternary "true" "false" $localSidecar.enabled -}}
{{- else -}}
  {{- $globalEnabled := false -}}
  {{- if hasKey .Values "global" -}}
    {{- if hasKey .Values.global "observability" -}}
      {{- if hasKey .Values.global.observability "sidecar" -}}
        {{- if hasKey .Values.global.observability.sidecar "enabled" -}}
          {{- $globalEnabled = .Values.global.observability.sidecar.enabled -}}
        {{- end -}}
      {{- end -}}
    {{- end -}}
  {{- end -}}
  {{- $globalEnabled -}}
{{- end -}}
{{- end -}}

{{/*
Return whether the OTel sidecar is enabled for a named service.
{{ include "otel.sidecar.enabledFor" (dict "serviceName" "tenant" "context" .) }}
*/}}
{{- define "otel.sidecar.enabledFor" -}}
{{- $ctx := .context -}}
{{- $svcName := .serviceName -}}
{{- $globalEnabled := (include "otel.sidecar.enabled" $ctx) -}}
{{- $result := $globalEnabled -}}
{{- if hasKey $ctx.Values $svcName -}}
  {{- $svcValues := index $ctx.Values $svcName | default dict -}}
  {{- if kindIs "map" $svcValues -}}
    {{- $svcOtel := $svcValues.otel | default dict -}}
    {{- $svcSidecar := $svcOtel.sidecar | default dict -}}
    {{- if hasKey $svcSidecar "enabled" -}}
      {{- $result = ternary "true" "false" $svcSidecar.enabled -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- $result -}}
{{- end -}}

{{/*
Return the OTLP endpoint for the current context.
{{ include "otel.endpoint" . }}
*/}}
{{- define "otel.endpoint" -}}
{{- if eq (include "otel.sidecar.enabled" .) "true" -}}
http://localhost:4318
{{- else -}}
http://{{ .Release.Name }}-otel-collector:4318
{{- end -}}
{{- end -}}

{{/*
Return the OTLP endpoint for a named service.
{{ include "otel.endpoint.forService" (dict "serviceName" "plan" "context" .) }}
*/}}
{{- define "otel.endpoint.forService" -}}
{{- if eq (include "otel.sidecar.enabledFor" .) "true" -}}
http://localhost:4318
{{- else -}}
http://{{ .context.Release.Name }}-otel-collector:4318
{{- end -}}
{{- end -}}

{{/*
Inject OTel environment variables for the current context.
{{ include "otel.env-vars" . | nindent 12 }}
*/}}
{{- define "otel.env-vars" -}}
- name: OTEL_EXPORTER_OTLP_ENDPOINT
  value: "{{ include "otel.endpoint" . }}"
- name: OTEL_TRACES_EXPORTER
  value: "otlp"
- name: OTEL_METRICS_EXPORTER
  value: "otlp"
- name: OTEL_LOGS_EXPORTER
  value: "otlp"
{{- if ne (include "otel.sidecar.enabled" .) "true" }}
- name: OTEL_BSP_MAX_QUEUE_SIZE
  value: "4096"
- name: OTEL_BSP_MAX_EXPORT_BATCH_SIZE
  value: "1024"
- name: OTEL_BSP_SCHEDULE_DELAY
  value: "1000"
{{- end }}
{{- end -}}

{{/*
Inject OTel environment variables for a named service.
{{ include "otel.env-vars.forService" (dict "serviceName" "plan" "context" .) | nindent 12 }}
*/}}
{{- define "otel.env-vars.forService" -}}
- name: OTEL_EXPORTER_OTLP_ENDPOINT
  value: "{{ include "otel.endpoint.forService" . }}"
- name: OTEL_TRACES_EXPORTER
  value: "otlp"
- name: OTEL_METRICS_EXPORTER
  value: "otlp"
- name: OTEL_LOGS_EXPORTER
  value: "otlp"
{{- if ne (include "otel.sidecar.enabledFor" .) "true" }}
- name: OTEL_BSP_MAX_QUEUE_SIZE
  value: "4096"
- name: OTEL_BSP_MAX_EXPORT_BATCH_SIZE
  value: "1024"
- name: OTEL_BSP_SCHEDULE_DELAY
  value: "1000"
{{- end }}
{{- end -}}


{{- define "otel.sidecar._container" -}}
- name: otel-sidecar
  image: "otel/opentelemetry-collector-contrib:0.93.0"
  imagePullPolicy: IfNotPresent
  command: ["/otelcol-contrib"]
  args: ["--config=/conf/sidecar.yaml"]
  resources:
    limits:
      cpu: 100m
      memory: 200Mi
    requests:
      cpu: 50m
      memory: 100Mi
  volumeMounts:
    - name: otel-sidecar-conf
      mountPath: /conf
{{- end -}}
{{/*
Render the OTel sidecar container for the current context.
{{ include "otel.sidecar.conditional" . | nindent 8 }}
*/}}
{{- define "otel.sidecar.conditional" -}}
{{- if eq (include "otel.sidecar.enabled" .) "true" -}}
{{- include "otel.sidecar._container" . -}}
{{- end -}}
{{- end -}}

{{/*
Render the OTel sidecar container for a named service.
{{ include "otel.sidecar.conditionalFor" (dict "serviceName" "plan" "context" .) | nindent 8 }}
*/}}
{{- define "otel.sidecar.conditionalFor" -}}
{{- if eq (include "otel.sidecar.enabledFor" .) "true" -}}
{{- include "otel.sidecar._container" . -}}
{{- end -}}
{{- end -}}


{{- define "otel.sidecar._volume" -}}
- name: otel-sidecar-conf
  configMap:
    name: {{ .context.Release.Name }}-{{ .serviceName }}-otel-sidecar
{{- end -}}
{{/*
Render the OTel sidecar ConfigMap volume for the current context.
{{ include "otel.sidecar.volume" (dict "serviceName" "control" "context" .) | nindent 8 }}
*/}}
{{- define "otel.sidecar.volume" -}}
{{- if eq (include "otel.sidecar.enabled" .context) "true" -}}
{{- include "otel.sidecar._volume" . -}}
{{- end -}}
{{- end -}}

{{/*
Render the OTel sidecar ConfigMap volume for a named service.
{{ include "otel.sidecar.volumeFor" (dict "serviceName" "plan" "context" .) | nindent 8 }}
*/}}
{{- define "otel.sidecar.volumeFor" -}}
{{- if eq (include "otel.sidecar.enabledFor" .) "true" -}}
{{- include "otel.sidecar._volume" . -}}
{{- end -}}
{{- end -}}


{{- define "otel.sidecar.configmap._body" -}}
apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ .context.Release.Name }}-{{ .serviceName }}-otel-sidecar
  labels:
    app.kubernetes.io/name: {{ .serviceName }}
    app.kubernetes.io/instance: {{ .context.Release.Name }}
data:
  sidecar.yaml: |
    receivers:
      otlp:
        protocols:
          grpc:
            endpoint: 0.0.0.0:4317
          http:
            endpoint: 0.0.0.0:4318
    processors:
      batch:
        timeout: 1s
      resource:
        attributes:
          - key: service.name
            value: "{{ .serviceName }}"
            action: upsert
    exporters:
      otlp/dataprepper:
        endpoint: "{{ .context.Release.Name }}-otel-collector:4317"
        tls:
          insecure: true
    service:
      pipelines:
        traces:
          receivers: [otlp]
          processors: [resource, batch]
          exporters: [otlp/dataprepper]
        logs:
          receivers: [otlp]
          processors: [resource, batch]
          exporters: [otlp/dataprepper]
        metrics:
          receivers: [otlp]
          processors: [resource, batch]
          exporters: [otlp/dataprepper]
{{- end -}}
{{/*
Render the OTel sidecar ConfigMap for the current context.
{{ include "otel.sidecar.configmap" (dict "serviceName" "control" "context" .) }}
*/}}
{{- define "otel.sidecar.configmap" -}}
{{- if and (eq (include "otel.enabled" .context) "true") (eq (include "otel.sidecar.enabled" .context) "true") -}}
{{- include "otel.sidecar.configmap._body" . -}}
{{- end -}}
{{- end -}}

{{/*
Render the OTel sidecar ConfigMap for a named service.
{{ include "otel.sidecar.configmapFor" (dict "serviceName" "plan" "context" .) }}
*/}}
{{- define "otel.sidecar.configmapFor" -}}
{{- if and (eq (include "otel.enabled" .context) "true") (eq (include "otel.sidecar.enabledFor" .) "true") -}}
{{- include "otel.sidecar.configmap._body" . -}}
{{- end -}}
{{- end -}}

{{/*
Return the PostgreSQL hostname.
When ibm-devops-prod.postgresql.external is true, uses the configured hostname.
Otherwise, defaults to the internal service name.
*/}}
{{- define "devops-platform.postgresql.hostname" -}}
{{- if index .Values "ibm-devops-prod" "postgresql" "external" -}}
{{- tpl (index .Values "ibm-devops-prod" "postgresql" "hostname") . -}}
{{- else -}}
{{- printf "%s-postgresql" .Release.Name -}}
{{- end -}}
{{- end -}}

{{/*
Return the PostgreSQL port.
*/}}
{{- define "devops-platform.postgresql.port" -}}
{{- tpl (index .Values "ibm-devops-prod" "postgresql" "port") . -}}
{{- end -}}

{{/*
Return JDBC URL trailer for SSL parameters when using external PostgreSQL.
Mirrors the testhub.postgresql.jdbcTrailer pattern from ibm-devops-prod.
*/}}
{{- define "devops-platform.postgresql.jdbcTrailer" -}}
{{- if index .Values "ibm-devops-prod" "postgresql" "external" -}}
{{- printf "?sslmode=%s&sslfactory=org.postgresql.ssl.DefaultJavaSSLFactory" (tpl (index .Values "ibm-devops-prod" "postgresql" "params" "sslmode") .) -}}
{{- end -}}
{{- end -}}