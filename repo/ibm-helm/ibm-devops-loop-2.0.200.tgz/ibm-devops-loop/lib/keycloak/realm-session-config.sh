#!/usr/bin/env bash
# HCL Technologies Confidential
# (C) Copyright HCL Technologies 2026. All Rights Reserved.
# The source code for this program is not published or otherwise divested
# of its trade secrets, irrespective of what has been deposited with the
# U.S. Copyright Office.

# Configures Keycloak realm session timeout settings via the Admin REST API.
# Required env vars: KEYCLOAK_URL, REALM_NAME, ADMIN_TOKEN (or ADMIN_NAME/ADMIN_PASS)
# Optional env vars: SSO_SESSION_IDLE_TIMEOUT, SSO_SESSION_MAX_LIFESPAN

set -euo pipefail

. "$(dirname "${BASH_SOURCE[0]}")/admin-token.sh"

SSO_SESSION_IDLE_TIMEOUT="${SSO_SESSION_IDLE_TIMEOUT:-86400}"
SSO_SESSION_MAX_LIFESPAN="${SSO_SESSION_MAX_LIFESPAN:-86400}"

echo "Configuring realm session timeouts for realm '$REALM_NAME'"
echo "  ssoSessionIdleTimeout: ${SSO_SESSION_IDLE_TIMEOUT}s"
echo "  ssoSessionMaxLifespan: ${SSO_SESSION_MAX_LIFESPAN}s"

PAYLOAD=$(cat <<EOF
{
  "ssoSessionIdleTimeout": ${SSO_SESSION_IDLE_TIMEOUT},
  "ssoSessionMaxLifespan": ${SSO_SESSION_MAX_LIFESPAN}
}
EOF
)

HTTP_RESPONSE=$(curl -s -w "\n%{http_code}" $CAFILE -X PUT \
  "$KEYCLOAK_URL/admin/realms/$REALM_NAME" \
  -H 'Content-Type: application/json' \
  -H "Authorization: Bearer $ADMIN_TOKEN" \
  -d "$PAYLOAD")

HTTP_CODE=$(echo "$HTTP_RESPONSE" | tail -n1)
BODY=$(echo "$HTTP_RESPONSE" | sed '$d')

if [ "$HTTP_CODE" -ge 300 ]; then
  echo "Failed to configure realm session timeouts. HTTP response code: $HTTP_CODE"
  echo "Response: $BODY"
  exit 1
fi

echo "Realm session timeouts configured successfully"
