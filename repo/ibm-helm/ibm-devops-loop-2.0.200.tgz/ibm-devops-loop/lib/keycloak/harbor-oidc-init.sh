#!/usr/bin/env bash
set -euo pipefail

if [ -z "${HARBOR_URL:-}" ]; then
  echo "HARBOR_URL is required for Harbor OIDC initialization"
  exit 1
fi

case "${HARBOR_URL}" in
  http://*|https://*)
    HARBOR_EXTERNAL_URL="${HARBOR_URL}"
    ;;
  *)
    HARBOR_EXTERNAL_URL="https://${HARBOR_URL}"
    ;;
esac

HARBOR_EXTERNAL_URL="${HARBOR_EXTERNAL_URL%/}"
HARBOR_OIDC_ADMIN_GROUP="${HARBOR_OIDC_ADMIN_GROUP:-harbor-admins}"
HARBOR_CORE_API_URL="${HARBOR_CORE_API_URL:-http://devops-loop-harbor-core}"

echo "Waiting for Harbor API..."

until curl -k -s "${HARBOR_CORE_API_URL}/api/v2.0/ping" >/dev/null; do
  echo "Harbor not ready..."
  sleep 10
done

echo "Ensuring Harbor admin group exists in Keycloak: ${HARBOR_OIDC_ADMIN_GROUP}"
export REALM_ROLES='[]'
export REALM_GROUPS="[{\"name\":\"${HARBOR_OIDC_ADMIN_GROUP}\"}]"

/usr/local/bin/add-realm-roles-groups.sh

echo "Ensuring Harbor Keycloak client URLs use: ${HARBOR_EXTERNAL_URL}"

export CLIENT_ID="harbor"
export CLIENT_SECRET="${HARBOR_OIDC_CLIENT_SECRET}"
export BASE_URL="${HARBOR_EXTERNAL_URL}"
export REDIRECT_URIS="[\"${HARBOR_EXTERNAL_URL}/*\"]"
export WEB_ORIGINS="[\"${HARBOR_EXTERNAL_URL}\"]"
export STANDARD_FLOW=true
export DIRECT_ACCESS_GRANTS=false
export FRONT_CHANNEL_LOGOUT_URL="${HARBOR_EXTERNAL_URL}/c/oidc/logout"

export DEFAULT_SCOPES='["groups"]'
export GROUPS_MAPPER_ENABLED=true

. /usr/local/bin/admin-token.sh
existing_client_id=$(. /usr/local/bin/client-id.sh)

if [ -n "${existing_client_id}" ]; then
  echo "Updating existing Harbor Keycloak client"
else
  echo "Creating Harbor Keycloak client"
fi

/usr/local/bin/client-create.sh

echo "Ensuring Harbor Keycloak client URL settings are current..."

. /usr/local/bin/admin-token.sh
harbor_client_id=$(. /usr/local/bin/client-id.sh)

if [ -z "${harbor_client_id}" ]; then
  echo "Unable to resolve Harbor Keycloak client after create/update"
  exit 1
fi

client_get_response=$(curl -s -w "\n%{http_code}" $CAFILE \
  "${KEYCLOAK_URL}/admin/realms/${REALM_NAME}/clients/${harbor_client_id}" \
  -H 'Accept: application/json' \
  -H "Authorization: Bearer ${ADMIN_TOKEN}")

client_get_code=$(echo "${client_get_response}" | tail -n1)
client_get_body=$(echo "${client_get_response}" | sed '$d')

if [ "${client_get_code}" -ge 300 ]; then
  echo "Failed to read Harbor Keycloak client. HTTP response code: ${client_get_code}"
  echo "Response: ${client_get_body}"
  exit 1
fi

client_update_payload=$(echo "${client_get_body}" | jq \
  --arg harbor_url "${HARBOR_EXTERNAL_URL}" \
  --arg client_secret "${HARBOR_OIDC_CLIENT_SECRET}" \
  '.rootUrl = $harbor_url
   | .baseUrl = $harbor_url
   | .adminUrl = $harbor_url
   | .secret = $client_secret
   | .redirectUris = [($harbor_url + "/*")]
   | .webOrigins = [$harbor_url]
   | .frontchannelLogout = true
   | .attributes = ((.attributes // {}) + {"frontchannel.logout.url": ($harbor_url + "/c/oidc/logout")})')

client_update_response=$(curl -s -w "\n%{http_code}" $CAFILE \
  -X PUT \
  "${KEYCLOAK_URL}/admin/realms/${REALM_NAME}/clients/${harbor_client_id}" \
  -H 'Content-Type: application/json' \
  -H "Authorization: Bearer ${ADMIN_TOKEN}" \
  -d "${client_update_payload}")

client_update_code=$(echo "${client_update_response}" | tail -n1)
client_update_body=$(echo "${client_update_response}" | sed '$d')

if [ "${client_update_code}" -ge 300 ]; then
  echo "Failed to update Harbor Keycloak client URLs. HTTP response code: ${client_update_code}"
  echo "Response: ${client_update_body}"
  exit 1
fi

echo "Harbor OIDC client ensured."

echo "Configuring Harbor OIDC through internal Harbor core service..."

config_code=$(curl -sk -o /tmp/harbor-oidc-config.out -w "%{http_code}" \
  -u "admin:${HARBOR_ADMIN_PASSWORD}" \
  -X PUT \
  "${HARBOR_CORE_API_URL}/api/v2.0/configurations" \
  -H "Content-Type: application/json" \
  -d "{
    \"auth_mode\":\"oidc_auth\",
    \"oidc_name\":\"Keycloak\",
    \"oidc_endpoint\":\"${HARBOR_OIDC_ENDPOINT:-${KEYCLOAK_URL}/realms/${REALM_NAME}}\",
    \"oidc_client_id\":\"harbor\",
    \"oidc_client_secret\":\"${HARBOR_OIDC_CLIENT_SECRET}\",
    \"oidc_scope\":\"openid,profile,email,groups\",
    \"oidc_groups_claim\":\"groups\",
    \"oidc_admin_group\":\"${HARBOR_OIDC_ADMIN_GROUP}\",
    \"oidc_verify_cert\":false,
    \"oidc_auto_onboard\":true,
    \"oidc_user_claim\":\"preferred_username\"
  }")

if [ "${config_code}" != "200" ]; then
  echo "Harbor OIDC configuration failed. HTTP code: ${config_code}"
  cat /tmp/harbor-oidc-config.out
  exit 1
fi

echo "Harbor OIDC configured."

verify_auth_mode=$(curl -sk \
  -u "admin:${HARBOR_ADMIN_PASSWORD}" \
  "${HARBOR_CORE_API_URL}/api/v2.0/configurations" \
  | sed -n 's/.*"auth_mode":{"editable":[^}]*"value":"\([^"]*\)".*/\1/p')

if [ "${verify_auth_mode}" != "oidc_auth" ]; then
  echo "Harbor auth mode verification failed. Current auth mode: ${verify_auth_mode}"
  exit 1
fi

echo "Harbor OIDC verification successful."
