#!/usr/bin/env bash
# HCL Technologies Confidential
# (C) Copyright HCL Technologies 2026. All Rights Reserved.
# The source code for this program is not published or otherwise divested
# of its trade secrets, irrespective of what has been deposited with the
# U.S. Copyright Office.

# MCP-focused Keycloak initialization for DevOps Loop applications.
# NOTE: Shared-script candidate. Move to a library chart for subchart reuse.

set -euo pipefail

ADMIN_TOKEN_CACHE_FILE="${ADMIN_TOKEN_CACHE_FILE:-/tmp/keycloak-admin-token.cache}"
CAFILE="${CAFILE:-}"
MANAGED_CLIENT_IDS="${MANAGED_CLIENT_IDS:-api:loop api:tenant api:licensing api:code}"
MANAGED_CLIENT_LOOKUP_RETRIES="${MANAGED_CLIENT_LOOKUP_RETRIES:-40}"
MANAGED_CLIENT_LOOKUP_INTERVAL_SECONDS="${MANAGED_CLIENT_LOOKUP_INTERVAL_SECONDS:-5}"

OAUTH_INIT_START_TS=$(date +%s)
echo "========================================"
echo "[oauth-init] Starting at $(date -u '+%Y-%m-%dT%H:%M:%SZ')"
echo "[oauth-init] MANAGED_CLIENT_IDS=$MANAGED_CLIENT_IDS"
echo "[oauth-init] MANAGED_CLIENT_LOOKUP_RETRIES=$MANAGED_CLIENT_LOOKUP_RETRIES  INTERVAL=${MANAGED_CLIENT_LOOKUP_INTERVAL_SECONDS}s"
echo "[oauth-init] KEYCLOAK_URL=${KEYCLOAK_URL:-<not set>}  REALM_NAME=${REALM_NAME:-<not set>}"
echo "========================================"

save_admin_token_cache() {
  if [ -n "${ADMIN_TOKEN:-}" ]; then
    umask 077
    printf '%s' "$ADMIN_TOKEN" > "$ADMIN_TOKEN_CACHE_FILE"
  fi
}

load_admin_token_cache() {
  if [ -f "$ADMIN_TOKEN_CACHE_FILE" ]; then
    local cached_token
    cached_token="$(cat "$ADMIN_TOKEN_CACHE_FILE" 2>/dev/null || true)"
    if [ -n "$cached_token" ]; then
      ADMIN_TOKEN="$cached_token"
    fi
  fi
}

refresh_admin_token() {
  . "$(dirname "${BASH_SOURCE[0]}")/admin-token.sh"
  save_admin_token_cache
}

if [ -z "${ADMIN_TOKEN:-}" ]; then
  refresh_admin_token
else
  save_admin_token_cache
fi

kc_request_once() {
  local method="$1"
  local url="$2"
  local payload="${3:-__NO_PAYLOAD__}"
  local include_headers="${4:-false}"

  load_admin_token_cache

  if [ "$include_headers" = "true" ]; then
    if [ "$payload" = "__NO_PAYLOAD__" ]; then
      curl -s -w "\n%{http_code}" -i $CAFILE -X "$method" "$url" \
        -H "Authorization: Bearer $ADMIN_TOKEN"
    else
      curl -s -w "\n%{http_code}" -i $CAFILE -X "$method" "$url" \
        -H 'Content-Type: application/json' \
        -H "Authorization: Bearer $ADMIN_TOKEN" \
        -d "$payload"
    fi
  else
    if [ "$payload" = "__NO_PAYLOAD__" ]; then
      curl -s -w "\n%{http_code}" $CAFILE -X "$method" "$url" \
        -H "Authorization: Bearer $ADMIN_TOKEN"
    else
      curl -s -w "\n%{http_code}" $CAFILE -X "$method" "$url" \
        -H 'Content-Type: application/json' \
        -H "Authorization: Bearer $ADMIN_TOKEN" \
        -d "$payload"
    fi
  fi
}

kc_request_with_retry() {
  local method="$1"
  local url="$2"
  local payload="${3:-__NO_PAYLOAD__}"
  local include_headers="${4:-false}"

  local response http_code
  response=$(kc_request_once "$method" "$url" "$payload" "$include_headers")
  http_code=$(echo "$response" | tail -n1)

  if [ "$http_code" -eq 401 ]; then
    echo "Received 401 for $method $url; refreshing admin token and retrying once" >&2
    refresh_admin_token
    response=$(kc_request_once "$method" "$url" "$payload" "$include_headers")
  fi

  echo "$response"
}

kc_get_json_or_exit() {
  local url="$1"
  local description="$2"

  local response http_code body
  response=$(kc_request_with_retry "GET" "$url")
  http_code=$(echo "$response" | tail -n1)
  body=$(echo "$response" | sed '$d')

  if [ "$http_code" -ge 300 ]; then
    echo "Failed to fetch $description. HTTP response code: $http_code"
    echo "Response: $body"
    exit 1
  fi

  if ! printf '%s' "$body" | jq -e . >/dev/null 2>&1; then
    echo "Failed to parse JSON response for $description"
    echo "Response: $body"
    exit 1
  fi

  printf '%s' "$body"
}

is_managed_client() {
  local client_id="$1"
  local token

  for token in ${MANAGED_CLIENT_IDS//,/ }; do
    if [ "$token" = "$client_id" ]; then
      return 0
    fi
  done

  return 1
}

lookup_client_uuid() {
  local client_id="$1"
  kc_get_json_or_exit "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients?clientId=$client_id" "client lookup '$client_id'" | jq -r '.[0].id // empty'
}

# 503-tolerant variant: returns empty string on transient HTTP errors instead
# of fatally exiting. Use this before wait loops so a Keycloak 503 during
# startup doesn't kill the script before the retry logic is reached.
lookup_client_uuid_safe() {
  local client_id="$1"
  local response http_code body
  response=$(kc_request_with_retry "GET" "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients?clientId=$client_id")
  http_code=$(echo "$response" | tail -n1)
  body=$(echo "$response" | sed '$d')
  if [ "$http_code" -lt 300 ]; then
    printf '%s' "$body" | jq -r '.[0].id // empty'
  else
    echo "[oauth-init] lookup_client_uuid_safe: transient error looking up '$client_id' (HTTP $http_code); treating as not-found" >&2
    echo ""
  fi
}

# Uniformly creates a bearer-only placeholder client with devops.placeholder=true.
# Prints the new client's UUID to stdout on success (or after 409 conflict resolution).
# Returns 0 on success, 1 on unrecoverable failure (caller decides whether to exit).
create_placeholder_client() {
  local client_id="$1"
  local payload response http_code body

  payload=$(jq -n --arg clientId "$client_id" '{
    clientId: $clientId,
    bearerOnly: true,
    publicClient: false,
    standardFlowEnabled: false,
    directAccessGrantsEnabled: false,
    serviceAccountsEnabled: false,
    authorizationServicesEnabled: false,
    attributes: {
      "devops.placeholder": "true"
    }
  }')

  response=$(kc_request_with_retry "POST" "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients" "$payload" true)
  http_code=$(echo "$response" | tail -n1)
  body=$(echo "$response" | sed '$d')

  if [ "$http_code" -ge 300 ] && [ "$http_code" -ne 409 ]; then
    echo "[oauth-init] create_placeholder_client: failed to create '$client_id'. HTTP $http_code" >&2
    echo "[oauth-init]   Response: $body" >&2
    return 1
  fi

  if [ "$http_code" -lt 300 ]; then
    echo "[oauth-init] create_placeholder_client: created '$client_id'" >&2
  else
    echo "[oauth-init] create_placeholder_client: '$client_id' already exists (409 conflict)" >&2
  fi

  # Resolve UUID after create (or after 409)
  local uuid
  uuid=$(lookup_client_uuid "$client_id")
  if [ -n "$uuid" ]; then
    echo "$uuid"
    return 0
  fi
  echo "[oauth-init] create_placeholder_client: could not resolve UUID for '$client_id' after create" >&2
  return 1
}

wait_for_managed_client_uuid_or_fail() {
  local client_id="$1"
  local retries="$MANAGED_CLIENT_LOOKUP_RETRIES"
  local interval="$MANAGED_CLIENT_LOOKUP_INTERVAL_SECONDS"
  local attempt=0
  local client_uuid=""
  local wait_start
  wait_start=$(date +%s)

  echo "[oauth-init] Waiting for managed client '$client_id' (max ${retries}x${interval}s = $((retries * interval))s)" >&2

  while [ "$attempt" -lt "$retries" ]; do
    # Tolerate transient HTTP errors (e.g. 503 during Keycloak startup) instead
    # of fatally exiting via kc_get_json_or_exit.
    local response http_code body
    response=$(kc_request_with_retry "GET" "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients?clientId=$client_id")
    http_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | sed '$d')

    if [ "$http_code" -lt 300 ]; then
      client_uuid=$(printf '%s' "$body" | jq -r '.[0].id // empty')
      if [ -n "$client_uuid" ]; then
        local elapsed=$(( $(date +%s) - wait_start ))
        echo "[oauth-init] Managed client '$client_id' found (uuid=$client_uuid) after ${elapsed}s (attempt $((attempt + 1))/$retries)" >&2
        echo "$client_uuid"
        return 0
      fi
    else
      echo "[oauth-init] Transient error polling for managed client '$client_id' (HTTP $http_code, attempt $((attempt + 1))/$retries); will retry" >&2
    fi

    if [ "$attempt" -lt "$((retries - 1))" ]; then
      echo "[oauth-init] Managed client '$client_id' not found yet; retrying lookup ($((attempt + 1))/$retries)" >&2
      sleep "$interval"
    fi
    attempt=$((attempt + 1))
  done

  local elapsed=$(( $(date +%s) - wait_start ))
  echo "[oauth-init] ERROR: Managed client '$client_id' was not found after $retries retries (${elapsed}s elapsed); failing to avoid placeholder override risk" >&2
  exit 1
}

ensure_audience_client() {
  local audience_client="$1"

  if [ -z "$audience_client" ]; then
    return 0
  fi

  echo "[oauth-init] ensure_audience_client: processing '$audience_client'"

  local previous_client_id="${CLIENT_ID:-}"
  CLIENT_ID="$audience_client"

  local existing_id
  existing_id=$(lookup_client_uuid_safe "$audience_client")

  if [ -n "$existing_id" ]; then
    echo "[oauth-init] ensure_audience_client: '$audience_client' already exists (uuid=$existing_id)"
  else
    echo "[oauth-init] ensure_audience_client: '$audience_client' does not exist yet in Keycloak"
  fi

  if is_managed_client "$audience_client"; then
    echo "[oauth-init] ensure_audience_client: '$audience_client' is a managed client — will NOT create or normalize"
    if [ -z "$existing_id" ]; then
      echo "[oauth-init] ensure_audience_client: '$audience_client' not yet created by init container; entering wait loop"
      existing_id=$(wait_for_managed_client_uuid_or_fail "$audience_client")
    fi
    echo "Skipping audience client create/normalize for managed client '$audience_client'"
    CLIENT_ID="$previous_client_id"
    return 0
  fi

  if [ -z "$existing_id" ]; then
    existing_id=$(create_placeholder_client "$audience_client") || {
      echo "[oauth-init] ensure_audience_client: failed to create placeholder for '$audience_client'; exiting"
      exit 1
    }
  fi

  if [ -n "$existing_id" ]; then
    existing_payload=$(kc_get_json_or_exit "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$existing_id" "audience client '$audience_client'")

    local should_normalize
    should_normalize=$(echo "$existing_payload" | jq -r '
      # Normalize only placeholder-shaped clients; skip fully managed clients.
      # Condition 1: authoritative — client was explicitly tagged by this script.
      ((.attributes."devops.placeholder" // "") == "true") or (
      # Condition 2: backward-compatibility — matches clients created before
      # devops.placeholder was introduced. All new placeholders now get the
      # attribute, so this path will stop matching once existing installs are
      # migrated. Safe because fully-managed service clients always have at
      # least one flow enabled or redirect URIs configured.
        (.standardFlowEnabled // false) == false and
        (.directAccessGrantsEnabled // false) == false and
        (.serviceAccountsEnabled // false) == false and
        (.authorizationServicesEnabled // false) == false and
        (.publicClient // false) == false and
        ((.redirectUris // []) | length) == 0 and
        ((.webOrigins // []) | length) == 0 and
        ((.baseUrl // "") | length) == 0
      )
    ')

    if [ "$should_normalize" != "true" ]; then
      echo "[oauth-init] ensure_audience_client: '$audience_client' looks fully managed (should_normalize=false); skipping normalization"
      echo "[oauth-init]   client state: standardFlow=$(echo "$existing_payload" | jq -r '.standardFlowEnabled'), serviceAccounts=$(echo "$existing_payload" | jq -r '.serviceAccountsEnabled'), tokenExchange=$(echo "$existing_payload" | jq -r '.attributes."standard.token.exchange.enabled" // "n/a"'), bearerOnly=$(echo "$existing_payload" | jq -r '.bearerOnly'), placeholder=$(echo "$existing_payload" | jq -r '.attributes."devops.placeholder" // "n/a"')"
      CLIENT_ID="$previous_client_id"
      return 0
    fi

    echo "[oauth-init] ensure_audience_client: '$audience_client' is a placeholder-shaped client (should_normalize=true); normalizing to bearer-only"
    echo "[oauth-init]   current client state: standardFlow=$(echo "$existing_payload" | jq -r '.standardFlowEnabled'), serviceAccounts=$(echo "$existing_payload" | jq -r '.serviceAccountsEnabled'), tokenExchange=$(echo "$existing_payload" | jq -r '.attributes."standard.token.exchange.enabled" // "n/a"'), bearerOnly=$(echo "$existing_payload" | jq -r '.bearerOnly'), placeholder=$(echo "$existing_payload" | jq -r '.attributes."devops.placeholder" // "n/a"')"

    # Remove .secret to avoid replaying credentials. Remove .clientAuthenticatorType
    # because bearer-only clients do not use a client authenticator; omitting it lets
    # Keycloak reset to the default ("client-secret"), which is harmless for bearer-only.
    payload=$(echo "$existing_payload" | jq '
      del(.secret, .clientAuthenticatorType) |
      .bearerOnly = true |
      .publicClient = false |
      .standardFlowEnabled = false |
      .directAccessGrantsEnabled = false |
      .serviceAccountsEnabled = false |
      .authorizationServicesEnabled = false |
      .attributes = ((.attributes // {}) + {"devops.placeholder": "true"})
    ')

    response=$(kc_request_with_retry "PUT" "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$existing_id" "$payload" true)

    http_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | sed '$d')

    if [ "$http_code" -ge 300 ]; then
      echo "Failed to update audience client '$audience_client'. HTTP response code: $http_code"
      echo "Response: $body"
      exit 1
    fi
    echo "Updated audience client '$audience_client'"
  fi

  CLIENT_ID="$previous_client_id"
}

upsert_audience_mapper_for_scope() {
  local scope_id="$1"
  local scope_name="$2"
  local audience_client="$3"

  if [ -z "$scope_id" ] || [ -z "$scope_name" ] || [ -z "$audience_client" ]; then
    return 0
  fi

  local mapper_name="${scope_name}-audience-mapper"

  local existing_mappers
  existing_mappers=$(kc_get_json_or_exit "$KEYCLOAK_URL/admin/realms/$REALM_NAME/client-scopes/$scope_id/protocol-mappers/models" "protocol mappers for scope '$scope_name'")

  local mapper_id
  mapper_id=$(echo "$existing_mappers" | jq -r --arg name "$mapper_name" '.[] | select(.name==$name) | .id' | head -n1)

  local payload
  payload=$(jq -n \
    --arg name "$mapper_name" \
    --arg audience "$audience_client" \
    '{
      name: $name,
      protocol: "openid-connect",
      protocolMapper: "oidc-audience-mapper",
      consentRequired: false,
      config: {
        "id.token.claim": "false",
        "lightweight.claim": "false",
        "access.token.claim": "true",
        "introspection.token.claim": "true",
        "included.client.audience": $audience
      }
    }')

  local response http_code body
  if [ -n "$mapper_id" ] && [ "$mapper_id" != "null" ]; then
    payload=$(echo "$payload" | jq --arg id "$mapper_id" '.id = $id')
    response=$(kc_request_with_retry "PUT" "$KEYCLOAK_URL/admin/realms/$REALM_NAME/client-scopes/$scope_id/protocol-mappers/models/$mapper_id" "$payload" true)
  else
    response=$(kc_request_with_retry "POST" "$KEYCLOAK_URL/admin/realms/$REALM_NAME/client-scopes/$scope_id/protocol-mappers/models" "$payload" true)
  fi

  http_code=$(echo "$response" | tail -n1)
  body=$(echo "$response" | sed '$d')

  if [ "$http_code" -ge 300 ]; then
    echo "Failed to upsert audience mapper for scope '$scope_name'. HTTP response code: $http_code"
    echo "Response: $body"
    exit 1
  fi
}

upsert_client_audience_mapper_for_scope() {
  local scope_id="$1"
  local scope_name="$2"
  local audience_client="$3"
  local target_client_id="$4"

  if [ -z "$scope_id" ] || [ -z "$scope_name" ] || [ -z "$audience_client" ] || [ -z "$target_client_id" ]; then
    return 0
  fi

  echo "[oauth-init] upsert_client_audience_mapper: scope='$scope_name' audience='$audience_client' target_client='$target_client_id'"

  local target_client_uuid
  target_client_uuid=$(lookup_client_uuid_safe "$target_client_id")

  if [ -z "$target_client_uuid" ]; then
    echo "[oauth-init] upsert_client_audience_mapper: target '$target_client_id' not found yet"
    if is_managed_client "$target_client_id"; then
      echo "[oauth-init] upsert_client_audience_mapper: '$target_client_id' is managed — entering wait loop"
      target_client_uuid=$(wait_for_managed_client_uuid_or_fail "$target_client_id")
    fi
  else
    echo "[oauth-init] upsert_client_audience_mapper: target '$target_client_id' found (uuid=$target_client_uuid)"
  fi

  if [ -z "$target_client_uuid" ]; then
    echo "[oauth-init] upsert_client_audience_mapper: Client '$target_client_id' not found; creating placeholder client before mapper reconciliation"

    target_client_uuid=$(create_placeholder_client "$target_client_id") || {
      echo "[oauth-init] upsert_client_audience_mapper: skipping — could not create placeholder for '$target_client_id'"
      return 0
    }

    if [ -z "$target_client_uuid" ]; then
      echo "[oauth-init] upsert_client_audience_mapper: skipping — could not resolve client '$target_client_id' after placeholder create"
      return 0
    fi
  fi

  local assign_response assign_code assign_body
  assign_response=$(kc_request_with_retry "PUT" "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$target_client_uuid/optional-client-scopes/$scope_id")
  assign_code=$(echo "$assign_response" | tail -n1)
  assign_body=$(echo "$assign_response" | sed '$d')

  if [ "$assign_code" -ge 300 ] && [ "$assign_code" -ne 409 ]; then
    echo "Failed to assign scope '$scope_name' to client '$target_client_id'. HTTP response code: $assign_code"
    echo "Response: $assign_body"
    return 0
  fi

  local mapper_name="${scope_name}-audience-mapper"
  local existing_mappers
  existing_mappers=$(kc_get_json_or_exit "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$target_client_uuid/protocol-mappers/models" "protocol mappers for client '$target_client_id'")

  local mapper_id
  mapper_id=$(echo "$existing_mappers" | jq -r --arg name "$mapper_name" '.[] | select(.name==$name) | .id' | head -n1)

  local mapper_payload
  mapper_payload=$(jq -n \
    --arg name "$mapper_name" \
    --arg audience "$audience_client" \
    '{
      name: $name,
      protocol: "openid-connect",
      protocolMapper: "oidc-audience-mapper",
      consentRequired: false,
      config: {
        "id.token.claim": "false",
        "lightweight.claim": "false",
        "access.token.claim": "true",
        "introspection.token.claim": "true",
        "included.client.audience": $audience
      }
    }')

  local response http_code body
  if [ -n "$mapper_id" ] && [ "$mapper_id" != "null" ]; then
    mapper_payload=$(echo "$mapper_payload" | jq --arg id "$mapper_id" '.id = $id')
    response=$(kc_request_with_retry "PUT" "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$target_client_uuid/protocol-mappers/models/$mapper_id" "$mapper_payload" true)
  else
    response=$(kc_request_with_retry "POST" "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$target_client_uuid/protocol-mappers/models" "$mapper_payload" true)
  fi

  http_code=$(echo "$response" | tail -n1)
  body=$(echo "$response" | sed '$d')

  if [ "$http_code" -ge 300 ]; then
    echo "Failed to upsert client audience mapper '$mapper_name' on '$target_client_id'. HTTP response code: $http_code"
    echo "Response: $body"
    return 0
  fi

  echo "Ensured client audience mapper '$mapper_name' on '$target_client_id' for audience '$audience_client'"
}

upsert_allowed_client_scopes_policy() {
  local allowed_scopes_json="${ALLOWED_CLIENT_SCOPES_JSON:-}"
  local allowed_scopes_legacy="${ALLOWED_CLIENT_SCOPES:-}"
  local policy_subtype="${POLICY_SUBTYPE:-anonymous}"
  local allow_default_scopes="${ALLOW_DEFAULT_SCOPES:-true}"
  local update_existing="${ALLOWED_CLIENT_SCOPES_UPDATE_EXISTING:-true}"

  if [ -z "$allowed_scopes_json" ] && [ -z "$allowed_scopes_legacy" ]; then
    echo "No Allowed Client Scopes policy config provided."
    return 0
  fi

  if [ -z "$allowed_scopes_json" ]; then
    allowed_scopes_json=$(printf '%s' "$allowed_scopes_legacy" | jq -R 'split(" ") | map(select(length>0))')
  fi

  local allowed_scopes
  allowed_scopes=$(echo "$allowed_scopes_json" | jq -c 'if type=="array" then map(select(type=="string" and length>0)) | unique else [] end')

  if [ "$(echo "$allowed_scopes" | jq -r 'length')" -eq 0 ]; then
    echo "No allowed client scopes configured. Skipping Allowed Client Scopes policy."
    return 0
  fi

  echo "Upserting Allowed Client Scopes policy ($policy_subtype)"
  local components
  components=$(kc_get_json_or_exit "$KEYCLOAK_URL/admin/realms/$REALM_NAME/components" "realm components")

  local payload
  payload=$(jq -n \
    --arg subtype "$policy_subtype" \
    --arg allowDefault "$allow_default_scopes" \
    --argjson scopes "$allowed_scopes" \
    '{
      name: "Allowed Client Scopes",
      providerType: "org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy",
      providerId: "allowed-client-templates",
      subType: $subtype,
      config: {
        "allowed-client-scopes": $scopes,
        "allow-default-scopes": [ $allowDefault ]
      }
    }')

  local comp_id
  comp_id=$(echo "$components" | jq -r --arg subtype "$policy_subtype" '
    .[] | select(.name=="Allowed Client Scopes" and .providerType=="org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy" and .providerId=="allowed-client-templates" and (.subType|ascii_downcase)==($subtype|ascii_downcase)) | .id' | head -n1)

  if [ -n "$comp_id" ] && [ "$comp_id" != "null" ]; then
    local existing_allowed_scopes
    existing_allowed_scopes=$(echo "$components" | jq -c --arg id "$comp_id" '
      .[] | select(.id==$id) | (.config["allowed-client-scopes"] // []) | map(tostring) | unique')
    local existing_allow_default
    existing_allow_default=$(echo "$components" | jq -r --arg id "$comp_id" '
      .[] | select(.id==$id) | (.config["allow-default-scopes"][0] // "false") | tostring | ascii_downcase')
    local desired_allow_default
    desired_allow_default=$(echo "$allow_default_scopes" | tr '[:upper:]' '[:lower:]')

    if [ "$existing_allowed_scopes" = "$allowed_scopes" ] && [ "$existing_allow_default" = "$desired_allow_default" ]; then
      echo "Allowed Client Scopes policy already up-to-date; skipping"
    else
      if [ "$update_existing" = "true" ]; then
        echo "Allowed Client Scopes policy differs; updating existing component"
        local update_response update_code update_body
        update_response=$(kc_request_with_retry "PUT" "$KEYCLOAK_URL/admin/realms/$REALM_NAME/components/$comp_id" "$payload")
        update_code=$(echo "$update_response" | tail -n1)
        update_body=$(echo "$update_response" | sed '$d')

        if [ "$update_code" -ge 300 ]; then
          echo "Failed to update existing Allowed Client Scopes policy. HTTP response code: $update_code"
          echo "Response: $update_body"
          exit 1
        fi
      else
        echo "Allowed Client Scopes policy differs from desired config, but update is disabled (ALLOWED_CLIENT_SCOPES_UPDATE_EXISTING=false)"
        echo "Current: $existing_allowed_scopes"
        echo "Desired: $allowed_scopes"
      fi
    fi
  else
    local response http_code body
    response=$(kc_request_with_retry "POST" "$KEYCLOAK_URL/admin/realms/$REALM_NAME/components" "$payload")

    http_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | sed '$d')

    if [ "$http_code" -ge 300 ]; then
      echo "Failed to upsert Allowed Client Scopes policy. HTTP response code: $http_code"
      echo "Response: $body"
      exit 1
    fi
  fi
}

ALLOWED_CLIENT_SCOPES_JSON=${ALLOWED_CLIENT_SCOPES_JSON:-}
ALLOWED_CLIENT_SCOPES=${ALLOWED_CLIENT_SCOPES:-}
POLICY_SUBTYPE=anonymous
ALLOW_DEFAULT_SCOPES=${ALLOW_DEFAULT_SCOPES:-true}
ALLOWED_CLIENT_SCOPES_UPDATE_EXISTING=${ALLOWED_CLIENT_SCOPES_UPDATE_EXISTING:-true}

OAUTH_SCOPES_JSON=${OAUTH_SCOPES_JSON:-}
OAUTH_SCOPES_FILE=${OAUTH_SCOPES_FILE:-}
OAUTH_CONFIG_ENABLED=${OAUTH_CONFIG_ENABLED:-true}

if [ "$OAUTH_CONFIG_ENABLED" = "true" ]; then
  if [ -z "$OAUTH_SCOPES_JSON" ] && [ -z "$OAUTH_SCOPES_FILE" ]; then
    echo "No OAuth scopes provided (OAUTH_SCOPES_JSON/OAUTH_SCOPES_FILE). Skipping scope initialization."
  else
    if [ -n "$OAUTH_SCOPES_FILE" ]; then
      if [ ! -f "$OAUTH_SCOPES_FILE" ]; then
        echo "OAUTH_SCOPES_FILE not found: $OAUTH_SCOPES_FILE"
        exit 1
      fi
      OAUTH_SCOPES_JSON=$(cat "$OAUTH_SCOPES_FILE")
    fi

    scopes_json=$(echo "$OAUTH_SCOPES_JSON" | jq -c 'if type=="array" then . elif has("scopes") then .scopes else [] end')

    if [ "$(echo "$scopes_json" | jq -r 'length')" -eq 0 ]; then
      echo "No OAuth scopes found after parsing."
    else
      scope_count=$(echo "$scopes_json" | jq -r 'length')
      echo "[oauth-init] Syncing $scope_count OAuth scope(s) to realm $REALM_NAME"
      existing_scopes=$(kc_get_json_or_exit "$KEYCLOAK_URL/admin/realms/$REALM_NAME/client-scopes" "existing client scopes")
      existing_scope_count=$(echo "$existing_scopes" | jq -r 'length')
      echo "[oauth-init] Found $existing_scope_count existing client scope(s) in realm"

      scope_index=0
      echo "$scopes_json" | jq -c '.[]' | while read -r scope; do
      scope_index=$((scope_index + 1))
      name=$(echo "$scope" | jq -r '.name')
      if [ -z "$name" ] || [ "$name" = "null" ]; then
        echo "Skipping scope with no name: $scope"
        continue
      fi

      description=$(echo "$scope" | jq -r '.description // .name')
      map_audience=$(echo "$scope" | jq -r '.mapAudience // false')
      audience=$(echo "$scope" | jq -r '.audience // empty')
      audience_clients_count=$(echo "$scope" | jq -r '.audienceClients // [] | length')

      echo "[oauth-init] ---- Processing scope $scope_index/$scope_count: '$name' (audience='$audience', mapAudience=$map_audience, audienceClients=$audience_clients_count)"

      if [ -z "$audience" ] && [ "$map_audience" = "true" ]; then
        audience="${name%:*}"
        if [ "$audience" = "$name" ]; then
          audience="$name"
        fi
      fi
      
      # Derive audience for audienceClients mapping even if mapAudience is false
      if [ -z "$audience" ] && [ "$audience_clients_count" -gt 0 ]; then
        audience="${name%:all}"
        if [ "$audience" = "$name" ]; then
          audience="$name"
        fi
      fi

      is_api_scope=false
      if [[ "$name" == api:* ]] || [[ "$audience" == api:* ]]; then
        is_api_scope=true
      fi

      # Create audience client if mapAudience is true OR if any audienceClients use this scope
      if [ "$is_api_scope" = "true" ] && { [ "$map_audience" = "true" ] || [ "$audience_clients_count" -gt 0 ]; }; then
        ensure_audience_client "$audience"
      fi

      scope_id=$(echo "$existing_scopes" | jq -r --arg name "$name" '.[] | select(.name==$name) | .id' | head -n1)

      payload=$(jq -n \
        --arg name "$name" \
        --arg desc "$description" \
        --arg audience "$audience" \
        --arg mapAudience "$map_audience" \
        --arg isApi "$is_api_scope" \
        'def base:
          {name:$name,
           protocol:"openid-connect",
           type:"optional",
           description:$desc,
           attributes:{
             "display.on.consent.screen":"true",
             "consent.screen.text":$desc,
             "include.in.token.scope":"true",
             "type":"optional"
           }};
         base + (if $mapAudience == "true" then
            {protocolMappers:[{
              name: ($name + "-audience-mapper"),
              protocol: "openid-connect",
              protocolMapper: "oidc-audience-mapper",
              consentRequired: false,
              config: {
                "id.token.claim": "false",
                "lightweight.claim": "false",
                "access.token.claim": "true",
                "introspection.token.claim": "true",
                "included.client.audience": (if $isApi == "true" then $audience else empty end),
                "included.custom.audience": (if $isApi == "true" then empty else $audience end)
              }
            }]}
          else {} end)')

      if [ -n "$scope_id" ]; then
        echo "Updating client scope $name ($scope_id)"
        response=$(kc_request_with_retry "PUT" "$KEYCLOAK_URL/admin/realms/$REALM_NAME/client-scopes/$scope_id" "$payload" true)
      else
        echo "Creating client scope $name"
        response=$(kc_request_with_retry "POST" "$KEYCLOAK_URL/admin/realms/$REALM_NAME/client-scopes" "$payload" true)
      fi

      http_code=$(echo "$response" | tail -n1)
      body=$(echo "$response" | sed '$d')

      if [ "$http_code" -ge 300 ]; then
        if [ -z "$scope_id" ] && [ "$http_code" -eq 409 ]; then
          echo "Client scope '$name' already exists (409 on create); resolving existing ID and continuing"
          scope_id=$(kc_get_json_or_exit "$KEYCLOAK_URL/admin/realms/$REALM_NAME/client-scopes" "client scopes after create conflict" | jq -r --arg name "$name" '.[] | select(.name==$name) | .id' | head -n1)
          if [ -z "$scope_id" ] || [ "$scope_id" = "null" ]; then
            echo "Failed to resolve existing client scope '$name' after 409 conflict"
            echo "Response: $body"
            exit 1
          fi
        else
          echo "Failed to upsert client scope '$name'. HTTP response code: $http_code"
          echo "Response: $body"
          exit 1
        fi
      fi

      if [ -z "$scope_id" ]; then
        scope_id=$(kc_get_json_or_exit "$KEYCLOAK_URL/admin/realms/$REALM_NAME/client-scopes" "client scopes after upsert" | jq -r --arg name "$name" '.[] | select(.name==$name) | .id' | head -n1)
      fi

      if [ -n "$scope_id" ]; then
        echo "Ensuring scope '$name' is optional in realm"
        response=$(kc_request_with_retry "PUT" "$KEYCLOAK_URL/admin/realms/$REALM_NAME/default-optional-client-scopes/$scope_id")
        http_code=$(echo "$response" | tail -n1)
        if [ "$http_code" -ge 300 ] && [ "$http_code" -ne 409 ]; then
          echo "Failed to mark scope '$name' optional. HTTP response code: $http_code"
          exit 1
        fi
        if [ "$http_code" -eq 409 ]; then
          echo "Scope '$name' already optional in realm"
        fi

        if [ "$map_audience" = "true" ]; then
          upsert_audience_mapper_for_scope "$scope_id" "$name" "$audience"
        else
          # Remove scope-level audience mapper if mapAudience is false
          mapper_name="${name}-audience-mapper"
          existing_mappers=$(kc_get_json_or_exit "$KEYCLOAK_URL/admin/realms/$REALM_NAME/client-scopes/$scope_id/protocol-mappers/models" "protocol mappers for scope '$name'")
          
          mapper_id=$(echo "$existing_mappers" | jq -r --arg name "$mapper_name" '.[] | select(.name==$name) | .id' | head -n1)
          
          if [ -n "$mapper_id" ] && [ "$mapper_id" != "null" ]; then
            echo "Removing scope-level audience mapper '$mapper_name' from scope '$name' (mapAudience is false)"
            response=$(kc_request_with_retry "DELETE" "$KEYCLOAK_URL/admin/realms/$REALM_NAME/client-scopes/$scope_id/protocol-mappers/models/$mapper_id")
            
            http_code=$(echo "$response" | tail -n1)
            if [ "$http_code" -ge 300 ]; then
              body=$(echo "$response" | sed '$d')
              echo "Warning: Failed to delete scope-level audience mapper. HTTP: $http_code"
              echo "Response: $body"
            else
              echo "Successfully removed scope-level audience mapper '$mapper_name'"
            fi
          fi
        fi

        if [ "$audience_clients_count" -gt 0 ] && [ -n "$audience" ]; then
          echo "$scope" | jq -r '.audienceClients[]?' | while read -r target_client_id; do
            if [ -z "$target_client_id" ]; then
              continue
            fi
            upsert_client_audience_mapper_for_scope "$scope_id" "$name" "$audience" "$target_client_id"
          done
        fi
      fi
      done
    fi
  fi
  upsert_allowed_client_scopes_policy
  echo "[oauth-init] Scope synchronization complete"
else
  echo "OAuth scope and Allowed Client Scopes policy initialization disabled (OAUTH_CONFIG_ENABLED=false)"
fi

TRUSTED_HOSTS_ACTION=${TRUSTED_HOSTS_ACTION:-skip}
TRUSTED_HOSTS_POLICY_SUBTYPE=anonymous
TRUSTED_HOSTS_CONFIG_JSON=${TRUSTED_HOSTS_CONFIG_JSON:-}
FULL_SCOPE_DISABLED_ACTION=delete
FULL_SCOPE_DISABLED_POLICY_SUBTYPE=anonymous

if [ "$TRUSTED_HOSTS_ACTION" != "skip" ]; then
  components=$(kc_get_json_or_exit "$KEYCLOAK_URL/admin/realms/$REALM_NAME/components" "realm components")

  trusted_hosts_id=$(echo "$components" | jq -r --arg subtype "$TRUSTED_HOSTS_POLICY_SUBTYPE" '
    .[] | select(.name=="Trusted Hosts" and .providerType=="org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy" and .providerId=="trusted-hosts" and (.subType|ascii_downcase)==($subtype|ascii_downcase)) | .id' | head -n1)

  if [ "$TRUSTED_HOSTS_ACTION" = "delete" ]; then
    if [ -n "$trusted_hosts_id" ] && [ "$trusted_hosts_id" != "null" ]; then
      response=$(kc_request_with_retry "DELETE" "$KEYCLOAK_URL/admin/realms/$REALM_NAME/components/$trusted_hosts_id")
      http_code=$(echo "$response" | tail -n1)
      if [ "$http_code" -ge 300 ]; then
        echo "Failed to delete Trusted Hosts policy. HTTP response code: $http_code"
        exit 1
      fi
      echo "Deleted Trusted Hosts policy"
    else
      echo "Trusted Hosts policy not found; nothing to delete"
    fi
  elif [ "$TRUSTED_HOSTS_ACTION" = "upsert" ]; then
    if [ -z "$TRUSTED_HOSTS_CONFIG_JSON" ] || [ "$TRUSTED_HOSTS_CONFIG_JSON" = "null" ]; then
      echo "TRUSTED_HOSTS_CONFIG_JSON is required for upsert"
      exit 1
    fi

    config_json=$(echo "$TRUSTED_HOSTS_CONFIG_JSON" | jq 'to_entries | map({key:.key, value: (if (.value|type)=="array" then .value elif (.value|type)=="string" then [ .value ] else .value end)}) | from_entries')

    payload=$(jq -n \
      --arg subtype "$TRUSTED_HOSTS_POLICY_SUBTYPE" \
      --argjson config "$config_json" \
      '{
        name: "Trusted Hosts",
        providerType: "org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy",
        providerId: "trusted-hosts",
        subType: $subtype,
        config: $config
      }')

    if [ -n "$trusted_hosts_id" ] && [ "$trusted_hosts_id" != "null" ]; then
      response=$(kc_request_with_retry "PUT" "$KEYCLOAK_URL/admin/realms/$REALM_NAME/components/$trusted_hosts_id" "$payload")
    else
      response=$(kc_request_with_retry "POST" "$KEYCLOAK_URL/admin/realms/$REALM_NAME/components" "$payload")
    fi

    http_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | sed '$d')
    if [ "$http_code" -ge 300 ]; then
      echo "Failed to upsert Trusted Hosts policy. HTTP response code: $http_code"
      echo "Response: $body"
      exit 1
    fi
    echo "Upserted Trusted Hosts policy"
  else
    echo "Unknown TRUSTED_HOSTS_ACTION: $TRUSTED_HOSTS_ACTION"
    exit 1
  fi
fi

if [ "$FULL_SCOPE_DISABLED_ACTION" != "skip" ]; then
  components=$(kc_get_json_or_exit "$KEYCLOAK_URL/admin/realms/$REALM_NAME/components" "realm components")

  full_scope_disabled_ids=$(echo "$components" | jq -r '[ .[] | select(.name=="Full Scope Disabled") | .id ] | unique | .[]')
  # Now: delete all with name 'Full Scope Disabled', matching tenant-server logic

  if [ "$FULL_SCOPE_DISABLED_ACTION" = "delete" ]; then
    if [ -n "$full_scope_disabled_ids" ]; then
      deleted_count=0
      while IFS= read -r full_scope_disabled_id; do
        if [ -z "$full_scope_disabled_id" ] || [ "$full_scope_disabled_id" = "null" ]; then
          continue
        fi

        response=$(kc_request_with_retry "DELETE" "$KEYCLOAK_URL/admin/realms/$REALM_NAME/components/$full_scope_disabled_id")
        http_code=$(echo "$response" | tail -n1)
        if [ "$http_code" -ge 300 ]; then
          echo "Failed to delete Full Scope Disabled policy ($full_scope_disabled_id). HTTP response code: $http_code"
          exit 1
        fi

        deleted_count=$((deleted_count + 1))
      done <<< "$full_scope_disabled_ids"

      echo "Deleted Full Scope Disabled policy components: $deleted_count"
    else
      echo "Full Scope Disabled policy with name 'Full Scope Disabled' not found; nothing to delete"
    fi
  else
    echo "Unsupported FULL_SCOPE_DISABLED_ACTION: $FULL_SCOPE_DISABLED_ACTION"
    exit 1
  fi
fi

OAUTH_INIT_ELAPSED=$(( $(date +%s) - OAUTH_INIT_START_TS ))
echo "========================================"
echo "[oauth-init] Finished at $(date -u '+%Y-%m-%dT%H:%M:%SZ') (${OAUTH_INIT_ELAPSED}s elapsed)"
echo "========================================"
