#!/bin/bash
# Observability Stack Health Check Script
# Verifies OpenTelemetry Collector and Data Prepper are running correctly

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Get release name from command line or default
RELEASE_NAME="${1:-devops-loop}"
NAMESPACE="${2:-default}"

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}Observability Stack Health Check${NC}"
echo -e "${BLUE}Release: ${RELEASE_NAME}${NC}"
echo -e "${BLUE}Namespace: ${NAMESPACE}${NC}"
echo -e "${BLUE}========================================${NC}\n"

# Check if kubectl is available
if ! command -v kubectl &> /dev/null; then
    echo -e "${RED}✗ kubectl not found${NC}"
    exit 1
fi

# Check if observability is enabled
echo -e "${YELLOW}Checking if observability is enabled...${NC}"
ENABLED=$(kubectl get configmap -n "$NAMESPACE" -l "app.kubernetes.io/instance=${RELEASE_NAME},app.kubernetes.io/name=observability" 2>/dev/null | wc -l)
if [ "$ENABLED" -eq 0 ]; then
    echo -e "${RED}✗ Observability not deployed (global.observability.enabled: false)${NC}"
    echo -e "${YELLOW}  Enable with: helm upgrade --set global.observability.enabled=true${NC}\n"
    exit 0
fi
echo -e "${GREEN}✓ Observability is enabled${NC}\n"

# Check OTel Collector DaemonSet
echo -e "${YELLOW}Checking OTel Collector DaemonSet...${NC}"
OTEL_DS=$(kubectl get daemonset -n "$NAMESPACE" -l "app.kubernetes.io/component=otel-collector,app.kubernetes.io/instance=${RELEASE_NAME}" -o name 2>/dev/null)
if [ -z "$OTEL_DS" ]; then
    echo -e "${RED}✗ OTel Collector DaemonSet not found${NC}\n"
else
    kubectl get "$OTEL_DS" -n "$NAMESPACE"
    DESIRED=$(kubectl get "$OTEL_DS" -n "$NAMESPACE" -o jsonpath='{.status.desiredNumberScheduled}')
    READY=$(kubectl get "$OTEL_DS" -n "$NAMESPACE" -o jsonpath='{.status.numberReady}')
    if [ "$DESIRED" -eq "$READY" ]; then
        echo -e "${GREEN}✓ OTel Collector: ${READY}/${DESIRED} pods ready${NC}\n"
    else
        echo -e "${RED}✗ OTel Collector: ${READY}/${DESIRED} pods ready${NC}\n"
    fi
fi

# Check Data Prepper Deployment
echo -e "${YELLOW}Checking Data Prepper Deployment...${NC}"
DATA_PREPPER=$(kubectl get deployment -n "$NAMESPACE" -l "app.kubernetes.io/component=data-prepper,app.kubernetes.io/instance=${RELEASE_NAME}" -o name 2>/dev/null)
if [ -z "$DATA_PREPPER" ]; then
    echo -e "${RED}✗ Data Prepper Deployment not found${NC}\n"
else
    kubectl get "$DATA_PREPPER" -n "$NAMESPACE"
    DESIRED=$(kubectl get "$DATA_PREPPER" -n "$NAMESPACE" -o jsonpath='{.status.replicas}')
    READY=$(kubectl get "$DATA_PREPPER" -n "$NAMESPACE" -o jsonpath='{.status.readyReplicas}')
    if [ "$DESIRED" -eq "$READY" ]; then
        echo -e "${GREEN}✓ Data Prepper: ${READY}/${DESIRED} replicas ready${NC}\n"
    else
        echo -e "${RED}✗ Data Prepper: ${READY:-0}/${DESIRED} replicas ready${NC}\n"
    fi
fi

# Check all observability pods
echo -e "${YELLOW}All Observability Pods:${NC}"
kubectl get pods -n "$NAMESPACE" -l "app.kubernetes.io/name=observability,app.kubernetes.io/instance=${RELEASE_NAME}" 2>/dev/null || echo "No pods found"
echo ""

# Check OTel Collector logs for errors
echo -e "${YELLOW}Recent OTel Collector logs (last 20 lines):${NC}"
OTEL_POD=$(kubectl get pods -n "$NAMESPACE" -l "app.kubernetes.io/component=otel-collector,app.kubernetes.io/instance=${RELEASE_NAME}" -o jsonpath='{.items[0].metadata.name}' 2>/dev/null)
if [ -n "$OTEL_POD" ]; then
    kubectl logs -n "$NAMESPACE" "$OTEL_POD" --tail=20 2>/dev/null || echo "Could not retrieve logs"
    
    # Check for common issues
    ERRORS=$(kubectl logs -n "$NAMESPACE" "$OTEL_POD" --tail=100 2>/dev/null | grep -i error | wc -l)
    if [ "$ERRORS" -gt 0 ]; then
        echo -e "\n${RED}✗ Found ${ERRORS} error messages in logs${NC}"
    else
        echo -e "\n${GREEN}✓ No errors in recent logs${NC}"
    fi
else
    echo -e "${RED}No OTel Collector pod found${NC}"
fi
echo ""

# Check Data Prepper logs for OpenSearch connectivity
echo -e "${YELLOW}Recent Data Prepper logs (last 20 lines):${NC}"
DP_POD=$(kubectl get pods -n "$NAMESPACE" -l "app.kubernetes.io/component=data-prepper,app.kubernetes.io/instance=${RELEASE_NAME}" -o jsonpath='{.items[0].metadata.name}' 2>/dev/null)
if [ -n "$DP_POD" ]; then
    kubectl logs -n "$NAMESPACE" "$DP_POD" --tail=20 2>/dev/null || echo "Could not retrieve logs"
    
    # Check OpenSearch connectivity
    echo -e "\n${YELLOW}Checking OpenSearch connectivity...${NC}"
    OPENSEARCH_CONNECTED=$(kubectl logs -n "$NAMESPACE" "$DP_POD" --tail=100 2>/dev/null | grep -i "opensearch" | grep -i "connect" | tail -1)
    if [ -n "$OPENSEARCH_CONNECTED" ]; then
        echo -e "${GREEN}✓ OpenSearch connection activity detected${NC}"
        echo "$OPENSEARCH_CONNECTED"
    else
        echo -e "${YELLOW}⚠ No OpenSearch connection messages found${NC}"
    fi
else
    echo -e "${RED}No Data Prepper pod found${NC}"
fi
echo ""

# Summary
echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}Summary${NC}"
echo -e "${BLUE}========================================${NC}"

# Count running pods
RUNNING_PODS=$(kubectl get pods -n "$NAMESPACE" -l "app.kubernetes.io/name=observability,app.kubernetes.io/instance=${RELEASE_NAME}" -o jsonpath='{.items[?(@.status.phase=="Running")].metadata.name}' 2>/dev/null | wc -w)
TOTAL_PODS=$(kubectl get pods -n "$NAMESPACE" -l "app.kubernetes.io/name=observability,app.kubernetes.io/instance=${RELEASE_NAME}" -o name 2>/dev/null | wc -l)

echo -e "Pods Running: ${GREEN}${RUNNING_PODS}/${TOTAL_PODS}${NC}"

if [ "$RUNNING_PODS" -eq "$TOTAL_PODS" ] && [ "$TOTAL_PODS" -gt 0 ]; then
    echo -e "\n${GREEN}✓ Observability stack is healthy!${NC}"
elif [ "$TOTAL_PODS" -eq 0 ]; then
    echo -e "\n${RED}✗ No observability pods found${NC}"
else
    echo -e "\n${YELLOW}⚠ Some pods are not running${NC}"
fi

echo -e "\n${BLUE}Useful commands:${NC}"
echo "  View all resources:    kubectl get all -n $NAMESPACE -l app.kubernetes.io/name=observability"
echo "  OTel Collector logs:   kubectl logs -n $NAMESPACE -l app.kubernetes.io/component=otel-collector -f"
echo "  Data Prepper logs:     kubectl logs -n $NAMESPACE -l app.kubernetes.io/component=data-prepper -f"
echo "  Describe pod issues:   kubectl describe pods -n $NAMESPACE -l app.kubernetes.io/name=observability"
