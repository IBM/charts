preflight_check_storage() {
  for cmd in df awk; do
    if ! command -v "$cmd" >/dev/null 2>&1; then
      echo "Error: '$cmd' is required for storage check."
      exit 1
    fi
  done
  echo "========== Storage Check =========="
  RECOMMENDED_ROOT_GB=200
  MIN_ROOT_GB=120
  ROOT_SIZE_GB=$(df -BG / | awk 'NR==2 {gsub(/G/, "", $2); print $2}')
  if ! [[ "$ROOT_SIZE_GB" =~ ^[0-9]+$ ]]; then
    echo "Error: Unable to detect root partition size."
    exit 1
  fi
  echo "Detected root (/) size: ${ROOT_SIZE_GB}GB (recommended ~${RECOMMENDED_ROOT_GB}GB, minimum ${MIN_ROOT_GB}GB)"
  if [[ "$ROOT_SIZE_GB" -lt "$MIN_ROOT_GB" ]]; then
    echo "ERROR: Root (/) partition must be at least ${MIN_ROOT_GB}GB."
    exit 1
  elif [[ "$ROOT_SIZE_GB" -lt "$RECOMMENDED_ROOT_GB" ]]; then
    echo "Warning: Root partition below recommended ${RECOMMENDED_ROOT_GB}GB. This can trigger Kubernetes DiskPressure conditions, causing pods to fail or be evicted."
  else
    echo "[ OK ] Root partition size looks sufficient."
  fi
  echo
  echo "========== RAM Check =============="
  RECOMMENDED_RAM_GB=64
  MINIMUM_RAM_GB=32
  if [[ ! -f /proc/meminfo ]]; then
    echo "Error: Cannot determine system RAM."
    exit 1
  fi
  TOTAL_RAM_GB=$(( $(awk '/MemTotal/ {print $2}' /proc/meminfo) / 1024 / 1024 ))
  echo "Detected RAM: ${TOTAL_RAM_GB}GB (recommended ~${RECOMMENDED_RAM_GB}GB, minimum ${MINIMUM_RAM_GB}GB)"
  if [[ "$TOTAL_RAM_GB" -lt "$MINIMUM_RAM_GB" ]]; then
    echo "ERROR: Minimum RAM requirement is ${MINIMUM_RAM_GB}GB."
    exit 1
  elif [[ "$TOTAL_RAM_GB" -lt "$RECOMMENDED_RAM_GB" ]]; then
    echo "Warning: RAM below recommended ${RECOMMENDED_RAM_GB}GB. This may cause severe performance issues."
  else
    echo "[ OK ] RAM size looks sufficient."
  fi
  echo
} 

#Required
#External fully qualified domain name of the cluster
#
#See Installation of DevOps Loop documentation for more details:
#https://www.ibm.com/docs/en/devops-loop/2.0.2?topic=administration-installation-devops-loop
DOMAIN=$(hostname -I | awk '{ print $1; }').nip.io

#Required
#Set value to 'true' to accept the license. 
ACCEPT_LICENSE=true

#Required 
#Hostname of IBM Rational license server
LICENSE_SERVER=

#Required 
#SMTP Server configuration 
EMAIL_SERVER_HOST=
EMAIL_SERVER_PORT=
EMAIL_FROM_ADDRESS=

#Optional 
#Additional SMTP Server configuration
EMAIL_SERVER_USERNAME=""
EMAIL_SERVER_PASSWORD=""
EMAIL_SERVER_STARTTLS=false
EMAIL_SERVER_SMTPS=false

#Required
#Secure seed required to generate passwords
#A random string
#Unrecoverable so keep it safe
PASSWORD_SEED=secret

#Specify the TLS secret name in your namespace as necessary.
#
#See Installation of DevOps Loop documentation for more details:
#https://www.ibm.com/docs/en/devops-loop/2.0.2?topic=administration-installation-devops-loop
TLS_CERT_SECRET_NAME=devops-loop-tls-secret

#Set SELF_SIGNED=true to generate and use a self-signed certificate for the
#installation of DevOps Loop
SELF_SIGNED=true 

#Alternative RWX storage class
#See Storage
#For example: ibmc-file-gold-gid
RWX_STORAGE_CLASS=nfs-client

#Alternative RWO storage class
#See Storage
#For example: ibmc-block-gold
RWO_STORAGE_CLASS=nfs-client

# optional Appscan integration
APP_SCAN_ENABLED=false


# Required only when APP_SCAN_ENABLED=true
# External URL for AppScan (e.g. https://cloud.appscan.com)
APPSCAN_EXTERNAL_URL=										  

# Optional Harbor integration
HARBOR_ENABLED=false

# Required only when HARBOR_ENABLED=true
HARBOR_S3_BUCKET=
HARBOR_S3_REGION=
HARBOR_S3_ENDPOINT=

# Harbor Trivy cache uses RWX
#See Storage
#For example: ibmc-file-gold-gid
HARBOR_TRIVY_STORAGE_CLASS=

# Harbor OIDC admin group in Keycloak
# Users in this group become Harbor system administrators.
HARBOR_OIDC_ADMIN_GROUP=

#Required
NAMESPACE=devops-loop
HELM_NAME=devops-loop
LOOP_CHART_VERSION=2.0.202

#Optional Additional Helm options
ADDITIONAL_HELM_OPTIONS=""

wait_for_secret() {
  local secret_name="$1"
  local timeout_seconds="${2:-900}"
  local waited=0

  echo "Waiting for secret ${secret_name} in namespace ${NAMESPACE}..."

  until kubectl get secret "${secret_name}" -n "${NAMESPACE}" >/dev/null 2>&1; do
    if [ "${waited}" -ge "${timeout_seconds}" ]; then
      echo "Timed out waiting for secret ${secret_name}"
      return 1
    fi
    sleep 10
    waited=$((waited + 10))
  done

  echo "Secret ${secret_name} is available."
}
run_install() { 

  preflight_check_storage 
  
  if ! kubectl  get namespace ${NAMESPACE} > /dev/null 2>&1; then
    kubectl  create namespace ${NAMESPACE} || { echo "Failed to create namespace"; return 1; }
  fi


  if ! kubectl  get secret mongodb-url-secret --namespace ${NAMESPACE} > /dev/null 2>&1; then

    MONGO_CHART_VERSION="${MONGO_CHART_VERSION:-14.13.0}"
    MONGO_IMAGE_TAG="${MONGO_IMAGE_TAG:-6.0}"
    MONGO_IMAGE_REPO="${MONGO_IMAGE_REPO:-bitnamilegacy/mongodb}"
    MONGO_HELM_RELEASE_NAME="${MONGO_HELM_RELEASE_NAME:-devops-loop-mongo}"
    MONGO_NAMESPACE="${MONGO_NAMESPACE:-${NAMESPACE}}"
    MONGO_PVC_SIZE=${MONGO_PVC_SIZE:-20Gi}
  
    helm repo add bitnami https://charts.bitnami.com/bitnami --force-update 1> /dev/null

    MONGO_INSTALL_OPTIONS="\
      --set image.repository=${MONGO_IMAGE_REPO} \
      --set image.tag=${MONGO_IMAGE_TAG} \
      --set persistence.size=${MONGO_PVC_SIZE}
    "
    
    if [ -n "${RWO_STORAGE_CLASS}" ]; then
      MONGO_INSTALL_OPTIONS="${MONGO_INSTALL_OPTIONS} --set persistence.storageClass=${RWO_STORAGE_CLASS}"
    fi
    
    if [ -n "${MONGO_ADDITIONAL_INSTALL_OPTIONS}" ]; then
      MONGO_INSTALL_OPTIONS="${MONGO_INSTALL_OPTIONS} ${MONGO_ADDITIONAL_INSTALL_OPTIONS}"
    fi

    helm upgrade --install ${MONGO_HELM_RELEASE_NAME} \
      --version ${MONGO_CHART_VERSION} \
      ${MONGO_INSTALL_OPTIONS} \
      --namespace=${MONGO_NAMESPACE} \
      --create-namespace \
      bitnami/mongodb 1> /dev/null || { echo "Failed to install MongoDB"; return 1; }
    
    MONGODB_ROOT_PASSWORD=$(kubectl  get secret --namespace ${NAMESPACE} ${MONGO_HELM_RELEASE_NAME}-mongodb -o jsonpath="{.data.mongodb-root-password}" | base64 -d)
    
    MONGO_URL="mongodb://root:${MONGODB_ROOT_PASSWORD}@${MONGO_HELM_RELEASE_NAME}-mongodb:27017/admin"

    kubectl create secret generic mongodb-url-secret --namespace ${NAMESPACE} --from-literal=password="${MONGO_URL}" 1> /dev/null || { echo "Failed to create MongoDB secret"; return 1; }
     
  fi

  if [ "${SELF_SIGNED}" = "true" ]; then
    export TLS_CERT_SECRET_NAME=devops-loop-tls-secret
    openssl genrsa -out key.pem 2048
    openssl req -new -x509 -key key.pem -out cert.pem -days 365 \
            -subj "/CN=${DOMAIN}" -addext "subjectAltName = DNS:${DOMAIN},DNS:*.${DOMAIN}" \
            -addext "certificatePolicies = 1.2.3.4"

    kubectl create secret generic ${TLS_CERT_SECRET_NAME} \
     --type=kubernetes.io/tls \
     --from-file=ca.crt=./cert.pem \
     --from-file=tls.crt=./cert.pem \
     --from-file=tls.key=./key.pem \
     --namespace ${NAMESPACE}
  fi

  HELM_OPTIONS="${HELM_OPTIONS:-} \
--set global.domain=${DOMAIN} \
--set-literal global.passwordSeed=${PASSWORD_SEED} \
--set global.platform.smtp.sender=${EMAIL_FROM_ADDRESS} \
--set global.platform.smtp.host=${EMAIL_SERVER_HOST} \
--set global.platform.smtp.port=${EMAIL_SERVER_PORT} \
--set global.platform.smtp.username=${EMAIL_SERVER_USERNAME} \
--set global.platform.smtp.password=${EMAIL_SERVER_PASSWORD} \
--set global.platform.smtp.startTLS=${EMAIL_SERVER_STARTTLS} \
--set global.platform.smtp.smtps=${EMAIL_SERVER_SMTPS} \
--set global.ibmCertSecretName=${TLS_CERT_SECRET_NAME} \
--set license=${ACCEPT_LICENSE} \
--set platform.appscan.enabled=${APP_SCAN_ENABLED}
"
  if [ "${APP_SCAN_ENABLED}" = "true" ] && [ -n "${APPSCAN_EXTERNAL_URL}" ]; then
    HELM_OPTIONS="${HELM_OPTIONS} --set-string platform.appscan.externalURL=${APPSCAN_EXTERNAL_URL}"
  fi																		 

  if [ "${SELF_SIGNED}" = "true" ]; then
     HELM_OPTIONS="${HELM_OPTIONS} --set global.privateCaBundleSecretName=${TLS_CERT_SECRET_NAME}"
     HELM_OPTIONS="${HELM_OPTIONS} --set ibm-devops-prod.ingress.cert.selfSigned=true"
  fi

  if [ -n "${LICENSE_SERVER}" ]; then
    HELM_OPTIONS="${HELM_OPTIONS} --set global.rationalLicenseKeyServer=@${LICENSE_SERVER}"
  fi

  if [ -n "${RWX_STORAGE_CLASS}" ]; then
    HELM_OPTIONS="${HELM_OPTIONS} --set global.persistence.rwxStorageClass=${RWX_STORAGE_CLASS}"
  fi

  if [ -n "${RWO_STORAGE_CLASS}" ]; then
    HELM_OPTIONS="${HELM_OPTIONS} --set global.persistence.rwoStorageClass=${RWO_STORAGE_CLASS}"
  fi

  HELM_OPTIONS="${HELM_OPTIONS} ${ADDITIONAL_HELM_OPTIONS}"

  helm upgrade --install ${HELM_NAME} ibm-helm/ibm-devops-loop --version ${LOOP_CHART_VERSION} ${HELM_OPTIONS} \
     --set harbor.enabled=false \
    -n ${NAMESPACE} || return 1
    
  if [ "${HARBOR_ENABLED}" != "true" ]; then
    echo "Harbor is disabled. DevOps Loop installation completed."
    return 0
  fi

  echo "Validating Harbor prerequisites..."

  if [ -z "${HARBOR_S3_BUCKET}" ]; then
    echo "HARBOR_S3_BUCKET is required when HARBOR_ENABLED=true"
    return 1
  fi

  if [ -z "${HARBOR_S3_REGION}" ]; then
    echo "HARBOR_S3_REGION is required when HARBOR_ENABLED=true"
    return 1
  fi

  if [ -z "${HARBOR_S3_ENDPOINT}" ]; then
    echo "HARBOR_S3_ENDPOINT is required when HARBOR_ENABLED=true"
    return 1
  fi

  if ! kubectl get secret harbor-s3-secret -n "${NAMESPACE}" >/dev/null 2>&1; then
    echo "harbor-s3-secret is required when HARBOR_ENABLED=true"
    echo "Create it before install:"
    echo "kubectl create secret generic harbor-s3-secret -n ${NAMESPACE} --from-literal=accesskey='<ACCESS_KEY>' --from-literal=secretkey='<SECRET_KEY>'"
    return 1
  fi

  if [ -z "${HARBOR_TRIVY_STORAGE_CLASS}" ] && [ -z "${RWX_STORAGE_CLASS}" ]; then
    echo "Either HARBOR_TRIVY_STORAGE_CLASS or RWX_STORAGE_CLASS is required when HARBOR_ENABLED=true"
    return 1
  fi

  echo "Waiting for Harbor dependency secrets"

  for secret in devops-loop-valkey devops-loop-postgresql; do
    if ! wait_for_secret "${secret}" 1200; then
      echo "WARNING: Required Harbor dependency secret ${secret} was not available within timeout period."
      echo "Skipping Harbor installation/upgrade. DevOps Loop base installation completed successfully."
      echo "After ${secret} is available, rerun this script to enable Harbor."
      return 0
    fi
  done

  REDIS_PASSWORD=$(kubectl get secret devops-loop-valkey \
    -n "${NAMESPACE}" \
    -o jsonpath="{.data.valkey-password}" | base64 -d)| base64 -d)

  S3_ACCESS_KEY=$(kubectl get secret harbor-s3-secret     -n "${NAMESPACE}"     -o jsonpath="{.data.accesskey}" | base64 -d)

  S3_SECRET_KEY=$(kubectl get secret harbor-s3-secret     -n "${NAMESPACE}"     -o jsonpath="{.data.secretkey}" | base64 -d)
  
  if [ -z "${HARBOR_OIDC_ADMIN_GROUP}" ]; then
    HARBOR_OIDC_ADMIN_GROUP=harbor-admins
  fi

  echo "Using Harbor OIDC admin group: ${HARBOR_OIDC_ADMIN_GROUP}"

  HARBOR_URL="https://harbor.${DOMAIN}"

  HARBOR_HELM_OPTIONS="${HELM_OPTIONS} --set harbor.enabled=true --set platform.harbor.enabled=true --set-string harbor.externalURL=${HARBOR_URL} --set-string harbor.oidc.adminGroup=${HARBOR_OIDC_ADMIN_GROUP} --set-string harbor.redis.external.password=${REDIS_PASSWORD} --set-string harbor.trivy.externalRedis.password=${REDIS_PASSWORD} --set-string harbor.persistence.imageChartStorage.s3.bucket=${HARBOR_S3_BUCKET} --set-string harbor.persistence.imageChartStorage.s3.region=${HARBOR_S3_REGION} --set-string harbor.persistence.imageChartStorage.s3.regionendpoint=${HARBOR_S3_ENDPOINT} --set-string harbor.persistence.imageChartStorage.s3.accesskey=${S3_ACCESS_KEY} --set-string harbor.persistence.imageChartStorage.s3.secretkey=${S3_SECRET_KEY}"
  
  if [ -n "${HARBOR_TRIVY_STORAGE_CLASS}" ]; then
    HARBOR_HELM_OPTIONS="${HARBOR_HELM_OPTIONS} --set-string harbor.trivy.persistence.storageClass=${HARBOR_TRIVY_STORAGE_CLASS}"
  else
    HARBOR_HELM_OPTIONS="${HARBOR_HELM_OPTIONS} --set-string harbor.trivy.persistence.storageClass=${RWX_STORAGE_CLASS}"
  fi

  echo "Installing optional Harbor integration..."
  
  HARBOR_HELM_OPTIONS="${HARBOR_HELM_OPTIONS} ${ADDITIONAL_HELM_OPTIONS}"
															 
  helm upgrade --install ${HELM_NAME} ibm-helm/ibm-devops-loop \
  --version ${LOOP_CHART_VERSION} \
  ${HARBOR_HELM_OPTIONS} \
  --hide-notes \
  --timeout 30m \
  -n ${NAMESPACE} || return 1

  echo "DevOps Loop + Harbor installation completed."
  echo ""
  echo "Harbor URL:"
  echo "  https://harbor.${DOMAIN}"
  echo ""
  echo "Monitor Harbor pods:"
  echo "  kubectl get pods -n ${NAMESPACE} | grep harbor"
  echo ""
  echo "Bootstrap Harbor images:"
  echo "  1. Update scripts/harbor/bootstrap-images.txt"
  echo "  2. Run:"
  echo "     DOMAIN=${DOMAIN} NAMESPACE=${NAMESPACE} RELEASE=${HELM_NAME} scripts/harbor/bootstrap-images.sh"
}

run_install