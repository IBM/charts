# Harbor OpenShift SCC

Harbor remains disabled by default on OpenShift. When enabling Harbor, the Helm
chart creates a namespace-scoped dedicated ServiceAccount, but it does not create
or modify cluster-scoped SecurityContextConstraints.

A cluster administrator must explicitly apply the dedicated SCC before Harbor is
enabled:

```sh
scripts/harbor/openshift/apply-harbor-scc.sh \
  --namespace devops-loop \
  --service-account harbor \
  --scc-name harbor-uid-10000-devops-loop
```

The SCC is scoped to UID/GID `10000` by requiring:

- `runAsUser: MustRunAs` with UID `10000`
- `fsGroup: MustRunAs` with range `10000-10000`
- `supplementalGroups: MustRunAs` with range `10000-10000`

The helper binds the SCC only to:

```text
system:serviceaccount:<namespace>:<service-account>
```

The main OpenShift installer performs a preflight check only. If the SCC or
binding is missing, installation fails with an instruction to have a cluster
administrator apply this package.
