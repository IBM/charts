#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<'USAGE'
Apply the dedicated OpenShift SCC for Harbor UID/GID 10000.

This script is intended for a cluster administrator. It creates or updates only
one SCC and binds it only to one predictable Harbor ServiceAccount.

Required:
  --namespace <namespace>              or NAMESPACE

Optional:
  --service-account <name>             or HARBOR_SERVICE_ACCOUNT, default: harbor
  --scc-name <name>                    or HARBOR_SCC_NAME, default: harbor-uid-10000-<namespace>
  --dry-run                            render YAML only; do not call oc
  --yes                                apply without interactive confirmation
  -h, --help                           show this help

Example:
  scripts/harbor/openshift/apply-harbor-scc.sh \
    --namespace devops-loop \
    --service-account harbor \
    --scc-name harbor-uid-10000-devops-loop
USAGE
}

NAMESPACE="${NAMESPACE:-}"
HARBOR_SERVICE_ACCOUNT="${HARBOR_SERVICE_ACCOUNT:-harbor}"
HARBOR_SCC_NAME="${HARBOR_SCC_NAME:-}"
DRY_RUN=false
YES=false

while [ "$#" -gt 0 ]; do
  case "$1" in
    --namespace)
      NAMESPACE="${2:-}"
      shift 2
      ;;
    --service-account)
      HARBOR_SERVICE_ACCOUNT="${2:-}"
      shift 2
      ;;
    --scc-name)
      HARBOR_SCC_NAME="${2:-}"
      shift 2
      ;;
    --dry-run)
      DRY_RUN=true
      shift
      ;;
    --yes)
      YES=true
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unknown argument: $1" >&2
      usage >&2
      exit 1
      ;;
  esac
done

if [ -z "${NAMESPACE}" ]; then
  echo "NAMESPACE is required. Use --namespace <namespace> or set NAMESPACE." >&2
  exit 1
fi

if [ -z "${HARBOR_SERVICE_ACCOUNT}" ]; then
  echo "HARBOR_SERVICE_ACCOUNT must not be empty." >&2
  exit 1
fi

if [ -z "${HARBOR_SCC_NAME}" ]; then
  HARBOR_SCC_NAME="harbor-uid-10000-${NAMESPACE}"
fi

validate_dns_label() {
  local value="$1"
  local field="$2"

  if ! printf '%s' "${value}" | grep -Eq '^[a-z0-9]([-a-z0-9]*[a-z0-9])?$'; then
    echo "${field} must be a lowercase DNS label: ${value}" >&2
    exit 1
  fi
}

validate_dns_label "${NAMESPACE}" "namespace"
validate_dns_label "${HARBOR_SERVICE_ACCOUNT}" "service account"
validate_dns_label "${HARBOR_SCC_NAME}" "SCC name"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TEMPLATE_FILE="${SCRIPT_DIR}/harbor-scc.yaml"

render_template() {
  sed \
    -e "s|\${NAMESPACE}|${NAMESPACE}|g" \
    -e "s|\${HARBOR_SERVICE_ACCOUNT}|${HARBOR_SERVICE_ACCOUNT}|g" \
    -e "s|\${HARBOR_SCC_NAME}|${HARBOR_SCC_NAME}|g" \
    "${TEMPLATE_FILE}"
}

if [ "${DRY_RUN}" = "true" ]; then
  render_template
  exit 0
fi

if ! command -v oc >/dev/null 2>&1; then
  echo "oc CLI was not found in PATH." >&2
  exit 1
fi

if [ "${YES}" != "true" ]; then
  echo "This will apply cluster-scoped SCC ${HARBOR_SCC_NAME} and bind it only to:"
  echo "  system:serviceaccount:${NAMESPACE}:${HARBOR_SERVICE_ACCOUNT}"
  printf 'Continue? [y/N] '
  read -r answer
  case "${answer}" in
    y|Y|yes|YES)
      ;;
    *)
      echo "Aborted."
      exit 1
      ;;
  esac
fi

render_template | oc apply -f -

echo "Applied SCC ${HARBOR_SCC_NAME} for system:serviceaccount:${NAMESPACE}:${HARBOR_SERVICE_ACCOUNT}."
