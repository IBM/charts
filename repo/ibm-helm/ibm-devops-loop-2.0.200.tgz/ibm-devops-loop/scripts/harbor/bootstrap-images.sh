#!/usr/bin/env bash
set -euo pipefail

NAMESPACE="${NAMESPACE:-devops-loop}"
RELEASE="${RELEASE:-devops-loop}"
DOMAIN="${DOMAIN:?DOMAIN is required, example: harborprod-iks2.us-east.containers.appdomain.cloud}"

HARBOR_HOST="${HARBOR_HOST:-harbor.${DOMAIN}}"
HARBOR_URL="https://${HARBOR_HOST}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

IMAGE_LIST_FILE="${IMAGE_LIST_FILE:-${SCRIPT_DIR}/bootstrap-images.txt}"

SKOPEO_BIN="${SKOPEO_BIN:-${SCRIPT_DIR}/tools/skopeo}"

if [ ! -x "${SKOPEO_BIN}" ]; then
  SKOPEO_BIN="$(command -v skopeo || true)"
fi

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "Required command not found: $1"
    exit 1
  fi
}

require_cmd kubectl
require_cmd curl

if [ -z "${SKOPEO_BIN}" ]; then
  echo "skopeo not found."
  echo "Provide skopeo in scripts/harbor/tools/skopeo or set SKOPEO_BIN."
  exit 1
fi

if [ ! -f "${IMAGE_LIST_FILE}" ]; then
  echo "Image list file not found: ${IMAGE_LIST_FILE}"
  exit 1
fi

echo "Waiting for Harbor API: ${HARBOR_URL}"

until curl -k -s "${HARBOR_URL}/api/v2.0/ping" >/dev/null; do
  echo "Harbor API not ready yet..."
  sleep 10
done

HARBOR_ADMIN_PASSWORD="$(kubectl get secret "${RELEASE}-harbor-core" \
  -n "${NAMESPACE}" \
  -o jsonpath='{.data.HARBOR_ADMIN_PASSWORD}' | base64 -d)"

create_project() {
  local project="$1"

  echo "Ensuring Harbor project exists: ${project}"

  code="$(curl -k -s -o /tmp/harbor-project.out -w "%{http_code}" \
    -u "admin:${HARBOR_ADMIN_PASSWORD}" \
    -H "Content-Type: application/json" \
    -X POST \
    "${HARBOR_URL}/api/v2.0/projects" \
    -d "{\"project_name\":\"${project}\",\"public\":false}")"

  if [ "${code}" = "201" ] || [ "${code}" = "409" ]; then
    echo "Project ready: ${project}"
  else
    echo "Project creation failed. HTTP ${code}"
    cat /tmp/harbor-project.out
    exit 1
  fi

  curl -k -s \
    -u "admin:${HARBOR_ADMIN_PASSWORD}" \
    -H "Content-Type: application/json" \
    -X PUT \
    "${HARBOR_URL}/api/v2.0/projects/${project}" \
    -d '{"metadata":{"auto_scan":"true"}}' >/dev/null || true
}

create_robot() {
  local project="$1"
  local secret_name="harbor-bootstrap-robot-${project}"

  if kubectl get secret "${secret_name}" -n "${NAMESPACE}" >/dev/null 2>&1; then
    ROBOT_USER="$(kubectl get secret "${secret_name}" -n "${NAMESPACE}" -o jsonpath='{.data.HARBOR_ROBOT_USER}' | base64 -d)"
    ROBOT_TOKEN="$(kubectl get secret "${secret_name}" -n "${NAMESPACE}" -o jsonpath='{.data.HARBOR_ROBOT_TOKEN}' | base64 -d)"
    return
  fi

  robot_name="bootstrap-seeder-${project}"

  echo "Creating Harbor robot account: ${robot_name}"

  robot_resp="$(curl -k -s \
    -u "admin:${HARBOR_ADMIN_PASSWORD}" \
    -H "Content-Type: application/json" \
    -X POST \
    "${HARBOR_URL}/api/v2.0/robots" \
    -d "{
      \"name\":\"${robot_name}\",
      \"description\":\"Bootstrap robot for seeded images\",
      \"level\":\"project\",
      \"disable\":false,
      \"duration\":30,
      \"permissions\":[
        {
          \"kind\":\"project\",
          \"namespace\":\"${project}\",
          \"access\":[
            {\"resource\":\"repository\",\"action\":\"pull\"},
            {\"resource\":\"repository\",\"action\":\"push\"}
          ]
        }
      ]
    }")"

  echo "${robot_resp}" > /tmp/harbor-robot.json

  ROBOT_USER="$(sed -n 's/.*"name":"\([^"]*\)".*/\1/p' /tmp/harbor-robot.json)"
  ROBOT_TOKEN="$(sed -n 's/.*"secret":"\([^"]*\)".*/\1/p' /tmp/harbor-robot.json)"

  if [ -z "${ROBOT_USER}" ] || [ -z "${ROBOT_TOKEN}" ]; then
    echo "Robot creation failed."
    cat /tmp/harbor-robot.json
    exit 1
  fi

  kubectl create secret generic "${secret_name}" \
    -n "${NAMESPACE}" \
    --from-literal=HARBOR_ROBOT_USER="${ROBOT_USER}" \
    --from-literal=HARBOR_ROBOT_TOKEN="${ROBOT_TOKEN}" \
    --dry-run=client -o yaml | kubectl apply -f -
}

urlencode_repo() {
  echo "$1" | sed 's/\//%2F/g'
}

push_and_scan() {
  local source_image="$1"
  local project="$2"
  local repo="$3"
  local tag="$4"

  create_project "${project}"
  create_robot "${project}"

  target_image="docker://${HARBOR_HOST}/${project}/${repo}:${tag}"

  echo "Copying image:"
  echo "  Source: ${source_image}"
  echo "  Target: ${target_image}"

  "${SKOPEO_BIN}" copy \
    --src-tls-verify=false \
    --dest-tls-verify=false \
    --dest-creds "${ROBOT_USER}:${ROBOT_TOKEN}" \
    "${source_image}" \
    "${target_image}"

  echo "Image copied successfully."

  sleep 20

  encoded_repo="$(urlencode_repo "${repo}")"

  echo "Triggering Trivy scan for ${project}/${repo}:${tag}"

  scan_code="$(curl -k -s -o /tmp/harbor-scan.out -w "%{http_code}" \
    -u "admin:${HARBOR_ADMIN_PASSWORD}" \
    -H "Content-Type: application/json" \
    -H "Accept: application/json" \
    -X POST \
    "${HARBOR_URL}/api/v2.0/projects/${project}/repositories/${encoded_repo}/artifacts/${tag}/scan")"

  if [ "${scan_code}" = "202" ] || [ "${scan_code}" = "409" ]; then
    echo "Scan triggered or already queued."
  else
    echo "Scan trigger failed. HTTP ${scan_code}"
    cat /tmp/harbor-scan.out
    exit 1
  fi
}

while read -r source_image project repo tag; do

  case "${source_image:-}" in
    ""|\#*) continue ;;
  esac

  if [ -z "${project:-}" ] || [ -z "${repo:-}" ] || [ -z "${tag:-}" ]; then
    echo "Invalid line. Expected:"
    echo "source_image target_project target_repo target_tag"
    exit 1
  fi

  push_and_scan "${source_image}" "${project}" "${repo}" "${tag}"

done < "${IMAGE_LIST_FILE}"

echo "Harbor bootstrap completed successfully."

