# Application Integration Guide

## Connecting Applications to the Observability Stack

Applications use the **sidecar pattern** - each instrumented pod has an OTel Collector sidecar that receives telemetry locally and forwards it to the central collector.

### Data Flow

```
Application Container → OTel Sidecar (localhost) → Central OTel Collector → Data Prepper → OpenSearch
```

### Sidecar OTLP Endpoints (Recommended)

Applications send telemetry to their **local sidecar** on localhost:

| Protocol | Port | Endpoint |
|----------|------|----------|
| gRPC | 4317 | `localhost:4317` |
| HTTP | 4318 | `http://localhost:4318` |

### Direct to Central Collector (Alternative)

For pods without sidecars, connect directly to the central collector:

| Protocol | Port | Endpoint |
|----------|------|----------|
| gRPC | 4317 | `<release>-otel-collector:4317` |
| HTTP | 4318 | `http://<release>-otel-collector:4318` |

## Language-Specific Examples

### Go (with Sidecar)

**Environment Variables** (simplest):
```bash
export OTEL_EXPORTER_OTLP_ENDPOINT="http://localhost:4318"
export OTEL_SERVICE_NAME="my-service"
export OTEL_RESOURCE_ATTRIBUTES="environment=production"
```

**Code Configuration**:
```go
import (
    "go.opentelemetry.io/otel"
    "go.opentelemetry.io/otel/exporters/otlp/otlptrace/otlptracegrpc"
    "go.opentelemetry.io/otel/sdk/trace"
)

func initTracer(ctx context.Context) (*trace.TracerProvider, error) {
    exporter, err := otlptracegrpc.New(ctx,
        otlptracegrpc.WithEndpoint("localhost:4317"),  // Sidecar on localhost
        otlptracegrpc.WithInsecure(),
    )
    if err != nil {
        return nil, err
    }
    
    tp := trace.NewTracerProvider(
        trace.WithBatcher(exporter),
        trace.WithResource(resource.NewWithAttributes(
            semconv.SchemaURL,
            semconv.ServiceName("my-service"),
        )),
    )
    otel.SetTracerProvider(tp)
    return tp, nil
}
```

### Spring Boot (Java) with Sidecar

**application.yml**:
```yaml
management:
  otlp:
    tracing:
      endpoint: http://localhost:4318/v1/traces  # Sidecar on localhost
  tracing:
    sampling:
      probability: 1.0

spring:
  application:
    name: my-service
```

**Or using Java Agent** (no code changes):
```bash
java -javaagent:/path/to/opentelemetry-javaagent.jar \
     -Dotel.service.name=my-service \
     -Dotel.exporter.otlp.endpoint=http://localhost:4318 \
     -jar myapp.jar
```

### Python (with Sidecar)

```python
from opentelemetry import trace
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.sdk.resources import Resource

# Configure resource
resource = Resource.create({"service.name": "my-service"})

# Create tracer provider
trace.set_tracer_provider(TracerProvider(resource=resource))

# Configure OTLP exporter - sidecar on localhost
otlp_exporter = OTLPSpanExporter(
    endpoint="localhost:4317",
    insecure=True
)

# Add span processor
trace.get_tracer_provider().add_span_processor(
    BatchSpanProcessor(otlp_exporter)
)

# Get tracer
tracer = trace.get_tracer(__name__)
```

**Or using auto-instrumentation**:
```bash
export OTEL_EXPORTER_OTLP_ENDPOINT="http://localhost:4318"
export OTEL_SERVICE_NAME="my-service"
opentelemetry-instrument python myapp.py
```

### Node.js (with Sidecar)

```javascript
const { NodeTracerProvider } = require('@opentelemetry/sdk-trace-node');
const { OTLPTraceExporter } = require('@opentelemetry/exporter-trace-otlp-grpc');
const { BatchSpanProcessor } = require('@opentelemetry/sdk-trace-base');
const { Resource } = require('@opentelemetry/resources');
const { SemanticResourceAttributes } = require('@opentelemetry/semantic-conventions');

// Create exporter - sidecar on localhost
const exporter = new OTLPTraceExporter({
  url: 'localhost:4317',
});

// Create provider
const provider = new NodeTracerProvider({
  resource: new Resource({
    [SemanticResourceAttributes.SERVICE_NAME]: 'my-service',
  }),
});

provider.addSpanProcessor(new BatchSpanProcessor(exporter));
provider.register();
```

## Kubernetes Deployment Configuration

### With Sidecar (Recommended)

The sidecar is automatically injected using the `otel.sidecar.conditional` helper template.
Applications just need to set environment variables to point to localhost:

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: my-app
spec:
  template:
    spec:
      containers:
      - name: app
        image: my-app:latest
        env:
        - name: OTEL_EXPORTER_OTLP_ENDPOINT
          value: "http://localhost:4318"  # Sidecar on localhost
        - name: OTEL_SERVICE_NAME
          value: "my-app"
      # Sidecar is injected via helper template:
      # {{- include "otel.sidecar.conditional" . | nindent 6 }}
```

### Sidecar Helper Template Usage

In your deployment template, include the sidecar when observability is enabled:

```yaml
spec:
  template:
    spec:
      containers:
      - name: app
        # ... app container config ...
{{- if eq (include "otel.enabled" .) "true" }}
      {{- include "otel.sidecar.conditional" . | nindent 6 }}
{{- end }}
      volumes:
{{- if eq (include "otel.enabled" .) "true" }}
        - name: otel-sidecar-conf
          configMap:
            name: {{ .Release.Name }}-<service>-otel-sidecar
{{- end }}
```

### Without Sidecar (Direct to Central Collector)

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: my-app
spec:
  template:
    spec:
      containers:
      - name: app
        image: my-app:latest
        env:
        - name: OTEL_EXPORTER_OTLP_ENDPOINT
          value: "http://devops-loop-otel-collector:4317"  # Central collector
        - name: OTEL_SERVICE_NAME
          value: "my-app"
```

## Metrics Collection

### Option 1: Push Metrics via OTLP (Recommended)

Same endpoint as traces - the sidecar handles both:

```go
import "go.opentelemetry.io/otel/exporters/otlp/otlpmetric/otlpmetricgrpc"

exporter, _ := otlpmetricgrpc.New(ctx,
    otlpmetricgrpc.WithEndpoint("localhost:4317"),  // Sidecar on localhost
    otlpmetricgrpc.WithInsecure(),
)
```

### Option 2: Prometheus Scraping (Legacy)

If your app already exposes Prometheus metrics, annotate your pod:

```yaml
apiVersion: v1
kind: Pod
metadata:
  annotations:
    prometheus.io/scrape: "true"
    prometheus.io/port: "8080"
    prometheus.io/path: "/metrics"
spec:
  containers:
  - name: app
    ports:
    - name: metrics
      containerPort: 8080
```

The OTel Collector will automatically discover and scrape annotated pods.

## Logs Integration

### Recommended: Auto-Send ERROR Logs Only

Send only ERROR logs via OTLP for trace correlation:

**Go (slog)**:
```go
type OTLPErrorHandler struct {
    exporter *otlploggrpc.Exporter
}

func (h *OTLPErrorHandler) Handle(ctx context.Context, r slog.Record) error {
    if r.Level >= slog.LevelError {
        // Send to OTLP via sidecar
        return h.exporter.Export(ctx, convertToLogRecord(r))
    }
    return nil
}
```

**Spring Boot (Logback)**:
```xml
<appender name="OTLP" class="io.opentelemetry.instrumentation.logback.appender.v1_0.OpenTelemetryAppender">
  <endpoint>http://localhost:4318/v1/logs</endpoint>  <!-- Sidecar on localhost -->
  <filter class="ch.qos.logback.classic.filter.ThresholdFilter">
    <level>ERROR</level>
  </filter>
</appender>
```

**Python**:
```python
from opentelemetry.sdk._logs import LoggerProvider
from opentelemetry.exporter.otlp.proto.grpc._log_exporter import OTLPLogExporter

# Only send ERROR and above
logging.getLogger().setLevel(logging.ERROR)

otlp_exporter = OTLPLogExporter(
    endpoint="localhost:4317",  # Sidecar on localhost
    insecure=True
)
```

**All other logs** are collected via stdout/stderr.

## Verifying Connection

### Test Telemetry Flow

```bash
# Check sidecar is receiving data (from app pod)
kubectl logs <pod-name> -c otel-sidecar -n <namespace>

# Check central collector is receiving data
kubectl logs -l app.kubernetes.io/name=opentelemetry-collector -n <namespace> | grep -i "traces"

# Check Data Prepper is processing
kubectl logs -l app.kubernetes.io/component=data-prepper -n <namespace>

# Query OpenSearch for traces
kubectl exec -n <namespace> <opensearch-pod> -- curl -sk -u admin:<password> \
  "https://localhost:9200/otel-v1-apm-span-*/_search?size=1&pretty"
```

### Common Issues

| Issue | Solution |
|-------|----------|
| Connection refused | Verify service name matches your release |
| No data in OpenSearch | Check Data Prepper logs for errors |
| High latency | Adjust batch processor settings |
| Missing traces | Check sampling configuration |

## Production Checklist

- [ ] Set `OTEL_SERVICE_NAME` for each service
- [ ] Configure appropriate sampling rate
- [ ] Enable only ERROR logs via OTLP (use filelog for rest)
- [ ] Add resource attributes (environment, version, etc.)
- [ ] Test rollback procedure
- [ ] Monitor collector resource usage
- [ ] Set up alerts for collector failures

## References

- [OpenTelemetry SDKs](https://opentelemetry.io/docs/instrumentation/)
- [OTLP Specification](https://opentelemetry.io/docs/reference/specification/protocol/)
- [Official Collector Chart](https://github.com/open-telemetry/opentelemetry-helm-charts)
