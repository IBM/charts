# Private Registry Configuration

## Overview

The observability chart supports deployment from private/air-gapped registries using the `global.imageRegistry` pattern common across HCL DevOps charts.

## Image Architecture

The observability stack uses two container images:

| Component | Default Public Image | Required in Private Registry |
|-----------|---------------------|------------------------------|
| OTel Collector | `otel/opentelemetry-collector-contrib:0.93.0` | `${REGISTRY}/otel-opentelemetry-collector-contrib:0.93.0` |
| Data Prepper | `opensearchproject/data-prepper:2.6.1` | `${REGISTRY}/opensearchproject-data-prepper:2.6.1` |

## Configuration Pattern

### Using Global Image Registry (Recommended)

Set `global.imageRegistry` in the parent chart and override OTel Collector repository:

```bash
REGISTRY="hclsoftware-docker-dev.us-artifactory1.nonprod.hclpnp.com/rational-devops"

helm upgrade --install devops-loop . \
  --set global.imageRegistry="${REGISTRY}" \
  --set global.observability.enabled=true \
  --set observability.otel-collector.image.repository="${REGISTRY}/otel-opentelemetry-collector-contrib" \
  -f values-platform-enable.yaml
```

**How it works:**
- **Data Prepper** (automatic): Template detects `global.imageRegistry` and uses:
  - `${global.imageRegistry}/${dataPrepper.image.name}:${tag}`
  - Becomes: `hclsoftware-docker-dev.us-artifactory1.nonprod.hclpnp.com/rational-devops/opensearchproject/data-prepper:2.6.1`
  
- **OTel Collector** (requires override): Official chart doesn't auto-detect `global.imageRegistry`, so explicitly set:
  - `--set observability.otel-collector.image.repository="${REGISTRY}/otel-opentelemetry-collector-contrib"`
  - Becomes: `hclsoftware-docker-dev.us-artifactory1.nonprod.hclpnp.com/rational-devops/otel-opentelemetry-collector-contrib:0.93.0`

### Development Override (Temporary)

For development when images aren't yet in the private registry:

```bash
# Override to use public registries
helm upgrade --install devops-loop . \
  --set global.imageRegistry="" \
  --set global.observability.enabled=true \
  --set observability.dataPrepper.image.repository="opensearchproject/data-prepper" \
  --set observability.otel-collector.image.repository="otel/opentelemetry-collector-contrib" \
  -f values-platform-enable.yaml
```

Or create a temporary values file `values-observability-dev.yaml`:

```yaml
# Development override - use public registries
global:
  imageRegistry: ""  # Empty = use public registries

observability:
  dataPrepper:
    image:
      repository: opensearchproject/data-prepper
      tag: "2.6.1"
  
  otel-collector:
    image:
      repository: otel/opentelemetry-collector-contrib
      tag: "0.93.0"
```

Then deploy:

```bash
helm upgrade --install devops-loop . \
  --set global.observability.enabled=true \
  -f values-platform-enable.yaml \
  -f values-observability-dev.yaml
```

## Preparing Images for Private Registry

### Step 1: Pull Public Images

```bash
# OTel Collector
docker pull otel/opentelemetry-collector-contrib:0.93.0

# Data Prepper
docker pull opensearchproject/data-prepper:2.6.1
```

### Step 2: Tag for Private Registry

```bash
REGISTRY="hclsoftware-docker-dev.us-artifactory1.nonprod.hclpnp.com/rational-devops"

# OTel Collector - tag as required by chart
docker tag \
  otel/opentelemetry-collector-contrib:0.93.0 \
  ${REGISTRY}/otel-opentelemetry-collector-contrib:0.93.0

# Data Prepper - tag as required by chart
docker tag \
  opensearchproject/data-prepper:2.6.1 \
  ${REGISTRY}/opensearchproject/data-prepper:2.6.1
```

### Step 3: Push to Private Registry

```bash
# Login to your registry
docker login ${REGISTRY}

# Push OTel Collector
docker push ${REGISTRY}/otel-opentelemetry-collector-contrib:0.93.0

# Push Data Prepper
docker push ${REGISTRY}/opensearchproject/data-prepper:2.6.1
```

### Step 4: Verify Images

```bash
# List images in registry (if using Artifactory)
curl -u ${USER}:${PASSWORD} \
  "https://${REGISTRY}/v2/_catalog"

# Check specific image tags
curl -u ${USER}:${PASSWORD} \
  "https://${REGISTRY}/v2/otel-opentelemetry-collector-contrib/tags/list"

curl -u ${USER}:${PASSWORD} \
  "https://${REGISTRY}/v2/opensearchproject/data-prepper/tags/list"
```

## Image Pull Secrets (If Required)

If your private registry requires authentication:

### Create Image Pull Secret

```bash
kubectl create secret docker-registry observability-registry-secret \
  --docker-server=${REGISTRY} \
  --docker-username=${USER} \
  --docker-password=${PASSWORD} \
  --namespace=devops-loop
```

### Configure Chart to Use Secret

Add to your values:

```yaml
observability:
  # For Data Prepper
  dataPrepper:
    imagePullSecrets:
      - name: observability-registry-secret
  
  # For OTel Collector (official chart)
  otel-collector:
    imagePullSecrets:
      - name: observability-registry-secret
```

Or via command line:

```bash
helm upgrade --install devops-loop . \
  --set global.imageRegistry="${REGISTRY}" \
  --set observability.dataPrepper.imagePullSecrets[0].name=observability-registry-secret \
  --set observability.otel-collector.imagePullSecrets[0].name=observability-registry-secret \
  --set global.observability.enabled=true \
  -f values-platform-enable.yaml
```

## Automated Image Sync Script

For continuous sync of public images to private registry:

```bash
#!/bin/bash
# sync-observability-images.sh

set -e

REGISTRY="${IMAGE_REGISTRY:-hclsoftware-docker-dev.us-artifactory1.nonprod.hclpnp.com/rational-devops}"

echo "Syncing observability images to ${REGISTRY}..."

# Images to sync
images=(
  "otel/opentelemetry-collector-contrib:0.93.0:otel-opentelemetry-collector-contrib:0.93.0"
  "opensearchproject/data-prepper:2.6.1:opensearchproject/data-prepper:2.6.1"
)

for image_spec in "${images[@]}"; do
  IFS=':' read -r src_repo src_tag dst_repo dst_tag <<< "$image_spec"
  src="${src_repo}:${src_tag}"
  dst="${REGISTRY}/${dst_repo}:${dst_tag}"
  
  echo "Processing: ${src} -> ${dst}"
  
  docker pull "${src}"
  docker tag "${src}" "${dst}"
  docker push "${dst}"
  
  echo "✓ Synced ${dst}"
done

echo "All images synced successfully!"
```

Usage:

```bash
chmod +x sync-observability-images.sh
./sync-observability-images.sh
```

## Verification After Deployment

### Check Pod Images

```bash
# OTel Collector pods
kubectl get pods -l app.kubernetes.io/name=opentelemetry-collector \
  -n devops-loop \
  -o jsonpath='{range .items[*]}{.metadata.name}{"\t"}{.spec.containers[0].image}{"\n"}{end}'

# Data Prepper pods
kubectl get pods -l app.kubernetes.io/component=data-prepper \
  -n devops-loop \
  -o jsonpath='{range .items[*]}{.metadata.name}{"\t"}{.spec.containers[0].image}{"\n"}{end}'
```

Expected output when using private registry:

```
devops-loop-otel-collector-xxxxx   hclsoftware-docker-dev.us-artifactory1.nonprod.hclpnp.com/rational-devops/otel-opentelemetry-collector-contrib:0.93.0
devops-loop-observability-data-prepper-xxxxx   hclsoftware-docker-dev.us-artifactory1.nonprod.hclpnp.com/rational-devops/opensearchproject/data-prepper:2.6.1
```

### Check Image Pull Events

```bash
# Look for ImagePull events
kubectl get events -n devops-loop \
  --field-selector involvedObject.kind=Pod \
  --sort-by='.lastTimestamp' | grep -i image
```

## Troubleshooting

### ImagePullBackOff Error

**Symptom:**
```bash
kubectl get pods -n devops-loop
# Shows: ImagePullBackOff or ErrImagePull
```

**Diagnosis:**

```bash
# Check pod details
kubectl describe pod <pod-name> -n devops-loop | grep -A 10 Events

# Common errors:
# - "unauthorized: authentication required"  → Need imagePullSecret
# - "not found: manifest unknown"           → Image not in registry
# - "connection refused"                     → Registry URL wrong
```

**Solutions:**

1. **Authentication Error**: Create and configure imagePullSecret (see above)

2. **Image Not Found**: Verify image exists in registry:
   ```bash
   docker pull ${REGISTRY}/otel-opentelemetry-collector-contrib:0.93.0
   ```

3. **Wrong Registry Path**: Check `global.imageRegistry` matches your registry:
   ```bash
   helm get values devops-loop -n devops-loop | grep imageRegistry
   ```

### Slow Image Pull

Large images (OTel Collector ~200MB, Data Prepper ~500MB) may take time on first pull.

**Monitor progress:**

```bash
# Watch pod startup
kubectl get pods -n devops-loop -w

# Check node image cache
kubectl get nodes -o jsonpath='{range .items[*]}{.metadata.name}{"\n"}{range .status.images[*]}{"\t"}{.names[0]}{"\n"}{end}{end}' \
  | grep -E 'opentelemetry-collector|data-prepper'
```

## Production Checklist

- [ ] **Images uploaded** to private registry
- [ ] **Image tags** match chart values (0.93.0, 2.6.1)
- [ ] **Registry path** correct in `global.imageRegistry`
- [ ] **ImagePullSecret** created (if authentication required)
- [ ] **Network access** from cluster to registry verified
- [ ] **Automated sync** set up for future updates
- [ ] **Development overrides** removed from values
- [ ] **Deployment tested** with `--dry-run` first
- [ ] **Pod images** verified after deployment
- [ ] **Backup images** stored locally in case of registry issues

## Example Production Deployment

```bash
#!/bin/bash
# deploy-observability-prod.sh

set -e

NAMESPACE="devops-loop"
RELEASE="devops-loop"
REGISTRY="hclsoftware-docker-dev.us-artifactory1.nonprod.hclpnp.com/rational-devops"

echo "Deploying observability with private registry: ${REGISTRY}"

# Dry run first
helm upgrade --install ${RELEASE} . \
  --namespace ${NAMESPACE} \
  --set global.imageRegistry="${REGISTRY}" \
  --set global.observability.enabled=true \
  --set observability.otel-collector.image.repository="${REGISTRY}/otel-opentelemetry-collector-contrib" \
  -f values-platform-enable.yaml \
  -f values-images.yaml \
  --dry-run --debug

read -p "Proceed with deployment? (y/N): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
  helm upgrade --install ${RELEASE} . \
    --namespace ${NAMESPACE} \
    --set global.imageRegistry="${REGISTRY}" \
    --set global.observability.enabled=true \
    --set observability.otel-collector.image.repository="${REGISTRY}/otel-opentelemetry-collector-contrib" \
    -f values-platform-enable.yaml \
    -f values-images.yaml \
    --wait --timeout=10m
  
  echo "Verifying deployment..."
  kubectl get pods -n ${NAMESPACE} -l app.kubernetes.io/part-of=observability
  
  echo "✓ Deployment complete!"
fi
```

## Migration Path

### Phase 1: Development (Use Public Registries)

```bash
# Development/testing with public images
helm upgrade --install devops-loop . \
  --set global.imageRegistry="" \
  --set global.observability.enabled=true \
  -f values-observability-dev.yaml
```

### Phase 2: Staging (Migrate to Private Registry)

```bash
# Run sync script
./sync-observability-images.sh

# Deploy with private registry
helm upgrade --install devops-loop . \
  --set global.imageRegistry="${REGISTRY}" \
  --set global.observability.enabled=true \
  --set observability.otel-collector.image.repository="${REGISTRY}/otel-opentelemetry-collector-contrib" \
  -f values-platform-enable.yaml
```

### Phase 3: Production (Enforce Private Registry)

```yaml
# values-production.yaml
global:
  imageRegistry: "hclsoftware-docker-dev.us-artifactory1.nonprod.hclpnp.com/rational-devops"
  # No override - enforces private registry
```

```bash
helm upgrade --install devops-loop . \
  -f values-production.yaml \
  -f values-platform-enable.yaml
```
