{{/*
Expand the name of the chart.
*/}}
{{- define "observability.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "observability.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "observability.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "observability.labels" -}}
helm.sh/chart: {{ include "observability.chart" . }}
{{ include "observability.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "observability.selectorLabels" -}}
app.kubernetes.io/name: {{ include "observability.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "observability.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "observability.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Get OpenSearch host - auto-discover from parent chart or use override
*/}}
{{- define "observability.opensearchHost" -}}
{{- if .Values.opensearch.host }}
{{- .Values.opensearch.host }}
{{- else }}
{{- printf "%s-ibm-devopsplan-prod-opensearch" .Release.Name }}
{{- end }}
{{- end }}

{{/*
Get OpenSearch URL
*/}}
{{- define "observability.opensearchUrl" -}}
{{- printf "%s://%s:%d" .Values.opensearch.protocol (include "observability.opensearchHost" .) (int .Values.opensearch.port) }}
{{- end }}

{{/*
Get OpenSearch credentials secret
*/}}
{{- define "observability.opensearchSecret" -}}
{{- if .Values.opensearch.existingSecret }}
{{- .Values.opensearch.existingSecret }}
{{- else }}
{{- printf "%s-ibm-devopsplan-prod-opensearch" .Release.Name }}
{{- end }}
{{- end }}

{{/* Override upstream configName helper (v0.97.1 doesn't tpl-evaluate existingName). */}}
{{- define "opentelemetry-collector.configName" -}}
{{- include "observability.otelConfigMapName" . -}}
{{- end -}}

{{/* Resolve monitoring.opensearch.enabled (default: true). */}}
{{- define "observability.opensearchIngestionEnabled" -}}
{{- $m := .Values.monitoring | default dict -}}
{{- $os := $m.opensearch | default dict -}}
{{- if hasKey $os "enabled" -}}
  {{- ternary "true" "false" (ne (toString $os.enabled) "false") -}}
{{- else -}}
  {{- "true" -}}
{{- end -}}
{{- end -}}

{{/* OpenSearch-bound exporter keys, excluded when ingestion is disabled.
     Keep in sync with otelCollector.exporters keys that target OpenSearch. */}}
{{- define "observability.opensearchExporterKeys" -}}
dataprepper: true
opensearch: true
{{- end -}}

{{/* Resolve global.observability.blackbox.enabled (default: false). */}}
{{- define "observability.blackboxEnabled" -}}
{{- $g := (.Values.global).observability | default dict -}}
{{- $bb := $g.blackbox | default dict -}}
{{- if hasKey $bb "enabled" -}}
  {{- ternary "true" "false" (ne (toString $bb.enabled) "false") -}}
{{- else -}}
  {{- "false" -}}
{{- end -}}
{{- end -}}

{{/* Resolve global.observability.blackbox.persistence.enabled (default: false). */}}
{{- define "observability.blackboxPersistenceEnabled" -}}
{{- $g := (.Values.global).observability | default dict -}}
{{- $bb := ($g.blackbox | default dict).persistence | default dict -}}
{{- if hasKey $bb "enabled" -}}
  {{- ternary "true" "false" (ne (toString $bb.enabled) "false") -}}
{{- else -}}
  {{- "false" -}}
{{- end -}}
{{- end -}}

{{/* --- OTel Collector config helpers --- */}}

{{/* ConfigMap name matching upstream chart's expected naming convention. */}}
{{- define "observability.otelConfigMapName" -}}
{{- printf "%s-otel-collector" .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/* Render enabled exporters map. */}}
{{- define "observability.otelExportersMap" -}}
{{- $out := dict -}}
{{- $osEnabled := eq (include "observability.opensearchIngestionEnabled" .) "true" -}}
{{- $bbEnabled := eq (include "observability.blackboxEnabled" .) "true" -}}
{{- $blocked := include "observability.opensearchExporterKeys" . | fromYaml -}}
{{- range $key, $exp := .Values.otelCollector.exporters -}}
  {{- $on := $exp.enabled -}}
  {{- if and (not $on) $bbEnabled (eq $key "file") -}}
    {{- $on = true -}}
  {{- end -}}
  {{- if $on -}}
    {{- $skip := and (not $osEnabled) (hasKey $blocked $key) -}}
    {{- if not $skip -}}
      {{- $name := default $key $exp.name -}}
      {{- $cfg := $exp.config | default dict -}}
      {{- $rendered := tpl (toYaml $cfg) $ | fromYaml -}}
      {{- $_ := set $out $name $rendered -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- toYaml $out -}}
{{- end -}}

{{/* Map exporter keys to their OTel names. */}}
{{- define "observability.otelExporterNameMap" -}}
{{- $out := dict -}}
{{- $osEnabled := eq (include "observability.opensearchIngestionEnabled" .) "true" -}}
{{- $bbEnabled := eq (include "observability.blackboxEnabled" .) "true" -}}
{{- $blocked := include "observability.opensearchExporterKeys" . | fromYaml -}}
{{- range $key, $exp := .Values.otelCollector.exporters -}}
  {{- $on := $exp.enabled -}}
  {{- if and (not $on) $bbEnabled (eq $key "file") -}}
    {{- $on = true -}}
  {{- end -}}
  {{- if $on -}}
    {{- $skip := and (not $osEnabled) (hasKey $blocked $key) -}}
    {{- if not $skip -}}
      {{- $_ := set $out $key (default $key $exp.name) -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- toYaml $out -}}
{{- end -}}

{{/* Render the full OTel Collector config. */}}
{{- define "observability.otelConfig" -}}
{{- $base := index .Values "otel-collector" "config" | deepCopy -}}
{{- $exps := .Values.otelCollector.exporters -}}
{{- $osIngestion := eq (include "observability.opensearchIngestionEnabled" .) "true" -}}
{{- if and $osIngestion (hasKey $exps "opensearch") (index $exps "opensearch" "enabled") -}}
  {{- $extMap := ternary (index $base "extensions") dict (hasKey $base "extensions") -}}
  {{- if not (hasKey $extMap "basicauth/opensearch") -}}
    {{- $_ := set $extMap "basicauth/opensearch" (dict "client_auth" (dict "username" "${env:OS_USERNAME}" "password" "${env:OS_PASSWORD}")) -}}
    {{- $_ := set $base "extensions" $extMap -}}
  {{- end -}}
  {{- $svc := index $base "service" | default dict -}}
  {{- $extList := index $svc "extensions" | default list -}}
  {{- if not (has "basicauth/opensearch" $extList) -}}
    {{- $extList = append $extList "basicauth/opensearch" -}}
    {{- $_ := set $svc "extensions" $extList -}}
    {{- $_ := set $base "service" $svc -}}
  {{- end -}}
{{- end -}}
{{/* Merge raw and declarative exporters */}}
{{- $rawExporters := ternary (index $base "exporters") dict (hasKey $base "exporters") -}}
{{- $declExporters := include "observability.otelExportersMap" . | fromYaml -}}
{{- $mergedExporters := merge $declExporters $rawExporters -}}
{{- $_ := set $base "exporters" $mergedExporters -}}
{{/* Build pipelines from otelCollector.pipelines */}}
{{- $nameMap := include "observability.otelExporterNameMap" . | fromYaml -}}
{{- $bbOn := eq (include "observability.blackboxEnabled" .) "true" -}}
{{- $service := index $base "service" | default dict -}}
{{- $pipelines := index $service "pipelines" | default dict -}}
{{- $defaultReceivers := list "otlp" -}}
{{- $defaultProcessors := list "memory_limiter" "k8sattributes" "resource" "batch" -}}
{{- range $signal, $wiring := .Values.otelCollector.pipelines -}}
  {{- $base_pipe := ternary (index $pipelines $signal) dict (hasKey $pipelines $signal) -}}
  {{- $names := list -}}
  {{- range $key := $wiring.exporters -}}
    {{- if hasKey $nameMap $key -}}
      {{- $names = append $names (index $nameMap $key) -}}
    {{- end -}}
  {{- end -}}
  {{- if and $bbOn (hasKey $nameMap "file") -}}
    {{- $fileName := index $nameMap "file" -}}
    {{- if not (has $fileName $names) -}}
      {{- $names = append $names $fileName -}}
    {{- end -}}
  {{- end -}}
  {{- $_ := set $base_pipe "exporters" $names -}}
  {{- if not (hasKey $base_pipe "receivers") -}}
    {{- $_ := set $base_pipe "receivers" $defaultReceivers -}}
  {{- end -}}
  {{- if not (hasKey $base_pipe "processors") -}}
    {{- $_ := set $base_pipe "processors" $defaultProcessors -}}
  {{- end -}}
  {{- $_ := set $pipelines $signal $base_pipe -}}
{{- end -}}
{{- $_ := set $service "pipelines" $pipelines -}}
{{- $_ := set $base "service" $service -}}
{{- tpl (toYaml $base) . -}}
{{- end -}}

{{/* SHA256 checksum of rendered config for change detection. */}}
{{- define "observability.otelConfigChecksum" -}}
{{- include "observability.otelConfig" . | sha256sum -}}
{{- end -}}
