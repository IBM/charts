{{/*
CDC Access Server HELM Chart Helper Templates
Mirrors the pattern of the engine chart (_helpers.tpl in cdc-replication).
*/}}

{{/*
Return the chart name for use in labels.
This is always the chart name (e.g., "cdc-access-server").
*/}}
{{- define "cdc-as.name" -}}
{{- .Chart.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
Uses Release.Name directly as the resource name identifier.
Chart name is reflected in labels (app.kubernetes.io/name), not resource names.
This keeps resource names short and user-controlled.
*/}}
{{- define "cdc-as.fullname" -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "cdc-as.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Return the container image reference.
Uses digest when set (for pinned/air-gapped deployments), otherwise tag.
Applies common.imagePullPrefix from values.yaml.
*/}}
{{- define "cdc-as.image" -}}
{{- $fullImage := printf "%s/%s" .Values.common.imagePullPrefix .Values.image.name -}}
{{- if .Values.image.digest -}}
{{- printf "%s@%s" $fullImage .Values.image.digest -}}
{{- else -}}
{{- printf "%s:%s" $fullImage .Values.image.tag -}}
{{- end -}}
{{- end -}}

{{/*
Common labels — applied to all chart resources (StatefulSet, Service, ServiceAccount).
app.kubernetes.io/component is fixed to "access-server" to distinguish this workload
from engine pods when both are deployed in the same namespace.
cdc.ibm.com/license-type carries the IBM license offering for IBM-scoped label queries.
cdc.ibm.com/product-type is intentionally omitted — the Access Server has no product-type concept.
license-accepted is intentionally omitted: cdc-as.validateLicense fails the install if not
true, so acceptance is guaranteed by the time any resource is created.
*/}}
{{- define "cdc-as.labels" -}}
app.kubernetes.io/name: {{ include "cdc-as.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/component: access-server
cdc.ibm.com/license-type: {{ .Values.license.type | quote }}
{{- end -}}

{{/*
PVC labels — applied to volumeClaimTemplate metadata.
Intentionally omits app.kubernetes.io/version (PVC labels are immutable;
version changes on every release would require PVC deletion to update).
cdc.ibm.com/license-type is omitted: license type can change on upgrade/renewal and PVC
labels cannot be updated without deleting the PVC, which would destroy the user store.
*/}}
{{- define "cdc-as.pvcLabels" -}}
app.kubernetes.io/name: {{ include "cdc-as.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: access-server
{{- end -}}

{{/*
Selector labels — used in spec.selector.matchLabels and pod template labels.
Must remain stable across upgrades (changing selector labels requires delete+recreate).
*/}}
{{- define "cdc-as.selectorLabels" -}}
app.kubernetes.io/name: {{ include "cdc-as.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/*
Create the name of the service account to use.
*/}}
{{- define "cdc-as.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
{{- default (include "cdc-as.fullname" .) .Values.serviceAccount.name -}}
{{- else -}}
{{- default "default" .Values.serviceAccount.name -}}
{{- end -}}
{{- end -}}

{{/*
=============================================================================
VALIDATION HELPERS
=============================================================================
*/}}

{{/*
Validate license acceptance and type.
*/}}
{{- define "cdc-as.validateLicense" -}}
{{- if not .Values.license.accept -}}
{{- fail "\n\nERROR: License must be accepted before deployment\n\nYou must explicitly accept the license terms:\n  license:\n    accept: true\n    type: IDRAI\n\n  Or via command line:\n  helm install cdc-as ./cdc-access-server \\\n    --set license.accept=true \\\n    --set license.type=IDRAI\n\nReview license terms at:\n  https://www.ibm.com/software/sla/sladb.nsf\n" -}}
{{- end -}}
{{- if not .Values.license.type -}}
{{- fail "\n\nERROR: License type must be specified\n\nValid license types:\n  - IDRAI  (IBM Data Replication AI Edition)\n  - IDRAIZ (IBM Data Replication AI Edition for z/OS)\n\nExample:\n  license:\n    accept: true\n    type: IDRAI\n\n  Or via command line:\n  helm install cdc-as ./cdc-access-server \\\n    --set license.accept=true \\\n    --set license.type=IDRAI\n" -}}
{{- end -}}
{{- $validLicenses := list "IDRAI" "IDRAIZ" -}}
{{- if not (has .Values.license.type $validLicenses) -}}
{{- fail (printf "\n\nERROR: Invalid license type '%s'\n\nValid license types:\n  - IDRAI  (IBM Data Replication AI Edition)\n  - IDRAIZ (IBM Data Replication AI Edition for z/OS)\n\nExample:\n  helm install cdc-as ./cdc-access-server \\\n    --set license.accept=true \\\n    --set license.type=IDRAI\n" .Values.license.type) -}}
{{- end -}}
{{- end -}}

{{/*
Validate persistence configuration.
*/}}
{{- define "cdc-as.validatePersistence" -}}
{{- if not .Values.persistence.blockStorageClass -}}
{{- fail "\n\nERROR: persistence.blockStorageClass is required\n\nThe Access Server user store requires persistent storage. Specify the storage class:\n  persistence:\n    blockStorageClass: nfs-client\n\n  Or via command line:\n  helm install cdc-as ./cdc-access-server \\\n    --set persistence.blockStorageClass=nfs-client\n\nRun `kubectl get storageclass` to list available classes in your cluster.\n" -}}
{{- end -}}
{{- if not .Values.persistence.size -}}
{{- fail "\n\nERROR: persistence.size is required\n\nSpecify the volume size:\n  persistence:\n    size: 10Gi\n" -}}
{{- end -}}
{{- if not (regexMatch "^[0-9]+(Gi|Mi|Ti)$" .Values.persistence.size) -}}
{{- fail (printf "\n\nERROR: Invalid persistence.size '%s'\n\nSize must be specified with unit (Gi, Mi, or Ti). Example: 10Gi\n" .Values.persistence.size) -}}
{{- end -}}
{{- end -}}

{{/*
Validate resource requests do not exceed limits.
Normalises memory to Mi before comparing so cross-unit pairs (e.g. 8Gi
requests vs 512Mi limit) are caught correctly.
*/}}
{{- define "cdc-as.validateResources" -}}
{{- /* Guard: resources: null in an override file wipes all values.yaml defaults. */ -}}
{{- if not .Values.resources -}}
{{- fail "ERROR: resources is null. This happens when resources: or resources: ~ appears in your values file with no sub-keys. Either remove the resources: key entirely to use the chart defaults, or provide explicit sub-key configuration. Refer to the chart documentation for supported configuration options." -}}
{{- end -}}
{{- $reqRaw := .Values.resources.requests.memory -}}
{{- $limRaw := .Values.resources.limits.memory -}}
{{- $reqMi := 0 -}}
{{- $limMi := 0 -}}
{{- if hasSuffix "Gi" $reqRaw -}}
  {{- $reqMi = mul (trimSuffix "Gi" $reqRaw | atoi) 1024 -}}
{{- else if hasSuffix "Mi" $reqRaw -}}
  {{- $reqMi = trimSuffix "Mi" $reqRaw | atoi -}}
{{- end -}}
{{- if hasSuffix "Gi" $limRaw -}}
  {{- $limMi = mul (trimSuffix "Gi" $limRaw | atoi) 1024 -}}
{{- else if hasSuffix "Mi" $limRaw -}}
  {{- $limMi = trimSuffix "Mi" $limRaw | atoi -}}
{{- end -}}
{{- if and (gt $reqMi 0) (gt $limMi 0) (gt $reqMi $limMi) -}}
{{- fail (printf "ERROR: Memory requests (%s) cannot exceed limits (%s)" $reqRaw $limRaw) -}}
{{- end -}}
{{- $requestsCPU := .Values.resources.requests.cpu | trimSuffix "m" | float64 -}}
{{- $limitsCPU := .Values.resources.limits.cpu | trimSuffix "m" | float64 -}}
{{- if gt $requestsCPU $limitsCPU -}}
{{- fail (printf "ERROR: CPU requests (%s) cannot exceed limits (%s)" .Values.resources.requests.cpu .Values.resources.limits.cpu) -}}
{{- end -}}
{{- end -}}

{{/*
Validate the podSpec section is not null.
podSpec: ~ wipes hostNetwork, hostPID, and hostIPC defaults (all false),
causing a nil-pointer panic when the statefulset template accesses these fields.
*/}}
{{- define "cdc-as.validatePodSpec" -}}
{{- if not .Values.podSpec -}}
{{- fail "ERROR: podSpec is null. This happens when podSpec: or podSpec: ~ appears in your values file with no sub-keys. Either remove the podSpec: key entirely to use the chart defaults, or provide explicit sub-key configuration. Refer to the chart documentation for supported configuration options." -}}
{{- end -}}
{{- end -}}

{{/*
Validate the podSecurityContext section is not null.
podSecurityContext: ~ wipes runAsNonRoot, runAsUser, and fsGroup defaults,
causing a nil-pointer panic when the statefulset template accesses these fields.
*/}}
{{- define "cdc-as.validatePodSecurityContext" -}}
{{- if not .Values.podSecurityContext -}}
{{- fail "ERROR: podSecurityContext is null. This happens when podSecurityContext: or podSecurityContext: ~ appears in your values file with no sub-keys. Either remove the podSecurityContext: key entirely to use the chart defaults, or provide explicit sub-key configuration. Refer to the chart documentation for supported configuration options." -}}
{{- end -}}
{{- end -}}

{{/*
Validate the securityContext section is not null.
securityContext: ~ causes toYaml to render "null" as the container securityContext,
silently dropping all security constraints (privileged: false,
allowPrivilegeEscalation: false, capabilities.drop: ALL) with no error.
*/}}
{{- define "cdc-as.validateSecurityContext" -}}
{{- if not .Values.securityContext -}}
{{- fail "ERROR: securityContext is null. This happens when securityContext: or securityContext: ~ appears in your values file with no sub-keys. Either remove the securityContext: key entirely to use the chart defaults, or provide explicit sub-key configuration. Refer to the chart documentation for supported configuration options." -}}
{{- end -}}
{{- end -}}

{{/*
Validate the serviceAccount section is not null.
A plain `serviceAccount:` or `serviceAccount: ~` in an override file wipes all
values.yaml defaults, causing .Values.serviceAccount.create to be nil and the
serviceAccountName helper to panic.
*/}}
{{- define "cdc-as.validateServiceAccount" -}}
{{- /* Guard: serviceAccount: null in an override file wipes all values.yaml defaults. */ -}}
{{- if not .Values.serviceAccount -}}
{{- fail "ERROR: serviceAccount is null. This happens when serviceAccount: or serviceAccount: ~ appears in your values file with no sub-keys. Either remove the serviceAccount: key entirely to use the chart defaults, or provide explicit sub-key configuration. Refer to the chart documentation for supported configuration options." -}}
{{- end -}}
{{- end -}}

{{/*
Validate TLS configuration.
*/}}
{{- define "cdc-as.validateTLS" -}}
{{- /* Guard: tls: null in an override file wipes all values.yaml defaults. */ -}}
{{- if not .Values.tls -}}
{{- fail "ERROR: tls is null. This happens when tls: or tls: ~ appears in your values file with no sub-keys. Either remove the tls: key entirely to use the chart defaults, or provide explicit sub-key configuration. Refer to the chart documentation for supported configuration options." -}}
{{- end -}}
{{- if .Values.tls.enabled -}}
{{- if not .Values.tls.secretName -}}
{{- fail "ERROR: tls.enabled is true but tls.secretName is not set. Set tls.secretName to the name of the Kubernetes Secret holding the keystore and truststore." -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
=============================================================================
MASTER VALIDATION
=============================================================================
*/}}

{{/*
Master validation — orchestrates all validation checks.
Usage: {{- include "cdc-as.validate" . -}} at the top of each template.
*/}}
{{- define "cdc-as.validate" -}}
{{- include "cdc-as.validateLicense" . -}}
{{- include "cdc-as.validatePersistence" . -}}
{{- include "cdc-as.validateResources" . -}}
{{- include "cdc-as.validatePodSpec" . -}}
{{- include "cdc-as.validatePodSecurityContext" . -}}
{{- include "cdc-as.validateSecurityContext" . -}}
{{- include "cdc-as.validateServiceAccount" . -}}
{{- include "cdc-as.validateTLS" . -}}
{{- end -}}
