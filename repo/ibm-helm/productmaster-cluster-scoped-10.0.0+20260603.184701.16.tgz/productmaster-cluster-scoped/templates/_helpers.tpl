{{/*
Expand the name of the chart.
*/}}

{{/*
ibm-productmaster: Common name template
*/}}
{{- define "ibm-productmaster.name" -}}
{{- default .Values.nameOverride .Chart.Name | trunc 63 | trimSuffix "-" -}}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "ibm-productmaster.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains .Release.Name $name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Chart name and version
*/}}
{{- define "ibm-productmaster.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "ibm-productmaster.labels" -}}
helm.sh/chart: {{ include "ibm-productmaster.chart" . }}
{{ include "ibm-productmaster.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "ibm-productmaster.selectorLabels" -}}
app.kubernetes.io/name: {{ include "ibm-productmaster.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Service account name


{{- define "ibm-productmaster.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default .Values.serviceAccount.name (include "ibm-productmaster.fullname" .) }}
{{- else }}
{{- default .Values.serviceAccount.name "default" }}
{{- end }}
{{- end }}
*/}}

{{/*
Generate the ServiceAccount name:
- If .Values.productmaster.serviceAccountName is provided, use it.
- Else, use "<chartName>-sa"
*/}}
{{- define "ibm-productmaster.serviceAccountName" -}}
{{- if .Values.global.serviceAccountName -}}
{{- .Values.global.serviceAccountName -}}
{{- else -}}
{{- printf "%s-sa" .Chart.Name -}}
{{- end -}}
{{- end }}



{{/*
Generate ClusterRole name for productmaster CRD
*/}}
{{- define "ibm-productmaster.crdRoleName" -}}
{{- $crd := .Values.productmaster.crd.productmasterName | default "productmaster" -}}
{{- $ver := .Values.productmaster.crd.productmasterVersion | default "v1" -}}
{{- $ns := .Values.global.operatorNamespace | default .Release.Namespace -}}
{{- printf "%s-%s-%s-role" $crd $ver $ns }}
{{- end }}

{{/*
Generate ClusterRole name for productmasterservice CRD
*/}}
{{- define "ibm-productmasterservice.crdRoleName" -}}
{{- $crd := .Values.productmaster.crd.productmasterserviceName | default "productmasterservice" -}}
{{- $ver := .Values.productmaster.crd.productmasterserviceVersion | default "v1alpha1" -}}
{{- $ns := .Values.global.operatorNamespace | default .Release.Namespace -}}
{{- printf "%s-%s-%s-role" $crd $ver $ns }}
{{- end }}

