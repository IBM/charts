{{/*
Expand the name of the chart.
Defaults to openrag-cpd-operator unless nameOverride is provided.
*/}}
{{- define "ibm-openrag-operator.name" -}}
{{- default "openrag-cpd-operator" .Values.ibmWxdOpenrag.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "ibm-openrag-oss-operator.name" -}}
{{- default "openrag-cpd-oss-operator" .Values.ibmWxdOpenrag.oss.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Operator image pull prefix priority:
1. ibmWxdOpenrag.devImagePullPrefix
2. global.imagePullPrefix
3. default: icr.io
*/}}
{{- define "ibm-openrag-operator.operatorImagePullPrefix" -}}
{{- if .Values.ibmWxdOpenrag.devImagePullPrefix -}}
{{- .Values.ibmWxdOpenrag.devImagePullPrefix -}}
{{- else if .Values.global.imagePullPrefix -}}
{{- .Values.global.imagePullPrefix -}}
{{- else -}}
icr.io
{{- end -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
Do not derive from Chart.Name or Release.Name because split packaging
may rename the chart (for example, adding -cluster-scoped), while
Kubernetes resource names must remain canonical.
*/}}
{{- define "ibm-openrag-operator.fullname" -}}
{{- if .Values.ibmWxdOpenrag.fullnameOverride }}
{{- .Values.ibmWxdOpenrag.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- include "ibm-openrag-operator.name" . }}
{{- end }}
{{- end }}

{{- define "ibm-openrag-oss-operator.fullname" -}}
{{- if .Values.ibmWxdOpenrag.oss.fullnameOverride -}}
{{- .Values.ibmWxdOpenrag.oss.fullnameOverride }}
{{- else -}}
openrag-oss-cpd-operator
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "ibm-openrag-operator.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "ibm-openrag-operator.labels" -}}
helm.sh/chart: {{ include "ibm-openrag-operator.chart" . }}
component-id: ibm-wxd-openrag
{{ include "ibm-openrag-operator.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/component: operator
{{- end }}

{{/*
Selector labels
*/}}
{{- define "ibm-openrag-operator.selectorLabels" -}}
app.kubernetes.io/name: {{ include "ibm-openrag-operator.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "ibm-openrag-oss-operator.selectorLabels" -}}
app.kubernetes.io/name: {{ include "ibm-openrag-oss-operator.name" . }}
app.kubernetes.io/intance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "ibm-openrag-operator.serviceAccountName" -}}
{{- default "ibm-openrag-serviceaccount" .Values.ibmWxdOpenrag.operator.serviceAccount.name }}
{{- end }}

{{- define "ibm-openrag-oss-operator.serviceAccountName" -}}
{{ .Values.ibmWxdOpenrag.oss.serviceAccount.name | default "openrag-oss-serviceaccount" }}
{{- end }}

{{/*
IBM Product metering annotations
*/}}
{{- define "ibm-openrag-operator.meteringAnnotations" -}}
productName: {{ .Values.ibmWxdOpenrag.productMetering.productName | quote }}
productVersion: {{ .Values.ibmWxdOpenrag.productMetering.productVersion | quote }}
productMetric: {{ .Values.ibmWxdOpenrag.productMetering.productMetric | quote }}
productChargedContainers: {{ .Values.ibmWxdOpenrag.productMetering.productChargedContainers | quote }}
cloudpakId: {{ .Values.ibmWxdOpenrag.productMetering.cloudpakId | quote }}
cloudpakName: {{ .Values.ibmWxdOpenrag.productMetering.cloudpakName | quote }}
cloudpakVersion: {{ .Values.ibmWxdOpenrag.productMetering.cloudpakVersion | quote }}
{{- end }}

{{/*
IBM Cloud Pak for Data required labels (for RBAC resources - no 'name' label)
*/}}
{{- define "ibm-openrag-operator.cpdLabels" -}}
component-id: {{ .Chart.Name }}
icpdsupport/addOnId: {{ .Values.ibmWxdOpenrag.addOnId }}
{{- end }}

{{/*
IBM Cloud Pak for Data required labels for Deployments (includes 'name' label)
*/}}
{{- define "ibm-openrag-operator.cpdLabelsWithName" -}}
component-id: {{ .Chart.Name }}
icpdsupport/addOnId: {{ .Values.ibmWxdOpenrag.addOnId }}
name: {{ include "ibm-openrag-operator.fullname" . }}
{{- end }}

{{/*
Namespace for operator deployment
*/}}
{{- define "ibm-openrag-operator.namespace" -}}
{{- if .Values.ibmWxdOpenrag.namespace }}
{{- .Values.ibmWxdOpenrag.namespace }}
{{- else }}
{{- .Release.Namespace }}
{{- end }}
{{- end }}

{{/*
Watch namespace configuration
*/}}
{{- define "ibm-openrag-operator.watchNamespace" -}}
{{- if .Values.ibmWxdOpenrag.watchNamespace }}
{{- .Values.ibmWxdOpenrag.watchNamespace }}
{{- else }}
{{- "" }}
{{- end }}
{{- end }}

{{/*
Get the image for the OSS operator
*/}}
{{- define "ibm-openrag-oss-operator.image" -}}
{{- if .Values.ibmWxdOpenrag.oss.devImagePullPrefix -}}
{{ .Values.ibmWxdOpenrag.oss.devImagePullPrefix }}/{{ .Values.ibmWxdOpenrag.oss.image.repository }}@{{ .Values.ibmWxdOpenrag.oss.image.archdigest.amd64 }}
{{- else -}}
{{ include "ibm-openrag-operator.operatorImagePullPrefix" . }}/{{ .Values.ibmWxdOpenrag.oss.image.repository }}@{{ .Values.ibmWxdOpenrag.oss.image.archdigest.amd64 }}
{{- end }}
{{- end }}
