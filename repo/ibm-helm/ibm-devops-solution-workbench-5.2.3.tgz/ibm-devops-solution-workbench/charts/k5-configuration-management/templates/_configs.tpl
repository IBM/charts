{{/* Print the configurations */}}
{{- define "configuration-management-configmapentries" -}}
audit.namespace: {{ .Release.Namespace }}

server.servlet.context-path: {{ .Values.global.k5.ingress.path }}{{ .Values.global.k5.endpoints.configurationManagement.path }}
springdoc.swagger-ui.config-url: {{ .Values.global.k5.ingress.path }}{{ .Values.global.k5.endpoints.configurationManagement.path }}/-/configuration-management/api-docs/swagger-config

# Rewrite configuration
de.knowis.cp.cfgm.deployment.protocol: {{ tpl .Values.deployment.protocol . | quote }}
de.knowis.cp.cfgm.deployment.hostname: "{{ tpl .Values.global.domain . }}{{ .Values.global.k5.ingress.path }}{{ .Values.global.k5.endpoints.configurationManagement.path }}"
de.knowis.cp.cfgm.deployment.basePath: '{{ .Values.global.k5.ingress.path }}{{ .Values.global.k5.endpoints.configurationManagement.path }}'

de.knowis.cp.cfgm.cors.allowedDomains: {{ include "configuration-management.cors-allowed-domains.builder" . | trimSuffix "," | quote }}

kubernetes.common.labels.instance: {{ .Release.Name | quote }}
kubernetes.common.labels.managedBy: {{ template "configuration-management.name" . }}
kubernetes.common.labels.name: {{ template "configuration-management.fullname" . }}

# Spring settings
{{- if .Values.configmap.spring }}
{{ tpl .Values.configmap.spring . }}
{{- end }}

# logging settings
{{- if .Values.configmap.logging }}
{{ tpl .Values.configmap.logging . }}
{{- end }}

# JWT claim names from global Helm; bound by platform-common as security.jwt.claims.*
security.jwt.claims.userId: {{ .Values.global.k5.jwt.claims.userId | default "sub,oid" | quote }}
security.jwt.claims.username: {{ .Values.global.k5.jwt.claims.username | default "username,preferred_username,upn,unique_name" | quote }}
security.jwt.claims.email: {{ .Values.global.k5.jwt.claims.email | default "email,unique_name,upn,preferred_username" | quote }}
security.jwt.claims.givenName: {{ .Values.global.k5.jwt.claims.givenName | default "given_name,givenName,first_name,firstName" | quote }}
security.jwt.claims.familyName: {{ .Values.global.k5.jwt.claims.familyName | default "family_name,familyName,last_name,lastName" | quote }}
security.jwt.claims.name: {{ .Values.global.k5.jwt.claims.name | default "name" | quote }}
security.jwt.claims.tenant: {{ .Values.global.k5.jwt.claims.tenant | default "organization" | quote }}
security.jwt.claims.roles: {{ .Values.global.k5.jwt.claims.roles | default "roles" | quote }}

# Additional settings
{{- if .Values.configmap.extraConfiguration }}
{{ tpl .Values.configmap.extraConfiguration . }}
{{- end }}

{{- end -}}
