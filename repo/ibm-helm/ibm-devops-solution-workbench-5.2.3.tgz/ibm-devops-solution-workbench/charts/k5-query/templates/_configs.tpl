{{/* Print the configurations */}}
{{- define "k5-query-configmapentries" -}}
de.knowis.cp.run.query.host.name: {{ tpl .Values.global.k5.endpoints.query.host . | quote }}
de.knowis.cp.run.query.host.protocol: {{ .Values.protocol | quote }}

de.knowis.cp.run.query.codec.maxInMemorySize: {{ .Values.codec.maxInMemorySize | quote }}

de.knowis.cp.run.query.provider.fssCli.truststoreSecretName: {{ .Values.fssCli.truststoreSecretName | quote }}
de.knowis.cp.run.query.provider.fssCli.clientSecretName: {{ .Values.fssCli.clientSecretName | quote }}

de.knowis.cp.run.query.cors.allowedDomains: {{ include "k5-query.cors-allowed-domains.builder" . | trimSuffix "," | quote }}

de.knowis.cp.run.query.appLabel: {{ required "A valid .Values.global.k5.pod.labels.app" .Values.global.k5.pod.labels.app | quote }}
de.knowis.cp.run.query.tenantIsolation: {{ .Values.global.k5.tenantIsolation | default "false" | quote }}

# JWT claim names from global Helm; bound by platform-common as security.jwt.claims.*
security.jwt.claims.userId: {{ .Values.global.k5.jwt.claims.userId | default "sub,oid" | quote }}
security.jwt.claims.username: {{ .Values.global.k5.jwt.claims.username | default "username,preferred_username,upn,unique_name" | quote }}
security.jwt.claims.email: {{ .Values.global.k5.jwt.claims.email | default "email,unique_name,upn,preferred_username" | quote }}
security.jwt.claims.givenName: {{ .Values.global.k5.jwt.claims.givenName | default "given_name,givenName,first_name,firstName" | quote }}
security.jwt.claims.familyName: {{ .Values.global.k5.jwt.claims.familyName | default "family_name,familyName,last_name,lastName" | quote }}
security.jwt.claims.name: {{ .Values.global.k5.jwt.claims.name | default "name" | quote }}
security.jwt.claims.tenant: {{ .Values.global.k5.jwt.claims.tenant | default "organization" | quote }}
security.jwt.claims.roles: {{ .Values.global.k5.jwt.claims.roles | default "roles" | quote }}

# Spring settings
{{- if .Values.configmap.spring }}
{{ tpl .Values.configmap.spring . }}
{{- end }}

# logging settings
{{- if .Values.configmap.logging }}
{{ tpl .Values.configmap.logging . }}
{{- end }}

# Additional settings
{{- if .Values.configmap.extraConfiguration }}
{{ tpl .Values.configmap.extraConfiguration . }}
{{- end }}

{{- end -}}
