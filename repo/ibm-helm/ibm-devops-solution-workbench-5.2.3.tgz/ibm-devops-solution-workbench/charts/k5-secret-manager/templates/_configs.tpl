{{/* Print the configurations */}}
{{- define "k5-secret-manager-configmapentries" -}}

# logging settings
{{- if .Values.configmap.logging }}
{{ tpl .Values.configmap.logging . }}
{{- end }}

# spring settings
{{- if .Values.configmap.spring }}
{{ tpl .Values.configmap.spring . }}
{{- end }}

de.knowis.cp.k5secretmanager.provider.host.protocol: {{ tpl .Values.configurations.protocol . | quote }}
de.knowis.cp.k5secretmanager.provider.host.name: {{ tpl .Values.global.k5.endpoints.secretManager.host . | quote }}

de.knowis.cp.k5secretmanager.cors.allowedDomains: {{ include "k5-secret-manager.cors-allowed-domains.builder" . | trimSuffix "," | quote }}

audit.namespace: {{ .Release.Namespace }}

# JWT claim names from global Helm; bound by platform-common as security.jwt.claims.*
security.jwt.claims.userId: {{ .Values.global.k5.jwt.claims.userId | default "sub,oid" | quote }}
security.jwt.claims.username: {{ .Values.global.k5.jwt.claims.username | default "username,preferred_username,upn,unique_name" | quote }}
security.jwt.claims.email: {{ .Values.global.k5.jwt.claims.email | default "email,unique_name,upn,preferred_username" | quote }}
security.jwt.claims.givenName: {{ .Values.global.k5.jwt.claims.givenName | default "given_name,givenName,first_name,firstName" | quote }}
security.jwt.claims.familyName: {{ .Values.global.k5.jwt.claims.familyName | default "family_name,familyName,last_name,lastName" | quote }}
security.jwt.claims.name: {{ .Values.global.k5.jwt.claims.name | default "name" | quote }}
security.jwt.claims.tenant: {{ .Values.global.k5.jwt.claims.tenant | default "organization" | quote }}
security.jwt.claims.roles: {{ .Values.global.k5.jwt.claims.roles | default "roles" | quote }}

kubernetes.common.labels.instance: {{ .Release.Name | quote }}
kubernetes.common.labels.managedBy: {{ template "k5-secret-manager.name" . }}
kubernetes.common.labels.name: {{ template "k5-secret-manager.fullname" . }}

{{- end -}}
