#!/bin/bash
set -euo pipefail

while true; do
  code=$(curl -sw '%{http_code}' "$1" -o /dev/null || true)
  echo "GET $1 -> $code"
  if [ "$code" = "200" ]; then
      break
  fi
  sleep 15
done
