#!/bin/bash

if [ -z "$ADMIN_TOKEN" ]; then
  . "$(dirname "${BASH_SOURCE[0]}")/admin-token.sh"
fi

for policy_name in "$@"; do
  component_id=$(curl -s "$KEYCLOAK_URL/admin/realms/$REALM_NAME/components?type=org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy" \
    -H 'Accept: application/json' \
    -H "Authorization: Bearer $ADMIN_TOKEN" |
    sed -r -n 's/.*"id":"([^"]*)"[^}]*"name":"'"$policy_name"'".*/\1/p' | head -1)
  if [ -n "$component_id" ]; then
    curl -si -X DELETE "$KEYCLOAK_URL/admin/realms/$REALM_NAME/components/$component_id" \
      -H "Authorization: Bearer $ADMIN_TOKEN"
  fi
done