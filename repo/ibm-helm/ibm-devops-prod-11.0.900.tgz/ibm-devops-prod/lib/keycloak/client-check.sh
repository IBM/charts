#!/bin/bash
set -euo pipefail
# Return success when client credentials are valid; failure otherwise.

_CREDS=$(curl -s -X POST "$KEYCLOAK_URL/realms/$REALM_NAME/protocol/openid-connect/token" \
  -H 'Content-Type: application/x-www-form-urlencoded' \
  -d "client_id=$CLIENT_ID" \
  --data-urlencode "client_secret=$CLIENT_SECRET" \
  -d grant_type=client_credentials)

if echo "$_CREDS" | grep -q '"access_token"'; then
  exit 0
fi

exit 1
