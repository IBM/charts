#!/bin/bash
set -euo pipefail
# Run a keycloak admin command using admin credentials.
# If admin credentials are invalid and ADMIN_REQUIRED=true, errors and exits 1.
# Otherwise warns and continues.
# Usage: ADMIN_REQUIRED=true admin-run.sh <command> [args...]

if ADMIN_TOKEN=$(bash -c '. ./admin-token.sh >/dev/null 2>&1 && echo "$ADMIN_TOKEN"'); then
  export ADMIN_TOKEN
  "$@"
elif [ "${ADMIN_REQUIRED:-false}" = true ]; then
  echo "ERROR: Keycloak admin credentials are not valid and are required to run: $*"
  exit 1
else
  echo "WARNING: Keycloak admin credentials are not valid. Skipping: $*"
fi
