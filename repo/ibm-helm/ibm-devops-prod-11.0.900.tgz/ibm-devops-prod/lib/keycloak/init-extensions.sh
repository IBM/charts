#!/bin/bash

if [ -z "$ADMIN_TOKEN" ]; then
  . "$(dirname "${BASH_SOURCE[0]}")/admin-token.sh"
fi

echo "Creating client scope '$SCOPE' with audience mapper '$AUDIENCE'..."

_scope_create_resp="$(curl -si -X POST "$KEYCLOAK_URL/admin/realms/$REALM_NAME/client-scopes" \
  -H 'Content-Type: application/json' \
  -H "Authorization: Bearer $ADMIN_TOKEN" \
  -d @-<<EOF
{
    "name": "$SCOPE",
    "description": "Access to DevOps TestHub MCP tools",
    "protocol": "openid-connect",
    "attributes": {
        "include.in.token.scope": "true",
        "consent.screen.text": "Access to DevOps TestHub MCP tools"
    },
    "protocolMappers": [
        {
            "name": "$AUDIENCE:all-audience-mapper",
            "protocol": "openid-connect",
            "protocolMapper": "oidc-audience-mapper",
            "config": {
                "access.token.claim": "true",
                "included.custom.audience": "$AUDIENCE"
            }
        },
        {
            "name": "realm roles",
            "protocol": "openid-connect",
            "protocolMapper": "oidc-usermodel-realm-role-mapper",
            "config": {
                "multivalued": "true",
                "access.token.claim": "true",
                "claim.name": "realm_access.roles"
            }
        }
    ]
}
EOF
)"

_scope_http_code=$(sed -n '$p' <<< "$_scope_create_resp")

if echo "$_scope_create_resp" | grep -qi "^HTTP/.*201"; then
  id_location="$(sed -n 's#^[Ll]ocation:[ ].*/\([0-9a-fA-F-]\{36\}\).*$#\1#Ip' <<< "$_scope_create_resp" | tr -d '\r')"
  echo "Created client scope '$SCOPE' with id '$id_location'"
elif echo "$_scope_create_resp" | grep -qi "^HTTP/.*409"; then
  id_location="$(curl -s "$KEYCLOAK_URL/admin/realms/$REALM_NAME/client-scopes" \
    -H 'Accept: application/json' \
    -H "Authorization: Bearer $ADMIN_TOKEN" |
    sed -n 's/.*"id":"\([^"]*\)"[^}]*"name":"'"$SCOPE"'".*/\1/p;
            s/.*"name":"'"$SCOPE"'"[^}]*"id":"\([^"]*\)".*/\1/p' | head -1)"
  echo "Client scope '$SCOPE' already exists with scope id '$id_location'"
else
  echo "Failed to create client scope '$SCOPE'. Response: $_scope_create_resp"
  exit 1
fi

if [ -n "$id_location" ]; then
  _put_resp=$(curl -si -X PUT "$KEYCLOAK_URL/admin/realms/$REALM_NAME/default-optional-client-scopes/$id_location" -H "Authorization: Bearer $ADMIN_TOKEN")
  if echo "$_put_resp" | grep -qi "^HTTP/.*409"; then
    echo "Client scope '$SCOPE' is already assigned as optional default, skipping."
  fi
fi
