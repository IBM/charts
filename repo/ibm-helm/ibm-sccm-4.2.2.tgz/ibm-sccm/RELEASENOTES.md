# Breaking Changes

- Starting with this release, the default value for storageSecurity.runAsUser is left blank. This change does not affect existing configurations during upgrades, ensuring backward compatibility. However, for fresh installations, it is recommended to explicitly set a value if needed; otherwise, a random user ID will be assigned based on the Security Context Constraints (SCC) applied to the pod.

# Fixes


# Prerequisites

Please refer prerequisites section from [README.md](README.md)

# Documentation

Please refer to [README.md](README.md) provided with chart for detailed installation instruction.

# Version History

| Chart  | Date          | Kubernetes Required | OpenShift Required  | Image(s) Supported           | Details                                    |
| ------ | ------------- | ------------------- | ------------------- | ---------------------------- | ------------------------------------------ |
| 4.2.0  | Nov 21, 2025  | >= 1.31             | >= 4.16             | ibmscc:6.4.2.0_2025-11-18    | IBM Sterling Control Center Monitor 6.4.2.0|
| ------ | ------------- | ------------------- | ------------------- | ---------------------------- | ------------------------------------------ |
| 4.2.1  | Feb 24, 2026  | >= 1.30             | >= 4.15             | ibmscc:6.4.2.0.iFix01_2026-02-24    | IBM Sterling Control Center Monitor 6.4.2.0|
| ------ | ------------- | ------------------- | ------------------- | ---------------------------- | ------------------------------------------ |
| 4.2.2  | Apr 01, 2026  | >= 1.30             | >= 4.15             | ibmscc:6.4.2.0.iFix02_2026-03-30    | IBM Sterling Control Center Monitor 6.4.2.0|
| ------ | ------------- | ------------------- | ------------------- | ---------------------------- | ------------------------------------------ |
