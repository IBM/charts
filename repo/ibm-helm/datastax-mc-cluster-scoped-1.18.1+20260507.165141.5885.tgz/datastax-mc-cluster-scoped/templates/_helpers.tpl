{{- define "mission-control.watchNamespaces" -}}
{{- $watchNamespaces := .Values.global.tetheredNamespaces | default list -}}
{{- if .Values.global.instanceNamespace -}}
{{- $watchNamespaces = append $watchNamespaces .Values.global.instanceNamespace -}}
{{- end -}}
{{- $watchNamespaces = prepend $watchNamespaces .Values.global.operatorNamespace }}
{{- uniq $watchNamespaces | join "," | quote }}
{{- end -}}

{{- define "mission-control.watchNamespacesList" -}}
{{- $watchNamespaces := .Values.global.tetheredNamespaces | default list -}}
{{- if .Values.global.instanceNamespace -}}
{{- $watchNamespaces = append $watchNamespaces .Values.global.instanceNamespace -}}
{{- end -}}
{{- $watchNamespaces = prepend $watchNamespaces .Values.global.operatorNamespace }}
{{- uniq $watchNamespaces | toYaml }}
{{- end -}}

{{- define "mission-control.validateCustomVolumes" -}}
{{- if .Values.datastaxMc.ui.customVolumes -}}
{{- range .Values.datastaxMc.ui.customVolumes -}}
{{- if eq .name "cert" -}}
{{- fail "Custom volume cannot use the reserved name 'cert'. This name is reserved for the UI HTTPS certificate volume." -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "mission-control.validateCustomVolumeMounts" -}}
{{- if .Values.datastaxMc.ui.customVolumeMounts -}}
{{- range .Values.datastaxMc.ui.customVolumeMounts -}}
{{- if eq .name "cert" -}}
{{- fail "Custom volume mount cannot reference the reserved volume name 'cert'. This name is reserved for the UI HTTPS certificate volume." -}}
{{- end -}}
{{- if eq .mountPath "/tmp/certs" -}}
{{- fail "Custom volume mount cannot use the reserved mount path '/tmp/certs'. This path is reserved for the UI HTTPS certificate." -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "ibm.labels" -}}
{{ include "k8ssandra-common.labels" . }}
component-id: "datastax-mc"
{{- end -}}

{{- define "ibm.fullname" -}}
{{ $name := "datastax-mc" }}
{{- printf "%s" $name }}
{{- end -}}

{{- define "ibm.suffixName" -}}
{{- if hasKey . "Values" -}}
{{- $name := .Values.global.operatorNamespace -}}
{{- if $name -}}
{{- printf "-%s" $name }}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "ibm.serviceAccountName" -}}
{{- printf "%s" (include "ibm.fullname" .) -}}
{{- end -}}

{{- define "ibm.serviceAccount" -}}
apiVersion: v1
kind: ServiceAccount
metadata:
  name: {{ include "ibm.serviceAccountName" . }}
  labels: {{ include "ibm.labels" . | indent 4 }}
  {{- $annotations := include "k8ssandra-common.annotations" (dict "context" . "annotations" .Values.datastaxMc.serviceAccount.annotations) }}
  {{- if $annotations }}
  annotations:
    {{- $annotations | nindent 4 }}
  {{- end }}
{{- if semverCompare ">=1.24-0" .Capabilities.KubeVersion.GitVersion }}
secrets:
  - name: {{ include "ibm.serviceAccountName" . }}-token
{{- end }}
{{- if .Values.global.imagePullSecret }}
imagePullSecrets:
  - name: {{ .Values.global.imagePullSecret }}
{{- end }}
{{- end -}}

# Copied from k8ssandra-common

{{/*
Expand the name of the chart.
*/}}
{{- define "k8ssandra-common.name" -}}
{{ include "common.names.name" . }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "k8ssandra-common.fullname" -}}
{{ include "common.names.fullname" . }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "k8ssandra-common.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "k8ssandra-common.labels" }}
{{ include "common.labels.standard" . }}
app.kubernetes.io/part-of: k8ssandra-{{ .Release.Name }}-{{ .Release.Namespace }}
{{- $commonLabels := dict -}}
{{- if .Values.datastaxMc.commonLabels -}}
{{- $commonLabels = merge $commonLabels .Values.datastaxMc.commonLabels -}}
{{- end -}}
{{- if $commonLabels }}
{{ toYaml $commonLabels | trim }}
{{- end }}
{{- end }}

{{- define "k8ssandra-common.annotations" }}
{{- $context := . -}}
{{- if .context -}}
{{- $context = .context -}}
{{- end -}}
{{- $commonAnnotations := dict -}}
{{- if $context.Values.datastaxMc.commonAnnotations -}}
{{- $commonAnnotations = merge $commonAnnotations $context.Values.datastaxMc.commonAnnotations -}}
{{- end -}}
{{- if .annotations -}}
{{- $commonAnnotations = merge $commonAnnotations .annotations -}}
{{- end -}}
{{- if $commonAnnotations -}}
{{- toYaml $commonAnnotations | trim }}
{{- end -}}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "k8ssandra-common.selectorLabels" -}}
app.kubernetes.io/name: {{ include "k8ssandra-common.name" . | replace "\n" "" }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/part-of: k8ssandra-{{ .Release.Name }}-{{ .Release.Namespace }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "k8ssandra-common.serviceAccountName" -}}
{{- default (include "k8ssandra-common.fullname" .) .Values.serviceAccount.name }}
{{- end }}

{{/*
Generate a password for use in a secret. The password is a random alphanumeric 20 character
string that is base 64 encoded.
*/}}
{{- define "k8ssandra-common.password" -}}
{{ randAlphaNum 20 | b64enc | quote }}
{{- end }}


# From bitnami commons 0.16.0

{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "common.names.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "common.names.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "common.names.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create a default fully qualified dependency name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
Usage:
{{ include "common.names.dependency.fullname" (dict "chartName" "dependency-chart-name" "chartValues" .Values.dependency-chart "context" $) }}
*/}}
{{- define "common.names.dependency.fullname" -}}
{{- if .chartValues.fullnameOverride -}}
{{- .chartValues.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .chartName .chartValues.nameOverride -}}
{{- if contains $name .context.Release.Name -}}
{{- .context.Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .context.Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Allow the release namespace to be overridden for multi-namespace deployments in combined charts.
*/}}
{{- define "common.names.namespace" -}}
{{- if .Values.namespaceOverride -}}
{{- .Values.namespaceOverride -}}
{{- else -}}
{{- .Release.Namespace -}}
{{- end -}}
{{- end -}}

{{/*
Create a fully qualified app name adding the installation's namespace.
*/}}
{{- define "common.names.fullname.namespace" -}}
{{- printf "%s-%s" (include "common.names.fullname" .) (include "common.names.namespace" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/* vim: set filetype=mustache: */}}
{{/*
Kubernetes standard labels
*/}}
{{- define "common.labels.standard" -}}
app.kubernetes.io/name: {{ include "common.names.name" . }}
helm.sh/chart: {{ include "common.names.chart" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{/*
Labels to use on deploy.spec.selector.matchLabels and svc.spec.selector
*/}}
{{- define "common.labels.matchLabels" -}}
app.kubernetes.io/name: {{ include "common.names.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}
