#!/bin/bash
# Licensed Materials - Property of HCL
# (C) Copyright HCL Technologies Ltd. 2026. All Rights Reserved
#
# DevOps Loop Weekly Storage Cleanup
# Installed via cron: 0 2 * * 0 (Sundays at 2 AM)

LOG_FILE="/var/log/devops-loop-cleanup.log"
DATE=$(date '+%Y-%m-%d %H:%M:%S')

# Redirect all output to log file (append mode)
exec 1> >(tee -a "$LOG_FILE")
exec 2>&1

echo "=========================================="
echo "[$DATE] Starting DevOps Loop storage cleanup"
echo "=========================================="

# 1. Prune unused container images
echo "1. Pruning unused container images..."
if command -v crictl >/dev/null 2>&1; then
  crictl rmi --prune 2>&1 || echo "  crictl prune completed with warnings"
  echo "✓ crictl image prune completed"
else
  echo "⚠ crictl not found, skipping container image cleanup"
fi

# Alternative: podman (if present)
if command -v podman >/dev/null 2>&1; then
  podman image prune -af --filter "until=168h" 2>&1 || echo "  podman prune completed with warnings"
  echo "✓ podman image prune completed (7+ days old)"
fi

# 2. Clean DNF cache
echo ""
echo "2. Cleaning DNF package cache..."
dnf clean all 2>&1 || echo "  DNF clean completed with warnings"
echo "✓ DNF cache cleared"

# 3. Clean Maven cache (if present)
echo ""
echo "3. Cleaning Maven cache..."
MAVEN_CACHE_DIR="/root/.m2/repository"
if [[ -d "$MAVEN_CACHE_DIR" ]]; then
  # Remove cached artifacts older than 30 days
  find "$MAVEN_CACHE_DIR" -type f -mtime +30 -delete 2>&1 || true
  echo "✓ Maven cache cleaned (30+ days old)"
else
  echo "⚠ Maven cache not found at $MAVEN_CACHE_DIR"
fi

# 4. Clean temporary build artifacts
echo ""
echo "4. Cleaning temporary build directories..."
find /tmp -maxdepth 1 -type d -name "devops-*" -mtime +7 -exec rm -rf {} + 2>/dev/null || true
find /tmp -maxdepth 1 -type d -name "helm-*" -mtime +7 -exec rm -rf {} + 2>/dev/null || true
find /tmp -maxdepth 1 -type d -name "kube-*" -mtime +7 -exec rm -rf {} + 2>/dev/null || true
echo "✓ Temp build artifacts cleaned"

# 5. Clean Kubernetes pod logs (if applicable)
echo ""
echo "5. Cleaning old Kubernetes logs..."
if [[ -d /var/log/pods ]]; then
  find /var/log/pods -type f -mtime +14 -delete 2>/dev/null || true
  echo "✓ Old Kubernetes pod logs cleaned (14+ days)"
else
  echo "⚠ /var/log/pods not found"
fi

# 6. Verify journal size compliance
echo ""
echo "6. Checking journal disk usage..."
journalctl --disk-usage 2>&1 || echo "  journalctl not available"

# 7. Report disk usage
echo ""
echo "========== Disk Usage Report =========="
df -h / /home 2>/dev/null || df -h /
echo "======================================="

# 8. Check if storage redirection is active and report usage
if [[ -f /etc/devops-loop-storage-redirect.conf ]]; then
  echo ""
  echo "========== Redirected Storage Usage =========="
  source /etc/devops-loop-storage-redirect.conf
  echo "Redirect target: $REDIRECT_TARGET"
  
  if [[ -d "$REDIRECT_TARGET" ]]; then
    echo ""
    du -sh "$REDIRECT_TARGET"/* 2>/dev/null || echo "  (no data in redirect target yet)"
  fi
  echo "=============================================="
fi

# 9. Report current container image count
echo ""
echo "Current container image count:"
if command -v crictl >/dev/null 2>&1; then
  crictl images | wc -l | xargs echo "  crictl images:"
fi
if command -v podman >/dev/null 2>&1; then
  podman images | wc -l | xargs echo "  podman images:"
fi

# 10. Clean up old backup directories (90+ days)
echo ""
echo "10. Cleaning old backup directories..."
find /var -maxdepth 2 -type d -name "*.backup.*" -mtime +90 -exec rm -rf {} + 2>/dev/null || true
find /home -maxdepth 2 -type d -name "*.backup.*" -mtime +90 -exec rm -rf {} + 2>/dev/null || true
echo "✓ Old backup directories cleaned (90+ days)"

echo ""
echo "[$DATE] Cleanup completed successfully"
echo "=========================================="
echo ""
