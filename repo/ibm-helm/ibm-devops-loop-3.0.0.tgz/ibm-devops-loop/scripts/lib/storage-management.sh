#!/bin/bash
# Licensed Materials - Property of HCL
# (C) Copyright HCL Technologies Ltd. 2026. All Rights Reserved
#
# Storage Management Library for DevOps Loop
# Provides intelligent data redirection and retention capabilities

set -eo pipefail

# ============================================================================
# Function: analyze_partition_layout
# Description: Analyzes disk partition layout and determines if redirection
#              is needed based on root and home partition sizes
# ============================================================================
analyze_partition_layout() {
  echo "========== Partition Layout Analysis =========="
  
  # Detect root partition size
  ROOT_SIZE_GB=$(df -BG / | awk 'NR==2 {gsub(/G/, "", $2); print $2}')
  
  if ! [[ "$ROOT_SIZE_GB" =~ ^[0-9]+$ ]]; then
    echo "Error: Unable to detect root partition size."
    exit 1
  fi
  
  # Detect /home partition size (if separate mount)
  HOME_SIZE_GB=0
  HOME_IS_SEPARATE=false
  
  if df /home 2>/dev/null | tail -1 | grep -q "/home"; then
    HOME_SIZE_GB=$(df -BG /home | awk 'NR==2 {gsub(/G/, "", $2); print $2}')
    HOME_IS_SEPARATE=true
  fi
  
  # Thresholds for smart redirection
  ROOT_THRESHOLD=150
  HOME_THRESHOLD=200
  
  # Decision logic: Redirect if root < 150GB AND home > 200GB
  REDIRECT_ENABLED=false
  REDIRECT_TARGET=""
  
  if [[ "$ROOT_SIZE_GB" -lt "$ROOT_THRESHOLD" ]] && [[ "$HOME_SIZE_GB" -gt "$HOME_THRESHOLD" ]]; then
    REDIRECT_ENABLED=true
    REDIRECT_TARGET="/home/devops-loop-data"
  fi
  
  # Export decisions for use in other functions
  export ROOT_SIZE_GB HOME_SIZE_GB HOME_IS_SEPARATE
  export REDIRECT_ENABLED REDIRECT_TARGET
  export ROOT_THRESHOLD HOME_THRESHOLD
  
  # Log analysis summary
  echo "Root partition: ${ROOT_SIZE_GB}GB"
  echo "Home partition: ${HOME_SIZE_GB}GB (separate mount: ${HOME_IS_SEPARATE})"
  echo "Redirection threshold: Root < ${ROOT_THRESHOLD}GB AND Home > ${HOME_THRESHOLD}GB"
  echo "Redirection required: $REDIRECT_ENABLED"
  
  if [[ "$REDIRECT_ENABLED" == "true" ]]; then
    echo "Redirect target: $REDIRECT_TARGET"
    echo "✓ Smart redirection will be activated"
  else
    echo "✓ Using default storage paths (no redirection needed)"
  fi
  
  echo "==============================================="
}

# ============================================================================
# Function: configure_smart_redirection
# Description: Configures NFS and CRI-O storage redirection to /home partition
#              via symlinks when root partition is undersized
# ============================================================================
configure_smart_redirection() {
  if [[ "$REDIRECT_ENABLED" != "true" ]]; then
    echo "Smart redirection not needed. Using default paths."
    return 0
  fi
  
  echo "========== Configuring Smart Redirection =========="
  echo "Target directory: $REDIRECT_TARGET"
  
  # 1. Create target directory structure on /home partition
  sudo mkdir -p "$REDIRECT_TARGET"/{nfs-shares,crio-storage}
  sudo chmod 755 "$REDIRECT_TARGET"
  echo "✓ Created redirect target directories"
  
  # 2. Configure NFS export directory redirection
  NFS_ORIGINAL_PATH="/var/nfs-shares"
  NFS_REDIRECT_PATH="$REDIRECT_TARGET/nfs-shares"
  
  if [[ ! -L "$NFS_ORIGINAL_PATH" ]]; then
    # Backup existing directory if present
    if [[ -d "$NFS_ORIGINAL_PATH" ]] && [[ ! -L "$NFS_ORIGINAL_PATH" ]]; then
      BACKUP_PATH="${NFS_ORIGINAL_PATH}.backup.$(date +%Y%m%d%H%M%S)"
      sudo mv "$NFS_ORIGINAL_PATH" "$BACKUP_PATH"
      echo "✓ Backed up existing NFS directory to: $BACKUP_PATH"
    fi
    
    # Create symlink
    sudo ln -sf "$NFS_REDIRECT_PATH" "$NFS_ORIGINAL_PATH"
    echo "✓ NFS redirected: $NFS_ORIGINAL_PATH -> $NFS_REDIRECT_PATH"
  else
    echo "✓ NFS symlink already exists"
  fi
  
  # 3. Configure CRI-O storage root redirection
  CRIO_ORIGINAL_PATH="/var/lib/containers/storage"
  CRIO_REDIRECT_PATH="$REDIRECT_TARGET/crio-storage"
  
  # Stop CRI-O before relocating (if running)
  if systemctl is-active --quiet crio 2>/dev/null; then
    echo "Stopping CRI-O for storage relocation..."
    sudo systemctl stop crio
  fi
  
  if [[ ! -L "$CRIO_ORIGINAL_PATH" ]]; then
    # Backup existing directory if present
    if [[ -d "$CRIO_ORIGINAL_PATH" ]] && [[ ! -L "$CRIO_ORIGINAL_PATH" ]]; then
      BACKUP_PATH="${CRIO_ORIGINAL_PATH}.backup.$(date +%Y%m%d%H%M%S)"
      sudo mv "$CRIO_ORIGINAL_PATH" "$BACKUP_PATH"
      echo "✓ Backed up existing CRI-O storage to: $BACKUP_PATH"
    fi
    
    # Create symlink
    sudo ln -sf "$CRIO_REDIRECT_PATH" "$CRIO_ORIGINAL_PATH"
    echo "✓ CRI-O storage redirected: $CRIO_ORIGINAL_PATH -> $CRIO_REDIRECT_PATH"
  else
    echo "✓ CRI-O storage symlink already exists"
  fi
  
  # 4. Update CRI-O configuration to use redirected path
  sudo mkdir -p /etc/crio/crio.conf.d/
  cat <<EOF | sudo tee /etc/crio/crio.conf.d/10-storage-redirect.conf
# DevOps Loop - CRI-O Storage Redirection
# Auto-generated: $(date -Iseconds)
[crio.runtime]
root = "$CRIO_REDIRECT_PATH"
EOF
  
  echo "✓ CRI-O configuration updated"
  
  # 5. Start CRI-O if it was stopped
  if ! systemctl is-active --quiet crio 2>/dev/null; then
    echo "Starting CRI-O with redirected storage..."
    sudo systemctl start crio
    echo "✓ CRI-O started successfully"
  fi
  
  # 6. Create tracking/metadata file for auditability
  cat <<EOF | sudo tee /etc/devops-loop-storage-redirect.conf
# DevOps Loop Storage Redirection Metadata
# This file tracks the storage redirection configuration
REDIRECT_ENABLED=true
REDIRECT_TIMESTAMP=$(date -Iseconds)
ROOT_SIZE_GB=$ROOT_SIZE_GB
HOME_SIZE_GB=$HOME_SIZE_GB
ROOT_THRESHOLD=$ROOT_THRESHOLD
HOME_THRESHOLD=$HOME_THRESHOLD
REDIRECT_TARGET=$REDIRECT_TARGET
NFS_REDIRECT_PATH=$NFS_REDIRECT_PATH
CRIO_REDIRECT_PATH=$CRIO_REDIRECT_PATH
EOF
  
  echo "✓ Metadata file created: /etc/devops-loop-storage-redirect.conf"
  
  echo "========== Smart Redirection Complete =========="
  echo "Heavy data (NFS, CRI-O) will now use /home partition"
}

# ============================================================================
# Function: configure_log_rotation
# Description: Configures journald and CRI-O log rotation limits
#              - journald: 2GB system max
#              - CRI-O: 10MB per container
# ============================================================================
configure_log_rotation() {
  echo "========== Configuring Log Rotation =========="
  
  # 1. Configure systemd-journald with 2GB limit
  JOURNALD_CONFIG="/etc/systemd/journald.conf.d/10-devops-loop.conf"
  sudo mkdir -p /etc/systemd/journald.conf.d/
  
  cat <<'EOF' | sudo tee "$JOURNALD_CONFIG"
# DevOps Loop journald configuration
# Limit systemd journal to 2GB total
[Journal]
SystemMaxUse=2G
RuntimeMaxUse=500M
SystemKeepFree=1G
MaxRetentionSec=7day
MaxFileSec=1day
EOF
  
  echo "✓ journald configuration created: $JOURNALD_CONFIG"
  
  # Restart journald to apply configuration
  sudo systemctl restart systemd-journald
  echo "✓ systemd-journald restarted with new limits"
  
  # 2. Configure CRI-O log limits (10MB per container)
  CRIO_LOG_CONFIG="/etc/crio/crio.conf.d/20-log-limits.conf"
  sudo mkdir -p /etc/crio/crio.conf.d/
  
  cat <<'EOF' | sudo tee "$CRIO_LOG_CONFIG"
# DevOps Loop CRI-O log configuration
# Limit per-container logs to 10MB
[crio.runtime]
log_size_max = 10485760
EOF
  
  echo "✓ CRI-O log configuration created: $CRIO_LOG_CONFIG"
  
  # Restart CRI-O if it's running
  if systemctl is-active --quiet crio 2>/dev/null; then
    sudo systemctl restart crio
    echo "✓ CRI-O restarted with new log limits"
  else
    echo "✓ CRI-O log limits configured (service not yet running)"
  fi
  
  # 3. Verify configurations
  echo ""
  echo "Verification - Current journal disk usage:"
  journalctl --disk-usage || echo "  (journalctl not yet available)"
  
  echo ""
  echo "Log rotation configured:"
  echo "  - journald: 2GB system maximum"
  echo "  - CRI-O: 10MB per container (10485760 bytes)"
  
  echo "========== Log Rotation Complete =========="
}

# ============================================================================
# Function: install_scheduled_cleanup
# Description: Installs weekly cron job to prune unused images and clean caches
#              Schedule: Sundays at 2 AM
# ============================================================================
install_scheduled_cleanup() {
  echo "========== Installing Scheduled Cleanup =========="
  
  # 1. Copy cleanup script to system location
  CLEANUP_SCRIPT="/usr/local/bin/devops-loop-cleanup.sh"
  CLEANUP_SCRIPT_SOURCE="$(dirname "${BASH_SOURCE[0]}")/../config/storage-cleanup.sh"
  
  if [[ -f "$CLEANUP_SCRIPT_SOURCE" ]]; then
    sudo cp "$CLEANUP_SCRIPT_SOURCE" "$CLEANUP_SCRIPT"
    sudo chmod +x "$CLEANUP_SCRIPT"
    echo "✓ Cleanup script installed: $CLEANUP_SCRIPT"
  else
    echo "Warning: Cleanup script source not found at: $CLEANUP_SCRIPT_SOURCE"
    echo "Creating inline cleanup script..."
    
    # Create the cleanup script inline if source not found
    cat <<'CLEANUP_SCRIPT_CONTENT' | sudo tee "$CLEANUP_SCRIPT" > /dev/null
#!/bin/bash
# DevOps Loop Weekly Storage Cleanup
# Installed via cron: 0 2 * * 0 (Sundays at 2 AM)

LOG_FILE="/var/log/devops-loop-cleanup.log"
DATE=$(date '+%Y-%m-%d %H:%M:%S')

exec 1> >(tee -a "$LOG_FILE")
exec 2>&1

echo "=========================================="
echo "[$DATE] Starting DevOps Loop storage cleanup"
echo "=========================================="

# 1. Prune unused container images
echo "1. Pruning unused container images..."
if command -v crictl >/dev/null 2>&1; then
  crictl rmi --prune 2>&1 || echo "  crictl prune completed with warnings"
  echo "✓ crictl image prune completed"
else
  echo "⚠ crictl not found, skipping container image cleanup"
fi

# Alternative: podman (if present)
if command -v podman >/dev/null 2>&1; then
  podman image prune -af --filter "until=168h" 2>&1 || echo "  podman prune completed with warnings"
  echo "✓ podman image prune completed (7+ days old)"
fi

# 2. Clean DNF cache
echo ""
echo "2. Cleaning DNF package cache..."
dnf clean all 2>&1 || echo "  DNF clean completed with warnings"
echo "✓ DNF cache cleared"

# 3. Clean Maven cache (if present)
echo ""
echo "3. Cleaning Maven cache..."
MAVEN_CACHE_DIR="/root/.m2/repository"
if [[ -d "$MAVEN_CACHE_DIR" ]]; then
  find "$MAVEN_CACHE_DIR" -type f -mtime +30 -delete 2>&1 || true
  echo "✓ Maven cache cleaned (30+ days old)"
else
  echo "⚠ Maven cache not found at $MAVEN_CACHE_DIR"
fi

# 4. Clean temporary build artifacts
echo ""
echo "4. Cleaning temporary build directories..."
find /tmp -maxdepth 1 -type d -name "devops-*" -mtime +7 -exec rm -rf {} + 2>/dev/null || true
find /tmp -maxdepth 1 -type d -name "helm-*" -mtime +7 -exec rm -rf {} + 2>/dev/null || true
echo "✓ Temp build artifacts cleaned"

# 5. Verify journal size compliance
echo ""
echo "5. Checking journal disk usage..."
journalctl --disk-usage 2>&1 || echo "  journalctl not available"

# 6. Report disk usage
echo ""
echo "========== Disk Usage Report =========="
df -h / /home 2>/dev/null || df -h /
echo "======================================="

# 7. Check if redirection is active
if [[ -f /etc/devops-loop-storage-redirect.conf ]]; then
  echo ""
  echo "Storage redirection is active:"
  source /etc/devops-loop-storage-redirect.conf
  echo "  Redirect target: $REDIRECT_TARGET"
  du -sh "$REDIRECT_TARGET" 2>/dev/null || echo "  (unable to calculate size)"
fi

echo ""
echo "[$DATE] Cleanup completed successfully"
echo ""
CLEANUP_SCRIPT_CONTENT
    
    sudo chmod +x "$CLEANUP_SCRIPT"
    echo "✓ Inline cleanup script created: $CLEANUP_SCRIPT"
  fi
  
  # 2. Install cron job (Sundays at 2 AM)
  CRON_LINE="0 2 * * 0 $CLEANUP_SCRIPT"
  
  # Add to root's crontab if not already present
  if ! sudo crontab -l 2>/dev/null | grep -qF "$CLEANUP_SCRIPT"; then
    (sudo crontab -l 2>/dev/null || true; echo "$CRON_LINE") | sudo crontab -
    echo "✓ Cron job installed: Weekly cleanup (Sundays at 2 AM)"
  else
    echo "✓ Cron job already exists"
  fi
  
  # 3. Create log file with proper permissions
  sudo touch /var/log/devops-loop-cleanup.log
  sudo chmod 644 /var/log/devops-loop-cleanup.log
  echo "✓ Log file created: /var/log/devops-loop-cleanup.log"
  
  # 4. Verify cron installation
  echo ""
  echo "Installed cron jobs:"
  sudo crontab -l | grep devops-loop-cleanup || echo "  (verification failed - but job should be installed)"
  
  echo "========== Scheduled Cleanup Installed =========="
}

# ============================================================================
# Function: show_storage_summary
# Description: Displays a summary of all storage intelligence configurations
# ============================================================================
show_storage_summary() {
  echo ""
  echo "========================================"
  echo "Storage Intelligence Configuration Summary"
  echo "========================================"
  
  if [[ -f /etc/devops-loop-storage-redirect.conf ]]; then
    echo ""
    echo "Smart Redirection: ENABLED"
    source /etc/devops-loop-storage-redirect.conf
    echo "  Root partition: ${ROOT_SIZE_GB}GB"
    echo "  Home partition: ${HOME_SIZE_GB}GB"
    echo "  Redirect target: $REDIRECT_TARGET"
    echo "  NFS path: $NFS_REDIRECT_PATH"
    echo "  CRI-O path: $CRIO_REDIRECT_PATH"
  else
    echo ""
    echo "Smart Redirection: DISABLED (using default paths)"
  fi
  
  echo ""
  echo "Log Rotation:"
  echo "  journald: 2GB max (config: /etc/systemd/journald.conf.d/10-devops-loop.conf)"
  echo "  CRI-O: 10MB per container (config: /etc/crio/crio.conf.d/20-log-limits.conf)"
  
  echo ""
  echo "Scheduled Cleanup:"
  echo "  Script: /usr/local/bin/devops-loop-cleanup.sh"
  echo "  Schedule: Sundays at 2 AM (weekly)"
  echo "  Log: /var/log/devops-loop-cleanup.log"
  
  echo ""
  echo "Verification Commands:"
  echo "  journalctl --disk-usage"
  echo "  df -h / /home"
  echo "  sudo crontab -l | grep devops-loop-cleanup"
  echo "  ls -la /var/nfs-shares /var/lib/containers/storage"
  
  echo "========================================"
}
