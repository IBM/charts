# Storage Intelligence for DevOps Loop

## Overview

The Storage Intelligence feature is intended for demo environments running on single-node Kubernetes clusters. It provides intelligent data redirection and retention capabilities to protect the root partition from disk pressure conditions in these environments.

> **Important:** This setup is for demo environments only. Production environments are not hosted on single-node Kubernetes clusters and should not use this storage configuration.

## Problem Statement

In demo Kubernetes environments, heavy and unpredictable data growth from:
- Container images (CRI-O storage)
- NFS shared volumes
- System logs (journald, container logs)
- Build artifacts and caches

...can quickly exhaust the root partition, leading to:
- DiskPressure node conditions
- Pod evictions
- Failed deployments
- System instability

## Solution

This feature implements a three-pronged approach:

### 1. Smart Data Redirection

**Trigger Condition:** Root partition < 150GB AND /home partition > 200GB

**Actions:**
- Automatically redirects NFS shares from `/var/nfs-shares` to `/home/devops-loop-data/nfs-shares`
- Redirects CRI-O container storage from `/var/lib/containers/storage` to `/home/devops-loop-data/crio-storage`
- Uses symlinks for resilience and easy rollback
- Creates backup of original directories with timestamps

### 2. Log Rotation Limits

**journald Configuration:**
- System maximum: 2GB
- Runtime maximum: 500MB
- Retention: 7 days
- Config: `/etc/systemd/journald.conf.d/10-devops-loop.conf`

**CRI-O Configuration:**
- Per-container log limit: 10MB
- Config: `/etc/crio/crio.conf.d/20-log-limits.conf`

### 3. Scheduled Cleanup

**Weekly Cron Job (Sundays at 2 AM):**
- Prunes unused container images (crictl/podman)
- Cleans DNF package cache
- Removes old Maven artifacts (30+ days)
- Cleans temporary build directories (7+ days)
- Removes old Kubernetes pod logs (14+ days)
- Cleans old backup directories (90+ days)
- Reports disk usage and journal size

## Files

### Core Library
- **`scripts/lib/storage-management.sh`** - Main library with all functions:
  - `analyze_partition_layout()` - Detects partition sizes and makes redirection decision
  - `configure_smart_redirection()` - Sets up symlinks and redirects storage
  - `configure_log_rotation()` - Configures journald and CRI-O log limits
  - `install_scheduled_cleanup()` - Installs cron job and cleanup script
  - `show_storage_summary()` - Displays configuration summary

### Configuration Templates
- **`scripts/config/journald-devops-loop.conf`** - journald limits template
- **`scripts/config/crio-log-options.conf`** - CRI-O log limits template
- **`scripts/config/storage-cleanup.sh`** - Weekly cleanup script

### Standalone Installer
- **`scripts/storage-intelligence-setup.sh`** - Standalone installation script

### Integration
- **`scripts/demo/RHEL9-K8S-Infra-Setup.sh`** - Modified to include storage intelligence

## Installation

### Option 1: Integrated with Infrastructure Setup

The storage intelligence is automatically applied when running the RHEL9 Kubernetes infrastructure setup:

```bash
cd scripts/demo
./RHEL9-K8S-Infra-Setup.sh
```

### Option 2: Standalone Installation

For existing installations, run the standalone setup:

```bash
cd scripts
sudo ./storage-intelligence-setup.sh
```

### Option 3: Manual Integration

Source the library in your own scripts:

```bash
source scripts/lib/storage-management.sh

# Run individual phases
analyze_partition_layout
configure_smart_redirection
configure_log_rotation
install_scheduled_cleanup
```

## Usage

### Verify Installation

```bash
# Check if redirection is active
ls -la /var/nfs-shares
ls -la /var/lib/containers/storage

# View configuration metadata
cat /etc/devops-loop-storage-redirect.conf

# Check disk usage
df -h / /home

# Verify journal limits
journalctl --disk-usage

# Check cron job
sudo crontab -l | grep devops-loop-cleanup
```

### Manual Cleanup Execution

```bash
# Run cleanup manually
sudo /usr/local/bin/devops-loop-cleanup.sh

# View cleanup logs
tail -f /var/log/devops-loop-cleanup.log
```

### Monitoring

```bash
# Monitor redirected storage usage
du -sh /home/devops-loop-data/*

# Check CRI-O storage location
crictl info | grep root

# Verify log rotation is working
journalctl --verify
```

## Configuration Files

After installation, the following files are created:

| File | Purpose |
|------|---------|
| `/etc/devops-loop-storage-redirect.conf` | Redirection metadata and tracking |
| `/etc/systemd/journald.conf.d/10-devops-loop.conf` | journald log limits |
| `/etc/crio/crio.conf.d/10-storage-redirect.conf` | CRI-O storage path (if redirected) |
| `/etc/crio/crio.conf.d/20-log-limits.conf` | CRI-O per-container log limits |
| `/usr/local/bin/devops-loop-cleanup.sh` | Weekly cleanup script |
| `/var/log/devops-loop-cleanup.log` | Cleanup execution log |

## Thresholds

### Redirection Thresholds

| Parameter | Value | Configurable |
|-----------|-------|--------------|
| Root partition minimum | 150GB | Yes (edit `storage-management.sh`) |
| Home partition minimum | 200GB | Yes (edit `storage-management.sh`) |

### Log Limits

| Component | Limit | Configurable |
|-----------|-------|--------------|
| journald system max | 2GB | Yes (edit `journald-devops-loop.conf`) |
| journald runtime max | 500MB | Yes (edit `journald-devops-loop.conf`) |
| CRI-O per-container | 10MB | Yes (edit `crio-log-options.conf`) |

### Cleanup Retention

| Item | Retention | Configurable |
|------|-----------|--------------|
| Container images | Unused | Yes (edit `storage-cleanup.sh`) |
| Maven artifacts | 30 days | Yes (edit `storage-cleanup.sh`) |
| Temp directories | 7 days | Yes (edit `storage-cleanup.sh`) |
| Pod logs | 14 days | Yes (edit `storage-cleanup.sh`) |
| Backup directories | 90 days | Yes (edit `storage-cleanup.sh`) |

## Rollback

If redirection causes issues, rollback procedure:

```bash
# Stop CRI-O
sudo systemctl stop crio

# Remove symlinks
sudo rm /var/nfs-shares
sudo rm /var/lib/containers/storage

# Restore from backup (find latest backup)
sudo mv /var/nfs-shares.backup.* /var/nfs-shares
sudo mv /var/lib/containers/storage.backup.* /var/lib/containers/storage

# Remove redirect configs
sudo rm /etc/crio/crio.conf.d/10-storage-redirect.conf
sudo rm /etc/devops-loop-storage-redirect.conf

# Restart CRI-O
sudo systemctl start crio
```

## Testing

### Test Scenarios

1. **Partition Detection**
   ```bash
   # Verify correct detection
   source scripts/lib/storage-management.sh
   analyze_partition_layout
   ```

2. **Redirection Functionality**
   ```bash
   # After setup, verify symlinks
   ls -la /var/nfs-shares /var/lib/containers/storage
   
   # Start a test pod
   kubectl run test-nginx --image=nginx --restart=Never
   
   # Verify storage location
   df -h /home/devops-loop-data/crio-storage
   ```

3. **Log Rotation**
   ```bash
   # Check journal size
   journalctl --disk-usage
   
   # Verify CRI-O config
   cat /etc/crio/crio.conf.d/20-log-limits.conf
   ```

4. **Cleanup Execution**
   ```bash
   # Run manually
   sudo /usr/local/bin/devops-loop-cleanup.sh
   
   # Check log
   cat /var/log/devops-loop-cleanup.log
   ```

## Acceptance Criteria Validation

### AC1: Smart Redirection ✓
- [x] Detects root partition < 150GB
- [x] Detects home partition > 200GB
- [x] Automatically creates symlinks for NFS and CRI-O
- [x] Redirects to /home partition via symlinks
- [x] Backs up existing directories with timestamps

### AC2: Log Rotation ✓
- [x] journald capped at 2GB system maximum
- [x] CRI-O logs limited to 10MB per container
- [x] Configurations applied automatically
- [x] Services restarted with new limits

### AC3: Scheduled Cleanup ✓
- [x] Weekly cron job installed (Sundays 2 AM)
- [x] Prunes unused container images
- [x] Cleans Maven cache
- [x] Clears DNF cache
- [x] Logs execution to `/var/log/devops-loop-cleanup.log`

## Troubleshooting

### Issue: Redirection not triggered

**Cause:** Root or home partition sizes don't meet thresholds

**Solution:** Check partition sizes:
```bash
df -BG / /home
```

### Issue: CRI-O fails to start after redirection

**Cause:** Permissions or SELinux context issues

**Solution:**
```bash
# Check SELinux context
ls -laZ /home/devops-loop-data/crio-storage

# Restore context if needed
sudo restorecon -Rv /home/devops-loop-data/
```

### Issue: Cleanup script not running

**Cause:** Cron job not installed or cron service not running

**Solution:**
```bash
# Verify cron job
sudo crontab -l | grep devops-loop-cleanup

# Check cron service
sudo systemctl status crond

# Manually add cron job
(sudo crontab -l; echo "0 2 * * 0 /usr/local/bin/devops-loop-cleanup.sh") | sudo crontab -
```

### Issue: Journal still growing beyond 2GB

**Cause:** Config not applied or service not restarted

**Solution:**
```bash
# Verify config
cat /etc/systemd/journald.conf.d/10-devops-loop.conf

# Restart journald
sudo systemctl restart systemd-journald

# Force rotation
sudo journalctl --rotate
sudo journalctl --vacuum-size=2G
```

## Performance Impact

- **Redirection:** Negligible - symlinks add no performance overhead
- **Log rotation:** None - only limits growth, doesn't affect runtime
- **Cleanup:** Runs weekly off-peak (2 AM Sunday), minimal CPU/IO impact

## Security Considerations

- All configuration files created with appropriate permissions (644/755)
- Backup directories retain original permissions
- No credentials or sensitive data in configuration files
- Cleanup script runs as root via cron (required for system operations)

## Compatibility

- **OS:** RHEL 9.x, compatible derivatives (Rocky, AlmaLinux)
- **Kubernetes:** 1.30+
- **CRI-O:** 1.28+
- **Requires:** bash, systemd, cron, standard GNU utilities

## Future Enhancements

- [ ] Make thresholds configurable via environment variables
- [ ] Support additional redirect targets (/opt, /data)
- [ ] Prometheus metrics export
- [ ] Alerting integration (email, Slack)
- [ ] Dry-run mode for testing
- [ ] Migration tool for existing installations
- [ ] Dashboard UI for monitoring

## Support

For issues or questions:
1. Check the troubleshooting section above
2. Review logs: `/var/log/devops-loop-cleanup.log`
3. Verify configuration files in `/etc/`
4. Open a GitHub issue with:
   - Output of `df -h`
   - Contents of `/etc/devops-loop-storage-redirect.conf`
   - Recent entries from cleanup log

## License

Licensed Materials - Property of HCL  
(C) Copyright HCL Technologies Ltd. 2026. All Rights Reserved

## Version History

- **v1.0.0** (2026-08-25) - Initial release
  - Smart data redirection
  - Log rotation limits
  - Scheduled cleanup automation
