#Required
#External fully qualified domain name of the cluster
#
#See Installation of DevOps Loop documentation for more details:
#https://www.ibm.com/docs/en/devops-loop/3.0.0?topic=administration-installation-devops-loop
DOMAIN=

#Required
#Set value to 'true' to accept the license.
ACCEPT_LICENSE=

#Required
#Hostname of IBM Rational license server
LICENSE_SERVER=

#Required
#SMTP Server configuration
EMAIL_SERVER_HOST=
EMAIL_SERVER_PORT=
EMAIL_FROM_ADDRESS=

#Optional
#Additional SMTP Server configuration
EMAIL_SERVER_USERNAME=""
EMAIL_SERVER_PASSWORD=""
EMAIL_SERVER_STARTTLS=false
EMAIL_SERVER_SMTPS=false

#Required
#Secure seed required to generate passwords
#A random string
#Unrecoverable so keep it safe
PASSWORD_SEED=

#Specify the TLS secret name in your namespace as necessary.
#
#See Installation of DevOps Loop documentation for more details:
#https://www.ibm.com/docs/en/devops-loop/3.0.0?topic=administration-installation-devops-loop
TLS_CERT_SECRET_NAME=

#Set SELF_SIGNED=true to generate and use a self-signed certificate for the
#installation of DevOps Loop
SELF_SIGNED=

#Alternative RWX storage class
#See Storage
#For example: ibmc-file-gold-gid
RWX_STORAGE_CLASS=

#Alternative RWO storage class
#See Storage
#For example: ibmc-block-gold
RWO_STORAGE_CLASS=

# optional Appscan integration
APP_SCAN_ENABLED=false

# Required only when APP_SCAN_ENABLED=true
# External URL for AppScan (e.g. https://cloud.appscan.com)
APPSCAN_EXTERNAL_URL=

# Optional Harbor integration
HARBOR_ENABLED=false

# Required only when HARBOR_ENABLED=true
HARBOR_S3_BUCKET=
HARBOR_S3_REGION=
HARBOR_S3_ENDPOINT=

# Harbor Trivy cache uses RWX
#See Storage
#For example: ibmc-file-gold-gid
HARBOR_TRIVY_STORAGE_CLASS=

# Harbor OIDC admin group in Keycloak
# Users in this group become Harbor system administrators.
HARBOR_OIDC_ADMIN_GROUP=

#Required
NAMESPACE=devops-loop
HELM_NAME=devops-loop
LOOP_CHART_VERSION=3.0.0

#Optional Additional Helm options
ADDITIONAL_HELM_OPTIONS=""

CHART_REF="${CHART_REF:-ibm-helm/ibm-devops-loop}"
ROOT_DIR="${ROOT_DIR:-./ibm-devops-loop}"

if [ ! -f "${ROOT_DIR}/Chart.yaml" ]; then
  echo "Local chart not found at ${ROOT_DIR}. Pulling ${CHART_REF}..."

  helm repo add ibm-helm https://raw.githubusercontent.com/IBM/charts/master/repo/ibm-helm --force-update || {
    echo "ERROR: Failed to add IBM Helm repository"
    exit 1
  }

  helm pull --untar "${CHART_REF}" --version "${LOOP_CHART_VERSION}" || {
    echo "ERROR: Failed to pull DevOps Loop chart from ${CHART_REF}"
    exit 1
  }

  if [ ! -f "${ROOT_DIR}/Chart.yaml" ]; then
    echo "ERROR: Chart was pulled, but ${ROOT_DIR}/Chart.yaml was not found."
    exit 1
  fi
fi

MONGODB_HELPER_SCRIPT="${MONGODB_HELPER_SCRIPT:-${ROOT_DIR}/scripts/mongodb.sh}"
if [ ! -f "${MONGODB_HELPER_SCRIPT}" ]; then
  echo "ERROR: MongoDB helper not found at ${MONGODB_HELPER_SCRIPT}."
  echo "Set ROOT_DIR to the extracted DevOps Loop chart directory or set MONGODB_HELPER_SCRIPT."
  exit 1
fi
. "${MONGODB_HELPER_SCRIPT}"

wait_for_secret() {
  local secret_name="$1"
  local timeout_seconds="${2:-900}"
  local waited=0

  echo "Waiting for secret ${secret_name} in namespace ${NAMESPACE}..."

  until kubectl get secret "${secret_name}" -n "${NAMESPACE}" >/dev/null 2>&1; do
    if [ "${waited}" -ge "${timeout_seconds}" ]; then
      echo "Timed out waiting for secret ${secret_name}"
      return 1
    fi
    sleep 10
    waited=$((waited + 10))
  done

  echo "Secret ${secret_name} is available."
}

run_install() {

  if ! kubectl get namespace ${NAMESPACE} > /dev/null 2>&1; then
    kubectl  create namespace ${NAMESPACE} || { echo "Failed to create namespace"; return 1; }
  fi

  # Bitnami MongoDB provisioning has been removed. The helper deploys MongoDB
  # using the official library/mongo image by default, with MONGO_IMAGE_TAG=8.0.28 because
  # Velocity 5.2.x supports MongoDB 7.0 and 8.0. MongoDB 6.0 is unsupported for
  # Velocity 5.1.8 and later, and MongoDB 8.2.x is not currently listed as
  # supported for Velocity 5.2.x.
  KUBE_CMD=kubectl ensure_mongodb_url_secret || return 1

  if [ "${SELF_SIGNED}" = "true" ]; then
    export TLS_CERT_SECRET_NAME=devops-loop-tls-secret
    openssl genrsa -out key.pem 2048
    openssl req -new -x509 -key key.pem -out cert.pem -days 365 \
            -subj "/CN=${DOMAIN}" -addext "subjectAltName = DNS:${DOMAIN},DNS:*.${DOMAIN}" \
            -addext "certificatePolicies = 1.2.3.4"

    kubectl create secret generic ${TLS_CERT_SECRET_NAME} \
      --type=kubernetes.io/tls \
      --from-file=ca.crt=./cert.pem \
      --from-file=tls.crt=./cert.pem \
      --from-file=tls.key=./key.pem \
      --namespace ${NAMESPACE}
  fi

  HELM_OPTIONS="${HELM_OPTIONS:-} \
--set global.domain=${DOMAIN} \
--set-literal global.passwordSeed=${PASSWORD_SEED} \
--set global.platform.smtp.sender=${EMAIL_FROM_ADDRESS} \
--set global.platform.smtp.host=${EMAIL_SERVER_HOST} \
--set global.platform.smtp.port=${EMAIL_SERVER_PORT} \
--set global.platform.smtp.username=${EMAIL_SERVER_USERNAME} \
--set global.platform.smtp.password=${EMAIL_SERVER_PASSWORD} \
--set global.platform.smtp.startTLS=${EMAIL_SERVER_STARTTLS} \
--set global.platform.smtp.smtps=${EMAIL_SERVER_SMTPS} \
--set global.ibmCertSecretName=${TLS_CERT_SECRET_NAME} \
--set license=${ACCEPT_LICENSE} \
--set platform.appscan.enabled=${APP_SCAN_ENABLED}
"

  if [ "${APP_SCAN_ENABLED}" = "true" ] && [ -n "${APPSCAN_EXTERNAL_URL}" ]; then
    HELM_OPTIONS="${HELM_OPTIONS} --set-string platform.appscan.externalURL=${APPSCAN_EXTERNAL_URL}"
  fi

  if [ "${SELF_SIGNED}" = "true" ]; then
     HELM_OPTIONS="${HELM_OPTIONS} --set global.privateCaBundleSecretName=${TLS_CERT_SECRET_NAME}"
     HELM_OPTIONS="${HELM_OPTIONS} --set ibm-devops-prod.ingress.cert.selfSigned=true"
  fi

  if [ -n "${LICENSE_SERVER}" ]; then
    HELM_OPTIONS="${HELM_OPTIONS} --set global.rationalLicenseKeyServer=@${LICENSE_SERVER}"
  fi

  if [ -n "${RWX_STORAGE_CLASS}" ]; then
    HELM_OPTIONS="${HELM_OPTIONS} --set global.persistence.rwxStorageClass=${RWX_STORAGE_CLASS}"
  fi

  if [ -n "${RWO_STORAGE_CLASS}" ]; then
    HELM_OPTIONS="${HELM_OPTIONS} --set global.persistence.rwoStorageClass=${RWO_STORAGE_CLASS}"
  fi

  HELM_OPTIONS="${HELM_OPTIONS} ${ADDITIONAL_HELM_OPTIONS}"

  helm upgrade --install ${HELM_NAME} "${ROOT_DIR}" --version ${LOOP_CHART_VERSION} ${HELM_OPTIONS} \
    --set ibm-ucv-prod.secrets.database=mongodb-url-secret \
    --set harbor.enabled=false \
    -n ${NAMESPACE} || return 1

  if [ "${HARBOR_ENABLED}" != "true" ]; then
    echo "Harbor is disabled. DevOps Loop installation completed."
    return 0
  fi

  echo "Waiting for release jobs to complete before enabling Harbor..."
  for job in $(kubectl get jobs -n "${NAMESPACE}" \
    -l "app.kubernetes.io/instance=${HELM_NAME}" \
    -o jsonpath='{range .items[*]}{.metadata.name}{"\n"}{end}'); do
    kubectl get job "${job}" -n "${NAMESPACE}" >/dev/null 2>&1 || continue
    kubectl wait --for=condition=complete "job/${job}" -n "${NAMESPACE}" --timeout=900s 2>/dev/null || \
    { kubectl get job "${job}" -n "${NAMESPACE}" >/dev/null 2>&1 && return 1 || continue; }
  done

  echo "Validating Harbor prerequisites..."

  if [ -z "${HARBOR_S3_BUCKET}" ]; then
    echo "HARBOR_S3_BUCKET is required when HARBOR_ENABLED=true"
    return 1
  fi

  if [ -z "${HARBOR_S3_REGION}" ]; then
    echo "HARBOR_S3_REGION is required when HARBOR_ENABLED=true"
    return 1
  fi

  if [ -z "${HARBOR_S3_ENDPOINT}" ]; then
    echo "HARBOR_S3_ENDPOINT is required when HARBOR_ENABLED=true"
    return 1
  fi

  if ! kubectl get secret harbor-s3-secret -n "${NAMESPACE}" >/dev/null 2>&1; then
    echo "harbor-s3-secret is required when HARBOR_ENABLED=true"
    echo "Create it before install:"
    echo "kubectl create secret generic harbor-s3-secret -n ${NAMESPACE} --from-literal=accesskey='<ACCESS_KEY>' --from-literal=secretkey='<SECRET_KEY>'"
    return 1
  fi

  if [ -z "${HARBOR_TRIVY_STORAGE_CLASS}" ] && [ -z "${RWX_STORAGE_CLASS}" ]; then
    echo "Either HARBOR_TRIVY_STORAGE_CLASS or RWX_STORAGE_CLASS is required when HARBOR_ENABLED=true"
    return 1
  fi

  echo "Waiting for Harbor dependency secrets"
											  
  for secret in devops-loop-valkey devops-loop-postgresql; do
    if ! wait_for_secret "${secret}" 1200; then
      echo "WARNING: Required Harbor dependency secret ${secret} was not available within timeout period."
      echo "Skipping Harbor installation/upgrade. DevOps Loop base installation completed successfully."
      echo "After ${secret} is available, rerun this script to enable Harbor."
      return 0
    fi
  done

  REDIS_PASSWORD=$(kubectl get secret devops-loop-valkey \
  -n "${NAMESPACE}" \
  -o jsonpath="{.data.valkey-password}" | base64 -d)

  S3_ACCESS_KEY=$(kubectl get secret harbor-s3-secret \
    -n "${NAMESPACE}" \
    -o jsonpath="{.data.accesskey}" | base64 -d)

  S3_SECRET_KEY=$(kubectl get secret harbor-s3-secret \
    -n "${NAMESPACE}" \
    -o jsonpath="{.data.secretkey}" | base64 -d)
  if [ -z "${HARBOR_OIDC_ADMIN_GROUP}" ]; then
    HARBOR_OIDC_ADMIN_GROUP=harbor-admins
  fi

  echo "Using Harbor OIDC admin group: ${HARBOR_OIDC_ADMIN_GROUP}"
  HARBOR_URL="https://harbor.${DOMAIN}"

  HARBOR_HELM_OPTIONS="${HELM_OPTIONS} \
--set harbor.enabled=true \
--set platform.harbor.enabled=true \				
--set ibm-ucv-prod.secrets.database=mongodb-url-secret \
--set-string harbor.externalURL=${HARBOR_URL} \
--set-string harbor.oidc.adminGroup=${HARBOR_OIDC_ADMIN_GROUP} \
--set-string harbor.redis.external.password=${REDIS_PASSWORD} \
--set-string harbor.trivy.externalRedis.password=${REDIS_PASSWORD} \
--set-string harbor.persistence.imageChartStorage.s3.bucket=${HARBOR_S3_BUCKET} \
--set-string harbor.persistence.imageChartStorage.s3.region=${HARBOR_S3_REGION} \
--set-string harbor.persistence.imageChartStorage.s3.regionendpoint=${HARBOR_S3_ENDPOINT} \
--set-string harbor.persistence.imageChartStorage.s3.accesskey=${S3_ACCESS_KEY} \
--set-string harbor.persistence.imageChartStorage.s3.secretkey=${S3_SECRET_KEY}
"

  if [ -n "${HARBOR_TRIVY_STORAGE_CLASS}" ]; then
    HARBOR_HELM_OPTIONS="${HARBOR_HELM_OPTIONS} --set-string harbor.trivy.persistence.storageClass=${HARBOR_TRIVY_STORAGE_CLASS}"
  else
    HARBOR_HELM_OPTIONS="${HARBOR_HELM_OPTIONS} --set-string harbor.trivy.persistence.storageClass=${RWX_STORAGE_CLASS}"
  fi

  echo "Installing optional Harbor integration..."

  HARBOR_HELM_OPTIONS="${HARBOR_HELM_OPTIONS} ${ADDITIONAL_HELM_OPTIONS}"

  helm upgrade --install ${HELM_NAME} "${ROOT_DIR}" --version ${LOOP_CHART_VERSION} ${HARBOR_HELM_OPTIONS} \
    --hide-notes \
	  --timeout 30m \   
    -n ${NAMESPACE} || return 1

  echo "DevOps Loop + Harbor installation completed."
  echo ""
  echo "Harbor URL:"
  echo "  https://harbor.${DOMAIN}"
  echo ""
  echo "Monitor Harbor pods:"
  echo "  kubectl get pods -n ${NAMESPACE} | grep harbor"
  echo ""
  echo "Bootstrap Harbor images:"
  echo "  1. Update scripts/harbor/bootstrap-images.txt"
  echo "  2. Run:"
  echo "     DOMAIN=${DOMAIN} NAMESPACE=${NAMESPACE} RELEASE=${HELM_NAME} scripts/harbor/bootstrap-images.sh"
}

run_install
