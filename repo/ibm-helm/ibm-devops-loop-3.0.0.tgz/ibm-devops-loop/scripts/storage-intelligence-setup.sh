#!/bin/bash
# Licensed Materials - Property of HCL
# (C) Copyright HCL Technologies Ltd. 2026. All Rights Reserved
#
# DevOps Loop Storage Intelligence Setup
# Standalone installation script for intelligent data redirection and retention
#
# Usage: ./storage-intelligence-setup.sh
#
# This script can be run:
# 1. As part of RHEL9-K8S-Infra-Setup.sh (integrated)
# 2. As a standalone script on existing installations
#
# Features:
# - Smart data redirection (NFS, CRI-O to /home when root < 150GB)
# - Log rotation limits (journald: 2GB, CRI-O: 10MB per container)
# - Scheduled cleanup (weekly cron job)

set -eo pipefail

echo "=========================================="
echo "DevOps Loop Storage Intelligence Setup"
echo "=========================================="
echo "Version: 1.0.0"
echo "Date: $(date -Iseconds)"
echo ""

# Determine script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Source the storage management library
STORAGE_LIB="$SCRIPT_DIR/lib/storage-management.sh"

if [[ ! -f "$STORAGE_LIB" ]]; then
  echo "Error: Storage management library not found at: $STORAGE_LIB"
  echo "Please ensure the file structure is intact:"
  echo "  scripts/lib/storage-management.sh"
  echo "  scripts/config/storage-cleanup.sh"
  exit 1
fi

echo "Loading storage management library..."
source "$STORAGE_LIB"
echo "✓ Library loaded successfully"
echo ""

# Pre-flight checks
echo "========== Pre-flight Checks =========="

# Check if running as root or with sudo
if [[ $EUID -ne 0 ]] && ! sudo -n true 2>/dev/null; then
  echo "Error: This script requires root privileges or passwordless sudo."
  echo "Please run with sudo or as root user."
  exit 1
fi
echo "✓ Running with appropriate privileges"

# Check required commands
for cmd in df awk systemctl mkdir ln; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo "Error: Required command '$cmd' not found."
    exit 1
  fi
done
echo "✓ All required commands available"

echo "========================================"
echo ""

# Phase 1: Analyze partition layout
echo "PHASE 1: Partition Analysis"
echo "----------------------------"
analyze_partition_layout
echo ""

# Phase 2: Smart redirection (if needed)
echo "PHASE 2: Smart Redirection"
echo "--------------------------"
configure_smart_redirection
echo ""

# Phase 3: Log rotation configuration
echo "PHASE 3: Log Rotation"
echo "---------------------"
configure_log_rotation
echo ""

# Phase 4: Scheduled cleanup installation
echo "PHASE 4: Scheduled Cleanup"
echo "--------------------------"
install_scheduled_cleanup
echo ""

# Display summary
show_storage_summary

echo ""
echo "=========================================="
echo "Storage Intelligence Setup Complete"
echo "=========================================="
echo ""
echo "What was configured:"
echo "  ✓ Partition analysis and smart redirection"
echo "  ✓ Log rotation limits (journald + CRI-O)"
echo "  ✓ Weekly cleanup automation (cron)"
echo ""
echo "Next steps:"
echo "  1. Review the configuration summary above"
echo "  2. Test with: sudo /usr/local/bin/devops-loop-cleanup.sh"
echo "  3. Monitor logs: tail -f /var/log/devops-loop-cleanup.log"
echo ""
echo "To verify redirection (if enabled):"
echo "  ls -la /var/nfs-shares"
echo "  ls -la /var/lib/containers/storage"
echo "  df -h / /home"
echo ""
echo "Documentation:"
echo "  Configuration files:"
echo "    - /etc/devops-loop-storage-redirect.conf"
echo "    - /etc/systemd/journald.conf.d/10-devops-loop.conf"
echo "    - /etc/crio/crio.conf.d/10-storage-redirect.conf"
echo "    - /etc/crio/crio.conf.d/20-log-limits.conf"
echo ""
