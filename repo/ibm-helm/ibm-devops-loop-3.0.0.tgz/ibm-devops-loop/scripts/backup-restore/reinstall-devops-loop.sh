#!/bin/bash
#
# DevOps Loop - Reinstallation Script
#
# This script focuses on reinstall-specific tasks and calls the main installation script
# for common functionality.

set -e


NAMESPACE=
if [ -z "$NAMESPACE" ]; then
  echo "ERROR: NAMESPACE not set."
  exit 1
fi

HELM_NAME=
if [ -z "$HELM_NAME" ]; then
  echo "ERROR: HELM_NAME not set."
  exit 1
fi

LOOP_VERSION=2.0.100

ADDITIONAL_HELM_OPTIONS=""

CHART_REF="${CHART_REF:-ibm-helm/ibm-devops-loop}"
ROOT_DIR="${ROOT_DIR:-./ibm-devops-loop}"

if [ ! -f "${ROOT_DIR}/Chart.yaml" ]; then
  echo "Local chart not found at ${ROOT_DIR}. Pulling ${CHART_REF}..."

  helm repo add ibm-helm https://raw.githubusercontent.com/IBM/charts/master/repo/ibm-helm --force-update || {
    echo "ERROR: Failed to add IBM Helm repository"
    exit 1
  }

  helm pull --untar "${CHART_REF}" --version "${LOOP_VERSION}" || {
    echo "ERROR: Failed to pull DevOps Loop chart from ${CHART_REF}"
    exit 1
  }

  if [ ! -f "${ROOT_DIR}/Chart.yaml" ]; then
    echo "ERROR: Chart was pulled, but ${ROOT_DIR}/Chart.yaml was not found."
    exit 1
  fi
fi

MONGODB_HELPER_SCRIPT="${MONGODB_HELPER_SCRIPT:-${ROOT_DIR}/scripts/mongodb.sh}"
if [ ! -f "${MONGODB_HELPER_SCRIPT}" ]; then
  echo "ERROR: MongoDB helper not found at ${MONGODB_HELPER_SCRIPT}."
  echo "Set ROOT_DIR to the extracted DevOps Loop chart directory or set MONGODB_HELPER_SCRIPT."
  exit 1
fi
. "${MONGODB_HELPER_SCRIPT}"

check_mongodb() {  
  MONGO_HELM_RELEASE_NAME="${MONGO_HELM_RELEASE_NAME:-devops-loop-mongo}"
      
  if kubectl get pvc ${MONGO_HELM_RELEASE_NAME}-mongodb -n ${NAMESPACE} > /dev/null 2>&1; then
    export MONGO_PVC_NAME="${MONGO_HELM_RELEASE_NAME}-mongodb"
  fi
}

run_reinstall() {  
  check_mongodb  
  
  KUBE_CMD=kubectl ensure_mongodb_url_secret || return 1
  
  helm upgrade --install ${HELM_NAME} "${ROOT_DIR}" --version ${LOOP_VERSION} \
  --set ibm-ucv-prod.secrets.database=mongodb-url-secret \
  ${ADDITIONAL_HELM_OPTIONS} \
  -n ${NAMESPACE} \
  --reuse-values || return 1

  echo
  echo "Re-installation process completed successfully!"

}

run_reinstall
