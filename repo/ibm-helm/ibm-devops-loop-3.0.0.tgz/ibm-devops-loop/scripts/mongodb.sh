#!/bin/bash

# MongoDB 8.0.x is the default because DevOps Loop 2.0.2 includes
# HCL DevOps Velocity 5.2.5, which supports MongoDB 7.0 and 8.0.
# MongoDB 6.0 is unsupported for Velocity 5.1.8 and later, and
# MongoDB 8.2.x is not currently listed as supported for Velocity 5.2.x.

validate_mongodb_url_secret() {
  local kube_cmd="${KUBE_CMD:-kubectl}"
  local namespace="${NAMESPACE:?NAMESPACE must be set}"
  local mongo_url

  if ! "${kube_cmd}" get secret mongodb-url-secret --namespace "${namespace}" >/dev/null 2>&1; then
    echo "MongoDB URL secret mongodb-url-secret was not found in namespace ${namespace}."
    return 1
  fi

  mongo_url=$("${kube_cmd}" get secret mongodb-url-secret --namespace "${namespace}" -o jsonpath="{.data.password}" | base64 -d)
  case "${mongo_url}" in
    mongodb://*|mongodb+srv://*) ;;
    *)
      echo "Secret mongodb-url-secret must contain key password with a valid MongoDB URI."
      return 1
      ;;
  esac
}

generate_mongodb_password() {
  if command -v openssl >/dev/null 2>&1; then
    openssl rand -hex 24
  else
    printf '%s-%s\n' "$(date +%s)" "${RANDOM:-0}" | base64
  fi
}

urlencode_mongodb_password() {
  local value="$1"
  local hex
  local encoded=""
  local byte

  hex=$(printf '%s' "${value}" | od -An -tx1 | tr -d ' \n')
  while [ -n "${hex}" ]; do
    byte="${hex%${hex#??}}"
    encoded="${encoded}%${byte}"
    hex="${hex#??}"
  done
  printf '%s' "${encoded}"
}

ensure_mongodb_url_secret() {
  local kube_cmd="${KUBE_CMD:-kubectl}"
  local namespace="${NAMESPACE:?NAMESPACE must be set}"
  local mongo_install_mode="${MONGO_INSTALL_MODE:-managed}"
  local mongo_force_recreate_secret="${MONGO_FORCE_RECREATE_SECRET:-false}"
  local mongo_release="${MONGO_HELM_RELEASE_NAME:-devops-loop-mongo}"
  local mongo_namespace="${MONGO_NAMESPACE:-${namespace}}"
  local mongo_registry="${MONGO_REGISTRY:-}"
  local mongo_image_tag="${MONGO_IMAGE_TAG:-${MONGO_VERSION:-8.0.28}}"
  local mongo_image_repo="${MONGO_IMAGE_REPO:-library/mongo}"
  local mongo_image
  local mongo_image_pull_policy="${MONGO_IMAGE_PULL_POLICY:-IfNotPresent}"
  local mongo_image_pull_secret="${MONGO_IMAGE_PULL_SECRET:-${MONGO_PULLSECRET:-}}"
  local mongo_image_pull_secrets_yaml=""
  local mongo_storage_class_yaml=""
  local mongo_pvc_size="${MONGO_PVC_SIZE:-20Gi}"
  local mongo_pvc_name="${MONGO_PVC_NAME:-${mongo_release}-mongodb}"
  local mongo_auth_secret="${MONGO_AUTH_SECRET:-${mongo_release}-auth}"
  local mongo_ready_timeout="${MONGO_READY_TIMEOUT:-900s}"
  local mongo_cpu_request="${MONGO_CPU_REQUEST:-100m}"
  local mongo_memory_request="${MONGO_MEMORY_REQUEST:-256Mi}"
  local mongo_cpu_limit="${MONGO_CPU_LIMIT:-1000m}"
  local mongo_memory_limit="${MONGO_MEMORY_LIMIT:-1Gi}"
  local mongo_auth_check_attempts="${MONGO_AUTH_CHECK_ATTEMPTS:-30}"
  local mongo_auth_check_delay="${MONGO_AUTH_CHECK_DELAY:-5}"
  local mongodb_root_password
  local mongodb_uri_password
  local mongo_url
  local mongo_pod
  local mongo_auth_validation_output=""

  if [ -n "${MONGO_IMAGE:-}" ]; then
    mongo_image="${MONGO_IMAGE}"
  elif [ -n "${mongo_registry}" ]; then
    mongo_image="${mongo_registry}/${mongo_image_repo}:${mongo_image_tag}"
  else
    mongo_image="${mongo_image_repo}:${mongo_image_tag}"
  fi

  if [ "${mongo_install_mode}" = "external" ]; then
    validate_mongodb_url_secret
    echo "Using external MongoDB URL from mongodb-url-secret in namespace ${namespace}."
    return 0
  fi

  if "${kube_cmd}" get secret mongodb-url-secret --namespace "${namespace}" >/dev/null 2>&1; then
    if [ "${mongo_force_recreate_secret}" != "true" ]; then
      validate_mongodb_url_secret
      echo "Using existing mongodb-url-secret in namespace ${namespace}."
      return 0
    fi
    "${kube_cmd}" delete secret mongodb-url-secret --namespace "${namespace}" >/dev/null
  fi

  if [ "${mongo_install_mode}" = "airgap" ]; then
    case "${mongo_image}" in
      mongo:*|library/mongo:*|docker.io/*|index.docker.io/*|registry-1.docker.io/*)
        echo "MONGO_INSTALL_MODE=airgap requires MongoDB to use a private mirrored runtime image."
        echo "Set MONGO_IMAGE_REPO=\${DEST_REGISTRY}/mongo, or set MONGO_REGISTRY and MONGO_IMAGE_REPO, or set MONGO_IMAGE to a private mirrored image."
        return 1
        ;;
    esac
    mongo_install_mode="managed"
  fi

  if [ "${mongo_install_mode}" != "managed" ]; then
    echo "Unsupported MONGO_INSTALL_MODE=${mongo_install_mode}. Use managed, airgap, or external."
    return 1
  fi

  if [ -n "${mongo_image_pull_secret}" ]; then
    mongo_image_pull_secrets_yaml="      imagePullSecrets:
      - name: ${mongo_image_pull_secret}"
  fi

  if [ -n "${RWO_STORAGE_CLASS}" ]; then
    mongo_storage_class_yaml="  storageClassName: ${RWO_STORAGE_CLASS}"
  fi

  if ! "${kube_cmd}" get namespace "${mongo_namespace}" >/dev/null 2>&1; then
    "${kube_cmd}" create namespace "${mongo_namespace}" || { echo "Failed to create MongoDB namespace"; return 1; }
  fi

  if "${kube_cmd}" get secret "${mongo_auth_secret}" --namespace "${mongo_namespace}" >/dev/null 2>&1; then
    mongodb_root_password=$("${kube_cmd}" get secret "${mongo_auth_secret}" --namespace "${mongo_namespace}" -o jsonpath="{.data.mongodb-root-password}" | base64 -d)
  else
    mongodb_root_password="$(generate_mongodb_password)"
    "${kube_cmd}" create secret generic "${mongo_auth_secret}" \
      --namespace "${mongo_namespace}" \
      --from-literal=mongodb-root-password="${mongodb_root_password}" >/dev/null || {
        echo "Failed to create MongoDB auth secret"
        return 1
      }
  fi

  "${kube_cmd}" apply --namespace "${mongo_namespace}" -f - >/dev/null <<EOF || { echo "Failed to install MongoDB"; return 1; }
apiVersion: v1
kind: Service
metadata:
  name: ${mongo_release}-mongodb
  labels:
    app.kubernetes.io/name: mongodb
    app.kubernetes.io/instance: ${mongo_release}
spec:
  ports:
  - name: mongodb
    port: 27017
    targetPort: mongodb
  selector:
    app.kubernetes.io/name: mongodb
    app.kubernetes.io/instance: ${mongo_release}
---
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: ${mongo_pvc_name}
  labels:
    app.kubernetes.io/name: mongodb
    app.kubernetes.io/instance: ${mongo_release}
spec:
${mongo_storage_class_yaml}
  accessModes:
  - ReadWriteOnce
  resources:
    requests:
      storage: ${mongo_pvc_size}
EOF

  "${kube_cmd}" apply --namespace "${mongo_namespace}" -f - >/dev/null <<EOF || { echo "Failed to install MongoDB"; return 1; }
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: ${mongo_release}
  labels:
    app.kubernetes.io/name: mongodb
    app.kubernetes.io/instance: ${mongo_release}
spec:
  serviceName: ${mongo_release}-mongodb
  replicas: 1
  selector:
    matchLabels:
      app.kubernetes.io/name: mongodb
      app.kubernetes.io/instance: ${mongo_release}
  template:
    metadata:
      labels:
        app.kubernetes.io/name: mongodb
        app.kubernetes.io/instance: ${mongo_release}
    spec:
${mongo_image_pull_secrets_yaml}
      containers:
      - name: mongodb
        image: ${mongo_image}
        imagePullPolicy: ${mongo_image_pull_policy}
        ports:
        - name: mongodb
          containerPort: 27017
        resources:
          requests:
            cpu: ${mongo_cpu_request}
            memory: ${mongo_memory_request}
          limits:
            cpu: ${mongo_cpu_limit}
            memory: ${mongo_memory_limit}
        env:
        - name: MONGO_INITDB_ROOT_USERNAME
          value: root
        - name: MONGO_INITDB_ROOT_PASSWORD
          valueFrom:
            secretKeyRef:
              name: ${mongo_auth_secret}
              key: mongodb-root-password
        volumeMounts:
        - name: mongodb-data
          mountPath: /data/db
      volumes:
      - name: mongodb-data
        persistentVolumeClaim:
          claimName: ${mongo_pvc_name}
EOF

  mongodb_uri_password="$(urlencode_mongodb_password "${mongodb_root_password}")"
  mongo_url="mongodb://root:${mongodb_uri_password}@${mongo_release}-mongodb.${mongo_namespace}.svc.cluster.local:27017/admin"

  echo "Waiting for MongoDB StatefulSet ${mongo_release} to become ready..."
  "${kube_cmd}" rollout status "statefulset/${mongo_release}" \
    --namespace "${mongo_namespace}" \
    --timeout "${mongo_ready_timeout}" >/dev/null || {
      echo "Timed out waiting for MongoDB StatefulSet ${mongo_release} to become ready."
      return 1
    }

  mongo_pod=$("${kube_cmd}" get pod \
    --namespace "${mongo_namespace}" \
    -l "app.kubernetes.io/name=mongodb,app.kubernetes.io/instance=${mongo_release}" \
    -o jsonpath="{.items[0].metadata.name}")

  if [ -z "${mongo_pod}" ]; then
    echo "Failed to find MongoDB pod for release ${mongo_release} in namespace ${mongo_namespace}."
    return 1
  fi

  echo "Validating MongoDB authentication and connectivity..."
  for (( attempt=1; attempt<=mongo_auth_check_attempts; attempt++ )); do
    if mongo_auth_validation_output=$(
      "${kube_cmd}" exec "${mongo_pod}" --namespace "${mongo_namespace}" -- \
        env "MONGO_INITDB_ROOT_PASSWORD=${mongodb_root_password}" sh -c \
        'mongosh --quiet "mongodb://localhost:27017/admin?authSource=admin" --username root --password "${MONGO_INITDB_ROOT_PASSWORD}" --authenticationDatabase admin --eval "db.adminCommand({ ping: 1 })" >/dev/null' 2>&1
    ); then
      break
    fi

    if [ "${attempt}" -lt "${mongo_auth_check_attempts}" ]; then
      echo "Waiting for MongoDB authentication to become ready (attempt ${attempt}/${mongo_auth_check_attempts})..."
      sleep "${mongo_auth_check_delay}"
      continue
    fi

    echo "MongoDB did not accept the configured root credentials after retries. MongoDB auth was not ready after retry timeout. Credentials do not match existing MongoDB data/secrets if resources were not fully cleaned."
    return 1
  done

  "${kube_cmd}" create secret generic mongodb-url-secret \
    --namespace "${namespace}" \
    --from-literal=password="${mongo_url}" >/dev/null || {
      echo "Failed to create MongoDB URL secret"
      return 1
    }
}
