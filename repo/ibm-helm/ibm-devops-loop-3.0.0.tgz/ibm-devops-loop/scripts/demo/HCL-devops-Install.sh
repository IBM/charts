preflight_check_storage() {
  for cmd in df awk; do
    if ! command -v "$cmd" >/dev/null 2>&1; then
      echo "Error: '$cmd' is required for storage check."
      exit 1
    fi
  done
  echo "========== Storage Check =========="
  RECOMMENDED_ROOT_GB=200
  MIN_ROOT_GB=120
  ROOT_SIZE_GB=$(df -BG / | awk 'NR==2 {gsub(/G/, "", $2); print $2}')
  if ! [[ "$ROOT_SIZE_GB" =~ ^[0-9]+$ ]]; then
    echo "Error: Unable to detect root partition size."
    exit 1
  fi
  echo "Detected root (/) size: ${ROOT_SIZE_GB}GB (recommended ~${RECOMMENDED_ROOT_GB}GB, minimum ${MIN_ROOT_GB}GB)"
  if [[ "$ROOT_SIZE_GB" -lt "$MIN_ROOT_GB" ]]; then
    echo "ERROR: Root (/) partition must be at least ${MIN_ROOT_GB}GB."
    exit 1
  elif [[ "$ROOT_SIZE_GB" -lt "$RECOMMENDED_ROOT_GB" ]]; then
    echo "Warning: Root partition below recommended ${RECOMMENDED_ROOT_GB}GB. This can trigger Kubernetes DiskPressure conditions, causing pods to fail or be evicted."
  else
    echo "[ OK ] Root partition size looks sufficient."
  fi
  echo
  echo "========== RAM Check =============="
  RECOMMENDED_RAM_GB=64
  MINIMUM_RAM_GB=32
  if [[ ! -f /proc/meminfo ]]; then
    echo "Error: Cannot determine system RAM."
    exit 1
  fi
  TOTAL_RAM_GB=$(( $(awk '/MemTotal/ {print $2}' /proc/meminfo) / 1024 / 1024 ))
  echo "Detected RAM: ${TOTAL_RAM_GB}GB (recommended ~${RECOMMENDED_RAM_GB}GB, minimum ${MINIMUM_RAM_GB}GB)"
  if [[ "$TOTAL_RAM_GB" -lt "$MINIMUM_RAM_GB" ]]; then
    echo "ERROR: Minimum RAM requirement is ${MINIMUM_RAM_GB}GB."
    exit 1
  elif [[ "$TOTAL_RAM_GB" -lt "$RECOMMENDED_RAM_GB" ]]; then
    echo "Warning: RAM below recommended ${RECOMMENDED_RAM_GB}GB. This may cause severe performance issues."
  else
    echo "[ OK ] RAM size looks sufficient."
  fi
  echo
} 

#Required
#External fully qualified domain name of the cluster
#
#See Installation of DevOps Loop documentation for more details:
#https://help.hcl-software.com/devops/loop/3.0.0/docs/topics/c_install.html
DOMAIN=$(hostname -I | awk '{ print $1; }').nip.io

#Required
#Set value to 'true' to accept the license.
ACCEPT_LICENSE=true

#Required
#Hostname of HCL MHS license server eg. https://hcl.com:443
LICENSE_SERVER=
#License Pool ID (obtained from MHS)
LICENSE_ID=

#Required
#SMTP Server configuration
EMAIL_SERVER_HOST=
EMAIL_SERVER_PORT=
EMAIL_FROM_ADDRESS=

#Optional
#Additional SMTP Server configuration
EMAIL_SERVER_USERNAME=""
EMAIL_SERVER_PASSWORD=""
EMAIL_SERVER_STARTTLS=false
EMAIL_SERVER_SMTPS=false

#Required
#Secure seed required to generate passwords
#A random string
#Unrecoverable so keep it safe
PASSWORD_SEED=secret

#Specify the TLS secret name in your namespace as necessary.
#
#See Installation of DevOps Loop documentation for more details:
#https://help.hcl-software.com/devops/loop/3.0.0/docs/topics/c_install.html
TLS_CERT_SECRET_NAME=devops-loop-tls-secret

#Set SELF_SIGNED=true to generate and use a self-signed certificate for the
#installation of DevOps Loop
SELF_SIGNED=true

#Alternative RWX storage class
#See Storage
#For example: ibmc-file-gold-gid
RWX_STORAGE_CLASS=nfs-client

#Alternative RWO storage class
#See Storage
#For example: ibmc-block-gold
RWO_STORAGE_CLASS=nfs-client

# optional Appscan integration
APP_SCAN_ENABLED=false

# Required only when APP_SCAN_ENABLED=true
# External URL for AppScan (e.g. https://cloud.appscan.com)
APPSCAN_EXTERNAL_URL=									  

# Optional Harbor integration
HARBOR_ENABLED=false

# Required only when HARBOR_ENABLED=true
HARBOR_S3_BUCKET=
HARBOR_S3_REGION=
HARBOR_S3_ENDPOINT=

# Harbor Trivy cache uses RWX
#See Storage
#For example: ibmc-file-gold-gid
HARBOR_TRIVY_STORAGE_CLASS=

# Harbor OIDC admin group in Keycloak
# Users in this group become Harbor system administrators.
HARBOR_OIDC_ADMIN_GROUP=

#Required
NAMESPACE=devops-loop
HELM_NAME=devops-loop
LOOP_CHART_VERSION=3.0.0

#Optional Additional Helm options
ADDITIONAL_HELM_OPTIONS=""

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"

# Helm chart source. The chart is pulled locally so the install script can use
# scripts/HCL/prepare-self-signed-tls.sh before Helm runs.
CHART_REF="${CHART_REF:-oci://hclcr.io/devops-automation-helm/hcl-devops-loop}"
ROOT_DIR="${ROOT_DIR:-./hcl-devops-loop}"
SELF_SIGNED_TLS_SCRIPT="${SELF_SIGNED_TLS_SCRIPT:-}"

if [ ! -f "${ROOT_DIR}/Chart.yaml" ]; then
  echo "Local chart not found at ${ROOT_DIR}. Pulling ${CHART_REF}..."

  helm pull "${CHART_REF}" --version "${LOOP_CHART_VERSION}" --untar || {
    echo "ERROR: Failed to pull DevOps Loop chart from ${CHART_REF}"
    exit 1
  }

  if [ ! -f "${ROOT_DIR}/Chart.yaml" ]; then
    echo "ERROR: Chart was pulled, but ${ROOT_DIR}/Chart.yaml was not found."
    exit 1
  fi
fi

MONGODB_HELPER_SCRIPT="${MONGODB_HELPER_SCRIPT:-${ROOT_DIR}/scripts/mongodb.sh}"
if [ ! -f "${MONGODB_HELPER_SCRIPT}" ]; then
  echo "ERROR: MongoDB helper not found at ${MONGODB_HELPER_SCRIPT}."
  echo "Set ROOT_DIR to the extracted DevOps Loop chart directory or set MONGODB_HELPER_SCRIPT."
  exit 1
fi
. "${MONGODB_HELPER_SCRIPT}"

wait_for_secret() {
  local secret_name="$1"
  local timeout_seconds="${2:-900}"
  local waited=0

  echo "Waiting for secret ${secret_name} in namespace ${NAMESPACE}..."

  until kubectl get secret "${secret_name}" -n "${NAMESPACE}" >/dev/null 2>&1; do
    if [ "${waited}" -ge "${timeout_seconds}" ]; then
      echo "Timed out waiting for secret ${secret_name}"
      return 1
    fi
    sleep 10
    waited=$((waited + 10))
  done

  echo "Secret ${secret_name} is available."
}

run_install() {

  APPSCAN_EXTERNAL_URL="$(printf '%s' "${APPSCAN_EXTERNAL_URL:-}" | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//' -e 's:/*$::')"
  if [ "${APP_SCAN_ENABLED}" = "true" ]; then
    if [ -z "${APPSCAN_EXTERNAL_URL}" ]; then
      echo "APPSCAN_EXTERNAL_URL is required when APP_SCAN_ENABLED=true"
      return 1
    fi
    case "${APPSCAN_EXTERNAL_URL}" in
      https://*) ;;
      *) echo "APPSCAN_EXTERNAL_URL must start with https://"; return 1 ;;
    esac
  fi
  preflight_check_storage 

  if ! kubectl  get namespace ${NAMESPACE} > /dev/null 2>&1; then
    kubectl  create namespace ${NAMESPACE} || { echo "Failed to create namespace"; return 1; }
  fi


  KUBE_CMD=kubectl ensure_mongodb_url_secret || return 1

  if [ "${SELF_SIGNED}" = "true" ]; then
    TLS_CERT_SECRET_NAME="${TLS_CERT_SECRET_NAME:-devops-loop-tls-secret}"
    CERT_DIR="${CERT_DIR:-./appscan-sso-certs}"

    # Locate the TLS helper from standard chart/script locations.
    # It is invoked through bash, so executable permission is not required.
    SELF_SIGNED_TLS_SCRIPT="${SELF_SIGNED_TLS_SCRIPT:-${SCRIPT_DIR}/HCL/prepare-self-signed-tls.sh}"
    [ -f "${SELF_SIGNED_TLS_SCRIPT}" ] || SELF_SIGNED_TLS_SCRIPT="${ROOT_DIR}/scripts/HCL/prepare-self-signed-tls.sh"
    [ -f "${SELF_SIGNED_TLS_SCRIPT}" ] || SELF_SIGNED_TLS_SCRIPT="${SCRIPT_DIR}/hcl-devops-loop/scripts/HCL/prepare-self-signed-tls.sh"

    if [ ! -f "${SELF_SIGNED_TLS_SCRIPT}" ]; then
      echo "ERROR: prepare-self-signed-tls.sh not found. Set SELF_SIGNED_TLS_SCRIPT or ROOT_DIR."
      return 1
    fi

    bash "${SELF_SIGNED_TLS_SCRIPT}" \
      --domain "${DOMAIN}" \
      --namespace "${NAMESPACE}" \
      --secret-name "${TLS_CERT_SECRET_NAME}" \
      --cert-dir "${CERT_DIR}" || return 1
  fi

  HELM_OPTIONS="${HELM_OPTIONS:-} \
--set global.domain=${DOMAIN} \
--set-literal global.passwordSeed=${PASSWORD_SEED} \
--set global.platform.smtp.sender=${EMAIL_FROM_ADDRESS} \
--set global.platform.smtp.host=${EMAIL_SERVER_HOST} \
--set global.platform.smtp.port=${EMAIL_SERVER_PORT} \
--set global.platform.smtp.username=${EMAIL_SERVER_USERNAME} \
--set global.platform.smtp.password=${EMAIL_SERVER_PASSWORD} \
--set global.platform.smtp.startTLS=${EMAIL_SERVER_STARTTLS} \
--set global.platform.smtp.smtps=${EMAIL_SERVER_SMTPS} \
--set global.hclCertSecretName=${TLS_CERT_SECRET_NAME} \
--set license=${ACCEPT_LICENSE} \
--set platform.appscan.enabled="${APP_SCAN_ENABLED}" \
--set-string platform.appscan.externalURL="${APPSCAN_EXTERNAL_URL}" \
--set platform.appscan.keycloak.enabled="${APP_SCAN_ENABLED}" \
--set-string platform.appscan.keycloak.clientId="appscan360"
"

  if [ "${SELF_SIGNED}" = "true" ]; then
     HELM_OPTIONS="${HELM_OPTIONS} --set global.privateCaBundleSecretName=${TLS_CERT_SECRET_NAME}"
     HELM_OPTIONS="${HELM_OPTIONS} --set hcl-devops.ingress.cert.selfSigned=true"
  fi

  if [ -n "${LICENSE_SERVER}" ]; then
      HELM_OPTIONS="${HELM_OPTIONS} \
      --set licensing.vendor=HCL \
      --set global.hclLicensingURL=${LICENSE_SERVER} \
      --set global.hclLicensingID=${LICENSE_ID} \
      --set hcl-devops.hclLicensingURL=${LICENSE_SERVER} \
      --set hcl-devops.hclLicensingID=${LICENSE_ID}"
  fi

  if [ -n "${RWX_STORAGE_CLASS}" ]; then
    HELM_OPTIONS="${HELM_OPTIONS} --set global.persistence.rwxStorageClass=${RWX_STORAGE_CLASS}"
  fi

  if [ -n "${RWO_STORAGE_CLASS}" ]; then
    HELM_OPTIONS="${HELM_OPTIONS} --set global.persistence.rwoStorageClass=${RWO_STORAGE_CLASS}"
  fi

  HELM_OPTIONS="${HELM_OPTIONS} ${ADDITIONAL_HELM_OPTIONS}"

  helm upgrade --install ${HELM_NAME} "${ROOT_DIR}" --version ${LOOP_CHART_VERSION} ${HELM_OPTIONS} \
    --set ibm-ucv-prod.secrets.database=mongodb-url-secret \
    --set harbor.enabled=false \
    -n ${NAMESPACE} || return 1

  if [ "${HARBOR_ENABLED}" != "true" ]; then
    echo "Harbor is disabled. DevOps Loop installation completed."
    return 0
  fi

  echo "Waiting for release jobs to complete before enabling Harbor..."
  for job in $(kubectl get jobs -n "${NAMESPACE}" \
    -l "app.kubernetes.io/instance=${HELM_NAME}" \
    -o jsonpath='{range .items[*]}{.metadata.name}{"\n"}{end}'); do
    kubectl get job "${job}" -n "${NAMESPACE}" >/dev/null 2>&1 || continue
    kubectl wait --for=condition=complete "job/${job}" -n "${NAMESPACE}" --timeout=900s 2>/dev/null || \
    { kubectl get job "${job}" -n "${NAMESPACE}" >/dev/null 2>&1 && return 1 || continue; }
  done

  echo "Validating Harbor prerequisites..."

  if [ -z "${HARBOR_S3_BUCKET}" ]; then
    echo "HARBOR_S3_BUCKET is required when HARBOR_ENABLED=true"
    return 1
  fi

  if [ -z "${HARBOR_S3_REGION}" ]; then
    echo "HARBOR_S3_REGION is required when HARBOR_ENABLED=true"
    return 1
  fi

  if [ -z "${HARBOR_S3_ENDPOINT}" ]; then
    echo "HARBOR_S3_ENDPOINT is required when HARBOR_ENABLED=true"
    return 1
  fi

  if ! kubectl get secret harbor-s3-secret -n "${NAMESPACE}" >/dev/null 2>&1; then
    echo "harbor-s3-secret is required when HARBOR_ENABLED=true"
    echo "Create it before install:"
    echo "kubectl create secret generic harbor-s3-secret -n ${NAMESPACE} --from-literal=accesskey='<ACCESS_KEY>' --from-literal=secretkey='<SECRET_KEY>'"
    return 1
  fi

  if [ -z "${HARBOR_TRIVY_STORAGE_CLASS}" ] && [ -z "${RWX_STORAGE_CLASS}" ]; then
    echo "Either HARBOR_TRIVY_STORAGE_CLASS or RWX_STORAGE_CLASS is required when HARBOR_ENABLED=true"
    return 1
  fi

  echo "Waiting for Harbor dependency secrets"
											  

  for secret in devops-loop-valkey devops-loop-postgresql; do
    if ! wait_for_secret "${secret}" 1200; then
      echo "WARNING: Required Harbor dependency secret ${secret} was not available within timeout period."
      echo "Skipping Harbor installation/upgrade. DevOps Loop base installation completed successfully."
      echo "After ${secret} is available, rerun this script to enable Harbor."
      return 0
    fi
  done

  REDIS_PASSWORD=$(kubectl get secret devops-loop-valkey \
    -n "${NAMESPACE}" \
    -o jsonpath="{.data.valkey-password}" | base64 -d)


  S3_ACCESS_KEY=$(kubectl get secret harbor-s3-secret \
    -n "${NAMESPACE}" \
    -o jsonpath="{.data.accesskey}" | base64 -d)

  S3_SECRET_KEY=$(kubectl get secret harbor-s3-secret \
    -n "${NAMESPACE}" \
    -o jsonpath="{.data.secretkey}" | base64 -d)

  if [ -z "${HARBOR_OIDC_ADMIN_GROUP}" ]; then
    HARBOR_OIDC_ADMIN_GROUP=harbor-admins
  fi

  echo "Using Harbor OIDC admin group: ${HARBOR_OIDC_ADMIN_GROUP}"										  
  HARBOR_URL="https://harbor.${DOMAIN}"

  HARBOR_HELM_OPTIONS="${HELM_OPTIONS} \
--set harbor.enabled=true \
--set platform.harbor.enabled=true \									
--set ibm-ucv-prod.secrets.database=mongodb-url-secret \
--set-string harbor.externalURL=${HARBOR_URL} \
--set-string harbor.oidc.adminGroup=${HARBOR_OIDC_ADMIN_GROUP} \
--set-string harbor.redis.external.password=${REDIS_PASSWORD} \
--set-string harbor.trivy.externalRedis.password=${REDIS_PASSWORD} \
--set-string harbor.persistence.imageChartStorage.s3.bucket=${HARBOR_S3_BUCKET} \
--set-string harbor.persistence.imageChartStorage.s3.region=${HARBOR_S3_REGION} \
--set-string harbor.persistence.imageChartStorage.s3.regionendpoint=${HARBOR_S3_ENDPOINT} \
--set-string harbor.persistence.imageChartStorage.s3.accesskey=${S3_ACCESS_KEY} \
--set-string harbor.persistence.imageChartStorage.s3.secretkey=${S3_SECRET_KEY}
"

  if [ -n "${HARBOR_TRIVY_STORAGE_CLASS}" ]; then
    HARBOR_HELM_OPTIONS="${HARBOR_HELM_OPTIONS} --set-string harbor.trivy.persistence.storageClass=${HARBOR_TRIVY_STORAGE_CLASS}"
  else
    HARBOR_HELM_OPTIONS="${HARBOR_HELM_OPTIONS} --set-string harbor.trivy.persistence.storageClass=${RWX_STORAGE_CLASS}"
  fi

  echo "Installing optional Harbor integration..."

  HARBOR_HELM_OPTIONS="${HARBOR_HELM_OPTIONS} ${ADDITIONAL_HELM_OPTIONS}"

  helm upgrade --install ${HELM_NAME} "${ROOT_DIR}" --version ${LOOP_CHART_VERSION} ${HARBOR_HELM_OPTIONS} \
    --hide-notes \
	  --timeout 30m \
    -n ${NAMESPACE} || return 1
  echo "DevOps Loop + Harbor installation completed."
  echo ""
  echo "Harbor URL:"
  echo "  https://harbor.${DOMAIN}"
  echo ""
  echo "Monitor Harbor pods:"
  echo "  kubectl get pods -n ${NAMESPACE} | grep harbor"
  echo ""
  echo "Bootstrap Harbor images:"
  echo "  1. Update scripts/harbor/bootstrap-images.txt"
  echo "  2. Run:"
  echo "     DOMAIN=${DOMAIN} NAMESPACE=${NAMESPACE} RELEASE=${HELM_NAME} scripts/harbor/bootstrap-images.sh"

}
run_install
