{{/*
Expand the name of the chart.
*/}}
{{- define "observability.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "observability.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "observability.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "observability.labels" -}}
helm.sh/chart: {{ include "observability.chart" . }}
{{ include "observability.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "observability.selectorLabels" -}}
app.kubernetes.io/name: {{ include "observability.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "observability.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "observability.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Get OpenSearch host - auto-discover from parent chart or use override
*/}}
{{- define "observability.opensearchHost" -}}
{{- if .Values.opensearch.host }}
{{- .Values.opensearch.host }}
{{- else }}
{{- printf "%s-ibm-devopsplan-prod-opensearch" .Release.Name }}
{{- end }}
{{- end }}

{{/*
Get OpenSearch URL
*/}}
{{- define "observability.opensearchUrl" -}}
{{- printf "%s://%s:%d" .Values.opensearch.protocol (include "observability.opensearchHost" .) (int .Values.opensearch.port) }}
{{- end }}

{{/*
Get OpenSearch credentials secret
*/}}
{{- define "observability.opensearchSecret" -}}
{{- if .Values.opensearch.existingSecret }}
{{- .Values.opensearch.existingSecret }}
{{- else }}
{{- printf "%s-ibm-devopsplan-prod-opensearch" .Release.Name }}
{{- end }}
{{- end }}

{{/* Override upstream configName helper (v0.97.1 doesn't tpl-evaluate existingName). */}}
{{- define "opentelemetry-collector.configName" -}}
{{- include "observability.otelConfigMapName" . -}}
{{- end -}}

{{/* Resolve monitoring.opensearch.enabled (default: true). */}}
{{- define "observability.opensearchIngestionEnabled" -}}
{{- $m := .Values.monitoring | default dict -}}
{{- $os := $m.opensearch | default dict -}}
{{- if hasKey $os "enabled" -}}
  {{- ternary "true" "false" (ne (toString $os.enabled) "false") -}}
{{- else -}}
  {{- "true" -}}
{{- end -}}
{{- end -}}

{{/* OpenSearch-bound exporter keys, excluded when ingestion is disabled.
     Keep in sync with otelCollector.exporters keys that target OpenSearch. */}}
{{- define "observability.opensearchExporterKeys" -}}
dataprepper: true
opensearch: true
{{- end -}}

{{/* Resolve global.observability.blackbox.enabled (default: false). */}}
{{- define "observability.blackboxEnabled" -}}
{{- $g := (.Values.global).observability | default dict -}}
{{- $bb := $g.blackbox | default dict -}}
{{- if hasKey $bb "enabled" -}}
  {{- ternary "true" "false" (ne (toString $bb.enabled) "false") -}}
{{- else -}}
  {{- "false" -}}
{{- end -}}
{{- end -}}

{{/* Resolve global.observability.blackbox.persistence.enabled (default: false). */}}
{{- define "observability.blackboxPersistenceEnabled" -}}
{{- $g := (.Values.global).observability | default dict -}}
{{- $bb := ($g.blackbox | default dict).persistence | default dict -}}
{{- if hasKey $bb "enabled" -}}
  {{- ternary "true" "false" (ne (toString $bb.enabled) "false") -}}
{{- else -}}
  {{- "false" -}}
{{- end -}}
{{- end -}}

{{/* --- OTel Collector config helpers --- */}}

{{/* ConfigMap name matching upstream chart's expected naming convention. */}}
{{- define "observability.otelConfigMapName" -}}
{{- printf "%s-otel-collector" .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/* Render enabled exporters map. */}}
{{- define "observability.otelExportersMap" -}}
{{- $out := dict -}}
{{- $osEnabled := eq (include "observability.opensearchIngestionEnabled" .) "true" -}}
{{- $bbEnabled := eq (include "observability.blackboxEnabled" .) "true" -}}
{{- $blocked := include "observability.opensearchExporterKeys" . | fromYaml -}}
{{- range $key, $exp := .Values.otelCollector.exporters -}}
  {{- $on := $exp.enabled -}}
  {{- if and (not $on) $bbEnabled (eq $key "file") -}}
    {{- $on = true -}}
  {{- end -}}
  {{- if $on -}}
    {{- $skip := and (not $osEnabled) (hasKey $blocked $key) -}}
    {{- if not $skip -}}
      {{- $name := default $key $exp.name -}}
      {{- $cfg := $exp.config | default dict -}}
      {{- $rendered := tpl (toYaml $cfg) $ | fromYaml -}}
      {{- $_ := set $out $name $rendered -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- toYaml $out -}}
{{- end -}}

{{/* Map exporter keys to their OTel names. */}}
{{- define "observability.otelExporterNameMap" -}}
{{- $out := dict -}}
{{- $osEnabled := eq (include "observability.opensearchIngestionEnabled" .) "true" -}}
{{- $bbEnabled := eq (include "observability.blackboxEnabled" .) "true" -}}
{{- $blocked := include "observability.opensearchExporterKeys" . | fromYaml -}}
{{- range $key, $exp := .Values.otelCollector.exporters -}}
  {{- $on := $exp.enabled -}}
  {{- if and (not $on) $bbEnabled (eq $key "file") -}}
    {{- $on = true -}}
  {{- end -}}
  {{- if $on -}}
    {{- $skip := and (not $osEnabled) (hasKey $blocked $key) -}}
    {{- if not $skip -}}
      {{- $_ := set $out $key (default $key $exp.name) -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- toYaml $out -}}
{{- end -}}

{{/* Render the full OTel Collector config. */}}
{{- define "observability.otelConfig" -}}
{{- $_ := include "observability.byooValidate" . -}}
{{- $base := index .Values "otel-collector" "config" | deepCopy -}}
{{- $exps := .Values.otelCollector.exporters -}}
{{- $osIngestion := eq (include "observability.opensearchIngestionEnabled" .) "true" -}}
{{- if and $osIngestion (hasKey $exps "opensearch") (index $exps "opensearch" "enabled") -}}
  {{- $extMap := ternary (index $base "extensions") dict (hasKey $base "extensions") -}}
  {{- if not (hasKey $extMap "basicauth/opensearch") -}}
    {{- $_ := set $extMap "basicauth/opensearch" (dict "client_auth" (dict "username" "${env:OS_USERNAME}" "password" "${env:OS_PASSWORD}")) -}}
    {{- $_ := set $base "extensions" $extMap -}}
  {{- end -}}
  {{- $svc := index $base "service" | default dict -}}
  {{- $extList := index $svc "extensions" | default list -}}
  {{- if not (has "basicauth/opensearch" $extList) -}}
    {{- $extList = append $extList "basicauth/opensearch" -}}
    {{- $_ := set $svc "extensions" $extList -}}
    {{- $_ := set $base "service" $svc -}}
  {{- end -}}
{{- end -}}
{{/* Merge raw, declarative, and BYOO exporters */}}
{{- $rawExporters := ternary (index $base "exporters") dict (hasKey $base "exporters") -}}
{{- $declExporters := include "observability.otelExportersMap" . | fromYaml -}}
{{- $mergedExporters := merge $declExporters $rawExporters -}}
{{- $byooExporters := include "observability.byooExporters" . | fromYaml -}}
{{- $mergedExporters = merge $mergedExporters $byooExporters -}}
{{- $_ := set $base "exporters" $mergedExporters -}}
{{/* Build pipelines from otelCollector.pipelines */}}
{{- $nameMap := include "observability.otelExporterNameMap" . | fromYaml -}}
{{- $bbOn := eq (include "observability.blackboxEnabled" .) "true" -}}
{{- $byooPipelineKeys := include "observability.byooPipelineKeys" . | fromYaml -}}
{{- $service := index $base "service" | default dict -}}
{{- $pipelines := index $service "pipelines" | default dict -}}
{{- $defaultReceivers := list "otlp" -}}
{{- $defaultProcessors := list "memory_limiter" "k8sattributes" "resource" "batch" -}}
{{- range $signal, $wiring := .Values.otelCollector.pipelines -}}
  {{- $base_pipe := ternary (index $pipelines $signal) dict (hasKey $pipelines $signal) -}}
  {{- $names := list -}}
  {{- range $key := $wiring.exporters -}}
    {{- if hasKey $nameMap $key -}}
      {{- $names = append $names (index $nameMap $key) -}}
    {{- end -}}
  {{- end -}}
  {{- if and $bbOn (hasKey $nameMap "file") -}}
    {{- $fileName := index $nameMap "file" -}}
    {{- if not (has $fileName $names) -}}
      {{- $names = append $names $fileName -}}
    {{- end -}}
  {{- end -}}
  {{- if hasKey $byooPipelineKeys $signal -}}
    {{- range $bk := index $byooPipelineKeys $signal -}}
      {{- if not (has $bk $names) -}}
        {{- $names = append $names $bk -}}
      {{- end -}}
    {{- end -}}
  {{- end -}}
  {{- if eq (len $names) 0 -}}
    {{- fail (printf "observability: pipeline %s has no exporters enabled (would crash-loop) — enable at least one destination (debug is on by default)" $signal) -}}
  {{- end -}}
  {{- $_ := set $base_pipe "exporters" $names -}}
  {{- if not (hasKey $base_pipe "receivers") -}}
    {{- $_ := set $base_pipe "receivers" $defaultReceivers -}}
  {{- end -}}
  {{- if not (hasKey $base_pipe "processors") -}}
    {{- $_ := set $base_pipe "processors" $defaultProcessors -}}
  {{- end -}}
  {{- $_ := set $pipelines $signal $base_pipe -}}
{{- end -}}
{{- $_ := set $service "pipelines" $pipelines -}}
{{- $_ := set $base "service" $service -}}
{{- tpl (toYaml $base) . -}}
{{- end -}}

{{/* SHA256 checksum of rendered config for change detection. */}}
{{- define "observability.otelConfigChecksum" -}}
{{- include "observability.otelConfig" . | sha256sum -}}
{{- end -}}

{{/* --- BYOO (Bring Your Own Observability) external routing helpers. Config lives
     under global.observability.externalRouting so the pod override can read it too. */}}

{{/* Destination-scoped header key -> collector env-var name, e.g. "logs_Authorization" -> "BYOO_LOGS_AUTHORIZATION". Scoping keeps destinations that share a header name (e.g. Authorization) from colliding onto the same env var and secretKeyRef. */}}
{{- define "observability.byooEnvName" -}}
{{- $slug := regexReplaceAll "[^A-Za-z0-9]" (upper .) "_" -}}
{{- printf "BYOO_%s" $slug -}}
{{- end -}}

{{/* Headers list -> name->value map, scoped to one destination. `value` headers emit inline; `secret` headers emit as "${env:BYOO_<SCOPE>_<slug>}". Input: dict{scope, headers}. */}}
{{- define "observability.byooHeaders" -}}
{{- $scope := .scope -}}
{{- $out := dict -}}
{{- range $h := .headers -}}
  {{- if hasKey $h "secret" -}}
    {{- $envName := include "observability.byooEnvName" (printf "%s_%s" $scope $h.name) -}}
    {{- $_ := set $out $h.name (printf "${env:%s}" $envName) -}}
  {{- else -}}
    {{- $_ := set $out $h.name $h.value -}}
  {{- end -}}
{{- end -}}
{{- toYaml $out -}}
{{- end -}}

{{/* Validate one destination's headers list. Input: dict{headers, path}. */}}
{{- define "observability.byooValidateHeaders" -}}
{{- $path := .path -}}
{{- $seen := list -}}
{{- range $h := .headers -}}
  {{- if not $h.name -}}
    {{- fail (printf "%s: header entry missing required 'name'" $path) -}}
  {{- end -}}
  {{- if has $h.name $seen -}}
    {{- fail (printf "%s: header %q declared more than once for this destination" $path $h.name) -}}
  {{- end -}}
  {{- $seen = append $seen $h.name -}}
  {{- $hasValue := hasKey $h "value" -}}
  {{- $hasSecret := hasKey $h "secret" -}}
  {{- if and $hasValue $hasSecret -}}
    {{- fail (printf "%s: header %q must set exactly one of 'value' or 'secret', not both" $path $h.name) -}}
  {{- end -}}
  {{- if not (or $hasValue $hasSecret) -}}
    {{- fail (printf "%s: header %q must set one of 'value' or 'secret'" $path $h.name) -}}
  {{- end -}}
  {{- if $hasSecret -}}
    {{- if or (not $h.secret) (not $h.secret.name) (not $h.secret.key) -}}
      {{- fail (printf "%s: header %q secret requires both 'name' and 'key'" $path $h.name) -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- end -}}

{{/* Fail-fast validation of the whole externalRouting block. No output on success. */}}
{{- define "observability.byooValidate" -}}
{{- $er := ((.Values.global).observability).externalRouting | default dict -}}
{{- $g := $er.global | default dict -}}
{{- if $g.enabled -}}
  {{- if not $g.endpoint -}}
    {{- fail "global.observability.externalRouting.global.endpoint is required when global.enabled is true" -}}
  {{- end -}}
  {{- $proto := default "otlphttp" $g.protocol -}}
  {{- if not (has $proto (list "otlp" "otlphttp")) -}}
    {{- fail (printf "global.observability.externalRouting.global.protocol must be 'otlp' or 'otlphttp', got %q" $proto) -}}
  {{- end -}}
  {{- include "observability.byooValidateHeaders" (dict "headers" $g.headers "path" "global.observability.externalRouting.global") -}}
{{- else -}}
  {{- $ps := $er.perSignal | default dict -}}
  {{- $logs := $ps.logs | default dict -}}
  {{- if $logs.enabled -}}
    {{- if not $logs.endpoint -}}
      {{- fail "global.observability.externalRouting.perSignal.logs.endpoint is required when enabled" -}}
    {{- end -}}
    {{- $proto := default "otlphttp" $logs.protocol -}}
    {{- if not (has $proto (list "otlp" "otlphttp")) -}}
      {{- fail (printf "global.observability.externalRouting.perSignal.logs.protocol must be 'otlp' or 'otlphttp', got %q" $proto) -}}
    {{- end -}}
    {{- include "observability.byooValidateHeaders" (dict "headers" $logs.headers "path" "global.observability.externalRouting.perSignal.logs") -}}
  {{- end -}}
  {{- $traces := $ps.traces | default dict -}}
  {{- if $traces.enabled -}}
    {{- if not $traces.endpoint -}}
      {{- fail "global.observability.externalRouting.perSignal.traces.endpoint is required when enabled" -}}
    {{- end -}}
    {{- $proto := default "otlphttp" $traces.protocol -}}
    {{- if not (has $proto (list "otlp" "otlphttp")) -}}
      {{- fail (printf "global.observability.externalRouting.perSignal.traces.protocol must be 'otlp' or 'otlphttp', got %q" $proto) -}}
    {{- end -}}
    {{- include "observability.byooValidateHeaders" (dict "headers" $traces.headers "path" "global.observability.externalRouting.perSignal.traces") -}}
  {{- end -}}
  {{- $metrics := $ps.metrics | default dict -}}
  {{- if $metrics.enabled -}}
    {{- if not $metrics.endpoint -}}
      {{- fail "global.observability.externalRouting.perSignal.metrics.endpoint is required when enabled" -}}
    {{- end -}}
    {{- include "observability.byooValidateHeaders" (dict "headers" $metrics.headers "path" "global.observability.externalRouting.perSignal.metrics") -}}
  {{- end -}}
{{- end -}}
{{- end -}}

{{/* Enabled BYOO exporters as name->config. Global takes precedence over per-signal. */}}
{{- define "observability.byooExporters" -}}
{{- $out := dict -}}
{{- $er := ((.Values.global).observability).externalRouting | default dict -}}
{{- $g := $er.global | default dict -}}
{{- if $g.enabled -}}
  {{- $proto := default "otlphttp" $g.protocol -}}
  {{- $name := printf "%s/byoo-global" $proto -}}
  {{- $tlsInsecure := false -}}
  {{- if $g.tls -}}{{- $tlsInsecure = default false $g.tls.insecure -}}{{- end -}}
  {{- $cfg := dict "endpoint" $g.endpoint "tls" (dict "insecure" $tlsInsecure) -}}
  {{- $headers := include "observability.byooHeaders" (dict "scope" "global" "headers" $g.headers) | fromYaml -}}
  {{- if $headers -}}{{- $_ := set $cfg "headers" $headers -}}{{- end -}}
  {{- $_ := set $out $name $cfg -}}
{{- else -}}
  {{- $ps := $er.perSignal | default dict -}}
  {{- $logs := $ps.logs | default dict -}}
  {{- if $logs.enabled -}}
    {{- $proto := default "otlphttp" $logs.protocol -}}
    {{- $name := printf "%s/byoo-logs" $proto -}}
    {{- $tlsInsecure := false -}}
    {{- if $logs.tls -}}{{- $tlsInsecure = default false $logs.tls.insecure -}}{{- end -}}
    {{- $cfg := dict "endpoint" $logs.endpoint "tls" (dict "insecure" $tlsInsecure) -}}
    {{- $headers := include "observability.byooHeaders" (dict "scope" "logs" "headers" $logs.headers) | fromYaml -}}
    {{- if $headers -}}{{- $_ := set $cfg "headers" $headers -}}{{- end -}}
    {{- $_ := set $out $name $cfg -}}
  {{- end -}}
  {{- $traces := $ps.traces | default dict -}}
  {{- if $traces.enabled -}}
    {{- $proto := default "otlphttp" $traces.protocol -}}
    {{- $name := printf "%s/byoo-traces" $proto -}}
    {{- $tlsInsecure := false -}}
    {{- if $traces.tls -}}{{- $tlsInsecure = default false $traces.tls.insecure -}}{{- end -}}
    {{- $cfg := dict "endpoint" $traces.endpoint "tls" (dict "insecure" $tlsInsecure) -}}
    {{- $headers := include "observability.byooHeaders" (dict "scope" "traces" "headers" $traces.headers) | fromYaml -}}
    {{- if $headers -}}{{- $_ := set $cfg "headers" $headers -}}{{- end -}}
    {{- $_ := set $out $name $cfg -}}
  {{- end -}}
  {{- $metrics := $ps.metrics | default dict -}}
  {{- if $metrics.enabled -}}
    {{- $name := "prometheusremotewrite/byoo-metrics" -}}
    {{- $tlsInsecure := false -}}
    {{- if $metrics.tls -}}{{- $tlsInsecure = default false $metrics.tls.insecure -}}{{- end -}}
    {{- $cfg := dict "endpoint" $metrics.endpoint "tls" (dict "insecure" $tlsInsecure) -}}
    {{- $headers := include "observability.byooHeaders" (dict "scope" "metrics" "headers" $metrics.headers) | fromYaml -}}
    {{- if $headers -}}{{- $_ := set $cfg "headers" $headers -}}{{- end -}}
    {{- $_ := set $out $name $cfg -}}
  {{- end -}}
{{- end -}}
{{- toYaml $out -}}
{{- end -}}

{{/* Map signal -> [exporter names] for the BYOO exporters above (mirrors observability.byooExporters). */}}
{{- define "observability.byooPipelineKeys" -}}
{{- $out := dict "traces" (list) "metrics" (list) "logs" (list) -}}
{{- $er := ((.Values.global).observability).externalRouting | default dict -}}
{{- $g := $er.global | default dict -}}
{{- if $g.enabled -}}
  {{- $proto := default "otlphttp" $g.protocol -}}
  {{- $name := printf "%s/byoo-global" $proto -}}
  {{- $_ := set $out "traces" (list $name) -}}
  {{- $_ := set $out "metrics" (list $name) -}}
  {{- $_ := set $out "logs" (list $name) -}}
{{- else -}}
  {{- $ps := $er.perSignal | default dict -}}
  {{- $logs := $ps.logs | default dict -}}
  {{- if $logs.enabled -}}
    {{- $proto := default "otlphttp" $logs.protocol -}}
    {{- $_ := set $out "logs" (list (printf "%s/byoo-logs" $proto)) -}}
  {{- end -}}
  {{- $traces := $ps.traces | default dict -}}
  {{- if $traces.enabled -}}
    {{- $proto := default "otlphttp" $traces.protocol -}}
    {{- $_ := set $out "traces" (list (printf "%s/byoo-traces" $proto)) -}}
  {{- end -}}
  {{- $metrics := $ps.metrics | default dict -}}
  {{- if $metrics.enabled -}}
    {{- $_ := set $out "metrics" (list "prometheusremotewrite/byoo-metrics") -}}
  {{- end -}}
{{- end -}}
{{- toYaml $out -}}
{{- end -}}

{{/* Pod env entries for secret-backed headers, via secretKeyRef against the operator's own Secret. Only the active destination set contributes, deduped by env name. */}}
{{- define "observability.byooSecretEnvs" -}}
{{- $out := dict -}}
{{- $er := ((.Values.global).observability).externalRouting | default dict -}}
{{- $g := $er.global | default dict -}}
{{- $collect := list -}}
{{- if $g.enabled -}}
  {{- $collect = append $collect (dict "scope" "global" "headers" $g.headers) -}}
{{- else -}}
  {{- $ps := $er.perSignal | default dict -}}
  {{- $logs := $ps.logs | default dict -}}
  {{- $traces := $ps.traces | default dict -}}
  {{- $metrics := $ps.metrics | default dict -}}
  {{- if $logs.enabled -}}{{- $collect = append $collect (dict "scope" "logs" "headers" $logs.headers) -}}{{- end -}}
  {{- if $traces.enabled -}}{{- $collect = append $collect (dict "scope" "traces" "headers" $traces.headers) -}}{{- end -}}
  {{- if $metrics.enabled -}}{{- $collect = append $collect (dict "scope" "metrics" "headers" $metrics.headers) -}}{{- end -}}
{{- end -}}
{{- range $entry := $collect -}}
  {{- $scope := $entry.scope -}}
  {{- range $h := $entry.headers -}}
    {{- if hasKey $h "secret" -}}
      {{- $envName := include "observability.byooEnvName" (printf "%s_%s" $scope $h.name) -}}
      {{- if not (hasKey $out $envName) -}}
        {{- $_ := set $out $envName (dict "name" $envName "valueFrom" (dict "secretKeyRef" (dict "name" $h.secret.name "key" $h.secret.key))) -}}
      {{- end -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- $list := list -}}
{{- range $k, $v := $out -}}
  {{- $list = append $list $v -}}
{{- end -}}
{{- toYaml $list -}}
{{- end -}}
