# Observability Subchart

This Helm subchart deploys a complete observability solution using OpenTelemetry and OpenSearch Data Prepper.

## Why a Separate Observability Stack?

This subchart deploys **observability-specific** components that work with your existing OpenSearch:
- **Data Prepper** - Transforms OTel data into OpenSearch formats (Trace Analytics, Service Maps, SS4O schema)
- **OTel Collector** - Collects traces, metrics, and logs from applications and infrastructure

**Important**: The parent chart (ibm-devopsplan-prod) includes OpenSearch and Dashboards, but **NOT** Data Prepper. Data Prepper is essential for OpenSearch observability features and is deployed separately to:
- Process telemetry data specifically for observability use cases
- Scale independently based on observability load
- Enable/disable observability without affecting the main application
- Maintain different pipeline configurations for traces, metrics, and logs

## Overview

**Architecture:**
- **OpenTelemetry Collector** (Deployment): Central, shared collector every service sends telemetry to by default
- **OpenTelemetry Sidecar** (opt-in, per service): A per-pod collector for services that need to isolate telemetry overhead — the exception, not the default. See [Telemetry Direction: Push vs. Pull](#telemetry-direction-push-vs-pull) and `OTEL-Sidecar-Decision-Guide.md`
- **Data Prepper**: Processes and transforms telemetry data for OpenSearch (with readiness probe for startup reliability)
- **Your Existing OpenSearch**: Stores and analyzes telemetry data (auto-discovered)

**Data Flow (default — no sidecar):**
```
Application → Central OTel Collector (<release>-otel-collector:4317/4318) → Data Prepper → OpenSearch
```

**Data Flow (opt-in sidecar mode, per service):**
```
Application → OTel Sidecar (localhost:4317/4318) → Central OTel Collector → Data Prepper → OpenSearch
```

**Key Features:**
- **Shared collector by default**: every service sends telemetry directly to the central collector; a sidecar is only added per-service when the sidecar decision guide calls for it (CPU/GC pressure, bursty telemetry, etc.)
- Distributed tracing with OTLP protocol
- OpenSearch native observability (Trace Analytics, Service Maps)
- Simple Schema for Observability (SS4O) for logs and metrics
- **Auto-provisioned index patterns**: Dashboard setup job creates `ss4o_logs-*`, `ss4o_metrics-otel-*`, `otel-v1-apm-span-*`
- **Auto-provisioned index templates**: Index template job ensures correct mappings for trace data

## Installation

### As Part of Parent Chart

Add to your `values.yaml`:

```yaml
observability:
  enabled: true
```

Then upgrade your release:

```bash
helm upgrade --install my-release .
```

### Standalone Installation

```bash
helm install observability ./charts/observability \
  --set enabled=true \
  --set opensearch.host=my-opensearch \
  --set opensearch.existingSecret=my-secret
```

## Configuration

### Minimal Configuration

```yaml
observability:
  enabled: true
```

This uses auto-discovery to connect to your existing OpenSearch from the `ibm-devopsplan-prod` subchart.

### Custom OpenSearch

```yaml
observability:
  enabled: true
  opensearch:
    host: "my-opensearch.example.com"
    port: 9200
    protocol: https
    existingSecret: "my-opensearch-secret"
    usernameKey: "username"
    passwordKey: "password"
```

### Resource Configuration

```yaml
observability:
  dataPrepper:
    replicaCount: 2
    resources:
      requests:
        cpu: 1
        memory: 2Gi
  otelCollector:
    resources:
      requests:
        cpu: 500m
        memory: 1Gi
```

### Feature Toggles

```yaml
observability:
  otelCollector:
    receivers:
      filelog:
        enabled: false      # Container logs (off by default)
      prometheus:
        enabled: true       # Pod metrics via prometheus.io/* annotations
      kubeletstats:
        enabled: true       # Node/pod stats
      hostMetrics:
        enabled: true       # Host-level metrics
```

> **Known gap**: `kubeletstats`, `hostMetrics`, and `filelog` are declarative
> toggles only — flipping them here does not currently add a corresponding
> receiver to the rendered collector config or wire it into any pipeline (no
> `config.receivers.kubeletstats`/`hostmetrics` block exists, and `filelog`'s
> receiver definition is fully commented out). `prometheus` is the only
> receiver toggle here that's actually wired end-to-end today.

## Bring Your Own Observability (BYOO)

> ⚠️ **Breaking default change**: as of this release, local OpenSearch ingestion
> is **OFF by default** (`observability.monitoring.opensearch.enabled: false`).
> Every export destination — OpenSearch, file/PVC archive, S3, and external — is
> now an independent, opt-in peer; none is privileged. If you are upgrading and
> want to keep sending telemetry to OpenSearch, you must enable it explicitly —
> see [Upgrading from a pre-BYOO install](#upgrading-from-a-pre-byoo-install) below.

Forward a copy of logs, traces, and metrics to an external observability
backend (Grafana Cloud, Datadog, a self-hosted LGTM stack, etc.) by editing
`values.yaml` only — no collector template overrides required. All routing
config lives under **`global.observability.externalRouting`** (not the
chart-local `observability:` block), because the nested collector subchart's
pod template needs to read it directly to inject credentials.

**The chart never creates a Kubernetes Secret.** If a header value is
sensitive, you pre-create the Secret yourself and the chart references it by
name + key.

### Option A — one unified backend (Global)

Use this for a single SaaS backend that accepts all three signals over OTLP
(e.g. Grafana Cloud, Datadog). When enabled, this is the **sole** external
destination — any `perSignal` settings below are ignored.

```yaml
global:
  observability:
    externalRouting:
      global:
        enabled: true
        protocol: otlphttp            # otlp (gRPC) | otlphttp (HTTP)
        endpoint: "https://otlp-gateway.grafana.net/otlp"
        headers:
          - name: Authorization
            secret:
              name: grafana-cloud-creds   # a Secret YOU create
              key: otlp-token
```

```bash
kubectl create secret generic grafana-cloud-creds --from-literal=otlp-token=<TOKEN>
```

### Option B — separate self-hosted backends per signal

Use this when logs, traces, and metrics each go to their own store. Active
only when `global.enabled: false`. Logs and traces route over OTLP; metrics
route over Prometheus remote-write.

```yaml
global:
  observability:
    externalRouting:
      global:
        enabled: false
      perSignal:
        logs:
          enabled: true
          endpoint: "https://loki.example.com/otlp"
        traces:
          enabled: true
          endpoint: "https://tempo.example.com:4318"
        metrics:
          enabled: true
          endpoint: "https://mimir.example.com/api/v1/push"
```

### Headers without authentication

`headers` is optional. Leave it as `[]` (the default) for endpoints that need
no authentication at all. A non-sensitive value can be set inline:

```yaml
headers:
  - name: X-Scope-OrgID
    value: "42"
```

### Fan-out with the local store

Destinations are independent peers — enabling `externalRouting` does not
disable OpenSearch, and vice versa. To send telemetry to both:

```yaml
observability:
  monitoring:
    opensearch:
      enabled: true
  dataPrepper:
    enabled: true
```

Disabling OpenSearch (the default) also stops the Data Prepper Deployment,
ConfigMap, and Service from being provisioned at all — not merely idled —
reclaiming its CPU/memory footprint.

### Upgrading from a pre-BYOO install

Reproduce the old OpenSearch-only default explicitly:

```yaml
observability:
  monitoring:
    opensearch:
      enabled: true
  dataPrepper:
    enabled: true
  otelCollector:
    exporters:
      dataprepper:
        enabled: true
    pipelines:
      traces:  { exporters: [dataprepper, debug] }
      metrics: { exporters: [dataprepper, debug] }
      logs:    { exporters: [dataprepper, debug] }
```

## Application Integration

### Telemetry Direction: Push vs. Pull

**Target standard — OTLP push.** Pushing telemetry via OpenTelemetry (OTLP) is the recommended architectural direction for DevOps Loop. It unifies metrics, logs, and traces in a single pipeline, decouples workloads from scraper network configuration, and scales more predictably in dynamic environments. For Spring apps, implement via the OpenTelemetry Java Agent or `micrometer-registry-otlp`. See [Direct to Central Collector](#direct-to-central-collector-default) (the default) and [Sidecar Pattern](#sidecar-pattern-opt-in-per-service) (opt-in per service) below.

**Supported alternative — Prometheus pull.** Prometheus-style scraping (the collector pulling from your pod's `/metrics` endpoint via annotations) remains fully supported to accommodate existing implementations and unblock teams that don't control the source of the workload being instrumented (e.g. vendored/third-party products like Control). Spring Boot supports it out of the box via Micrometer and Actuator (`/actuator/prometheus`). See [Export Metrics](#export-metrics) below.

New services should default to OTLP push; Prometheus pull remains supported for existing implementations and legacy compatibility.

### Direct to Central Collector (Default)

Every service sends telemetry straight to the shared collector — no sidecar involved:

```bash
OTEL_EXPORTER_OTLP_ENDPOINT=http://{{ .Release.Name }}-otel-collector:4317
```

### Sidecar Pattern (Opt-in, Per Service)

Applications send telemetry to an OTel sidecar running in the same pod on `localhost`, which then forwards to the shared collector:

**Environment Variable:**
```bash
OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4318
```

**Java (Spring Boot) - application.yml:**
```yaml
management:
  otlp:
    tracing:
      endpoint: http://localhost:4318/v1/traces
```

The sidecar is injected via the `otel.sidecar.conditionalFor`/`otel.sidecar.enabledFor` helpers, and requires **both** `global.observability.enabled: true` **and** `global.observability.sidecar.enabled: true` (or a per-service override, e.g. `<service>.otel.sidecar.enabled: true`) — enabling observability alone does not turn on the sidecar. See `OTEL-Sidecar-Decision-Guide.md` for when a sidecar is actually warranted; the default for every service is no sidecar.

### Export Metrics

Annotate your pods:

```yaml
apiVersion: v1
kind: Pod
metadata:
  annotations:
    prometheus.io/scrape: "true"
    prometheus.io/port: "8080"
    prometheus.io/path: "/metrics"
    prometheus.io/service: "my-service-name"   # optional, see below
```

| Annotation | Required | Purpose |
|---|---|---|
| `prometheus.io/scrape` | Yes | Must be `"true"` for this pod to be scraped at all. |
| `prometheus.io/port` | Yes | Port your app's metrics endpoint listens on. |
| `prometheus.io/path` | Yes | HTTP path your app serves metrics on (e.g. `/metrics`, `/actuator/prometheus`). |
| `prometheus.io/service` | No | Not a standard Prometheus annotation — a platform-specific override for the scraped metrics' `job`/`service.name` identity. If set, metrics from this pod are grouped under that name instead of the shared, generic `kubernetes-pods` job every annotation-scraped pod defaults to. If omitted, this pod's metrics stay in the generic `kubernetes-pods` bucket alongside every other annotation-scraped pod that hasn't set it. |

This is the **Prometheus pull** path — see [Telemetry Direction: Push vs. Pull](#telemetry-direction-push-vs-pull) above for when to use it instead of OTLP push.

## Viewing Telemetry Data

Access your OpenSearch Dashboards:

1. **Trace Analytics**: Observability → Trace Analytics
2. **Service Maps**: Observability → Trace Analytics → Services
3. **Logs**: Discover → Create index pattern `ss4o_logs-*`
4. **Metrics**: Discover → Create index pattern `ss4o_metrics-*`

## Troubleshooting

### Docker Desktop Mount Propagation Issue

If you see this error on Docker Desktop:
```
Error: failed to start container "otel-collector": Error response from daemon: 
path / is mounted on / but it is not a shared or slave mount
```

**Quick Fix:**
```bash
docker run --rm --privileged --pid=host alpine:latest \
  nsenter -t 1 -m -u -n -i sh -c "mount --make-rshared /"
```

See [DOCKER-DESKTOP-SETUP.md](DOCKER-DESKTOP-SETUP.md) for permanent solutions.

### General Troubleshooting

**Check OTel Collector:**
```bash
kubectl logs -l app.kubernetes.io/component=otel-collector
kubectl describe deployment -l app.kubernetes.io/component=otel-collector
```

**Check Data Prepper:**
```bash
kubectl logs -l app.kubernetes.io/component=data-prepper
kubectl get pods -l app.kubernetes.io/component=data-prepper
```

**Verify OpenSearch Connection:**
```bash
kubectl exec -it deployment/{{ .Release.Name }}-observability-data-prepper -- \
  curl -k $OPENSEARCH_URL/_cluster/health
```

**Check Telemetry Flow:**
```bash
# Send test trace
kubectl run test-trace --image=curlimages/curl --rm -it -- \
  curl -X POST http://{{ .Release.Name }}-observability-otel-collector:4318/v1/traces \
  -H "Content-Type: application/json" \
  -d '{"resourceSpans":[]}'
```

## Values Reference

| Parameter | Description | Default |
|-----------|-------------|---------|
| `enabled` | Enable observability stack | `false` |
| `global.imageRegistry` | Private registry path (see [PRIVATE-REGISTRY.md](PRIVATE-REGISTRY.md)) | `""` |
| `opensearch.host` | OpenSearch host (auto-discovered) | `""` |
| `opensearch.existingSecret` | Secret with credentials | Auto-detected |
| `dataPrepper.image.repository` | Data Prepper image (public registry) | `opensearchproject/data-prepper` |
| `dataPrepper.image.name` | Data Prepper image name (private registry) | `opensearchproject/data-prepper` |
| `dataPrepper.replicaCount` | Number of Data Prepper replicas | `1` |
| `dataPrepper.resources` | Resource requests/limits | See values.yaml |
| `otelCollector.receivers.filelog.enabled` | Collect container logs (declarative toggle only — see [Feature Toggles](#feature-toggles)) | `false` |
| `otelCollector.receivers.prometheus.enabled` | Scrape Prometheus metrics via `prometheus.io/*` pod annotations | `true` |
| `otel-collector.image.repository` | OTel Collector image path, prefixed with `global.imageRegistry` when set (this platform always sets it in practice — see [Private Registry](PRIVATE-REGISTRY.md)) | `otel-opentelemetry-collector-contrib` |
| `serviceAccount.create` | Create ServiceAccount | `true` |
| `rbac.create` | Create RBAC resources | `true` |

See [values.yaml](values.yaml) for complete configuration options.

## Private Registry / Air-Gapped Deployment

For deployments requiring private container registries, see [PRIVATE-REGISTRY.md](PRIVATE-REGISTRY.md) for:
- Image preparation and tagging
- Global registry configuration
- Development overrides
- Troubleshooting

**Quick Start:**
```bash
REGISTRY="hclsoftware-docker-dev.us-artifactory1.nonprod.hclpnp.com/rational-devops"

helm upgrade --install devops-loop . \
  --set global.imageRegistry="${REGISTRY}" \
  --set global.observability.enabled=true \
  --set observability.otel-collector.image.repository="${REGISTRY}/otel-opentelemetry-collector-contrib" \
  -f values-platform-enable.yaml
