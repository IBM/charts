{{- /*
Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements.  See the NOTICE file
distributed with this work for additional information
regarding copyright ownership.  The ASF licenses this file
to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/ -}}

{{/*
Expand the name of the chart.
*/}}
{{- define "flink-operator.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "flink-operator.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "flink-operator.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "flink-operator.labels" -}}
{{- if not .Values.olm }}
helm.sh/chart: {{ include "flink-operator.chart" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- else }}
app.kubernetes.io/managed-by: olm
{{- end }}
{{ include "flink-operator.selectorLabels" . }}
app.kubernetes.io/instance: ibm-eventautomation-flink-operator
{{- if .Chart.Version }}
app.kubernetes.io/version: {{ .Chart.Version | quote }}
{{- end }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "flink-operator.selectorLabels" -}}
app.kubernetes.io/name: {{ include "flink-operator.name" . }}
{{- end }}

{{- define "ibm-eventautomation-flink-operator.labels" -}}
name: ibm-eventautomation-flink-operator
{{- end }}

{{- define "ibm-eventautomation-flink-operator.annotations" -}}
productID: 682b6db3fed247a098d85da5ab905b46
productMetric: FREE
productName: IBM Event Automation
productVersion: 1.5.2
{{- end }}

{{/*
Image pull policy.
*/}}
{{- define "flink-operator.pull-policy" -}}
{{- if hasSuffix ":latest" .Values.images.operator -}}
imagePullPolicy: Always
{{- else -}}
imagePullPolicy: IfNotPresent
{{- end -}}
{{- end -}}