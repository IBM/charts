{{- define "testhub.cacerts.volumeMount" }}
- name: trust-store
  mountPath: {{ .path }}
  subPath: cacerts
{{- end }}

{{- define "testhub.cacerts.volumes" }}
- name: trust-store
  configMap:
    name: '{{ .trustStoreConfigMap }}'
{{- if .caBundleConfigMap }}
- name: ca-bundle
  configMap:
    name: '{{ .caBundleConfigMap }}'
{{- end }}
{{- end }}
