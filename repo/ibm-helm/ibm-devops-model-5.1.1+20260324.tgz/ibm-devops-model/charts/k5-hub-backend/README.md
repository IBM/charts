## Chart Details

The chart will set up a Kubernetes namespace and deploy the hub-backend.

## Prerequisites

- Kubernetes 1.4+ with Beta APIs enabled

## TODO
...