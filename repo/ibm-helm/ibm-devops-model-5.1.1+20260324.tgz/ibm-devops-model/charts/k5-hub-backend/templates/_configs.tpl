{{/* Print the configurations */}}
{{- define "k5-hub-backend-configmapentries" -}}
pipelineUrlVersion: ""
{{- end -}}
