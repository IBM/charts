## Chart Details

The chart will set up a Kubernetes namespace and deploy the k5-service-project-manager.

## Prerequisites

- Kubernetes 1.4+ with Beta APIs enabled

## TODO
...