{{/*
Label stack used for labelling.
*/}}
{{- define "k5-component-repository-controller.labels" -}}
app.kubernetes.io/version: {{ .Chart.AppVersion }}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version | replace "+" "_" }}
app.kubernetes.io/part-of: k5-hub
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{ template "k5-component-repository-controller.matchLabels" . }}
{{- end -}}

{{/*
Default match labels.
*/}}
{{- define "k5-component-repository-controller.matchLabels" -}}
app.kubernetes.io/name: {{ template "k5-component-repository-controller.fullname" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/*
Label used to select server pods only.
*/}}
{{- define "k5-component-repository-controller.serverSelector" -}}
app.kubernetes.io/component: {{ .Chart.Name }}-server
{{- end -}}
