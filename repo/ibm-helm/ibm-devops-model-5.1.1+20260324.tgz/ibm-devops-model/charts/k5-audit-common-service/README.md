## Chart Details

The chart will set up a Kubernetes namespace and deploy the k5-audit-common-service.

## Prerequisites

- Kubernetes 1.4+ with Beta APIs enabled

## TODO
...