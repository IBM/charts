{{/* Print the configurations */}}
{{- define "k5-project-operator-configmapentries" -}}
de.knowis.cp.operator.config.default.serviceAccounts.admin: {{ .Values.global.k5.serviceAccounts.admin | quote }}
de.knowis.cp.operator.config.default.serviceAccounts.view: {{ .Values.global.k5.serviceAccounts.view | quote }}
de.knowis.cp.operator.config.default.serviceAccounts.pipeline: {{ .Values.global.k5.serviceAccounts.pipeline | quote }}
de.knowis.cp.operator.config.default.watchNamespacesExternalSecrets.configmap: {{ default "k5-projects-configmap" .Values.configurations.watchNamespacesExternalSecrets.configmap | quote }}
de.knowis.cp.operator.config.default.watchNamespacesExternalSecrets.key: {{ default "projects" .Values.configurations.watchNamespacesExternalSecrets.key | quote }}

de.knowis.cp.operator.config.default.protocol: {{ .Values.configurations.protocol | quote }}
de.knowis.cp.operator.config.default.truststoreName: {{ .Values.configurations.truststoreName | quote }}
de.knowis.cp.operator.config.default.kafka.secretName: {{ .Values.configurations.kafka.secretName | quote }}
de.knowis.cp.operator.config.default.kafka.replicationFactor: {{ .Values.configurations.kafka.replicationFactor | quote }}
de.knowis.cp.operator.config.default.kafka.numPartitions: {{ .Values.configurations.kafka.numPartitions | quote }}
de.knowis.cp.operator.config.default.kafka.dataEventsRetentionHours: {{ .Values.configurations.kafka.dataEventsRetentionHours | quote }}
de.knowis.cp.operator.config.default.kafka.auditRetentionHours: {{ .Values.configurations.kafka.auditRetentionHours | quote }}

de.knowis.cp.operator.config.default.dashboard.serviceAccountName: {{ .Values.configurations.dashboard.serviceAccountName | quote }}
de.knowis.cp.operator.config.default.dashboard.mvnDeps.enabled: {{ .Values.configurations.dashboard.mvnDeps.enabled | quote }}
de.knowis.cp.operator.config.default.dashboard.oauthclientsecretName: {{ .Values.configurations.dashboard.oauthclientsecretName | quote }}
de.knowis.cp.operator.config.default.dashboard.fsscli.clientSecretName: {{ .Values.configurations.dashboard.fsscli.clientSecretName | quote }}
de.knowis.cp.operator.config.default.dashboard.runtimeauthserver.claimUsername: {{ .Values.configurations.dashboard.oidc.claimUsername | quote }}
de.knowis.cp.operator.config.default.dashboard.runtimeauthserver.claimName: {{ .Values.configurations.dashboard.oidc.claimName | quote }}
de.knowis.cp.operator.config.default.dashboard.favicon: {{ .Values.global.k5.frontend.favicon | quote }}
de.knowis.cp.operator.config.default.dashboard.vendor: {{ .Values.global.k5.frontend.vendor | quote }}
de.knowis.cp.operator.config.default.dashboard.applicationName: {{ .Values.global.k5.frontend.dashboardApplicationName | quote }}
de.knowis.cp.operator.config.default.dashboard.info.timeoutMs: {{ .Values.configurations.dashboard.info.timeoutMs | quote }}
de.knowis.cp.operator.config.default.dashboard.route.timeout: {{ .Values.configurations.dashboard.route.timeout | quote }}
de.knowis.cp.operator.config.default.dashboard.image: {{ include "k5-project-operator.image.builder" (dict "values" .Values "image" .Values.dashboardImage) }}
de.knowis.cp.operator.config.default.dashboard.imageTag: {{ .Values.dashboardImage.tag | quote }}

de.knowis.cp.operator.config.default.mongo.secretName: {{ .Values.configurations.mongo.secretName | quote }}

de.knowis.cp.operator.config.default.identity.provisionerSecretName: {{ tpl .Values.configurations.iam.provisionerSecretName . | quote }}
de.knowis.cp.operator.config.default.identity.bindingSecretName: {{ tpl .Values.configurations.iam.bindingSecretName . | quote }}
de.knowis.cp.operator.config.default.identity.issuerTemplate: {{ tpl .Values.configurations.iam.issuerTemplate . | quote }}
de.knowis.cp.operator.config.default.identity.jwkUriTemplate: {{ tpl .Values.configurations.iam.jwkUriTemplate . | quote }}
de.knowis.cp.operator.config.default.identity.userAuthUriTemplate: {{ tpl .Values.configurations.iam.userAuthUriTemplate . | quote }}
de.knowis.cp.operator.config.default.identity.tokenEndPoint: {{ tpl .Values.configurations.iam.tokenEndPoint . | quote }}
de.knowis.cp.operator.config.default.identity.keyCloakTokenURL: {{ tpl .Values.configurations.iam.keyCloakTokenURL . | quote }}
de.knowis.cp.operator.config.default.identity.keyCloakRealmURL: {{ tpl .Values.configurations.iam.keyCloakRealmURL . | quote }}
de.knowis.cp.operator.config.default.identity.keyCloakClientsURL: {{ tpl .Values.configurations.iam.keyCloakClientsURL . | quote }}
de.knowis.cp.operator.config.default.identity.createClientWaitTimeout: {{ .Values.configurations.iam.createClientWaitTimeout | quote }}
de.knowis.cp.operator.config.default.identity.createClientSleepInterval: {{ .Values.configurations.iam.createClientSleepInterval | quote }}

de.knowis.cp.operator.config.default.hub.truststoreName: {{ .Values.global.k5.secrets.truststore | quote }}
de.knowis.cp.operator.config.default.hub.schemaRegistrySecretName: {{ .Values.global.k5.secrets.schemaRegistry | quote }}

kubernetes.common.labels.instance: {{ .Release.Name | quote }}
kubernetes.common.labels.managedBy: {{ template "k5-project-operator.name" . }}
kubernetes.common.labels.name: {{ template "k5-project-operator.fullname" . }}
kubernetes.common.labels.version: {{ .Chart.AppVersion | quote }}

{{/* Values get set via hub */}}
{{- if .Values.global.k5.pod }}
{{- if .Values.global.k5.pod.annotations }}
{{- range $k, $v := .Values.global.k5.pod.annotations }}
{{- printf "\nde.knowis.cp.operator.config.default.pod.annotations.%s: " $k -}}{{- printf "%s" $v | quote -}}
{{- end }}
{{- end }}

{{- if .Values.global.k5.pod.labels }}
{{- range $k, $v := .Values.global.k5.pod.labels }}
{{/* "/" is not allowed in a config map key */}}
{{- printf "\nde.knowis.cp.operator.config.default.pod.labels.%s: " $k | replace "/" "-" -}}{{- printf "%s" $v | quote -}}
{{- end }}
{{- end }}
{{- end }}

# Spring settings
{{- if .Values.configmap.spring }}
{{ tpl .Values.configmap.spring . }}
{{- end }}

# logging settings
{{- if .Values.configmap.logging }}
{{ tpl .Values.configmap.logging . }}
{{- end }}

# Additional settings
{{- if .Values.configmap.extraConfiguration }}
{{ tpl .Values.configmap.extraConfiguration . }}
{{- end }}

# settings for the operator namespace scope
{{- if .Values.watch.namespaces.blacklist }}
{{- range $i, $e := .Values.watch.namespaces.blacklist }}
{{- printf "\nde.knowis.cp.operator.config.namespaces.blacklist.%d: " $i -}}{{- printf "%s" $e | quote -}}
{{- end }}
{{- end }}

{{- if .Values.watch.namespaces.whitelist }}
{{- range $i, $e := .Values.watch.namespaces.whitelist }}
{{- printf "\nde.knowis.cp.operator.config.namespaces.whitelist.%d: " $i -}}{{- printf "%s" $e | quote -}}
{{- end }}
{{- end }}

# Image Registry Configurations
de.knowis.cp.operator.config.default.imagePullSecret: {{ .Values.global.k5.image.pullSecret | quote }}

## network policy settings
de.knowis.cp.operator.config.default.networkPolicy.enabled: {{ .Values.global.k5.network.ingressPolicy.enabled | quote }}

{{- end -}}
