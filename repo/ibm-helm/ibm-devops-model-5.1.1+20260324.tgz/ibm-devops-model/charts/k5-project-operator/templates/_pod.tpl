{{/*global values set via hub chart*/}}
{{- define "k5-project-operator.global.pod.annotations" }}
{{- if .Values.global.k5.pod }}
{{- if .Values.global.k5.pod.annotations }}
{{- range $k, $v := .Values.global.k5.pod.annotations }}
{{- printf "\n%s: " $k -}}{{- printf "%s" $v | quote -}}
{{- end }}
{{- end }}
{{- end }}
{{- end -}}

{{/*global values set via hub chart*/}}
{{- define "k5-project-operator.global.pod.labels" }}
{{- if .Values.global.k5.pod }}
{{- if .Values.global.k5.pod.labels }}
{{- range $k, $v := .Values.global.k5.pod.labels }}
{{- printf "\n%s: " $k -}}{{- printf "%s" $v | quote -}}
{{- end }}
{{- end }}
{{- end }}
{{- end -}}

{{/*global values set via hub chart*/}}
{{- define "k5-project-operator.global.pod.serviceLabels" }}
{{- if .Values.global.k5.pod }}
{{- if .Values.global.k5.pod.serviceLabels }}
{{- range $k, $v := .Values.global.k5.pod.serviceLabels }}
{{- printf "\n%s: " $k -}}{{- printf "%s" $v | quote -}}
{{- end }}
{{- end }}
{{- end }}
{{- end -}}
