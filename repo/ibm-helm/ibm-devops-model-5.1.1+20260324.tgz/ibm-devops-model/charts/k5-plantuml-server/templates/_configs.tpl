{{/* Print the configurations */}}
{{- define "k5-plantuml-server-configmapentries" -}}

de.knowis.plantuml.cors.allowedDomains: {{ include "k5-plantuml-server.cors-allowed-domains.builder" . | trimSuffix "," | quote }}

# Spring settings
{{- if .Values.configmap.spring }}
{{ tpl .Values.configmap.spring . }}
{{- end }}

# logging settings
{{- if .Values.configmap.logging }}
{{ tpl .Values.configmap.logging . }}
{{- end }}

# Additional settings
{{- if .Values.configmap.extraConfiguration }}
{{ tpl .Values.configmap.extraConfiguration . }}
{{- end }}

{{- end -}}
