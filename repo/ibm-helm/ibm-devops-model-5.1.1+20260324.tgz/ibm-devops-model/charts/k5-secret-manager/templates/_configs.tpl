{{/* Print the configurations */}}
{{- define "k5-secret-manager-configmapentries" -}}

# logging settings
{{- if .Values.configmap.logging }}
{{ tpl .Values.configmap.logging . }}
{{- end }}

# spring settings
{{- if .Values.configmap.spring }}
{{ tpl .Values.configmap.spring . }}
{{- end }}

de.knowis.cp.k5secretmanager.provider.host.protocol: {{ tpl .Values.configurations.protocol . | quote }}
de.knowis.cp.k5secretmanager.provider.host.name: {{ tpl .Values.global.k5.endpoints.secretManager.host . | quote }}

de.knowis.cp.k5secretmanager.cors.allowedDomains: {{ include "k5-secret-manager.cors-allowed-domains.builder" . | trimSuffix "," | quote }}

audit.namespace: {{ .Release.Namespace }}

kubernetes.common.labels.instance: {{ .Release.Name | quote }}
kubernetes.common.labels.managedBy: {{ template "k5-secret-manager.name" . }}
kubernetes.common.labels.name: {{ template "k5-secret-manager.fullname" . }}

{{- end -}}
