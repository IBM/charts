# Cli-Provider

The Cli-Provider is providing the cli download end points
business domains.

## Introduction

This chart deploys cli-provider into an IBM Cloud Private Kubernetes environment or in an IBM Cloud Container Services environment  using the [Helm](https://helm.sh) package manager.

## Chart Details

The chart will set up a Kubernetes namespace and deploy the cli-provider components.

## Prerequisites

- Kubernetes 1.4+ with Beta APIs enabled

## TODO
...