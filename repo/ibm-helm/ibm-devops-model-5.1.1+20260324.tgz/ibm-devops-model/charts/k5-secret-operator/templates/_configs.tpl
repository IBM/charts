{{/* Print the configurations */}}
{{- define "k5-secret-operator-configmapentries" -}}

de.knowis.secretoperator.reconciliationPeriod: {{ tpl .Values.config.reconciliationPeriod . | quote }}
de.knowis.secretoperator.saTokenPath: {{ tpl .Values.config.saTokenPath . | quote }}
de.knowis.secretoperator.secretManager.role: {{ tpl .Values.secretManager.secretManagerRole . | quote }}
de.knowis.secretoperator.secretManager.url: '{{ include "k5-secret-operator.http.scheme" . }}://{{ tpl .Values.global.k5.endpoints.secretManager.internalUrl .}}'

# Spring settings
{{- if .Values.configmap.spring }}
{{ tpl .Values.configmap.spring . }}
{{- end }}

# logging settings
{{- if .Values.configmap.logging }}
{{ tpl .Values.configmap.logging . }}
{{- end }}

# Additional settings
{{- if .Values.configmap.extraConfiguration }}
{{ tpl .Values.configmap.extraConfiguration . }}
{{- end }}

{{- end -}}
