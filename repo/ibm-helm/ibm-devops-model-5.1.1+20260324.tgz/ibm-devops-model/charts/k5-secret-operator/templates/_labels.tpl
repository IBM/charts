{{/*
Label stack used for labelling.
*/}}
{{- define "k5-secret-operator.labels" -}}
app.kubernetes.io/version: {{ .Chart.AppVersion }}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version | replace "+" "_" }}
app.kubernetes.io/part-of: k5-hub
ssob-type: infrastructure
{{ template "k5-secret-operator.matchLabels" . }}
{{- end -}}

{{- define "k5-secret-operator.matchLabels" -}}
app.kubernetes.io/name: {{ template "k5-secret-operator.fullname" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: {{ .Chart.Name }}
{{- end -}}
