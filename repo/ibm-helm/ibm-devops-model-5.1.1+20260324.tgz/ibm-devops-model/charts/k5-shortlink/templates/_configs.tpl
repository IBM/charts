{{/* Print the configurations */}}
{{- define "k5-shortlink-learningLinksConfigmapentries" -}}

{{- if .Values.configmap.learningLinks }}
{{ tpl .Values.configmap.learningLinks . }}
{{- end }}

{{- end -}}


{{- define "k5-shortlink-docLinksConfigmapentries" -}}

{{- if .Values.configmap.docLinks }}
{{ tpl .Values.configmap.docLinks . }}
{{- end }}

{{- end -}}
