[TOC]

## Description

Backend that acts as a shortlink for the documentation, written in TypeScript, running on NestJS and deployed to K8s

- **LOCAL**: <http://localhost:8888/swagger/>
- **DEV**: <https://dev-shortlink.apps.openshift-03.knowis.cloud>
- **INTEGRATION**: <https://int-shortlink.apps.openshift-03.knowis.cloud>

## Setup

### Prerequisites

- [Git](https://git-scm.com/)
- [Node.js](https://nodejs.org/en/) > 14.17.0
- [Pnpm](https://pnpm.io/installation) for package management
- [TypeScript](https://www.typescriptlang.org/)
- [NestJs](https://docs.nestjs.com/first-steps)
- Git Bash on Windows
- ZSH on Mac
- [OC CLI](https://docs.openshift.com/container-platform/4.2/cli_reference/openshift_cli/getting-started-cli.html)

## Installation

### Local Development

```bash
# If the private @knowis scope has not been registered and/or authenticated yet
npm login --registry=https://urm.knowis.net/repository/npm-private/ --scope=@knowis
```

When doing a fresh install or an update with changed dependencies in `package.json` arrived:

```bash
pnpm install
```

Now run the build step (does more than just a tsc compile!).

```bash
pnpm build
```

If you haven't done so, create a `.env` file in the project root directory.
You can use this template: <https://gitlab.knowis.net/cp-designer/backend/wikis/setup/.env.md>

In order to authenticate against some integrated services we need to set up an opensfhit token file
The path to the token can be specified as `CP_OPENSHIFT_TOKEN_PATH` in the `.env` file(default is `../secrets/token` in order to survive the pnpm build cleanup).

**NOTE:**

- Get your openshift access token from the openshift console -> `Click on your username in the top right corner -> Copy login command -> AzureAD -> Display Access Token -> Log in with this token` and paste it into your token file.

- Get your encryption key for an environment following the steps below:

  - Copy the `oc login` command from the openshift console -> `Click on your username in the top right corner -> Copy login command -> AzureAD -> Display Access Token -> Log in with this token` and paste it into your terminal.

  - Login and select the realm you want to use using the command below:
    `oc project <projectName>`

  - Retrieve the encryption key from the corresponding environment using the command below:
    `oc get secret k5-encryption-master-key -o=jsonpath='{.data.key}' | base64 -d`

  - Copy the key to the file mentioned in `CP_LOCAL_MASTER_KEY_FILE_PATH` in .env file.

### Customer Installation / Cluster Installation

- See [Installation Manual](docs/Installation.md)

## Usage

### Run server

For running the server in a local dev environment one needs to adjust the `start-server.ts` file. Go to that file and adjust it so that it looks like that:

```bash
# Starts the server with the configured database
pnpm start

# Start the server in development mode with live compilation and reloading:
pnpm run debug
```

## Docker

### Build and run with local docker

```bash
# First get the NPM_TOKEN_READONLY and export it as an env variable
# You can get it from the GitLab ENV variables: https://gitlab.knowis.net/groups/cp-designer/-/settings/ci_cd
# If you don't want to repeat this constantly, consider adding it to your `~/.bashrc` file
export NPM_TOKEN_READONLY="SECRET"

# If you are not already logged in to our private docker registry, please do so
# You can get the token from https://gitlab.knowis.net/groups/cp-designer/-/settings/ci_cd
docker login -u token -p "${CP_CI_CONTAINER_REGISTRY_TOKEN}" registry.eu-de.bluemix.net

# Now you can run the local docker build. Please follow further instructions / help there
pnpm build-docker
```

## Contribution to this project

- See our [Contribution Guide](./CONTRIBUTING.md)

## Test

- Read our [Testing Guidelines](/docs/Testing.md)

```bash
# Run linter
pnpm lint

# Run unit-tests
pnpm test-unit

# Run integration-tests
pnpm test-interation

# Run integration-tests
pnpm test-api
pnpm test-api-local # to automatically start local server

# Run all tests: Unit, Integration, API and end-to-end tests with coverage report
# Recommended to do this before pushing to the server!
pnpm test-all

# Run unit-tests in --watch mode
pnpm test-unit --watch

# Run a specificly named test in watch mode
pnpm test-integration -t "codegenService.generate" --watch
```

## Update logging level (local development)

The default log level is `info`. There are two ways to change log level from default value as described below:

- In your terminal, set it like below and start the server:

  ```sh
  export CP_LOG_LEVEL="debug"
  ```

- Create `log-config.json` file at the root of the project and add the following paths:

  ```json
  {
    "@knowis/cp-designer-backend": "debug"
  }
  ```

  This way, you can also add the path to a particular file/folder to change its log level.
