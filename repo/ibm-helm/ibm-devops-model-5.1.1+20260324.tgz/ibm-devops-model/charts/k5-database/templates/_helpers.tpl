{{/* vim: set filetype=mustache: */}}

{{/*
Expand the name of the chart.
*/}}
{{- define "k5-database.name-postgresql" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}-postgresql
{{- end -}}

{{- define "k5-database.name-ferretdb" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}-ferretdb
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
*/}}
{{- define "k5-database.fullname-postgresql" -}}
{{- $name := .Chart.Name -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}-postgresql
{{- end -}}

{{- define "k5-database.fullname-ferretdb" -}}
{{- $name := .Chart.Name -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}-ferretdb
{{- end -}}


{{/*
Build an image from given values
*/}}
{{- define "k5-database.image.builder" -}}
{{- $registry := .values.global.image.registry -}}
{{- $repository := .image.repository -}}
{{ if .values.global.imageRegistry }}
{{- $registry = .values.global.imageRegistry -}}
{{- $repository = printf "%s-%s" .values.global.image.prefix .image.repository -}}
{{- else if  .values.global.image.privateRegistry }}
{{- $registry = .values.global.image.privateRegistry -}}
{{- $repository = printf "%s-%s" .values.global.image.prefix .image.repository -}}
{{- end -}}
{{ if .image.digest }}
{{- printf "%s/%s@%s" $registry $repository .image.digest -}}
{{ else }}
{{- printf "%s/%s:%s" $registry $repository .image.tag -}}
{{- end -}}
{{- end -}}

{{- define "k5-database.connectionString" -}}
{{- if .Values.postgres.adminPw }}
{{- printf "mongodb://%s:%s@k5-database-ferretdb.%s.svc.cluster.local:27017/" .Values.postgres.admin .Values.postgres.adminPw .Release.Namespace -}}
{{- else }}
{{- $adminPw := print (default .Release.Name .Values.global.passwordSeed) | sha256sum | urlquery -}}
{{- printf "mongodb://%s:%s@k5-database-ferretdb.%s.svc.cluster.local:27017/" .Values.postgres.admin $adminPw .Release.Namespace -}}
{{- end -}}
{{- end -}}

