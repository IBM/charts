{{/*
Label stack used for labelling.
*/}}
{{- define "k5-database.labels-postgresql" -}}
app: {{ template "k5-database.name-postgresql" . }}
app.kubernetes.io/version: {{ .Chart.AppVersion }}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version | replace "+" "_" }}
app.kubernetes.io/part-of: k5-database
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{ template "k5-database.matchLabels-postgresql" . }}
{{- end -}}

{{- define "k5-database.labels-ferretdb" -}}
app: {{ template "k5-database.name-ferretdb" . }}
app.kubernetes.io/version: {{ .Chart.AppVersion }}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version | replace "+" "_" }}
app.kubernetes.io/part-of: k5-database
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{ template "k5-database.matchLabels-ferretdb" . }}
{{- end -}}

{{/*
Default match labels.
*/}}
{{- define "k5-database.matchLabels-postgresql" -}}
app.kubernetes.io/name: {{ template "k5-database.fullname-postgresql" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{- define "k5-database.matchLabels-ferretdb" -}}
app.kubernetes.io/name: {{ template "k5-database.fullname-ferretdb" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/*
Label used to select server pods only.
*/}}
{{- define "k5-database.serverSelector" -}}
app.kubernetes.io/component: {{ .Chart.Name }}-server
{{- end -}}
