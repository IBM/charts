## Chart Details

The chart will set up a Kubernetes namespace and deploy the git-integration-controller.

## Prerequisites

- Kubernetes 1.4+ with Beta APIs enabled

## TODO
...