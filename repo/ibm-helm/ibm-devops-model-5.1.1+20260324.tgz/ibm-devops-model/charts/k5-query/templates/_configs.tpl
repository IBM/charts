{{/* Print the configurations */}}
{{- define "k5-query-configmapentries" -}}
de.knowis.cp.run.query.host.name: {{ tpl .Values.global.k5.endpoints.query.host . | quote }}
de.knowis.cp.run.query.host.protocol: {{ .Values.protocol | quote }}

de.knowis.cp.run.query.codec.maxInMemorySize: {{ .Values.codec.maxInMemorySize | quote }}

de.knowis.cp.run.query.provider.fssCli.truststoreSecretName: {{ .Values.fssCli.truststoreSecretName | quote }}
de.knowis.cp.run.query.provider.fssCli.clientSecretName: {{ .Values.fssCli.clientSecretName | quote }}

de.knowis.cp.run.query.cors.allowedDomains: {{ include "k5-query.cors-allowed-domains.builder" . | trimSuffix "," | quote }}

de.knowis.cp.run.query.appLabel: {{ required "A valid .Values.global.k5.pod.labels.app" .Values.global.k5.pod.labels.app | quote }}
de.knowis.cp.run.query.tenantIsolation: {{ .Values.global.k5.tenantIsolation | default "false" | quote }}

# Spring settings
{{- if .Values.configmap.spring }}
{{ tpl .Values.configmap.spring . }}
{{- end }}

# logging settings
{{- if .Values.configmap.logging }}
{{ tpl .Values.configmap.logging . }}
{{- end }}

# Additional settings
{{- if .Values.configmap.extraConfiguration }}
{{ tpl .Values.configmap.extraConfiguration . }}
{{- end }}

{{- end -}}
