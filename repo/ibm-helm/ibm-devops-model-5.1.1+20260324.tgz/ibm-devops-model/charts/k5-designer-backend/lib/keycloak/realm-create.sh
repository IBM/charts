#!/usr/bin/env bash

if [ "$REALM_EXISTS" = "true" ]; then
  exit 0
fi

if [ -z "$ADMIN_TOKEN" ]; then
  . "$(dirname "${BASH_SOURCE[0]}")/admin-token.sh"
fi

if [ -n "$REALM_THEME" ]; then
  THEME='"loginTheme":"'$REALM_THEME'","accountTheme":"'$REALM_THEME'",'
fi

curl -si $CAFILE -X POST "$KEYCLOAK_URL/admin/realms" \
  -H 'Content-Type: application/json' \
  -H "Authorization: Bearer $ADMIN_TOKEN" \
  -d @-<<EOF
{
"realm":"$REALM_NAME",
"enabled":"true",
"roles":{"realm":[{"name":"dc_admin","description":"Administrator role"}]},
"groups":[{"name":"Admins","realmRoles":["dc_admin"]}],
$THEME
"bruteForceProtected":true,
"passwordPolicy":"length(8)",
"failureFactor": 10,
"minimumQuickLoginWaitSeconds":300,
"waitIncrementSeconds":300,
"internationalizationEnabled":true,
"registrationAllowed":${SIGNUP-false}
}
EOF
