#!/usr/bin/env bash

set -e

if [ -z "$ADMIN_TOKEN" ]; then
  . "$(dirname "${BASH_SOURCE[0]}")/admin-token.sh"
fi

id=$(. "$(dirname "${BASH_SOURCE[0]}")/client-id.sh")

if [ -z "$id" ]; then
  echo "No id found for $CLIENT_ID, so creating a new client..."
  method=POST
fi

if [ "${STANDARD_FLOW:-true}" = "true" ] && [ -z "$BASE_URL" ]; then
  echo "BASE_URL is required when standard flow is enabled for $CLIENT_ID"
  exit 1
fi

if [ -z "$CLIENT_SECRET" ] && [ "${STANDARD_FLOW:-true}" = "false" ] && [ "${DIRECT_ACCESS_GRANTS:-false}" = "false" ]; then
  echo "Creating audience-only public client (no flows enabled)"
fi

service_accounts_enabled=false

if [ -n "$AUTHORIZATION_SERVICES" ] || [ -n "$ROLE_MAPPINGS" ]; then
  service_accounts_enabled=true
fi

if [ "$service_accounts_enabled" = true ] && [ -z "$CLIENT_SECRET" ]; then
  echo "Service accounts require a client secret"
  exit 1
fi

if [ -n "$CLIENT_SECRET" ]; then

  json_client_payload=$(cat <<EOF
{
  "clientId": "$CLIENT_ID",
  "clientAuthenticatorType": "client-secret",
  "standardFlowEnabled": ${STANDARD_FLOW:-true},
  "directAccessGrantsEnabled": ${DIRECT_ACCESS_GRANTS:-false},
  "publicClient": false,
  "secret": "$CLIENT_SECRET",
  "serviceAccountsEnabled": ${service_accounts_enabled},$( [ -n "$FRONT_CHANNEL_LOGOUT_URL" ] && echo '
  "frontchannelLogout": true,' )
  "attributes": {$( [ -n "$FRONT_CHANNEL_LOGOUT_URL" ] && echo '
    "frontchannel.logout.url": "'"$FRONT_CHANNEL_LOGOUT_URL"'",' )
    "oauth2.device.authorization.grant.enabled": "${OAUTH2_DEVICE_AUTHORIZATION_GRANTS:-false}",
    "standard.token.exchange.enabled": "${STANDARD_TOKEN_EXCHANGE:-false}"$( [ -n "$LOGIN_THEME" ] && echo ",\"login_theme\": \"$LOGIN_THEME\"" )
  },$( [ "${STANDARD_FLOW:-true}" = "true" ] && echo '
  "baseUrl": "'"${BASE_URL}"'",
  "redirectUris": '"${REDIRECT_URIS:-[\"${BASE_URL}/*\"]}",'
  "webOrigins": '"${WEB_ORIGINS:-[\"+\"]}," )
  "authorizationServicesEnabled": ${AUTHORIZATION_SERVICES:-false}
}
EOF
)

  echo "Enabling client $json_client_payload"

  response=$(curl -s -w "\n%{http_code}" -i $CAFILE -X ${method:-PUT} "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$id" \
    -H 'Content-Type: application/json' \
    -H "Authorization: Bearer $ADMIN_TOKEN" \
    -d "${json_client_payload}")

  http_code=$(echo "$response" | tail -n1)

  body=$(echo "$response" | sed '$d')

  if [ "$http_code" -ge 300 ]; then
    echo "Failed to enable client. HTTP response code: $http_code"
    echo "Response: $body"
    exit 1
  fi

  id_location=$(echo "$body" | sed -n 's#^location:[ ]*##ip' | tr -d '\r')

else

  if [ "${STANDARD_FLOW:-true}" = "true" ] && [ -z "$FRONT_CHANNEL_LOGOUT_URL" ]; then
    echo "No front channel logout URL found for public client $CLIENT_ID with standard flow enabled"
    exit 1
  fi

  json_client_payload=$(cat <<EOF
{
  "clientId": "$CLIENT_ID",
  "standardFlowEnabled": ${STANDARD_FLOW:-true},
  "directAccessGrantsEnabled": ${DIRECT_ACCESS_GRANTS:-false},
  "implicitFlowEnabled": true,
  "publicClient": true,$( [ "${STANDARD_FLOW:-true}" = "true" ] && [ -n "$FRONT_CHANNEL_LOGOUT_URL" ] && echo '
  "frontchannelLogout": true,' )
  "attributes": {
    $(if [ "${PKCE_CODE_CHALLENGE_METHOD_SKIP:-false}" != "true" ]; then echo '"pkce.code.challenge.method": "S256",'; fi)$( [ "${STANDARD_FLOW:-true}" = "true" ] && [ -n "$FRONT_CHANNEL_LOGOUT_URL" ] && echo '
    "frontchannel.logout.url": "'"$FRONT_CHANNEL_LOGOUT_URL"'",' )
    "oauth2.device.authorization.grant.enabled": "${OAUTH2_DEVICE_AUTHORIZATION_GRANTS:-false}"$( [ -n "$LOGIN_THEME" ] && echo ",\"login_theme\": \"$LOGIN_THEME\"" )
  }$( [ "${STANDARD_FLOW:-true}" = "true" ] && echo ',
  "baseUrl": "'"${BASE_URL}"'",
  "redirectUris": '"${REDIRECT_URIS:-[\"${BASE_URL}/*\"]}",'
  "webOrigins": '"${WEB_ORIGINS:-[\"+\"]}" )
}
EOF
)

  echo "Enabling client $json_client_payload"

  response="$(curl -s -w "\n%{http_code}" -i $CAFILE -X ${method:-PUT} "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$id" \
    -H 'Content-Type: application/json' \
    -H "Authorization: Bearer $ADMIN_TOKEN" \
    -d "${json_client_payload}")"

  http_code=$(echo "$response" | tail -n1)

  body=$(echo "$response" | sed '$d')

  if [ "$http_code" -ge 300 ]; then
    echo "Failed to enable client. HTTP response code: $http_code"
    echo "Response: $body"
    exit 1
  fi

  id_location=$(echo "$body" | sed -n 's#^location:[ ]*##ip' | tr -d '\r')

fi

if [ -n "$id_location" ]; then
  echo "Location found for $CLIENT_ID is $id_location"
  id="${id_location##*/}"
fi

if [ -n "$OPTIONAL_SCOPES" ] && [ -n "$id" ]; then
  echo "Processing client scopes for client ID: $id"

  echo "$OPTIONAL_SCOPES" | jq -r '.[]' | while read -r scope_name; do
    echo "Checking scope '$scope_name'..."

    scope_id=$(curl -s $CAFILE -X GET "$KEYCLOAK_URL/admin/realms/$REALM_NAME/client-scopes" \
      -H "Authorization: Bearer $ADMIN_TOKEN" | jq -r ".[] | select(.name==\"$scope_name\") | .id")

    if [ -n "$scope_id" ]; then
      echo "Found existing scope ID: $scope_id for scope: $scope_name"
    else
      echo "Scope '$scope_name' not found. Creating it..."

      scope_payload=$(cat <<EOF
{
  "name": "$scope_name",
  "description": "$scope_name",
  "protocol": "openid-connect",
  "attributes": {
    "include.in.token.scope": "true",
    "display.on.consent.screen": "true"
  }
}
EOF
)

      response=$(curl -s -w "\n%{http_code}" -i $CAFILE -X POST "$KEYCLOAK_URL/admin/realms/$REALM_NAME/client-scopes" \
        -H 'Content-Type: application/json' \
        -H "Authorization: Bearer $ADMIN_TOKEN" \
        -d "$scope_payload")

      http_code=$(echo "$response" | tail -n1)
      body=$(echo "$response" | sed '$d')

      if [ "$http_code" -ge 300 ]; then
        echo "Failed to create client scope '$scope_name'. HTTP response code: $http_code"
        echo "Response: $body"
        exit 1
      else
        echo "Successfully created client scope: $scope_name"

        scope_id=$(curl -s $CAFILE -X GET "$KEYCLOAK_URL/admin/realms/$REALM_NAME/client-scopes" \
          -H "Authorization: Bearer $ADMIN_TOKEN" | jq -r ".[] | select(.name==\"$scope_name\") | .id")
      fi
    fi

    if [ -n "$scope_id" ]; then
      echo "Assigning scope '$scope_name' (ID: $scope_id) to client..."

      response=$(curl -s -w "\n%{http_code}" $CAFILE -X PUT "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$id/optional-client-scopes/$scope_id" \
        -H "Authorization: Bearer $ADMIN_TOKEN")

      http_code=$(echo "$response" | tail -n1)
      body=$(echo "$response" | sed '$d')

      if [ "$http_code" -ge 300 ]; then
        echo "Failed to assign scope '$scope_name' to client. HTTP response code: $http_code"
        echo "Response: $body"
        exit 1
      fi
      echo "Successfully assigned scope '$scope_name' to client"
    else
      echo "Could not obtain scope ID for '$scope_name'"
      exit 1
    fi
  done
fi

if [ -n "$ROLES_CLAIM" ]; then

  response="$(curl -s -w "\n%{http_code}" $CAFILE -X GET "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$id/protocol-mappers/models" \
    -H "Authorization: Bearer $ADMIN_TOKEN")"
  http_code=$(echo "$response" | tail -n1)
  body=$(echo "$response" | sed '$d')
  if [ "$http_code" -ge 300 ]; then
    echo "Failed to get the protocol mappers. HTTP response code: $http_code"
    echo "Response: $body"
    exit 1
  fi

  echo "Protocol mappers: $body"

  mapper_enabled="$(echo "$body" | jq '.[] | select(.name=="realm_roles" and .protocolMapper=="oidc-usermodel-realm-role-mapper")')"

  echo "Mapper_enabled: $mapper_enabled"

  if [ -n "$mapper_enabled" ]; then
    echo "The protocol mapper: realm_roles is already present."

  else

    json_role_mapper_payload=$(cat <<EOF
{
      "name":"realm_roles",
      "protocol":"openid-connect",
      "protocolMapper":"oidc-usermodel-realm-role-mapper",
      "consentRequired":false,
      "config":{
        "claim.name":"$ROLES_CLAIM",
        "jsonType.label":"String",
        "access.token.claim":"true",
        "id.token.claim":"$ENABLE_ID_TOKEN",
        "userinfo.token.claim":"true",
        "multivalued": "true"
      }
    }
EOF
)

    echo "Adding mapper $json_role_mapper_payload"

    response="$(curl -s -w "\n%{http_code}" -i $CAFILE -X POST "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$id/protocol-mappers/models" \
      -H 'Content-Type: application/json' \
      -H "Authorization: Bearer $ADMIN_TOKEN" \
      -d "${json_role_mapper_payload}")"
    http_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | sed '$d')
    if [ "$http_code" -ge 300 ]; then
      echo "Failed to add realm roles mapper. HTTP response code: $http_code"
      echo "Response: $body"
      exit 1
    fi

  fi

fi

if [ -n "$TEAMSPACES_CLAIM" ]; then

  response="$(curl -s -w "\n%{http_code}" $CAFILE -X GET "$KEYCLOAK_URL/admin/realms/$REALM_NAME/users/profile" \
    -H "Authorization: Bearer $ADMIN_TOKEN")"
  http_code=$(echo "$response" | tail -n1)
  profile_body=$(echo "$response" | sed '$d')
  if [ "$http_code" -ge 300 ]; then
    echo "Failed to get the user profile. HTTP response code: $http_code"
    echo "Response: $profile_body"
    exit 1
  fi

  echo "User profile: $profile_body"

  teamspaces_attr_enabled="$(echo "$profile_body" | jq 'any(.attributes[]; .name == "teamspaces")')"

  echo "Teamspaces attribute enabled: $teamspaces_attr_enabled"

  if [ "$teamspaces_attr_enabled" == "true" ]; then
    echo "In the user profile: 'teamspaces' is already present"

  else
    new_attr_json='{"name":"teamspaces","displayName":"teamspaces","validations":{},"annotations":{},"permissions":{"view":["admin","user"],"edit":["admin"]},"group":"user-metadata","multivalued":true}'

    updated_profile_body="$(echo "$profile_body" | jq --argjson new_attr "$new_attr_json" '.attributes += [$new_attr]')"

    response="$(curl -s -w "\n%{http_code}" -i $CAFILE -X PUT "$KEYCLOAK_URL/admin/realms/$REALM_NAME/users/profile" \
      -H 'Content-Type: application/json' \
      -H "Authorization: Bearer $ADMIN_TOKEN" \
      -d "$updated_profile_body")"
    http_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | sed '$d')
    if [ "$http_code" -ge 300 ]; then
      echo "Failed to add 'teamspaces' attribute to the user profile. HTTP response code: $http_code"
      echo "Response: $body"
      exit 1
    fi
    echo "Successfully added 'teamspaces' attribute."

  fi

  response="$(curl -s -w "\n%{http_code}" $CAFILE -X GET "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$id/protocol-mappers/models" \
    -H "Authorization: Bearer $ADMIN_TOKEN")"
  http_code=$(echo "$response" | tail -n1)
  body=$(echo "$response" | sed '$d')
  if [ "$http_code" -ge 300 ]; then
    echo "Failed to get the protocol mappers. HTTP response code: $http_code"
    echo "Response: $body"
    exit 1
  fi

  echo "Protocol mappers: $body"

  mapper_enabled="$(echo "$body" | jq '.[] | select(.name=="teamspaces" and .protocolMapper=="oidc-usermodel-attribute-mapper")')"

  echo "Mapper_enabled: $mapper_enabled"

  if [ -n "$mapper_enabled" ]; then
    echo "The protocol mapper: teamspaces is already present."

  else

    json_attribute_payload=$(cat <<EOF
{
      "name":"teamspaces",
      "protocol":"openid-connect",
      "protocolMapper":"oidc-usermodel-attribute-mapper",
      "consentRequired":false,
      "config":{
        "user.attribute":"teamspaces",
        "claim.name":"$TEAMSPACES_CLAIM",
        "jsonType.label":"String",
        "access.token.claim":"true",
        "id.token.claim":"$ENABLE_ID_TOKEN",
        "userinfo.token.claim":"true",
        "multivalued": "true"
      }
    }
EOF
)

    echo "Adding mapper $json_attribute_payload"

    response="$(curl -s -w "\n%{http_code}" -i $CAFILE -X POST "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$id/protocol-mappers/models" \
      -H 'Content-Type: application/json' \
      -H "Authorization: Bearer $ADMIN_TOKEN" \
      -d "${json_attribute_payload}")"
    http_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | sed '$d')
    if [ "$http_code" -ge 300 ]; then
      echo "Failed to add attribute mapper - teamspaces. HTTP response code: $http_code"
      echo "Response: $body"
      exit 1
    fi
    echo "Successfully added attribute mapper - teamspaces"

  fi

fi

if [ -n "$ENTITLEMENTS_CLAIM" ]; then

  response="$(curl -s -w "\n%{http_code}" $CAFILE -X GET "$KEYCLOAK_URL/admin/realms/$REALM_NAME/users/profile" \
    -H "Authorization: Bearer $ADMIN_TOKEN")"
  http_code=$(echo "$response" | tail -n1)
  profile_body=$(echo "$response" | sed '$d')
  if [ "$http_code" -ge 300 ]; then
    echo "Failed to get the user profile. HTTP response code: $http_code"
    echo "Response: $profile_body"
    exit 1
  fi

  echo "User profile: $profile_body"

  entitlements_attr_enabled="$(echo "$profile_body" | jq 'any(.attributes[]; .name == "entitlements")')"

  echo "Entitlements attribute enabled: $entitlements_attr_enabled"

  if [ "$entitlements_attr_enabled" == "true" ]; then
    echo "In the user profile: 'entitlements' is already present"

  else
    new_attr_json='{"name":"entitlements","displayName":"entitlements","validations":{},"annotations":{},"permissions":{"view":["admin","user"],"edit":["admin"]},"group":"user-metadata","multivalued":true}'

    updated_profile_body="$(echo "$profile_body" | jq --argjson new_attr "$new_attr_json" '.attributes += [$new_attr]')"

    response="$(curl -s -w "\n%{http_code}" -i $CAFILE -X PUT "$KEYCLOAK_URL/admin/realms/$REALM_NAME/users/profile" \
      -H 'Content-Type: application/json' \
      -H "Authorization: Bearer $ADMIN_TOKEN" \
      -d "$updated_profile_body")"
    http_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | sed '$d')
    if [ "$http_code" -ge 300 ]; then
      echo "Failed to add 'entitlements' attribute to the user profile. HTTP response code: $http_code"
      echo "Response: $body"
      exit 1
    fi
    echo "Successfully added 'entitlements' attribute."

  fi

  response="$(curl -s -w "\n%{http_code}" $CAFILE -X GET "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$id/protocol-mappers/models" \
    -H "Authorization: Bearer $ADMIN_TOKEN")"
  http_code=$(echo "$response" | tail -n1)
  body=$(echo "$response" | sed '$d')
  if [ "$http_code" -ge 300 ]; then
    echo "Failed to get the protocol mappers. HTTP response code: $http_code"
    echo "Response: $body"
    exit 1
  fi

  echo "Protocol mappers: $body"

  mapper_enabled="$(echo "$body" | jq '.[] | select(.name=="entitlements" and .protocolMapper=="oidc-usermodel-attribute-mapper")')"

  echo "Mapper_enabled: $mapper_enabled"

  if [ -n "$mapper_enabled" ]; then
    echo "The protocol mapper: entitlements is already present."

  else

    json_attribute_payload=$(cat <<EOF
{
      "name":"entitlements",
      "protocol":"openid-connect",
      "protocolMapper":"oidc-usermodel-attribute-mapper",
      "consentRequired":false,
      "config":{
        "user.attribute":"entitlements",
        "claim.name":"$ENTITLEMENTS_CLAIM",
        "jsonType.label":"String",
        "access.token.claim":"true",
        "id.token.claim":"$ENABLE_ID_TOKEN",
        "userinfo.token.claim":"true",
        "multivalued": "true"
      }
    }
EOF
)

    echo "Adding mapper $json_attribute_payload"

    response="$(curl -s -w "\n%{http_code}" -i $CAFILE -X POST "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$id/protocol-mappers/models" \
      -H 'Content-Type: application/json' \
      -H "Authorization: Bearer $ADMIN_TOKEN" \
      -d "${json_attribute_payload}")"
    http_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | sed '$d')
    if [ "$http_code" -ge 300 ]; then
      echo "Failed to add attribute mapper - entitlements. HTTP response code: $http_code"
      echo "Response: $body"
      exit 1
    fi
    echo "Successfully added attribute mapper - entitlements"

  fi

fi

if [ -n "$ROLE_MAPPINGS" ]; then

  user_id="$(curl -si $CAFILE "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$id/service-account-user" \
      -H 'Accept: application/json' \
      -H "Authorization: Bearer $ADMIN_TOKEN" |
      sed -r -n 's/.*"id":"([^"]*)",.*/\1/p')"
  echo "user_id: $user_id"

  sanitized_client_id=$(echo "$CLIENT_ID" | tr ':' '-')

  json_service_account_email_payload=$(cat <<EOF
  {
    "email": "$sanitized_client_id@knowis.de"
  }
EOF
  )
  echo "Adding service account email $json_service_account_email_payload"
  response="$(curl -s -w "\n%{http_code}" -i $CAFILE -X PUT "$KEYCLOAK_URL/admin/realms/$REALM_NAME/users/$user_id" \
      -H 'Content-Type: application/json' \
      -H "Authorization: Bearer $ADMIN_TOKEN" \
      -d "${json_service_account_email_payload}")"
  http_code=$(echo "$response" | tail -n1)
  body=$(echo "$response" | sed '$d')
  if [ "$http_code" -ge 300 ]; then
    echo "Failed to set service account email. HTTP response code: $http_code"
    echo "Response: $body"
    exit 1
  fi

  for perm_group in $ROLE_MAPPINGS; do
    perm_roles="$(tr '|' ' ' <<< "${perm_group#*|}")"
    perm_client=${perm_group%%|*}
    echo perm_client: $perm_client
    perm_id="$(CLIENT_ID=$perm_client ADMIN_TOKEN=$ADMIN_TOKEN "$(dirname "${BASH_SOURCE[0]}")/client-id.sh")"
    echo perm_id: $perm_id

    roles="$(curl -si $CAFILE "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$perm_id/roles" \
     -H 'Accept: application/json' \
     -H "Authorization: Bearer $ADMIN_TOKEN")"
    echo "Client Roles: $roles"

    payload=
    for role in $perm_roles; do
      p="$(sed -r -n 's/.*("id":"[^"]*","name":"'"$role"'","description":"[^"]*"),.*/\1/p' <<< "$roles")"
      echo "Checking role: $role"
      if [ -n "$p" ]; then
        echo "Adding client role: $p"
        payload="$payload,{$p}"
      fi
    done

    if [ -n "$payload" ]; then
      echo "Creating client role mapping: $payload"
      curl -i $CAFILE -X POST "$KEYCLOAK_URL/admin/realms/$REALM_NAME/users/$user_id/role-mappings/clients/$perm_id" \
        -H 'Content-Type: application/json' \
        -H "Authorization: Bearer $ADMIN_TOKEN" \
        -d @-<<EOF
[${payload:1}]
EOF
    fi

    realm_roles="$(curl -si $CAFILE "$KEYCLOAK_URL/admin/realms/$REALM_NAME/roles" \
     -H 'Accept: application/json' \
     -H "Authorization: Bearer $ADMIN_TOKEN")"

    echo "Realm Roles: $realm_roles"
    payload=
    for realm_role in $perm_roles; do
      echo "Checking role: $role"
      p="$(sed -r -n 's/.*("id":"[^"]*","name":"'"$realm_role"'","description":"[^"]*"),.*/\1/p' <<< "$realm_roles")"
      if [ -n "$p" ]; then
        echo "Adding realm role: $p"
        payload="$payload,{$p}"
      fi
    done

    if [ -n "$payload" ]; then
      echo "Creating realm role mapping: $payload"
      curl -i $CAFILE -X POST "$KEYCLOAK_URL/admin/realms/$REALM_NAME/users/$user_id/role-mappings/realm" \
        -H 'Content-Type: application/json' \
        -H "Authorization: Bearer $ADMIN_TOKEN" \
        -d @-<<EOF
[${payload:1}]
EOF
    fi
  done
fi
