{{/* Print the configurations */}}
{{- define "k5-designer-backend-configmapentries" -}}
pipelineUrlVersion: ""
{{- end -}}

{{- define "k5-designer-backend-decisionsTemplatesConfigmap" -}}

{{- if .Values.backend.defaultDecisionTemplate }}
{{ tpl .Values.backend.defaultDecisionTemplate . }}
{{- end }}

{{- end -}}
