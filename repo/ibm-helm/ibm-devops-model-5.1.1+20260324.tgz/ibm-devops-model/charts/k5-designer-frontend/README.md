# Financial Services Sector Cloud Platform Runtime

The Financial Services Sector Cloud Platform is a low code solution for creating and managing cloud native business applications centered around
namespaces.

## Introduction

This chart deploys a single knowis fss runtime into an IBM Cloud Private Kubernetes environment or in an IBM Cloud Container Services environment  using the [Helm](https://helm.sh) package manager.

## Chart Details

The chart will set up a kubernetes namespace and deploy the runtime infrastructure components of the fss runtime. After the setup, the runtime is ready to run cloud native fss applications.

## Prerequisites

- Kubernetes 1.4+ with Beta APIs enabled

## TODO
...