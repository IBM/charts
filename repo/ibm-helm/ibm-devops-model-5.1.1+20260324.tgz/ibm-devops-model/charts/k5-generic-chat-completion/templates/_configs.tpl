{{/* Print the configurations */}}
{{- define "k5-generic-chat-completion-configmapentries" -}}
pipelineUrlVersion: ""
{{- end -}}
