{{/* vim: set filetype=mustache: */}}

{{/*
Expand the name of the chart.
*/}}
{{- define "k5-code-generation-provider.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
*/}}
{{- define "k5-code-generation-provider.fullname" -}}
{{- $name := .Chart.Name -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Build an image from given values
*/}}
{{- define "k5-code-generation-provider.image.builder" -}}
{{- $registry := .values.global.image.registry -}}
{{- $repository := .image.repository -}}
{{ if .values.global.imageRegistry }}
{{- $registry = .values.global.imageRegistry -}}
{{- $repository = printf "%s-%s" .values.global.image.prefix .image.repository -}}
{{- else if  .values.global.image.privateRegistry }}
{{- $registry = .values.global.image.privateRegistry -}}
{{- $repository = printf "%s-%s" .values.global.image.prefix .image.repository -}}
{{- end -}}
{{ if .image.digest }}
{{- printf "%s/%s@%s" $registry $repository .image.digest -}}
{{ else }}
{{- printf "%s/%s:%s" $registry $repository .image.tag -}}
{{- end -}}
{{- end -}}

{{/*
Build a list of allowed domains as a comma separated string - supports global and project specific allowedDomains
*/}}
{{- define "k5-code-generation-provider.cors-allowed-domains.builder" -}}
{{- range $DOMAIN := .Values.global.k5.cors.allowedDomains -}}
{{ tpl $DOMAIN $ }}{{- printf "," }}
{{- end -}}
{{- if ((.Values.cors).allowedDomains) -}}
{{- range $DOMAIN := .Values.cors.allowedDomains -}}
{{ tpl $DOMAIN $ }}{{- printf "," }}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "k5-code-generation-provider.http.scheme.upperCase" -}}
{{- if (.Capabilities.APIVersions.Has "getambassador.io/v2") }}
{{- printf "HTTP" }}
{{- else }}
{{- printf "HTTPS" }}
{{- end }}
{{- end }}

{{- define "k5-code-generation-provider.http.scheme" -}}
{{- if (.Capabilities.APIVersions.Has "getambassador.io/v2") }}
{{- printf "http" }}
{{- else }}
{{- printf "https" }}
{{- end }}
{{- end }}
