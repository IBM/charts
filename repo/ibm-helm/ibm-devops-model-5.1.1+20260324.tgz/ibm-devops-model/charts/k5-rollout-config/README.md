# k5 rollout config component
