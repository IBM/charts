{{/* Print the configurations */}}
{{- define "k5-rollout-configmapentries" -}}
de.knowis.cp.run.rolloutconfig.scheduler.checksum.initialDelayMs: {{ .Values.scheduler.checksum.initialDelayMs | quote }}
de.knowis.cp.run.rolloutconfig.scheduler.checksum.fixedDelayMs: {{ .Values.scheduler.checksum.fixedDelayMs | quote }}

# Spring settings
{{- if .Values.configmap.spring }}
{{ tpl .Values.configmap.spring . }}
{{- end }}

# logging settings
{{- if .Values.configmap.logging }}
{{ tpl .Values.configmap.logging . }}
{{- end }}

# Additional settings
{{- if .Values.configmap.extraConfiguration }}
{{ tpl .Values.configmap.extraConfiguration .}}
{{- end }}

{{- end -}}
