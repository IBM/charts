## Chart Details

The chart will set up a Kubernetes namespace and deploy the k5-diagram-modeller.

## Prerequisites

- Kubernetes 1.4+ with Beta APIs enabled

## TODO
...