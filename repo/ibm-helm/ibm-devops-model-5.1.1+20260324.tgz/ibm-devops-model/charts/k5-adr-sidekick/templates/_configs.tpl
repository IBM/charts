{{/* Print the configurations */}}
{{- define "k5-adr-sidekick-configmapentries" -}}
pipelineUrlVersion: ""
{{- end -}}
