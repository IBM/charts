{{/* Print the configurations */}}
{{- define "k5-pipeline-manager-configmapentries" -}}

# logging settings
{{- if .Values.configmap.logging }}
{{ tpl .Values.configmap.logging . }}
{{- end }}

# spring settings
{{- if .Values.configmap.spring }}
{{ tpl .Values.configmap.spring . }}
{{- end }}

de.knowis.cp.pipelinemanager.provider.host.protocol: {{ tpl .Values.configurations.protocol . | quote }}
de.knowis.cp.pipelinemanager.provider.host.name: {{ tpl .Values.global.k5.endpoints.pipelineManager.host . | quote }}

de.knowis.cp.pipelinemanager.cors.allowedDomains: {{ include "k5-pipeline-manager.cors-allowed-domains.builder" . | trimSuffix "," | quote }}

de.knowis.cp.pipelinemanager.pipelines.names.cloneTask: {{ tpl .Values.tekton.task.cloneTask.name . | quote }}
de.knowis.cp.pipelinemanager.pipelines.names.undeployTask: {{ tpl .Values.tekton.task.undeploy.name . | quote }}
de.knowis.cp.pipelinemanager.pipelines.names.eventListener: {{ tpl .Values.tekton.eventListener . | quote }}
de.knowis.cp.pipelinemanager.pipelines.names.triggerBinding: {{ tpl .Values.tekton.triggerBinding.name . | quote }}
de.knowis.cp.pipelinemanager.pipelines.names.webhookSecret: {{ tpl .Values.tekton.webhookSecret . | quote }}
de.knowis.cp.pipelinemanager.pipelines.names.pipelineSa: {{ tpl .Values.tekton.pipelineSa . | quote }}
de.knowis.cp.pipelinemanager.pipelines.names.pipelineRole: {{ tpl .Values.tekton.pipelineRole . | quote }}
de.knowis.cp.pipelinemanager.pipelines.names.workspaceStorage: {{ tpl .Values.tekton.workspace.storage . | quote }}
de.knowis.cp.pipelinemanager.pipelines.names.workspaceStorageClassName: {{ tpl .Values.tekton.workspace.storageClassName . | quote }}
de.knowis.cp.pipelinemanager.pipelines.names.managedByKey: {{ tpl .Values.tekton.managedBy.key . | quote }}
de.knowis.cp.pipelinemanager.pipelines.names.managedByValue: {{ tpl .Values.tekton.managedBy.value . | quote }}
de.knowis.cp.pipelinemanager.pipelines.names.scheduleInMinutes: {{ tpl .Values.tekton.cleanup.scheduleInMinutes . | quote }}
de.knowis.cp.pipelinemanager.pipelines.names.keepLastPipelineRuns: {{ tpl .Values.tekton.cleanup.keepLastPipelineRuns . | quote }}
de.knowis.cp.pipelinemanager.pipelines.names.keepLastPipelineRunsCompletedBefore: {{ tpl .Values.tekton.cleanup.keepLastPipelineRunsCompletedBefore . | quote }}
de.knowis.cp.pipelinemanager.pipelines.names.cronEnabled: {{ tpl .Values.tekton.cleanup.enabled . | quote }}
de.knowis.cp.pipelinemanager.pipelines.names.tektonEnabled: {{ tpl .Values.tekton.enabled . | quote }}
de.knowis.cp.pipelinemanager.pipelines.names.tenantIsolation: {{ .Values.global.k5.tenantIsolation | default "false" | quote }}

kubernetes.common.labels.instance:  {{ .Release.Name | quote }}
kubernetes.common.labels.managedBy: {{ template "k5-pipeline-manager.name" . }}
kubernetes.common.labels.name: {{ template "k5-pipeline-manager.fullname" . }}

audit.namespace: {{ .Release.Namespace }}

{{- end -}}
