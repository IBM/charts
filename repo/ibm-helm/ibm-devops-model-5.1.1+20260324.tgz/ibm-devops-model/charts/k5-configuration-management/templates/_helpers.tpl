{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "configuration-management.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
*/}}
{{- define "configuration-management.fullname" -}}
{{- $name := .Chart.Name -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
*/}}
{{- define "configuration-management.jobs.fullname" -}}
{{- $name := .Chart.Name -}}
{{- printf "%s-%s-%s" .Release.Name $name "migration" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified job name.
Due to the job only being allowed to run once, we add the chart revision so helm
upgrades don't cause errors trying to create the already ran job.
*/}}
{{- define "configuration-management.perform-migration-script.name" -}}
{{- $rand := randAlphaNum 7 | lower }}
{{- printf "k5-configuration-management-perform-migration-%d-%s" .Release.Revision $rand | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Print .Values.global.endpoints.configurationManagement.host as default redirect uri. More redirect uris can be appended from oauth.redirects.
*/}}
{{- define "configuration-management.redirects" -}}
"{{- printf "https://" -}}{{ tpl .Values.global.domain . }}{{- printf "/*" }}"
{{- if .Values.oauth.redirects }}
{{- range $RURI := .Values.oauth.redirects }}
{{- printf "," }} "{{ $RURI }}"
{{- end }}
{{- end }}
{{- end -}}

{{/*
Create the name of service cert secret.
*/}}
{{- define "configuration-management.service-cert.name" -}}
{{- printf "%s-service-cert" .Values.deployment.name | quote -}}
{{- end -}}

{{/*
Build additional global route annotations
*/}}
{{- define "configuration-management.routes.annotations" -}}
{{- if .Values.global.k5.routes.annotations -}}
{{ tpl (toYaml .Values.global.k5.routes.annotations)  . }}
{{- end -}}
{{- end -}}

{{/*
Build an image from given values
*/}}
{{- define "configuration-management.image.builder" -}}
{{- $registry := .values.global.image.registry -}}
{{- $repository := .image.repository -}}
{{ if .values.global.imageRegistry }}
{{- $registry = .values.global.imageRegistry -}}
{{- $repository = printf "%s-%s" .values.global.image.prefix .image.repository -}}
{{- else if  .values.global.image.privateRegistry }}
{{- $registry = .values.global.image.privateRegistry -}}
{{- $repository = printf "%s-%s" .values.global.image.prefix .image.repository -}}
{{- end -}}
{{ if .image.digest }}
{{- printf "%s/%s@%s" $registry $repository .image.digest -}}
{{ else }}
{{- printf "%s/%s:%s" $registry $repository .image.tag -}}
{{- end -}}
{{- end -}}

{{/*
Build a list of allowed domains as a comma separated string - supports global and project specific allowedDomains
*/}}
{{- define "configuration-management.cors-allowed-domains.builder" -}}
{{- range $DOMAIN := .Values.global.k5.cors.allowedDomains -}}
{{ tpl $DOMAIN $ }}{{- printf "," }}
{{- end -}}
{{- if ((.Values.cors).allowedDomains) -}}
{{- range $DOMAIN := .Values.cors.allowedDomains -}}
{{ tpl $DOMAIN $ }}{{- printf "," }}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "configuration-management.keycloak.secret.name" -}}
{{- default (printf "%s-keycloak" .Release.Name) .Values.global.k5.identity.secretName -}}
{{- end }}

{{- define "configuration-management.http.scheme.upperCase" -}}
{{- if (.Capabilities.APIVersions.Has "getambassador.io/v2") }}
{{- printf "HTTP" }}
{{- else }}
{{- printf "HTTPS" }}
{{- end }}
{{- end }}

{{- define "configuration-management.http.scheme" -}}
{{- if (.Capabilities.APIVersions.Has "getambassador.io/v2") }}
{{- printf "http" }}
{{- else }}
{{- printf "https" }}
{{- end }}
{{- end }}
