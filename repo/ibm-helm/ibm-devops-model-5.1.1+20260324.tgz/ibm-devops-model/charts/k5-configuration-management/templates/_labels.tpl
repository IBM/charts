{{/*
Label stack used for labelling.
*/}}
{{- define "configuration-management.labels" -}}
app.kubernetes.io/version: {{ .Chart.AppVersion }}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version | replace "+" "_" }}
app.kubernetes.io/part-of: k5-hub
{{ template "configuration-management.matchLabels" . }}
{{- end -}}

{{- define "configuration-management.matchLabels" -}}
app.kubernetes.io/name: {{ template "configuration-management.fullname" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: {{ .Chart.Name }}
{{- end -}}

{{/*
Job labels need to be unique, see BR-2861
*/}}
{{- define "configuration-management.jobs.labels" -}}
app.kubernetes.io/version: {{ .Chart.AppVersion }}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version | replace "+" "_" }}
app.kubernetes.io/part-of: k5-hub
{{ template "configuration-management.jobs.matchLabels" . }}
{{- end -}}

{{- define "configuration-management.jobs.matchLabels" -}}
app.kubernetes.io/name: {{ template "configuration-management.jobs.fullname" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}
