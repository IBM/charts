{{/* Print the configurations */}}
{{- define "configuration-management-configmapentries" -}}
audit.namespace: {{ .Release.Namespace }}

server.servlet.context-path: {{ .Values.global.k5.ingress.path }}{{ .Values.global.k5.endpoints.configurationManagement.path }}
springdoc.swagger-ui.config-url: {{ .Values.global.k5.ingress.path }}{{ .Values.global.k5.endpoints.configurationManagement.path }}/-/configuration-management/api-docs/swagger-config

# Rewrite configuration
de.knowis.cp.cfgm.deployment.protocol: {{ tpl .Values.deployment.protocol . | quote }}
de.knowis.cp.cfgm.deployment.hostname: "{{ tpl .Values.global.domain . }}{{ .Values.global.k5.ingress.path }}{{ .Values.global.k5.endpoints.configurationManagement.path }}"
de.knowis.cp.cfgm.deployment.basePath: '{{ .Values.global.k5.ingress.path }}{{ .Values.global.k5.endpoints.configurationManagement.path }}'

de.knowis.cp.cfgm.cors.allowedDomains: {{ include "configuration-management.cors-allowed-domains.builder" . | trimSuffix "," | quote }}

kubernetes.common.labels.instance: {{ .Release.Name | quote }}
kubernetes.common.labels.managedBy: {{ template "configuration-management.name" . }}
kubernetes.common.labels.name: {{ template "configuration-management.fullname" . }}

# Spring settings
{{- if .Values.configmap.spring }}
{{ tpl .Values.configmap.spring . }}
{{- end }}

# logging settings
{{- if .Values.configmap.logging }}
{{ tpl .Values.configmap.logging . }}
{{- end }}

# Additional settings
{{- if .Values.configmap.extraConfiguration }}
{{ tpl .Values.configmap.extraConfiguration . }}
{{- end }}

{{- end -}}
