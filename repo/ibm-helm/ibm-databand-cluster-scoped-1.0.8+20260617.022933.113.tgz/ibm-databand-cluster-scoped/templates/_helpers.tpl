{{- define "ibm-databand-cluster-scoped.standardLabels" -}}
app.kubernetes.io/managed-by: kustomize
app.kubernetes.io/name: ibm-databand-operator
control-plane: controller-manager
icpdsupport/addOnId: {{ .Values.ibmDataband.addonId }}
icpdsupport/app: databand
icpdsupport/module: databand
component-id: {{ .Chart.Name }}
{{- end -}}
