# Release Notes

This document is release notes for IBM Sterling Transformation Extender for Red Hat OpenShift 10.1.1

## What's new

This container version includes IBM Sterling Transformation Extender 10.1.1. It runs on supported versions of Red Hat OpenShift Container Platform (RHOCP).

## Fixes

N/A

## Prerequisites

Please refer to the main `README` document.

## Version History

1.0.x - IBM Sterling Transformation Extender Runtime Server 10.0.3
<br>2.0.x - IBM Sterling Transformation Extender for Red Hat OpenShift 10.1.1
* 2.0.1 - 20221116 : The image with ID 6696862641d4 includes security patches and fixes applied to IBM Transformation Extender through 10.1.1.1 build 135.
* 2.0.2 - 20240412 : The image with ID 83e54dd680ac includes security patches and fixes applied to IBM Transformation Extender through 10.1.1.1 build 168.
* 2.0.3 - 20250328 : The image with ID fa50c62b2ae7 includes security patches and fixes applied to IBM Transformation Extender through 10.1.1.1 build 219.
* 2.0.4 - 20251121 : The image with ID 9a6c8dfcef59 includes security patches and fixes applied to IBM Transformation Extender through 10.1.1.1 build 244.
* 2.0.5 - 20260320 : The image with ID bcdcbfa6c4c1 includes security patches and fixes applied to IBM Transformation Extender through 10.1.1.2 build 8.

<br>2.1.x - IBM Sterling Transformation Extender for Red Hat OpenShift 10.1.2
<br>3.0.x - IBM Sterling Transformation Extender for Red Hat OpenShift 11.0.1
<br>3.1.x - IBM Sterling Transformation Extender for Red Hat OpenShift 11.0.2

## Breaking Changes

N/A

## Documentation

For general IBM Sterling Transformation Extender documentation, please refer to the product's [knowledge center](https://www.ibm.com/docs/en/ste/10.1.1).
