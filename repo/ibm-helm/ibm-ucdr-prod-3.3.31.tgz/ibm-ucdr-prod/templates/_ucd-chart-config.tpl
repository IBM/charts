{{/*
license  parameter must be set to true
*/}}
{{- define "{{ .Chart.Name }}.licenseValidate" -}}
  {{ $license := .Values.license.accept }}
  {{- if $license -}}
    true
  {{- end -}}
{{- end -}}

{{- define "{{ .Chart.Name }}.imagePath" -}}
{{- $imagePrefix := "" -}}
{{- if or (eq .Values.global.imageRegistry "cp.icr.io/cp") (not .Values.global.imageRegistry) -}}
  {{- printf "cp.icr.io/cp%s" $imagePrefix -}}
{{- else if .Values.global.imageRegistry -}}
  {{- .Values.global.imageRegistry | clean | trimSuffix "/" -}}
{{- end -}}
{{- end -}}

{{/* Determine which image to use given the product version. 
   * Values.version can be an imagespec to allow registries other than IBM ER */}}
{{- define "{{ .Chart.Name }}.imageSpec" -}}
{{- $imagePathName := include "{{ .Chart.Name }}.imagePath" . | trim -}}
{{- if eq .Values.version "8.2.1.0" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:b6fe016c3b7e5cb3c9b7510ce260b46723c98b031c5b21ef000203f0447427a9
{{- else if eq .Values.version "8.2.0.1" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:5a2030cc1b63e7bf858ecb5b66e8ca53655599a91cdd1f39f23b39d2db52a54f
{{- else if eq .Values.version "8.2.0.0" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:6646734aa97d4a3a24887a4f549781862453c86ae0d2143e810d7b01e511335f
{{- else if eq .Values.version "8.1.2.6" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:4a0d365704d8eb16ae818843ced4c35ae635e29591c38df103972990adc4aa2a
{{- else if eq .Values.version "8.1.2.5" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:a69f2d427bb042840f1a10409ac2b40ad112b748891d0aab301c1674a7df49fb
{{- else if eq .Values.version "8.1.2.4" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:f530a2f26a1b99c34019ab70ea463b87e840cf59358d1842d2833678395742bc
{{- else if eq .Values.version "8.1.2.3" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:eca9b9d39ea5d371de560c38bbc496d3d6f19f2fa4c42cc29614b2cd090c656a
{{- else if eq .Values.version "8.1.2.2" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:f04d7cf4d3a4b104922a9024179179e5fd8f1d0d794e1a2a6cd6ae595ca678d9
{{- else if eq .Values.version "8.1.2.1" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:bd90abb992d3e1801edefaf131814655482bcb3aee382ddf5a774d7236a73240
{{- else if eq .Values.version "8.1.2.0" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:c6dc37d548af329dd03220cc30192f72e888d809d146f4e0ba692906e6ca93a4
{{- else if eq .Values.version "8.1.1.0" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:246b37dad1a9b99db1f08389e838b5e020b5d2da455ab0143f0a9398ac9e06ec
{{- else if eq .Values.version "8.1.0.1" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:7b69019ddfe1f6667fac60f3b38b135492d425e323f856a6e6f6b1c736dfdf91
{{- else if eq .Values.version "8.1.0.0" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:66d45241a22623147f68c5251793d53837650e3da3188cff365c4ef0adc4fa71
{{- else if eq .Values.version "8.0.1.13" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:8395c74bb12371f2529da03bb17f9abbb7c4fd8a42931c014da76950bb374252
{{- else if eq .Values.version "8.0.1.12" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:83656eab4688dcaf3aba0ae91ecf3d9b4829bfadc0511b4a59603c60d58302a2
{{- else if eq .Values.version "8.0.1.11" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:3a1c54dbab616a17f7466c900f7950fe1dfe6eb47939fcf6605073391b4be037
{{- else if eq .Values.version "8.0.1.10" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:4031cdf3ae17b0e89f0a5976e74bc3c65380fad7e754a747357d930cb194dab0
{{- else if eq .Values.version "8.0.1.9" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:828df53aeec0a77c7f6253adbca7d88b260b162b3d41b00d03e198720cf99a97
{{- else if eq .Values.version "8.0.1.8" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:015a387c64b25663d1d10e08922d069997406cc9b471cd71565596a6152d6013
{{- else if eq .Values.version "8.0.1.7" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:62dc809ba56af4dc1d73b728f87535babcf7f967b803499e4f73458e2fce3628
{{- else if eq .Values.version "8.0.1.6" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:5266ce4417c1789a215b4ac54574c274f15af130d2ed2bd1e87f5337c78f34d7
{{- else if eq .Values.version "8.0.1.5" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:fc50112bbd1288167c3b9916448dc822faa0ee9e58d8ae47a70be31feea5b2e6
{{- else if eq .Values.version "8.0.1.4" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:a701335fb6a6b1639541bb827ace56f06dadb7f3bf8e4f9d1b0ed8b9f5148e2d
{{- else if eq .Values.version "8.0.1.3" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:9427788bb2f9684692e782000aa06e485f4617f3a136bed2fc25f1e704e1e753
{{- else if eq .Values.version "8.0.1.2" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:531c455bc06d2d6a5bf02ac280b4848c5add247d879fc1b91cc7fd97ceb0a1d3
{{- else if eq .Values.version "8.0.1.1" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:0e2de3f7b137b87aee24aac4f41bbb860995b8608530593096bbf2eb30478dec
{{- else if eq .Values.version "8.0.1.0" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:83bbafed290e340fa7d4382c047f2cc325bde6331951e4071369a5ffc9929672
{{- else if eq .Values.version "8.0.0.1" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:2a495c7b53e11fe54b1c08e96b9dec5024e6e8b972dfc3bc65d71965ef7c4718
{{- else if eq .Values.version "8.0.0.0" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:7d853565b7849b92418ebe734d5950264a8b14fdf9e438c9db82a6967549e69d
{{- else if eq .Values.version "7.3.2.18" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:00a961f22d30dbfccde0156ee1df577b9742a41a2369760dc2fae8c061ba60b9
{{- else if eq .Values.version "7.3.2.17" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:5e635923ca92c23d97524e5fe1e818abb7255fb9ed17b73bebc6d83a92368f16
{{- else if eq .Values.version "7.3.2.16" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:a6bb0b79aea0b433ececb5f51087d68d105659c996abf9f4a9600cf698e25fc9
{{- else if eq .Values.version "7.3.2.15" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:47718e6fd6da16263e818da9e04f6e34fc05746006ed0106fccab73d1bb4d4df
{{- else if eq .Values.version "7.3.2.14" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:d3dda522ac7537d6866bc86e9438b63675d2530b5060a687d9e44ecbfe9eab75
{{- else if eq .Values.version "7.3.2.13" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:cd6e9f7fdb9c45d4df9e3e03fc34fca658ba385051da44ccb9e536fb3c8ffc63
{{- else if eq .Values.version "7.3.2.12" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:fd8e9a7683e73117e6da36b53a952f345053b05a3d1cc5cc01f7aeb27672aa13
{{- else if eq .Values.version "7.3.2.11" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:2bdedaa1e82c4c252aa1cf91440fc20f1933e41db422eb5a7a7bd15be0ac1665
{{- else if eq .Values.version "7.3.2.10" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:c26046d2db977c6720981b3f81e6eb6b91150729d57ab48c62ca5479223efa89
{{- else if eq .Values.version "7.3.2.9" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:4d6fc14222f197ac760b17c693d8c43323c177d45d1c98754bc8ac894022e8e2
{{- else if eq .Values.version "7.3.2.8" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:13a2e85f2a3d2bfa0929505892e5f8c9b8dc910f5a52f8d64b19de1aa16c621c
{{- else if eq .Values.version "7.3.2.7" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:c167242a27b23a59b897520ff4df6fff310fa4701305a0a3a964463d338cd5b8
{{- else if eq .Values.version "7.3.2.6" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:8f4bdb0ba7948e78459652289cc3b3098d5c357600b55e91ac7bb3d007a4e642
{{- else if eq .Values.version "7.3.2.5" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:f0513b51800146fac168276ff88e413e34efa82362f84863ece6d2f28a7aed66
{{- else if eq .Values.version "7.3.2.4" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:75573c9b7f80c5b69ace8bb6790c16f13f1ef415191b272fc485b83a021cca26
{{- else if eq .Values.version "7.3.2.3" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:7a85f789e252ad5703a00852bf7131b70ddf50a189a8f6d5e212f7cee744f470
{{- else if eq .Values.version "7.3.2.2" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:4ffb75ca25ac85a9a09b05f1501461f5b3e9cec251f103197264d2efe41edc05
{{- else if eq .Values.version "7.3.2.1" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:d7e20171c67883ed4cc92295ea61ae288317ee9711e194d69db0aafd1c6840dc
{{- else if eq .Values.version "7.3.2.0" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:6da0dc99e8b43887d980c4932c805bee9f2d504d8f8d1af983af020aee906838
{{- else if eq .Values.version "7.3.1.1" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:24b87bb8579f935a9a88a38639cf13f64f8c9035cb2e436a4c36981bed864a64
{{- else if eq .Values.version "7.3.1.0" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:7ec1e4038658a734eb3976cd927c556ce82e514ad1fa207f01c213f42a44dff0
{{- else if eq .Values.version "7.3.0.1" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:766fcb63209fd8022ec86868346d83dead8051d7b8050db9ce436d9a5a42a6f1
{{- else if eq .Values.version "7.3.0.0" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:0ebeea3c26290100c82b04d640bec0a672dd9675fc8b2877d03ac8952aabb9f8
{{- else if eq .Values.version "7.2.3.23" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:f37cd9f98f39e253bde36714df9bb1d9526bf919b255aa08ff466561d7724301
{{- else if eq .Values.version "7.2.3.22" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:bd9f231495c43f06db2f1cf7d00784b47dc219e4fd945fa303bb07fa602570a9
{{- else if eq .Values.version "7.2.3.21" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:b23297a83a5b6d7723bd29cf9b2e5211c3a769fa79defc56aed00e6d9418559e
{{- else if eq .Values.version "7.2.3.20" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:9b43f613c0c45d327a9204d8976a052782829a5f53dfbe2e4f89ae01818c5d14
{{- else if eq .Values.version "7.2.3.19" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:9f91f7b81027697d22b294697522cc1bb966b038a6c0b201aa2502fa404cc393
{{- else if eq .Values.version "7.2.3.18" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:d99af03a7ba50c7b8c773e021056a029960bc4c36fb860e5a90a3eaffb47f1fb
{{- else if eq .Values.version "7.2.3.17" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:e02b27bb510d9a312a70be6c5994ea3076ec66c6f3edfde159ec55c397cf09d4
{{- else if eq .Values.version "7.2.3.16" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:6c0c31ddc712277111eadc7e3edaeb78ace73d41b9301dbdfc4995da9be81110
{{- else if eq .Values.version "7.2.3.15" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:b5132e05971a0d3ab5248a3946aff879b3ad96531bdc413e5a66c5f41d69cd3f
{{- else if eq .Values.version "7.2.3.14" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:fe33f631a3727b031af679abcd5c5172eb90cf7c4a147780fbcd43f26c37191c
{{- else if eq .Values.version "7.2.3.13" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:e788f0829d2b8421239c4bbf4ac7bd15c4e2733a82d8191c3e292d5de0c13a8e
{{- else if eq .Values.version "7.2.3.12" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:8a95c3718749d5d1d750dcef33bfc3cfd5a975b7db6ab9b30e67572047df5c49
{{- else if eq .Values.version "7.2.3.11" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:641c574820f1fd3ba10a317beaedc3d5327168d0de2ae21e0f57ee9fb01c9a4b
{{- else if eq .Values.version "7.2.3.10" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:1ca959c9ba34133d097bd290d561c9295e61a1a007332e1bc7f489071c66fd56
{{- else if eq .Values.version "7.2.3.9" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:6bae52e1f35e1ddc6a6e0bcfa2da3cc5ed03088bf41b623194885f39e78c11bb
{{- else if eq .Values.version "7.2.3.8" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:9866e1963c4842dcc14f9c52d7347f9b071cd359d69fb9fb8689286ba7c09752
{{- else if eq .Values.version "7.2.3.7" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:926522dbc59854ad5c81a1c644d6fc90e6065cc7352a5bcc82203a66325292cc
{{- else if eq .Values.version "7.2.3.6" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:c0b1ff3efc9ad0e0565f83fcb812cf993b36595aa11b7d3e6869625ec0c7a315
{{- else if eq .Values.version "7.2.3.5" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:85561b8eced9e5054b8c8e4e7df15209ff271769e8b0fd66a0ba17c4c4f0970c
{{- else if eq .Values.version "7.2.3.4" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:c5cbb0440fa42740d52126301167bfa5eab1f3877a92c28f3198a6034e015f32
{{- else if eq .Values.version "7.2.3.3" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:7008bbe566a8876f2115344424d4408b8c250b41f6b203eeb4287c14a982b3ff
{{- else if eq .Values.version "7.2.3.2" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:a53dca44c65d3fa93db58cfcf110915e6ce823b6aaa473c19a2a9c0f0fe29a68
{{- else if eq .Values.version "7.2.3.1" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:a3391200008f31316999fc44e08bbd3cc66b31ed836d51033d1454e63d12d797
{{- else if eq .Values.version "7.2.3.0" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:0ff29870ab8929bbf1e3dfd2a4239f91ebce5c54fb1bf17ec08abb5b59419ed7
{{- else if eq .Values.version "7.2.2.1" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:38e5024e03668bba6dd03f1dfd7ae276ddc73c3473762c090ffd2cfad25b81d6
{{- else if eq .Values.version "7.2.2.0" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:7da498077339666f1e9d1ed3e165855586c0605612d306457012648eb3674b49
{{- else if eq .Values.version "7.2.1.2" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:93599e0b7abbbc0bda897edd13387c98a664be07d0cdc73f3418f46df3674564
{{- else if eq .Values.version "7.2.1.1" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:50f917e29166824bd454270b96486dd1002098c9e3a4ffe82d2efe142e21b070
{{- else if eq .Values.version "7.2.1.0" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:dbdf5434d4040bd42cd56e5cd59db8ff3368b54462c1427cee4eac97e46a7dd2
{{- else if eq .Values.version "7.2.0.2" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:c9b9ebe67e8c5c68554175563afc8c90b7fbf7cab41494401446c3302ff71d02
{{- else if eq .Values.version "7.2.0.1" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:f3d99000f9b7887b53c6a652f6168da6ab79da73a5a6ca73cf3d2c36274ef184
{{- else if eq .Values.version "7.2.0.0" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:4e6c314835ef19d448aaac92372211f9c9a7c0c397fa7c1d1a12eefd11f2b949
{{- else if eq .Values.version "7.1.2.30" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:092af108f668e5511d252be26e7ffb11419cd83fa6549205534cbb2ce37ea585
{{- else if eq .Values.version "7.1.2.29" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:5e2eecd880f92d2b4e29bb562979e09eff56ad7784ca22384ccbd4fe8d5c04ab
{{- else if eq .Values.version "7.1.2.28" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:d9d00c79239c35b03324d23fa63c03d94130693b816e14bdea9c72ce95e0eec2
{{- else if eq .Values.version "7.1.2.27" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:efa8e1070cd8b94621908a330e93c258de998df45694aeedd8ee17c2a365d93e
{{- else if eq .Values.version "7.1.2.26" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:e060b74ef3a562076da07be4c1b1fb7337102f1de73112b80c0226444ec91c0b
{{- else if eq .Values.version "7.1.2.25" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:76803872dc7269fa11110a189fc2baa17d584a2141304e954ed8b9ce83ad9bd9
{{- else if eq .Values.version "7.1.2.24" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:8c62a6d7fba78cf6058f06544e83ea54a8261779eb69e0386790af9b16d3b0bc
{{- else if eq .Values.version "7.1.2.23" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:0b1f8e914b38ba80cde3d88575522ea67751e561e0add0f9fdccb15704b62982
{{- else if eq .Values.version "7.1.2.22" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:384f876ad79ecc2170483d9853d67e660ecbc741bc50b865cbf7e1434de34459
{{- else if eq .Values.version "7.1.2.21" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:aa1854affeba3eb93461b3970193cea5aea84441ed1d350e8fcb5e71c3cf94a9
{{- else if eq .Values.version "7.1.2.20" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:77dcec4d661d137dc7784dd95adcad4b8b0d3fbba4e0e5aa6ecaaf10b016eabb
{{- else if eq .Values.version "7.1.2.19" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:6c459452abfdeade91e66f55f0f999cbd26925644ed8523dfb91f2a1894c4236
{{- else if eq .Values.version "7.1.2.18" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:e21ab63cf4d7f7d21841183d786876f7f7280b9a42432ad4cfbd4e7d0f5d5de8
{{- else if eq .Values.version "7.1.2.17" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:8623996de1af5b26113a251cf6023dbc3fdd97cd895dae2f32cb8245439701ce
{{- else if eq .Values.version "7.1.2.16" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:90c596d316bc7baa2296be703fef5e872d844a3ef964aeaac67cbf4d79cd819a
{{- else if eq .Values.version "7.1.2.15" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:2f5b9dab8943e7d98edb35d51dc5d562e41be560964b008a337643d3200641bf
{{- else if eq .Values.version "7.1.2.14" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:3b0c5b2f60c4dd963f5e7a678c4fa522a19b342350c6715024cb5130d2f70a55
{{- else if eq .Values.version "7.1.2.13" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:5d2b69a5205982f08c7d081db33139dab93f0b85ce1d65ca996d10508eb150b4
{{- else if eq .Values.version "7.1.2.12" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:ea8803e0aac2e37c8cc23496b46c54996bf12f9cef7247c155d03ef0a0fa7028
{{- else if eq .Values.version "7.1.2.11" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:cb26baf0f2ec452ae5c8b6a73ba6f25f2dfd5e90bc73ffd9261bd9218ab0cb04
{{- else if eq .Values.version "7.1.2.10" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:2a227e3f3092866599191f0fa707cb1bebc57d176384bc21f2e592bcd96adb01
{{- else if eq .Values.version "7.1.2.9" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:470592554ea829a994c3f22c878f49ab223519ee196f020390d35b6303ac0ce4
{{- else if eq .Values.version "7.1.2.8" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:947d70c0d38ddf35810e02f660cb7a8a24fd1c539ba17dd24cd8db539e38faae
{{- else if eq .Values.version "7.1.2.7" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:bc7b2584224998fd18dd7c40e1527ba3ba84fbbd4049aa626766e1f78cc59ddb
{{- else if eq .Values.version "7.1.2.6" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:7a130b45a6e7b10596ab96fc4e6fd7b8df492efee5c72ddc2ad7fc016e973523
{{- else if eq .Values.version "7.1.2.5" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:2bf4e65b85673f77cdcddd6141d96f1b3bdafee7fd08a78c80a697f09d54bd6f
{{- else if eq .Values.version "7.1.2.1" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:69a3250d66ba49d167b684b18912ec66a3cb3a3296febe301e8b98cbb41be550
{{- else if eq .Values.version "7.1.2.0" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:a3b316cbc716ec7fa639b946791a1a93f6ce5fc222cebf4c32bdbaba60fdd712
{{- else if eq .Values.version "7.1.1.2" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:8891ada27a80651425bb46d5c8b1e3401297480e23f7b9ddd24f1358d4c98ac1
{{- else if eq .Values.version "7.1.1.1" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:5bb36c060520dab8d639539a305525caffcba4a9c7e34c60110269a32bcecd33
{{- else if eq .Values.version "7.1.1.0" -}}
  {{ $imagePathName }}/ibm-ucdr@sha256:1a521134abc9496c0fe89534ac3cec48d34bb097f485d13c29a3b4f6c91c4849
{{- else if eq .Values.version "7.1.0.3" -}}
  {{ $imagePathName }}/ibm-ucdr:7.1.0.3.1069281
{{- else -}}
  {{ .Values.version }}
{{- end -}}
{{- end -}}
