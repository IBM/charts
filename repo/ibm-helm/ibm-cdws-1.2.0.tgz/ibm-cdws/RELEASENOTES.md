# Prerequisites

Please refer prerequisites section from [README.md](README.md)

# Documentation

Please refer to [README.md](README.md) provided with chart for detailed installation instruction.

# Version History

| Chart | Date         | Kubernetes Required | OpenShift Required       | Image(s) Supported                                    | Details            |
| ----- | ------------ | ------------------- | ------------------------ | ----------------------------------------------------- | ------------------ | 
| 1.2.0 | Oct 30, 2026 | >= 1.33.0           | >= 4.18                  | cdws:6.5.0.0_iFix00-2026-10-09                        | CDWS 6.5.0.0       |

`Note: The images listed here are minimum supported container image for the respective helm chart version.`
