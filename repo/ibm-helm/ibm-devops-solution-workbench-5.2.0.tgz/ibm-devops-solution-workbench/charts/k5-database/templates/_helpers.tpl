{{/* vim: set filetype=mustache: */}}

{{/*
Expand the name of the chart.
*/}}
{{- define "k5-database.name-postgresql" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}-postgresql
{{- end -}}

{{- define "k5-database.name-ferretdb" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}-ferretdb
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
*/}}
{{- define "k5-database.fullname-postgresql" -}}
{{- $name := .Chart.Name -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}-postgresql
{{- end -}}

{{- define "k5-database.fullname-ferretdb" -}}
{{- $name := .Chart.Name -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}-ferretdb
{{- end -}}

{{/*
Create the name of the FerretDB TLS service cert secret.
*/}}
{{- define "k5-database.service-cert.name" -}}
{{- printf "%s-service-cert" .Chart.Name | quote -}}
{{- end -}}

{{/*
Build the name of the FerretDB CA config map (OpenShift service CA injection).
*/}}
{{- define "k5-database-ca-configmap.name" -}}
{{- printf "%s-ferretdb-ca-configmap" .Chart.Name -}}
{{- end -}}

{{/*
FerretDB MongoDB connection host (cluster DNS).
*/}}
{{- define "k5-database.ferretdb.host" -}}
{{- printf "%s.%s.svc.cluster.local" (include "k5-database.name-ferretdb" .) .Release.Namespace -}}
{{- end -}}


{{/*
Build an image from given values
*/}}
{{- define "k5-database.image.builder" -}}
{{- $registry := .values.global.image.registry -}}
{{- $repository := .image.repository -}}
{{ if .values.global.imageRegistry }}
{{- $registry = .values.global.imageRegistry -}}
{{- $repository = printf "%s-%s" .values.global.image.prefix .image.repository -}}
{{- else if  .values.global.image.privateRegistry }}
{{- $registry = .values.global.image.privateRegistry -}}
{{- $repository = printf "%s-%s" .values.global.image.prefix .image.repository -}}
{{- end -}}
{{ if .image.digest }}
{{- printf "%s/%s@%s" $registry $repository .image.digest -}}
{{ else }}
{{- printf "%s/%s:%s" $registry $repository .image.tag -}}
{{- end -}}
{{- end -}}

{{- define "k5-database.connectionString" -}}
{{- $host := include "k5-database.ferretdb.host" . -}}
{{- $port := .Values.ferretdb.port | toString -}}
{{- $password := "" -}}
{{- if .Values.postgres.userPw -}}
{{- $password = .Values.postgres.userPw -}}
{{- else if .Values.postgres.adminPw -}}
{{- $password = .Values.postgres.adminPw -}}
{{- else -}}
{{- $password = print (default .Release.Name .Values.global.passwordSeed) | sha256sum | urlquery -}}
{{- end -}}
{{- $uri := printf "mongodb://%s:%s@%s:%s/" .Values.postgres.user $password $host $port -}}
{{- if (not (.Capabilities.APIVersions.Has "getambassador.io/v2")) -}}
{{- printf "%s?ssl=true" $uri -}}
{{- else -}}
{{- $uri -}}
{{- end -}}
{{- end -}}

