## Renders Directory

Once you render your helm chart, you will find the rendered files in this directory.
