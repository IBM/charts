{{- /*
Chart specific config file for SCH (Shared Configurable Helpers)
_sch-chart-config.tpl is a config file for the chart to specify additional
values and/or override values defined in the sch/_config.tpl file.

*/ -}}

{{- /*
"sch.chart.config.values" contains the chart specific values used to override or provide
additional configuration values used by the Shared Configurable Helpers.
*/ -}}
{{- define "ibm-cdws.sch.chart.config.values" -}}
sch:
  chart:
    appName: "ibm-cdws"
    metering:
    {{- if eq (toString .Values.licenseType | lower) "non-prod"  }}
      productName: "IBM Sterling Connect Direct Premium Ed Non Prod Certified Container"
      productID: "54f9be5388f94bd4a7fc1c56ca59a6bd"
    {{- else }}
      productName: "IBM Sterling Connect Direct Premium Ed Certified Container"
      productID: "0e99fe73c7ae4b799e11d00a9bbf0db0"
    {{- end }}
      productVersion: "v6.3"
      productMetric: "VIRTUAL_PROCESSOR_CORE"
      productChargedContainers: "All"
    podSecurityContext:
      runAsNonRoot: true
      supplementalGroups: {{ .Values.storageSecurity.supplementalGroups | default 65534 }}
      fsGroup: {{ .Values.storageSecurity.fsGroup }}
      runAsUser: {{ .Values.storageSecurity.runAsUser }}
      runAsGroup:  {{ .Values.storageSecurity.runAsGroup }}
      seccompProfile:
        type: {{ .Values.secComp.type | quote }}
        {{- if ne .Values.secComp.type "RuntimeDefault" }}
        localhostProfile: {{ .Values.secComp.profile | quote }}
        {{- end }}
    containerSecurityContext:
      privileged: false
      runAsUser: {{  .Values.storageSecurity.runAsUser }}
      readOnlyRootFilesystem: false
      allowPrivilegeEscalation: false
      capabilities:
        drop: [ "ALL" ]
        add: []
{{- end -}}
