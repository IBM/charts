#!/bin/bash

# --------- Namespace setup ---------
NAMESPACE="${1:-backup}"

# --------- Check oc, curl and jq, install if missing ---------
install_package() {
    local pkg="$1"
    echo "WARNING: $pkg not found, attempting to install..."
    if command -v apt-get >/dev/null 2>&1; then
        sudo apt-get update && sudo apt-get install -y "$pkg"
        if [ $? -ne 0 ]; then
            echo "ERROR: Failed to install $pkg using apt-get." >&2
            exit 1
        fi
    elif command -v yum >/dev/null 2>&1; then
        sudo yum install -y "$pkg"
        if [ $? -ne 0 ]; then
            echo "ERROR: Failed to install $pkg using yum." >&2
            exit 1
        fi
    else
        echo "ERROR: No supported package manager found to install $pkg." >&2
        exit 1
    fi
    echo "INFO: $pkg installed successfully."
}

if ! command -v oc >/dev/null 2>&1; then
    echo "ERROR: 'oc' CLI not found. Please install OpenShift CLI before running this script."
    exit 1
else
    echo "INFO: oc CLI is already installed."
fi

if ! command -v curl >/dev/null 2>&1; then
    install_package curl
else
    echo "INFO: curl is already installed."
fi

if ! command -v jq >/dev/null 2>&1; then
    install_package jq
else
    echo "INFO: jq is already installed."
fi

# --------- Helper: check curl response (timeout 3s, any HTTP response except 000 is success) ---------
check_curl() {
    local url="$1"
    http_code=$(curl -s -o /dev/null -w "%{http_code}" --max-time 3 "$url")
    if [[ "$http_code" == "000" ]]; then
        return 1
    fi
    return 0
}

# --------- Capture MinIO service name and Cluster IP ---------
SVC_JSON=$(oc get svc -n "$NAMESPACE" -o json 2>/dev/null)
if [ $? -ne 0 ] || [[ -z "$SVC_JSON" ]]; then
    echo "ERROR: Failed to retrieve services or namespace '$NAMESPACE' does not exist or is inaccessible."
    exit 1
fi

MINIO_SERVICE=$(echo "$SVC_JSON" | jq -r '.items[] | select(.metadata.name | test("minio")) | .metadata.name' | head -n1)
CLUSTER_IP=$(echo "$SVC_JSON" | jq -r --arg svc "$MINIO_SERVICE" '.items[] | select(.metadata.name == $svc) | .spec.clusterIP')

if [[ -z "$MINIO_SERVICE" || "$MINIO_SERVICE" == "null" ]]; then
    echo "ERROR: MinIO service not found in namespace '$NAMESPACE'."
    exit 1
fi

if [[ -z "$CLUSTER_IP" || "$CLUSTER_IP" == "null" ]]; then
    echo "WARNING: MinIO service '$MINIO_SERVICE' has no Cluster IP assigned."
else
    echo "INFO: MinIO Service Name: $MINIO_SERVICE"
    echo "INFO: MinIO Cluster IP: $CLUSTER_IP"
fi

# Function to update /etc/hosts for MinIO service FQDN (may require sudo)
update_etc_hosts() {
    local ip="$1"
    local fqdn="$2"
    if grep -qF "$fqdn" /etc/hosts; then
        sudo sed -i "/$fqdn/d" /etc/hosts
        if [ $? -ne 0 ]; then
            echo "ERROR: Failed to remove existing entry for $fqdn from /etc/hosts."
            return 1
        fi
        echo "INFO: Removed existing /etc/hosts entry for $fqdn."
    fi

    echo "$ip $fqdn" | sudo tee -a /etc/hosts > /dev/null
    if [ $? -ne 0 ]; then
        echo "ERROR: Failed to add new entry to /etc/hosts."
        return 1
    fi

    echo "INFO: Added /etc/hosts entry: $ip $fqdn"
}

# --------- Check connectivity on Cluster IP ports 9000 and 32722 ---------
CLUSTER_IPS_PORTS=(9000 32722)
CLUSTER_WORKING_URL=""
CLUSTER_WORKING_PORT=""

echo "INFO: Checking connectivity to MinIO service at Cluster IP ($CLUSTER_IP)..."

for port in "${CLUSTER_IPS_PORTS[@]}"; do
    url="http://$CLUSTER_IP:$port"
    echo "INFO: Checking connectivity to Cluster IP $CLUSTER_IP on port $port..."
    if check_curl "$url"; then
        CLUSTER_WORKING_URL="$url"
        CLUSTER_WORKING_PORT="$port"
        echo "INFO: Connectivity established at $url"
        break
    else
        echo "WARNING: No response from Cluster IP $CLUSTER_IP on port $port."
    fi
done

if [[ -n "$CLUSTER_WORKING_URL" ]]; then
    # Cluster IP reachable on one of the ports
    update_etc_hosts "$CLUSTER_IP" "$MINIO_SERVICE.$NAMESPACE.svc.cluster.local" || {
        echo "WARNING: Could not update /etc/hosts file properly."
    }
else
    echo "WARNING: Cluster IP is NOT reachable on ports 9000 or 32722."

    # --------- Get External IP or Hostname of MinIO service ---------
    EXTERNAL_IP=$(echo "$SVC_JSON" | jq -r --arg svc "$MINIO_SERVICE" \
        '.items[] | select(.metadata.name == $svc) | .status.loadBalancer.ingress[0].ip // .status.loadBalancer.ingress[0].hostname // empty')

    if [[ -z "$EXTERNAL_IP" ]]; then
        echo "ERROR: No external IP or hostname found for MinIO service."
        exit 2
    fi

    EXTERNAL_IPS_PORTS=(9000 32722)
    EXTERNAL_WORKING_URL=""
    EXTERNAL_WORKING_PORT=""

    # --------- Check connectivity on External IP with ports 9000 and 32722 ---------
    for port in "${EXTERNAL_IPS_PORTS[@]}"; do
        url="http://$EXTERNAL_IP:$port"
        echo "INFO: Checking connectivity to external IP $EXTERNAL_IP on port $port..."
        if check_curl "$url"; then
            EXTERNAL_WORKING_URL="$url"
            EXTERNAL_WORKING_PORT="$port"
            echo "INFO: Connectivity established at $url"
            break
        else
            echo "WARNING: No response from external IP $EXTERNAL_IP on port $port."
        fi
    done

    if [[ -z "$EXTERNAL_WORKING_URL" ]]; then
        echo "ERROR: No reachable endpoint found on external IP for ports 9000 or 32722."
        echo "ERROR: Please verify network connectivity, firewall rules, and service availability."
        exit 3
    fi

    # Add external IP to /etc/hosts with service FQDN since cluster IP was unreachable but external IP is reachable
    echo "INFO: Adding external IP $EXTERNAL_IP to /etc/hosts for $MINIO_SERVICE.$NAMESPACE.svc.cluster.local"
    update_etc_hosts "$EXTERNAL_IP" "$MINIO_SERVICE.$NAMESPACE.svc.cluster.local" || {
        echo "WARNING: Could not update /etc/hosts file properly with external IP."
    }
fi

# --------- Check Velero client installation and install if missing ---------
if ! command -v velero &> /dev/null; then
    echo "WARNING: Velero client not found. Installing Velero client v1.15.2..."

    TMP_DIR=$(mktemp -d)

    curl -L --fail -o "$TMP_DIR/velero-v1.15.2-linux-amd64.tar.gz" https://github.com/vmware-tanzu/velero/releases/download/v1.15.2/velero-v1.15.2-linux-amd64.tar.gz

    if [ $? -ne 0 ]; then
        echo "ERROR: Failed to download Velero client archive."
        rm -rf "$TMP_DIR"
        exit 5
    fi

    tar -xf "$TMP_DIR/velero-v1.15.2-linux-amd64.tar.gz" -C "$TMP_DIR"

    sudo mv "$TMP_DIR"/velero-v1.15.2-linux-amd64/velero /usr/local/bin/

    if [ $? -ne 0 ]; then
        echo "ERROR: Failed to move Velero binary to /usr/local/bin/"
        rm -rf "$TMP_DIR"
        exit 6
    fi

    rm -rf "$TMP_DIR"

    echo "INFO: Velero client installed successfully."
else
    echo "INFO: Velero client is already installed."
fi

echo "INFO: Velero client version:"
velero version -n "$NAMESPACE"

echo "INFO: Script execution completed successfully."

exit 0
