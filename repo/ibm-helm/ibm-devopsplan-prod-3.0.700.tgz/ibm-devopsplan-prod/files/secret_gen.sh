#!/bin/bash
set -euo pipefail

# =============================================================================
# HCL Velero STS Credential Management Script
# Production-ready script for generating and deploying Velero credentials
# =============================================================================

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration file path
CONFIG_FILE="$HOME/.velero_config"

# Fixed configuration
DURATION=3600  # Fixed 1 hour duration
SECRET_NAME="credentials-velero"  # Fixed secret name

# Logging function
log() {
    echo -e "${BLUE}[$(date +'%Y-%m-%d %H:%M:%S')]${NC} $1"
}

error() {
    echo -e "${RED}[ERROR]${NC} $1" >&2
}

success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

# Function to save configuration
save_config() {
    cat > "$CONFIG_FILE" <<EOF
NAMESPACE="$1"
AWS_ACCESS_KEY_ID="$2"
AWS_SECRET_ACCESS_KEY="$3"
ROLE_ARN="$4"
LAST_UPDATED="$(date)"
EOF
    chmod 600 "$CONFIG_FILE"
    success "Configuration saved for future use"
}

# Function to load configuration
load_config() {
    if [[ -f "$CONFIG_FILE" ]]; then
        source "$CONFIG_FILE"
        return 0
    else
        return 1
    fi
}

# Function to display saved configuration (masked)
display_saved_config() {
    echo
    echo "=================================================="
    echo -e "${GREEN}📋 Previously Saved Configuration:${NC}"
    echo "=================================================="
    echo -e "${BLUE}Namespace:${NC} $NAMESPACE"
    echo -e "${BLUE}AWS Access Key ID:${NC} ${AWS_ACCESS_KEY_ID:0:8}***"
    echo -e "${BLUE}AWS Secret Access Key:${NC} ***"
    echo -e "${BLUE}Role ARN:${NC} $ROLE_ARN"
    echo -e "${BLUE}Last Updated:${NC} $LAST_UPDATED"
    echo -e "${BLUE}Session Duration:${NC} ${DURATION}s (fixed)"
    echo -e "${BLUE}Secret Name:${NC} $SECRET_NAME (fixed)"
    echo "=================================================="
}

# Function to get user input
get_user_input() {
    echo -e "${BLUE}🔧 HCL Velero STS Credential Generator${NC}"
    echo "=================================================="

    # Namespace input
    read -p "Enter Kubernetes namespace for Velero: " NAMESPACE
    if [[ -z "$NAMESPACE" ]]; then
        error "Namespace cannot be empty"
        exit 1
    fi

    # AWS Access Key ID input
    read -p "Enter AWS Access Key ID: " AWS_ACCESS_KEY_ID
    if [[ -z "$AWS_ACCESS_KEY_ID" ]]; then
        error "AWS Access Key ID cannot be empty"
        exit 1
    fi

    # AWS Secret Access Key input (hidden)
    read -s -p "Enter AWS Secret Access Key: " AWS_SECRET_ACCESS_KEY
    echo
    if [[ -z "$AWS_SECRET_ACCESS_KEY" ]]; then
        error "AWS Secret Access Key cannot be empty"
        exit 1
    fi

    # Role ARN input
    read -p "Enter IAM Role ARN: " ROLE_ARN
    if [[ -z "$ROLE_ARN" ]]; then
        error "Role ARN cannot be empty"
        exit 1
    fi

    echo
    log "Fixed Settings:"
    echo -e "${BLUE}Session Duration:${NC} ${DURATION}s (1 hour)"
    echo -e "${BLUE}Secret Name:${NC} $SECRET_NAME"
}

# Function to cleanup credential files - improved version
cleanup_credential_files() {
    log "🧹 Cleaning up all credential files..."
    
    local files_found=0
    
    # Clean up timestamped credential files
    for file in ./credentials-velero-* ./credentials-velero; do
        if [[ -f "$file" ]] && [[ "$file" != "./credentials-velero-*" ]]; then
            files_found=1
            log "Removing: $(basename "$file")"
            
            # Try secure deletion first, fallback to regular rm
            if command -v shred >/dev/null 2>&1; then
                shred -vfz -n 3 "$file" >/dev/null 2>&1 && success "Securely deleted: $(basename "$file")" || {
                    rm -f "$file" && success "Deleted: $(basename "$file")"
                }
            else
                rm -f "$file" && success "Deleted: $(basename "$file")"
            fi
        fi
    done
    
    if [[ $files_found -eq 0 ]]; then
        log "No credential files found to clean up"
    else
        success "All credential files cleaned up"
    fi
}

# Trap to ensure cleanup on script exit
trap cleanup_credential_files EXIT

# =============================================================================
# CONFIGURATION MANAGEMENT
# =============================================================================

echo -e "${BLUE}🔧 HCL Velero STS Credential Generator${NC}"
echo "=================================================="

# Check if configuration exists
if load_config; then
    display_saved_config
    echo
    read -p "Do you want to use the saved configuration? (Y/n): " USE_SAVED
    
    if [[ "$USE_SAVED" =~ ^[Nn]$ ]]; then
        echo
        warning "Getting new configuration..."
        get_user_input
        
        # Ask if user wants to save new configuration
        echo
        read -p "Do you want to save this new configuration for future use? (Y/n): " SAVE_NEW
        if [[ ! "$SAVE_NEW" =~ ^[Nn]$ ]]; then
            save_config "$NAMESPACE" "$AWS_ACCESS_KEY_ID" "$AWS_SECRET_ACCESS_KEY" "$ROLE_ARN"
        fi
    else
        success "Using saved configuration"
    fi
else
    log "No saved configuration found. Please provide details:"
    echo
    get_user_input
    
    # Ask if user wants to save configuration
    echo
    read -p "Do you want to save this configuration for future use? (Y/n): " SAVE_CONFIG
    if [[ ! "$SAVE_CONFIG" =~ ^[Nn]$ ]]; then
        save_config "$NAMESPACE" "$AWS_ACCESS_KEY_ID" "$AWS_SECRET_ACCESS_KEY" "$ROLE_ARN"
    fi
fi

# =============================================================================
# VALIDATION AND PREREQUISITES
# =============================================================================

echo
log "🔍 Validating prerequisites..."

# Check required tools
for tool in aws kubectl jq; do
    if ! command -v $tool &> /dev/null; then
        error "$tool is not installed or not in PATH"
        exit 1
    fi
done

# Validate kubectl context and namespace
if ! kubectl cluster-info &> /dev/null; then
    error "kubectl is not configured or cluster is not accessible"
    exit 1
fi

# Check if namespace exists, create if it doesn't
if ! kubectl get namespace "$NAMESPACE" &> /dev/null; then
    warning "Namespace '$NAMESPACE' does not exist"
    read -p "Do you want to create it? (Y/n): " CREATE_NS
    if [[ ! "$CREATE_NS" =~ ^[Nn]$ ]]; then
        kubectl create namespace "$NAMESPACE"
        success "Namespace '$NAMESPACE' created"
    else
        error "Namespace '$NAMESPACE' is required"
        exit 1
    fi
fi

# =============================================================================
# STS ASSUME ROLE
# =============================================================================

echo
log "🔄 Starting STS assume role process..."

# Generate unique session name
SESSION_NAME="velero-hcl-$(date +%s)-$$"

log "Service User → Assuming Velero Role (${DURATION}s)..."
log "Role ARN: $ROLE_ARN"
log "Session Name: $SESSION_NAME"

# Assume role with error handling
if ! TEMP_CREDS=$(AWS_ACCESS_KEY_ID="$AWS_ACCESS_KEY_ID" \
                  AWS_SECRET_ACCESS_KEY="$AWS_SECRET_ACCESS_KEY" \
                  aws sts assume-role \
                  --role-arn "$ROLE_ARN" \
                  --role-session-name "$SESSION_NAME" \
                  --duration-seconds "$DURATION" \
                  --output json 2>/dev/null); then
    error "Failed to assume role. Please check your credentials and role ARN"
    exit 1
fi

# Extract credentials
ACCESS_KEY=$(echo "$TEMP_CREDS" | jq -r '.Credentials.AccessKeyId')
SECRET_KEY=$(echo "$TEMP_CREDS" | jq -r '.Credentials.SecretAccessKey')
SESSION_TOKEN=$(echo "$TEMP_CREDS" | jq -r '.Credentials.SessionToken')
EXPIRATION=$(echo "$TEMP_CREDS" | jq -r '.Credentials.Expiration')

# Validate extracted credentials
if [[ "$ACCESS_KEY" == "null" ]] || [[ "$SECRET_KEY" == "null" ]] || [[ "$SESSION_TOKEN" == "null" ]]; then
    error "Failed to extract credentials from STS response"
    exit 1
fi

success "STS credentials obtained successfully"
log "Credentials valid until: $EXPIRATION"

# =============================================================================
# KUBERNETES SECRET MANAGEMENT (Direct approach without file)
# =============================================================================

echo
log "🔧 Managing Kubernetes secret..."

# Check if secret exists and delete it
if kubectl get secret "$SECRET_NAME" -n "$NAMESPACE" &> /dev/null; then
    warning "Secret '$SECRET_NAME' already exists in namespace '$NAMESPACE'"
    log "Deleting existing secret..."
    if kubectl delete secret "$SECRET_NAME" -n "$NAMESPACE"; then
        success "Existing secret deleted"
    else
        error "Failed to delete existing secret"
        exit 1
    fi
fi

# Create credentials content in memory
CREDS_CONTENT="[default]
aws_access_key_id=$ACCESS_KEY
aws_secret_access_key=$SECRET_KEY
aws_session_token=$SESSION_TOKEN"

# Create new secret directly from stdin (no file needed)
log "Creating new secret '$SECRET_NAME' in namespace '$NAMESPACE'..."
if echo "$CREDS_CONTENT" | kubectl create secret generic "$SECRET_NAME" -n "$NAMESPACE" \
    --from-file=cloud=/dev/stdin; then
    success "Secret '$SECRET_NAME' created successfully"
else
    error "Failed to create secret"
    exit 1
fi

# Verify secret creation
if kubectl get secret "$SECRET_NAME" -n "$NAMESPACE" &> /dev/null; then
    success "Secret verification passed"
else
    error "Secret verification failed"
    exit 1
fi

# Clear sensitive variables
unset ACCESS_KEY SECRET_KEY SESSION_TOKEN CREDS_CONTENT TEMP_CREDS
unset AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY

# =============================================================================
# FINAL SUMMARY
# =============================================================================

echo
echo "=================================================="
success "🎉 Velero STS Credential Deployment Complete!"
echo "=================================================="
echo -e "${GREEN}✅ Role ARN:${NC} $ROLE_ARN"
echo -e "${GREEN}✅ Namespace:${NC} $NAMESPACE"
echo -e "${GREEN}✅ Secret Name:${NC} $SECRET_NAME (fixed)"
echo -e "${GREEN}✅ Session Duration:${NC} ${DURATION}s (fixed - 1 hour)"
echo -e "${GREEN}✅ Valid Until:${NC} $EXPIRATION"
echo -e "${GREEN}✅ Status:${NC} Ready for Helm deployment"
echo

echo
log "🚀 Ready for Velero deployment!"
echo -e "${BLUE}Next steps:${NC}"
echo "1. Deploy Velero using Helm with the created secret"
echo "2. Monitor the credential expiration time: $EXPIRATION"
echo "3. Re-run this script before expiration for credential renewal"
echo -e "${BLUE}Configuration Management:${NC}"
echo "- Configuration saved in: $CONFIG_FILE"
echo "- Run script again to reuse saved configuration"
echo "- Choose 'n' when prompted to modify saved details"
echo
