{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "ccm.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

Set devopsplan name.
*/}}
{{- define "plan.fullname" -}}
devopsplan
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "ccm.fullname" -}}
{{- if .Values.global.fullnameOverride }}
{{- .Values.global.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{- define "ccm.subchart.fullname" -}}
{{- if .Values.global.fullnameOverride }}
{{- .Values.global.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Values.parent.chartName .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "ccm.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "ccm.labels" -}}
helm.sh/chart: {{ include "ccm.chart" . }}
{{ include "ccm.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "ccm.selectorLabels" -}}
app.kubernetes.io/name: {{ include "ccm.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "ccm.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "ccm.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Image repository helper
Usage: {{ include "ccm.ccmImageRepo" . }}
*/}}
{{- define "ccm.ccmImageRepo" -}}
{{- $imagePrefix := "/devops-plan/" -}}
{{- if and (eq .Values.global.imageRegistry "hclcr.io") (eq .Values.global.devopsPlanBrand "HCL") -}}
  {{- printf "hclcr.io%s" $imagePrefix -}}
{{- else if and (eq .Values.global.imageRegistry "cp.icr.io/cp") (eq .Values.global.devopsPlanBrand "IBM") -}}
  {{- printf "cp.icr.io/cp%s" $imagePrefix -}}
{{- else if and (eq .Values.global.imageRegistry "cp.stg.icr.io/cp") (eq .Values.global.devopsPlanBrand "IBM") -}}
  {{- printf "cp.stg.icr.io/cp%s" $imagePrefix -}}
{{- else if eq .Values.global.imageRegistry "gcr.io/blackjack-209019" -}}
  {{- printf "gcr.io/blackjack-209019/services%s" $imagePrefix -}}
{{- else if eq .Values.global.imageRegistry "compass-docker-dev-local.us-artifactory1.nonprod.hclpnp.com" -}}
  {{- printf "compass-docker-dev-local.us-artifactory1.nonprod.hclpnp.com%s" $imagePrefix -}}
{{- else if .Values.global.imageRegistry -}}
  {{- printf "%s/" (.Values.global.imageRegistry | trimSuffix "/") -}}
{{- end -}}
{{- end -}}

{{- define "externalImagePrefix" -}}
  {{- if .Values.global.externalImageRegistry -}}
    {{- .Values.global.externalImageRegistry | trimSuffix "/" -}}/
  {{- end -}}
{{- end -}}

{{- define "ccm.app-version" -}}
{{- if eq .Values.global.devopsPlanBrand "HCL" -}}
3.0.7
{{- else if eq .Values.global.devopsPlanBrand "IBM" -}}
3.0.7
{{- end -}}
{{- end -}}

{{- define "ccm.app-folder" -}}
{{- if eq .Values.global.devopsPlanBrand "HCL" -}}
/opt/devops/plan/devopsplan-rest-server-distribution
{{- else if eq .Values.global.devopsPlanBrand "IBM" -}}
/opt/devops/plan/devopsplan-rest-server-distribution
{{- else -}}
/opt/devops/plan/devopsplan-rest-server-distribution
{{- end -}}
{{- end -}}

{{- define "analytics.app-folder" -}}
{{- if eq .Values.global.devopsPlanBrand "HCL" -}}
/opt/devops/plan/analytics-rest-server-distribution
{{- else if eq .Values.global.devopsPlanBrand "IBM" -}}
/opt/devops/plan/analytics-rest-server-distribution
{{- else -}}
/opt/devops/plan/analytics-rest-server-distribution
{{- end -}}
{{- end -}}

{{- define "mychart.secretHasCA" -}}
{{- $caCertExists := "false" }}
{{- if (.Values.global.certSecretName) }}
  {{- $secret := lookup "v1" "Secret" .Release.Namespace .Values.global.certSecretName }}
  {{- if and $secret (index $secret.data "ca.crt") }}
    {{- $caCertExists = "true" }}
  {{- end }}
{{- else if (.Values.global.platform.enabled) (.Values.global.ibmCertSecretName) }}
  {{- $ibmSecret := lookup "v1" "Secret" .Release.Namespace .Values.global.ibmCertSecretName }}
  {{- if and $ibmSecret (index $ibmSecret.data "ca.crt") }}
    {{- $caCertExists = "true" }}
  {{- end }}
{{- else if and (.Values.global.platform.enabled) (.Values.global.hclCertSecretName) }}
  {{- $hclSecret := lookup "v1" "Secret" .Release.Namespace .Values.global.hclCertSecretName }}
  {{- if and $hclSecret (index $hclSecret.data "ca.crt") }}
    {{- $caCertExists = "true" }}
  {{- end }}
{{- end }}
{{- $caCertExists -}}
{{- end }}

{{- define "mychart.caCertExists" -}}
{{- $caCertExists := "false" }}
{{- if and (.Values.global.platform.enabled) (.Values.global.privateCaBundleSecretName) }}
  {{- $secret := lookup "v1" "Secret" .Release.Namespace .Values.global.privateCaBundleSecretName }}
  {{- if and $secret (index $secret.data "ca.crt") }}
    {{- $caCertExists = "true" }}
  {{- end }}
{{- else if and (.Values.global.platform.enabled) (.Values.global.ibmCertSecretName) }}
  {{- $ibmSecret := lookup "v1" "Secret" .Release.Namespace .Values.global.ibmCertSecretName }}
  {{- if and $ibmSecret (index $ibmSecret.data "ca.crt") }}
    {{- $caCertExists = "true" }}
  {{- end }}
{{- else if and (.Values.global.platform.enabled) (.Values.global.hclCertSecretName) }}
  {{- $hclSecret := lookup "v1" "Secret" .Release.Namespace .Values.global.hclCertSecretName }}
  {{- if and $hclSecret (index $hclSecret.data "ca.crt") }}
    {{- $caCertExists = "true" }}
  {{- end }}
{{- end }}
{{- $caCertExists -}}
{{- end }}

{{- define "mychart.privateCaCertExists" -}}
{{- $exists := false }}
{{- if .Values.global.privateCaBundleSecretName }}
  {{- $secret := lookup "v1" "Secret" .Release.Namespace .Values.global.privateCaBundleSecretName }}
  {{- if and $secret (index $secret.data "ca.crt") }}
    {{- $exists = true }}
  {{- end }}
{{- end }}
{{- $exists | quote -}}
{{- end }}

Generate a password for postgresql
*/}}
{{- define "devops-platform.postgresql-password" -}}
{{- $context := .context -}}
{{- $pwseed := .passwordSeed -}}
{{- $cname := .componentName -}}
{{- $epwd := .existingPwd -}}
{{- with $context -}}
{{- if $epwd }}
{{- print $epwd }}
{{- else }}
{{- printf "%s%s-%s" (default .Release.Name $pwseed) $cname "postgresql" | sha256sum }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Generate a base64 password for postgresql
*/}}
{{- define "devops-platform.postgresql-password-b64" -}}
{{ printf "  %s: %s" "postgresql-password" ( include "devops-platform.postgresql-password" . | b64enc | quote )}}
{{- end }}

{{- define "ccm.url" -}}
{{- if .Values.global.domain }}
{{- if .Values.global.platform.enabled }}
https://{{ .Values.global.domain }}{{ .Values.ingress.path }}
{{- else }}
https://{{ include "ccm.fullname" . }}{{ .Values.ingress.suffix }}.{{ .Values.global.domain }}
{{- end }}
{{- else if .Values.global.sofySolutionContext }}
https://{{ include "ccm.fullname" . }}{{ .Values.ingress.suffix }}.{{- include "sofy-domain.configMapKeyRef"}}
{{- else if ( .Values.service.urlMapping ) }}
{{ .Values.service.urlMapping }}
{- else if and (or (eq "NodePort" .Values.service.type ) (eq "LoadBalancer" .Values.service.type )) (.Values.service.exposePort )) }}
{{- if .Values.service.ipAddress }}
"https://{{ .Values.service.ipAddress }}:{{ .Values.service.exposePort }}"
{{- else }}
"https://{{ .Values.keycloak.service.ipAddress }}:{{ .Values.service.exposePort }}"
{{- end }}
{{- else if .Values.service.urlMapping }}
"{{ .Values.service.urlMapping }}"
{{- end }}
{{- end }}

{{- define "dashboard.url" -}}
{{- if .Values.global.domain }}
{{- if .Values.nginx.service }}
https://{{ include "ccm.fullname" . }}-nginx{{ .Values.ingress.suffix }}.{{ .Values.global.domain }}
{{- end }}
{{- else if .Values.global.sofySolutionContext }}
{{- if .Values.nginx.service }}
https://{{ include "ccm.fullname" . }}-nginx{{ .Values.ingress.suffix }}.{{- include "sofy-domain.configMapKeyRef"}}
{{- end }}
{{- else if ( .Values.nginx.urlMapping ) }}
{{ .Values.nginx.urlMapping }}
{- else if and (or (eq "NodePort" .Values.nginx.type ) (eq "LoadBalancer" .Values.nginx.type )) (.Values.nginx.exposePort )) }}
{{- if .Values.service.ipAddress }}
"https://{{ .Values.service.ipAddress }}:{{ .Values.nginx.exposePort }}"
{{- else }}
"https://{{ .Values.keycloak.service.ipAddress }}:{{ .Values.nginx.exposePort }}"
{{- end }}
{{- else if .Values.nginx.urlMapping }}
"{{ .Values.nginx.urlMapping }}"
{{- end }}
{{- end }}

{{- define "keycloaksrv.common.names.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s" .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "opensearch.validatePassword" -}}
{{- $password := .password | default "" -}}

{{- $hasLower := false -}}
{{- $hasUpper := false -}}
{{- $hasSpecial := false -}}

{{- range $i := splitList "" $password }}
  {{- if and (not $hasLower) (contains $i "abcdefghijklmnopqrstuvwxyz") }}{{- $hasLower = true }}{{- end }}
  {{- if and (not $hasUpper) (contains $i "ABCDEFGHIJKLMNOPQRSTUVWXYZ") }}{{- $hasUpper = true }}{{- end }}
  {{- if and (not $hasSpecial) (contains $i "!@#$%^&*()-_=+[]{}") }}{{- $hasSpecial = true }}{{- end }}
{{- end }}

{{- if not (and $hasLower $hasUpper $hasSpecial) }}
  {{- fail (printf "Opensearch Password must contain at least one lowercase, one uppercase, and one special character. Provided: %s" $password) }}
{{- end }}
{{- end }}

{{/* Generate a secure password with at least 1 lowercase, 1 uppercase, 1 special character 
     password: {{ include "opensearch.securePassword" .Values.opensearch.passwordLength | b64enc | quote }}
*/}}
{{- define "opensearch.securePassword" -}}
{{- $secretName := "" -}}
{{- if .Values.global.platform.enabled }}
  {{- $secretName = printf "%s-%s-opensearch" .Release.Name (include "ccm.fullname" .) -}}
{{- else }}
  {{- $secretName = printf "%s-opensearch" (include "ccm.fullname" .) -}}
{{- end }}
{{- $existing := lookup "v1" "Secret" .Release.Namespace $secretName -}}
{{- if and $existing (index $existing.data "password") -}}
  {{- (index $existing.data "password") | b64dec -}}   {{/* Reuse password if secret exists */}}
{{- else -}}
  {{- $lower := "a" -}}
  {{- $upper := "A" -}}
  {{- $special := "@" -}}
  {{- $number := "5" -}}
  {{- $random := randAlphaNum 12 -}}
  {{- printf "%s%s%s%s%s" $lower $upper $special $number $random | shuffle -}}
{{- end -}}
{{- end -}}

{{/*
Return the PostgreSQL port the container should listen on
*/}}
{{- define "postgresql.containerPort" -}}
{{- if and (.Values.postgresql.enableExternalAccess) (.Values.postgresql.service.exposePort) -}}
{{- .Values.postgresql.service.exposePort -}}
{{- else -}}
{{- .Values.postgresql.service.containerPort -}}
{{- end -}}
{{- end -}}
