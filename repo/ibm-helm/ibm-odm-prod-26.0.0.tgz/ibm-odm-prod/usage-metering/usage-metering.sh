#!/usr/bin/env sh

# IBM Usage Metering Service (UMS) Integration Script
# This script sends metrics to IBM Usage Metering Service via curl
# Supports both in-cluster execution and local execution via kubectl

set -e

# Enable debug tracing if DEBUG environment variable is set
if [ "${DEBUG}" = "true" ]; then
    echo "DEBUG mode enabled"
fi

echo "Starting IBM Usage Metering Service integration..."

# Detect execution mode and get Kubernetes credentials
if [ -f "/run/secrets/kubernetes.io/serviceaccount/namespace" ]; then
    # Running inside a Kubernetes pod - use service account
    echo "Execution mode: in-cluster"
    NAMESPACE=$(cat /run/secrets/kubernetes.io/serviceaccount/namespace)
    K8S_TOKEN=$(cat /run/secrets/kubernetes.io/serviceaccount/token)
    K8S_API="https://${KUBERNETES_SERVICE_HOST}"
    K8S_CA_CERT="/run/secrets/kubernetes.io/serviceaccount/ca.crt"
    
    # Debug: Verify token is loaded
    if [ "${DEBUG}" = "true" ]; then
        echo "DEBUG: Token loaded, length: ${#K8S_TOKEN}"
        echo "DEBUG: Token prefix: $(echo ${K8S_TOKEN} | cut -c1-20)..."
    fi
else
    # Running locally - requires environment variables to be set
    echo "Execution mode: local (using environment variables)"
    
    # Check required environment variables
    if [ -z "${K8S_API}" ]; then
        echo "ERROR: K8S_API environment variable not set."
        echo "Please set K8S_API to your Kubernetes API server URL (e.g., https://kubernetes.default.svc)"
        exit 1
    fi
    
    if [ -z "${K8S_TOKEN}" ]; then
        echo "ERROR: K8S_TOKEN environment variable not set."
        echo "Please set K8S_TOKEN to your Kubernetes authentication token."
        echo "Or set K8S_TOKEN='proxy' if using kubectl proxy."
        exit 1
    fi
    
    # Detect kubectl proxy mode
    if [ "${K8S_TOKEN}" = "proxy" ]; then
        echo "Using kubectl proxy mode (no authentication header)"
        USE_PROXY_MODE=true
    else
        USE_PROXY_MODE=false
    fi
    
    # Get namespace from environment or use default
    if [ -z "${NAMESPACE}" ]; then
        NAMESPACE="default"
        echo "WARNING: NAMESPACE environment variable not set, using 'default'"
    fi
    
    # Handle CA certificate
    if [ -n "${K8S_CA_CERT_DATA}" ]; then
        # CA cert provided as base64-encoded data
        K8S_CA_CERT="/tmp/k8s-ca-$$.crt"
        echo "${K8S_CA_CERT_DATA}" | base64 -d > "${K8S_CA_CERT}" 2>/dev/null || true
        if [ ! -s "${K8S_CA_CERT}" ]; then
            echo "WARNING: Could not decode K8S_CA_CERT_DATA, will use insecure connection"
            K8S_CA_CERT=""
        fi
    elif [ -n "${K8S_CA_CERT_FILE}" ] && [ -f "${K8S_CA_CERT_FILE}" ]; then
        # CA cert provided as file path
        K8S_CA_CERT="${K8S_CA_CERT_FILE}"
    else
        echo "WARNING: No CA certificate provided (K8S_CA_CERT_DATA or K8S_CA_CERT_FILE), will use insecure connection"
        K8S_CA_CERT=""
    fi
fi

echo "Namespace: ${NAMESPACE}"
echo "Release Name: ${RELEASE_NAME}"
echo "Kubernetes API: ${K8S_API}"

# Function to get value from ConfigMap
get_configmap_value() {
    local configmap_name=$1
    local key=$2
    local namespace=${3:-$NAMESPACE}
    
    if [ "${USE_PROXY_MODE}" = "true" ]; then
        # Proxy mode - no authentication header needed
        curl -s "${K8S_API}/api/v1/namespaces/${namespace}/configmaps/${configmap_name}" \
            | jq -r ".data.\"${key}\" // empty"
    elif [ -n "${K8S_CA_CERT}" ] && [ -f "${K8S_CA_CERT}" ]; then
        curl -s --cacert "${K8S_CA_CERT}" \
            --header "Authorization: Bearer ${K8S_TOKEN}" \
            "${K8S_API}/api/v1/namespaces/${namespace}/configmaps/${configmap_name}" \
            | jq -r ".data.\"${key}\" // empty"
    else
        echo 'Running : curl -s -k \
            --header "Authorization: Bearer '${K8S_TOKEN}'" \
            "'${K8S_API}/api/v1/namespaces/${namespace}/configmaps/${configmap_name}'" \
            | jq -r ".data.\"'${key}'\" // empty'
        curl -s -k \
            --header "Authorization: Bearer ${K8S_TOKEN}" \
            "${K8S_API}/api/v1/namespaces/${namespace}/configmaps/${configmap_name}" \
            | jq -r ".data.\"${key}\" // empty"
    fi
}

# Function to get value from Secret
get_secret_value() {
    local secret_name=$1
    local key=$2
    local namespace=${3:-$NAMESPACE}
    
    if [ "${USE_PROXY_MODE}" = "true" ]; then
        # Proxy mode - no authentication header needed
        curl -s "${K8S_API}/api/v1/namespaces/${namespace}/secrets/${secret_name}" \
            | jq -r ".data.\"${key}\" // empty" | base64 -d
    elif [ -n "${K8S_CA_CERT}" ] && [ -f "${K8S_CA_CERT}" ]; then
        curl -s --cacert "${K8S_CA_CERT}" \
            --header "Authorization: Bearer ${K8S_TOKEN}" \
            "${K8S_API}/api/v1/namespaces/${namespace}/secrets/${secret_name}" \
            | jq -r ".data.\"${key}\" // empty" | base64 -d
    else
        curl -s -k \
            --header "Authorization: Bearer ${K8S_TOKEN}" \
            "${K8S_API}/api/v1/namespaces/${namespace}/secrets/${secret_name}" \
            | jq -r ".data.\"${key}\" // empty" | base64 -d
    fi
}

# Determine UMS URL
UMS_URL=""
if [ -n "${METERING_URL}" ]; then
    UMS_URL="${METERING_URL}"
    echo "Using URL from environment: ${UMS_URL}"
else
    echo "Fetching URL from ibm-usage-metering-upload-config ConfigMap..."
    UMS_URL=$(get_configmap_value "ibm-usage-metering-upload-config" "url" 2>/dev/null || true)
    
    if [ -z "${UMS_URL}" ]; then
        # Generate default URL using the current namespace
        UMS_URL="https://ibm-usage-metering-instance.${NAMESPACE}.svc.cluster.local:8081"
        echo "ConfigMap not found. Using default URL: ${UMS_URL}"
    else
        echo "Using URL from ConfigMap: ${UMS_URL}"
    fi
fi

# Determine authentication token
UMS_TOKEN=""
SECRET_PATH="/mnt/secrets/usage-metering-secret"

if [ -d "${SECRET_PATH}" ] && [ -f "${SECRET_PATH}/token" ]; then
    UMS_TOKEN=$(cat ${SECRET_PATH}/token)
    echo "Using token from mounted secret"
else
    echo "Fetching token from ibm-usage-metering-upload-token Secret..."
    UMS_TOKEN=$(get_secret_value "ibm-usage-metering-upload-token" "token")
    if [ -z "${UMS_TOKEN}" ]; then
        echo "ERROR: Could not determine authentication token. Mount secret or ensure ibm-usage-metering-upload-token Secret exists."
        exit 1
    fi
    echo "Using token from Kubernetes Secret"
fi

# Determine TLS certificate - always load into memory
TLS_CERT_CONTENT=""

if [ -d "${SECRET_PATH}" ] && [ -f "${SECRET_PATH}/tls.crt" ]; then
    TLS_CERT_CONTENT=$(cat "${SECRET_PATH}/tls.crt")
    echo "Using TLS certificate from mounted secret"
elif [ -d "/mnt/secrets/trusted-cert-volume" ]; then
    # Use first available certificate from trusted cert volume
    FIRST_CERT=$(find /mnt/secrets/trusted-cert-volume -type f -name "*.crt" -o -name "*.pem" | head -n 1)
    if [ -n "${FIRST_CERT}" ]; then
        TLS_CERT_CONTENT=$(cat "${FIRST_CERT}")
        echo "Using TLS certificate from trusted cert volume: ${FIRST_CERT}"
    fi
else
    echo "Fetching TLS certificate from ibm-usage-metering-upload-config ConfigMap..."
    TLS_CERT_CONTENT=$(get_configmap_value "ibm-usage-metering-upload-config" "tls.crt")
    if [ -n "${TLS_CERT_CONTENT}" ]; then
        echo "Using TLS certificate from ConfigMap"
    else
        echo "WARNING: No TLS certificate found. Will attempt insecure connection."
    fi
fi

# Count the number of ready pods for each ODM component using Deployment API
echo "Counting ready pods for release: ${RELEASE_NAME}"

# Function to count ready pods for a specific deployment using Deployment API
count_deployment_pods() {
    local deployment_name=$1
    local response
    local count
    local curl_cmd
    
    if [ "${USE_PROXY_MODE}" = "true" ]; then
        curl_cmd="curl -s \"${K8S_API}/apis/apps/v1/namespaces/${NAMESPACE}/deployments/${deployment_name}\""
        echo "Executing: ${curl_cmd}" >&2
        response=$(curl -s \
            "${K8S_API}/apis/apps/v1/namespaces/${NAMESPACE}/deployments/${deployment_name}")
    elif [ -n "${K8S_CA_CERT}" ] && [ -f "${K8S_CA_CERT}" ]; then
        curl_cmd="curl -s --cacert \"${K8S_CA_CERT}\" --header \"Authorization: Bearer \${K8S_TOKEN}\" \"${K8S_API}/apis/apps/v1/namespaces/${NAMESPACE}/deployments/${deployment_name}\""
        echo "Executing: ${curl_cmd}" >&2
        response=$(curl -s --cacert "${K8S_CA_CERT}" \
            --header "Authorization: Bearer ${K8S_TOKEN}" \
            "${K8S_API}/apis/apps/v1/namespaces/${NAMESPACE}/deployments/${deployment_name}")
    else
        curl_cmd="curl -s -k --header \"Authorization: Bearer \${K8S_TOKEN}\" \"${K8S_API}/apis/apps/v1/namespaces/${NAMESPACE}/deployments/${deployment_name}\""
        echo "Executing: ${curl_cmd}" >&2
        response=$(curl -s -k \
            --header "Authorization: Bearer ${K8S_TOKEN}" \
            "${K8S_API}/apis/apps/v1/namespaces/${NAMESPACE}/deployments/${deployment_name}")
    fi
    
    # Check if response is a valid deployment object (has kind: Deployment)
    if echo "${response}" | jq -e '.kind == "Deployment"' > /dev/null 2>&1; then
        # Valid deployment, extract readyReplicas
        count=$(echo "${response}" | jq '.status.readyReplicas // 0')
    else
        # Not a valid deployment (might be error or not found)
        if [ "${DEBUG}" = "true" ]; then
            echo "DEBUG: Deployment ${deployment_name} not found or error occurred" >&2
        fi
        count=0
    fi
    
    if [ -z "${count}" ] || [ "${count}" = "null" ]; then
        echo 0
    else
        echo "${count}"
    fi
}

# Count pods for each component by deployment name
DS_CONSOLE_COUNT=$(count_deployment_pods "${RELEASE_NAME}-odm-decisionserverconsole")
DS_RUNTIME_COUNT=$(count_deployment_pods "${RELEASE_NAME}-odm-decisionserverruntime")
DC_COUNT=$(count_deployment_pods "${RELEASE_NAME}-odm-decisioncenter")
DR_COUNT=$(count_deployment_pods "${RELEASE_NAME}-odm-decisionrunner")

echo "Pod counts by component:"
echo "  Decision Server Console: ${DS_CONSOLE_COUNT}"
echo "  Decision Server Runtime: ${DS_RUNTIME_COUNT}"
echo "  Decision Center: ${DC_COUNT}"
echo "  Decision Runner: ${DR_COUNT}"

# Function to get Decision Center usage metrics from metering.log.0
get_dc_usage_metrics() {
    echo ""
    echo "Fetching Decision Center usage metrics from metering.log.0..."
    
    # Construct Decision Center service URL
    local dc_service_name="${RELEASE_NAME}-odm-decisioncenter"
    local dc_service_url="https://${dc_service_name}.${NAMESPACE}.svc.cluster.local"
    
    # Append context root if specified
    local context_root="${DC_CONTEXT_ROOT:-}"
    local metering_endpoint="${dc_service_url}${context_root}/decisioncenter/assets/metering.log.0"
    
    echo "Decision Center service URL: ${dc_service_url}"
    echo "Metering endpoint: ${metering_endpoint}"
    
    # Fetch metering log via HTTP GET request
    echo "Fetching metering log via REST API endpoint..."
    local log_content=""
    log_content=$(curl -s -k -f "${metering_endpoint}" 2>/dev/null || echo "")
    
    if [ -z "${log_content}" ]; then
        echo "WARNING: Could not fetch metering.log.0 from Decision Center REST API endpoint"
        echo "Attempted URL: ${metering_endpoint}"
        return
    fi
    
    # Get the last line (most recent metrics)
    local last_line=$(echo "${log_content}" | tail -n 1)
    
    if [ -z "${last_line}" ]; then
        echo "WARNING: metering.log.0 is empty"
        return
    fi
    
    # Extract the JSON part (after the timestamp)
    local json_part=$(echo "${last_line}" | sed 's/^[^\t]*\t//')
    
    if [ -z "${json_part}" ]; then
        echo "WARNING: Could not extract JSON from metering log"
        return
    fi
    
    echo "Parsing usage metrics from last log entry..."
    
    # Extract each metric from usageList using jq
    REGISTERED_USERS=$(echo "${json_part}" | jq -r '.usageList[] | select(.metricType=="REGISTERED_USERS") | .metricValue // 0')
    ALL_ARTIFACTS=$(echo "${json_part}" | jq -r '.usageList[] | select(.metricType=="ALL_ARTIFACTS") | .metricValue // 0')
    
    # Set defaults if empty
    REGISTERED_USERS=${REGISTERED_USERS:-0}
    ALL_ARTIFACTS=${ALL_ARTIFACTS:-0}
    
    echo "Decision Center usage metrics:"
    echo "  Registered Users: ${REGISTERED_USERS}"
    echo "  All Artifacts: ${ALL_ARTIFACTS}"
}

# Get Decision Center usage metrics
get_dc_usage_metrics


# Prepare the metrics payload
TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

# Get product information from environment variables or use defaults
PRODUCT_ID=${PRODUCT_ID:-"b1a07d4dc0364452aa6206bb6584061d"}
PRODUCT_NAME=${PRODUCT_NAME:-"IBM Operational Decision Manager"}
PRODUCT_VERSION=${PRODUCT_VERSION:-"9.6.0"}

# Get breakdown attributes for CP4BA mode
if [ "${KUBE_VERSION}" = "CP4BA" ]; then
    ENVIRONMENT=${ENVIRONMENT:-"production"}
    ARCHITECTURE=$(uname -m | sed 's/x86_64/amd64/;s/aarch64/arm64/')
    PLATFORM=${PLATFORM:-"OCP"}
    CLOUDPAK_VERSION=${CLOUDPAK_VERSION:-"26.0.0"}

    echo "CP4BA mode detected (KUBE_VERSION=${KUBE_VERSION})"
    echo "Breakdown attributes:"
    echo "  Version: ${CLOUDPAK_VERSION}"
    echo "  Environment: ${ENVIRONMENT}"
    echo "  Architecture: ${ARCHITECTURE}"
    echo "  Platform: ${PLATFORM}"
fi

# Generic function to send payload to UMS
send_payload_to_ums() {
    local PAYLOAD=$1
    local DESCRIPTION=$2
    
    # Format JSON for readability
    local PAYLOAD_FORMATTED=$(echo "${PAYLOAD}" | jq '.' 2>/dev/null || echo "${PAYLOAD}")
    
    echo ""
    echo "Sending ${DESCRIPTION} to UMS..."
    echo "URL: ${UMS_URL}/api/v1/event"
    echo "Payload:"
    echo "${PAYLOAD_FORMATTED}"
    echo ""
    
    # Execute curl command with payload from stdin to avoid filesystem writes
    if [ -n "${TLS_CERT_CONTENT}" ]; then
        if [ "${DEBUG}" = "true" ]; then
            echo "DEBUG: Using TLS certificate from memory (process substitution)"
            echo "DEBUG: Certificate content length: ${#TLS_CERT_CONTENT} bytes"
            echo "DEBUG: Curl command to execute:"
            echo "  curl -s -w '\\nHTTP_CODE:%{http_code}\\n' \\"
            echo "    --max-time 30 \\"
            echo "    --connect-timeout 10 \\"
            echo "    -H 'Content-Type: application/json' \\"
            echo "    -H 'Authorization: Bearer \${UMS_TOKEN}' \\"
            echo "    --cacert <(echo \"\${TLS_CERT_CONTENT}\") \\"
            echo "    --request POST \\"
            echo "    --data-binary @- \\"
            echo "    '${UMS_URL}/api/v1/event'"
        fi
        
        RESPONSE=$(echo "${PAYLOAD}" | curl -s -w '\nHTTP_CODE:%{http_code}\n' \
            --max-time 30 \
            --connect-timeout 10 \
            -H 'Content-Type: application/json' \
            -H "Authorization: Bearer ${UMS_TOKEN}" \
            -k \
            --cacert <(echo "${TLS_CERT_CONTENT}") \
            --request POST \
            --data-binary @- \
            "${UMS_URL}/api/v1/event")
        CURL_EXIT_CODE=$?
    else
        echo "WARNING: Using insecure connection (no certificate verification)"
        
        if [ "${DEBUG}" = "true" ]; then
            echo "DEBUG: Curl command to execute:"
            echo "  curl -s -w '\\nHTTP_CODE:%{http_code}\\n' \\"
            echo "    --max-time 30 \\"
            echo "    --connect-timeout 10 \\"
            echo "    -H 'Content-Type: application/json' \\"
            echo "    -H 'Authorization: Bearer \${UMS_TOKEN}' \\"
            echo "    -k \\"
            echo "    --request POST \\"
            echo "    --data-binary @- \\"
            echo "    '${UMS_URL}/api/v1/event'"
        fi
        
        RESPONSE=$(echo "${PAYLOAD}" | curl -s -w '\nHTTP_CODE:%{http_code}\n' \
            --max-time 30 \
            --connect-timeout 10 \
            -H 'Content-Type: application/json' \
            -H "Authorization: Bearer ${UMS_TOKEN}" \
            -k \
            --request POST \
            --data-binary @- \
            "${UMS_URL}/api/v1/event")
        CURL_EXIT_CODE=$?
    fi
    
    # Debug: Show curl exit code and raw response if DEBUG is enabled
    if [ "${DEBUG}" = "true" ]; then
        echo "DEBUG: curl exit code: ${CURL_EXIT_CODE}"
        echo "DEBUG: Raw curl response:"
        echo "${RESPONSE}"
        echo "DEBUG: End of raw response"
    fi
    
    HTTP_CODE=$(echo "${RESPONSE}" | grep "HTTP_CODE:" | cut -d: -f2)
    RESPONSE_BODY=$(echo "${RESPONSE}" | grep -v "HTTP_CODE:")
    
    echo "Response: ${RESPONSE_BODY}"
    echo "HTTP Status Code: ${HTTP_CODE}"
    
    # Return 0 for success (2xx codes), 1 for failure
    if [ "${HTTP_CODE}" = "200" ] || [ "${HTTP_CODE}" = "201" ] || [ "${HTTP_CODE}" = "202" ]; then
        return 0
    else
        return 1
    fi
}

# Build CP4BA payload with consolidated pod counts
build_cp4ba_payload() {
    # Only build payload if at least one component exists
    if [ "${DC_COUNT}" -eq 0 ] && [ "${DS_RUNTIME_COUNT}" -eq 0 ] && [ "${DR_COUNT}" -eq 0 ] && [ "${DS_CONSOLE_COUNT}" -eq 0 ]; then
        echo ""
        return
    fi
    
    if [ "${DC_COUNT}" -eq 0 ]; then
        REGISTERED_USERS=0
        ALL_ARTIFACTS=0
    fi
    
    # Build instanceId from namespace and cloudpak version
    local INSTANCE_ID="${NAMESPACE}-cp4ba-${CLOUDPAK_VERSION}"
    
    # Build payload with all pod counts and DC usage metrics in a single metric object
    cat <<EOF
[{
  "mappingId": "cp4baodmdeployment00000000000001",
  "instances": [{
    "instanceId": "${INSTANCE_ID}",
    "metrics": [{
      "metricQuantity": 1,
      "version": "${CLOUDPAK_VERSION}",
      "environment": "${ENVIRONMENT}",
      "architecture": "${ARCHITECTURE}",
      "platform": "${PLATFORM}",
      "dc_pods_count": ${DC_COUNT},
      "dc_registered_users": ${REGISTERED_USERS},
      "dc_num_of_artifacts": ${ALL_ARTIFACTS},
      "dr_pods_count": ${DR_COUNT},
      "dsc_pods_count": ${DS_CONSOLE_COUNT},
      "dsr_pods_count": ${DS_RUNTIME_COUNT}
    }]
  }]
}]
EOF
}

# Build and send payloads based on KUBE_VERSION
echo "Building metrics payload..."

# Build instanceId from namespace and release name
INSTANCE_ID="${NAMESPACE}-${RELEASE_NAME}"

if [ "${KUBE_VERSION}" != "CP4BA" ]; then
    echo "Building standalone mode payload (KUBE_VERSION=${KUBE_VERSION})..."
    
    # Initialize metrics array
    METRICS_JSON=""
    
    # Standalone mode: Keep existing format with all fields
    METRICS_JSON="${METRICS_JSON}{\"metricName\":\"Decision Server Console Pods\",\"metricQuantity\":${DS_CONSOLE_COUNT},\"InstanceID\":\"${INSTANCE_ID}\",\"MetricDescription\":\"Number of Decision Server Console pods\",\"productId\":\"${PRODUCT_ID}\",\"productName\":\"${PRODUCT_NAME}\",\"productVersion\":\"${PRODUCT_VERSION}\"},"
    METRICS_JSON="${METRICS_JSON}{\"metricName\":\"Decision Server Runtime Pods\",\"metricQuantity\":${DS_RUNTIME_COUNT},\"InstanceID\":\"${INSTANCE_ID}\",\"MetricDescription\":\"Number of Decision Server Runtime pods\",\"productId\":\"${PRODUCT_ID}\",\"productName\":\"${PRODUCT_NAME}\",\"productVersion\":\"${PRODUCT_VERSION}\"},"
    METRICS_JSON="${METRICS_JSON}{\"metricName\":\"Decision Center Pods\",\"metricQuantity\":${DC_COUNT},\"InstanceID\":\"${INSTANCE_ID}\",\"MetricDescription\":\"Number of Decision Center pods\",\"productId\":\"${PRODUCT_ID}\",\"productName\":\"${PRODUCT_NAME}\",\"productVersion\":\"${PRODUCT_VERSION}\"},"
    METRICS_JSON="${METRICS_JSON}{\"metricName\":\"Decision Runner Pods\",\"metricQuantity\":${DR_COUNT},\"InstanceID\":\"${INSTANCE_ID}\",\"MetricDescription\":\"Number of Decision Runner pods\",\"productId\":\"${PRODUCT_ID}\",\"productName\":\"${PRODUCT_NAME}\",\"productVersion\":\"${PRODUCT_VERSION}\"},"
    
    # Add Decision Center usage metrics if available
    if [ -n "${REGISTERED_USERS}" ] && [ "${REGISTERED_USERS}" -gt 0 ]; then
        METRICS_JSON="${METRICS_JSON}{\"metricName\":\"Decision Center Registered Users\",\"metricQuantity\":${REGISTERED_USERS},\"InstanceID\":\"${INSTANCE_ID}\",\"MetricDescription\":\"Number of registered users in Decision Center\",\"productId\":\"${PRODUCT_ID}\",\"productName\":\"${PRODUCT_NAME}\",\"productVersion\":\"${PRODUCT_VERSION}\"},"
    fi
    
    if [ -n "${ALL_ARTIFACTS}" ] && [ "${ALL_ARTIFACTS}" -gt 0 ]; then
        METRICS_JSON="${METRICS_JSON}{\"metricName\":\"Decision Center All Artifacts\",\"metricQuantity\":${ALL_ARTIFACTS},\"InstanceID\":\"${INSTANCE_ID}\",\"MetricDescription\":\"Total number of artifacts in Decision Center\",\"productId\":\"${PRODUCT_ID}\",\"productName\":\"${PRODUCT_NAME}\",\"productVersion\":\"${PRODUCT_VERSION}\"},"
    fi
    
    # Add CNCF standalone installation metric
    echo "Detected ODM on CNCF standalone installation (KUBE_VERSION=${KUBE_VERSION})"
    METRICS_JSON="${METRICS_JSON}{\"metricName\":\"ODM on CNCF Installation\",\"metricQuantity\":1,\"InstanceID\":\"${INSTANCE_ID}\",\"MetricDescription\":\"ODM on CNCF standalone installation\",\"productId\":\"${PRODUCT_ID}\",\"productName\":\"${PRODUCT_NAME}\",\"productVersion\":\"${PRODUCT_VERSION}\"},"
    
    # Remove trailing comma
    METRICS_JSON=$(echo "${METRICS_JSON}" | sed 's/,$//')
    
    # Build standalone payload
    PAYLOAD="[{\"processing\":\"LAST\",\"instances\":[{\"metrics\":[${METRICS_JSON}]}]}]"
    
    # Send single payload for standalone mode
    send_payload_to_ums "${PAYLOAD}" "standalone metrics"
    SEND_RESULT=$?
else
    echo "Building CP4BA mode - sending single payload with all components..."
    echo "Component counts: DC=${DC_COUNT}, DS Runtime=${DS_RUNTIME_COUNT}, DR=${DR_COUNT}, DS Console=${DS_CONSOLE_COUNT}"
    
    # CP4BA mode: Build single payload with all metrics
    # This matches the breakdownDefs in IBMServiceMeterDefinition with mappingId: cp4baodmdeployment00000000000001
    PAYLOAD=$(build_cp4ba_payload)
    
    if [ -n "${PAYLOAD}" ]; then
        # Send single payload for all components
        send_payload_to_ums "${PAYLOAD}" "CP4BA ODM metrics"
        SEND_RESULT=$?
    else
        echo "No components to report"
        SEND_RESULT=0
    fi
fi

# Check if the request was successful
if [ ${SEND_RESULT} -eq 0 ]; then
    echo "✓ Metrics sent successfully to IBM Usage Metering Service"
    EXIT_CODE=0
else
    echo "✗ ERROR: Failed to send metrics to IBM Usage Metering Service"
    EXIT_CODE=1
fi

# Cleanup temporary CA certificate file if created for local execution
if [ -f "/tmp/k8s-ca-$$.crt" ]; then
    rm -f "/tmp/k8s-ca-$$.crt"
fi

exit ${EXIT_CODE}
