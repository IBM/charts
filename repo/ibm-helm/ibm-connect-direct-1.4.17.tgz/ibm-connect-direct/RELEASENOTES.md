# Breaking Changes

- None

# Whats new in Helm chart v1.4.17 for IBM Connect:Direct for UNIX v6.4.0.5-iFix007-2026-03-17-iFix000-2026-02-23-iFix011-2026-01-13-iFix003-2025-12-11-iFix000-2025-12-04-iFix011-2025-11-03-iFix001-2025-10-03-iFix012-2025-09-15-iFix008-2025-08-21-iFix004-2025-07-29

- UBI upgrade
- Security fixes

# Fixes

- For Application defect fixes, refer [fixlist.txt](./ibm_cloud_pak/fixlist.txt).

# Prerequisites

Please refer prerequisites section from [README.md](README.md)

# Documentation

Please refer to [README.md](README.md) provided with chart for detailed installation instruction.

# Version History

| Chart | Date         | Kubernetes Required | OpenShift Required       | Image(s) Supported                                    | Details            |
| ----- | ------------ | ------------------- | ------------------------ | ----------------------------------------------------- | ------------------ | 
| 1.4.0 | Nov 20, 2024 | >= 1.27 <= 1.31     | >=4.14 <=4.16            | cdu6.4_certified_container_6.4.0.0:6.4.0.0_ifix000    | C:D Unix 6.4.0.0   |
| 1.4.1 | Nov 26, 2024 | >= 1.27 <= 1.31     | >=4.14 <=4.16            | cdu6.4_certified_container_6.4.0.0:6.4.0.0_ifix001    | C:D Unix 6.4.0.0   |
| 1.4.2 | Jan 08, 2025 | >= 1.27 <= 1.32     | >=4.14 <=4.17            | cdu6.4_certified_container_6.4.0.1:6.4.0.1_iFix001	| C:D Unix 6.4.0.1   |
| 1.4.3 | Mar 06, 2025 | >= 1.27 <= 1.32     | >=4.14 <=4.17            | cdu6.4_certified_container_6.4.0.1:6.4.0.1_iFix018	| C:D Unix 6.4.0.1   |
| 1.4.4 | Apr 24, 2025 | >= 1.27 <= 1.32     | >=4.14 <=4.17            | cdu6.4_certified_container_6.4.0.1:6.4.0.1_iFix029	| C:D Unix 6.4.0.1   |
| 1.4.5 | May 27, 2025 | >= 1.27 <= 1.32     | >=4.14 <=4.17            | cdu6.4_certified_container_6.4.0.1:6.4.0.1_iFix034	| C:D Unix 6.4.0.1   |
| 1.4.6 | Jun 19, 2025 | >= 1.27 < 1.33      | >=4.14 <=4.18            | cdu6.4_certified_container_6.4.0.1:6.4.0.1_iFix038	| C:D Unix 6.4.0.1   |
| 1.4.7 | Jul 08, 2025 | >= 1.27 < 1.33      | >=4.14 <=4.18            | cdu6.4_certified_container_6.4.0.2:6.4.0.2_iFix000	| C:D Unix 6.4.0.2   |
| 1.4.8 | Jul 30, 2025 | >= 1.27 < 1.34      | >=4.14 <=4.18            | cdu:6.4.0.2-iFix004-2025-07-29	                | C:D Unix 6.4.0.2-iFix004-2025-07-29   |
| 1.4.9 | Aug 21, 2025 | >= 1.28 < 1.34      | >=4.15 <=4.19            | cdu:6.4.0.2-iFix008-2025-08-21	                | C:D Unix 6.4.0.2-iFix008-2025-08-21   |
| 1.4.10 | Sep 16, 2025 | >= 1.28 < 1.34     | >=4.15 <=4.19            | cdu:6.4.0.2-iFix012-2025-09-15	                | C:D Unix 6.4.0.2-iFix012-2025-09-15   |
| 1.4.11 | Oct 06, 2025 | >= 1.28 < 1.34     | >=4.15 <=4.19            | cdu:6.4.0.3-iFix001-2025-10-03	                | C:D Unix 6.4.0.3-iFix001-2025-10-03   |
| 1.4.12 | Nov 03, 2025 | >= 1.28 < 1.34     | >=4.15 <=4.19            | cdu:6.4.0.3-iFix011-2025-11-03	                | C:D Unix 6.4.0.3-iFix011-2025-11-03   |
| 1.4.13 | Dec 04, 2025 | >= 1.28 < 1.34     | >=4.15 <=4.19            | cdu:6.4.0.4-iFix000-2025-12-04	                | C:D Unix 6.4.0.4-iFix000-2025-12-04   |
| 1.4.14 | Dec 12, 2025 | >= 1.28 < 1.34     | >=4.15 <=4.19            | cdu:6.4.0.4-iFix003-2025-12-11	                | C:D Unix 6.4.0.4-iFix003-2025-12-11   |
| 1.4.15 | Jan 16, 2026 | >= 1.28 < 1.34     | >=4.15 <=4.19            | cdu:6.4.0.4-iFix011-2026-01-13	                | C:D Unix 6.4.0.4-iFix011-2026-01-13   |
| 1.4.16 | Feb 25, 2026 | >= 1.28 < 1.34     | >=4.15 <=4.19            | cdu:6.4.0.5-iFix000-2026-02-23	                | C:D Unix 6.4.0.5-iFix000-2026-02-23   |
| 1.4.17 | Mar 18, 2026 | >= 1.28            | >=4.15                   | cdu:6.4.0.5-iFix007-2026-03-17	                | C:D Unix 6.4.0.5-iFix007-2026-03-17   |

`Note: The images listed here are minimum supported container image for the respective helm chart version.`

