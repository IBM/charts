#!/usr/bin/env sh

RESTART=true
SECRETS_MOUNT_POINT=/mnt/secrets

if [ ! -d ${SECRETS_MOUNT_POINT} ]; then
    echo "${SECRETS_MOUNT_POINT} does not exist or is not a directory"
    exit 0
fi

SECRETS_SUM=$(cat $(find ${SECRETS_MOUNT_POINT} -type f | sort) | sha1sum | awk '{print $1}')
echo "Secret sum: ${SECRETS_SUM}"

NAMESPACE=$(cat /run/secrets/kubernetes.io/serviceaccount/namespace)
TOKEN=$(cat /run/secrets/kubernetes.io/serviceaccount/token)

OLD_SECRETS_SUM=$(curl https://${KUBERNETES_SERVICE_HOST}:443/api/v1/namespaces/${NAMESPACE}/configmaps/${BEACON_NAME} --header "Authorization: Bearer ${TOKEN}" --insecure --silent | jq -r ".data.secrets_sum")

echo "Old secret sum: ${OLD_SECRETS_SUM}"

if [[ ! ${OLD_SECRETS_SUM} ]]; then RESTART=false; fi

if [[ "${OLD_SECRETS_SUM}" != "${SECRETS_SUM}" ]]; then
    curl https://${KUBERNETES_SERVICE_HOST}:443/api/v1/namespaces/${NAMESPACE}/configmaps/${BEACON_NAME} \
        --data "{\"data\":{\"secrets_sum\":\"${SECRETS_SUM}\"}}" \
        --header "Authorization: Bearer ${TOKEN}" --header "content-type: application/merge-patch+json" \
        --insecure --request PATCH
   if [[ ${RESTART} = true ]]; then
    DEPLOYMENTS=(
        "${RELEASE_NAME}-odm-decisioncenter"
        "${RELEASE_NAME}-odm-decisionrunner"
        "${RELEASE_NAME}-odm-decisionserverconsole"
        "${RELEASE_NAME}-odm-decisionserverruntime"
    )
    PATCH='{"spec":{"template":{"metadata":{"annotations":{"checksum":"'$(echo ${SECRETS_SUM})'","kubectl.kubernetes.io/restartedAt":"'$(date -u +%Y-%m-%dT%H:%M:%SZ)'"}}}}}'
    echo "Restarting deployments:"
    for DEPLOYMENT in "${DEPLOYMENTS[@]}"; do
        STATUS=$(curl --write-out "%{http_code}" \
            --request PATCH \
            --header "Authorization: Bearer ${TOKEN}" \
            --header "Content-Type: application/strategic-merge-patch+json" \
            --data "${PATCH}" \
            --insecure \
            "https://${KUBERNETES_SERVICE_HOST}:443/apis/apps/v1/namespaces/${NAMESPACE}/deployments/${DEPLOYMENT}")
        echo "  ${DEPLOYMENT} → HTTP ${STATUS}"
    done
    fi
fi

exit 0
