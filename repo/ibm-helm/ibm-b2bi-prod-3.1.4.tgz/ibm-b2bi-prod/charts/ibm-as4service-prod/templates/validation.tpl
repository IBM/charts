# (C) Copyright 2025 Precisely Incorporated. All rights reserved.

{{- /*
A function to validate if passed parameter is a valid integer
*/ -}}
{{- define "integerValidation" -}}
{{- $type := kindOf . -}}
{{- if or (eq $type "float64") (eq $type "int") -}}
    {{- $isIntegerPositive := include "isIntegerPositive" . -}}
    {{- if eq $isIntegerPositive "true" -}}
    	true
    {{- else -}}
    	false
    {{- end -}}	
{{- else -}}
    false
{{- end -}}
{{- end -}}

{{/*
A function to validate if passed integer is non negative
*/}}
{{- define "isIntegerPositive" -}}
{{- $inputInt := int64 . -}}
{{- if gt $inputInt -1 -}}
    true
{{- else -}}
    false
{{- end -}}
{{- end -}}

{{/*
A function to validate if passed parameter is a valid string
*/}}
{{- define "stringValidation" -}}
{{- $type := kindOf . -}}
{{- if or (eq $type "string") (eq $type "String") -}}
    true
{{- else -}}
    false
{{- end -}}
{{- end -}}

{{/*
A function to check for mandatory arguments
*/}}
{{- define "mandatoryArgumentsCheck" -}}
{{- if . -}}
    true
{{- else -}}
    false
{{- end -}}
{{- end -}}

{{/*
A function to check for port range
*/}}
{{- define "portRangeValidation" -}}
{{- $portNo := int64 . -}}
{{- if and (gt $portNo 0) (lt $portNo 65536) -}}
    true
{{- else -}}
    false
{{- end -}}
{{- end -}}

{{/*
A function to check if port is valid
*/}}
{{- define "isPortValid" -}}
{{- $result := include "integerValidation" . -}}
{{- if eq $result "true" -}}
	{{- $isPortValid := include "portRangeValidation" . -}}
	{{- if eq $isPortValid "true" -}}
	true
	{{- else -}}
	false
	{{- end -}}
{{- else -}}
	false
{{- end -}}
{{- end -}}

{{/*
A function to check if port range is valid
*/}}
{{- define "isPortRangeValid" -}}
{{- $result := false -}}
{{- $portRangeNumbers := split "-" . -}}
{{- $isPortRangeStartValid := include "isPortValid" ($portRangeNumbers._0|int) -}}
{{- if eq $isPortRangeStartValid "true" -}}
	{{- $isPortRangeEndValid := include "isPortValid" ($portRangeNumbers._1|int) -}}
	{{- if eq $isPortRangeEndValid "true" -}}
	{{- $isPortRangeOrderValid := ge ($portRangeNumbers._1|int) ($portRangeNumbers._0|int) -}}
	{{- if eq $isPortRangeOrderValid true -}}
	{{- $result = true -}}
	{{- end -}}
	{{- end -}}
{{- end -}}
{{- if eq $result true -}}
  true
{{- else -}}
  false
{{- end -}}
{{- end -}}

{{/*
A function to check if name is valid
*/}}
{{- define "isNameValid" -}}
{{- $result := regexMatch "[a-z0-9]([-a-z0-9]*[a-z0-9])?" . -}}
{{- if eq $result true -}}
  true
{{- else -}}
  false
{{- end -}}
{{- end -}}


{{- define "backendServiceCheck" -}}
{{- $result := include "mandatoryArgumentsCheck" .type -}}
{{- if eq $result "false" -}}
{{- fail "backendService.type cannot be empty" -}}
{{- end -}}
{{- $result := .type -}}
{{- if not (or (eq $result "NodePort") (eq $result "LoadBalancer") (eq $result "ClusterIP") (eq $result "ExternalName")) -}}
{{- fail "backendService.type is not valid. Valid values are NodePort,LoadBalancer, ClusterIP or ExternalName" -}}
{{- end -}}
{{- $result := .sessionAffinity -}}
{{- if not (or (eq $result "ClientIP") (eq $result "None")) -}}
{{- fail "backendService.sessionAffinity is not valid. Valid values are ClientIP or None" -}}
{{- end -}}
{{- if (and (eq $result "ClientIP") (.sessionAffinityConfig.timeoutSeconds)) -}}
{{- $result := include "integerValidation" .sessionAffinityConfig.timeoutSeconds -}}
{{- if eq $result "false" -}}
{{- fail "Provide a valid value for backendService.sessionAffinityConfig.timeoutSeconds" -}}
{{- end -}}
{{- end -}}
{{- $result := .externalTrafficPolicy -}}
{{- if not (or (eq $result "Cluster") (eq $result "Local")) -}}
{{- fail "backendService.externalTrafficPolicy is not valid. Valid values are Cluster or Local" -}}
{{- end -}}
{{- range $i, $port := .ports -}}
{{- include "servicePortCheck" $port -}}
{{- end -}}
{{- range $i, $portRange := .portRanges -}}
{{- include "servicePortRangeCheck" $portRange -}}
{{- end -}}
{{- end -}}


{{/*
A function to check for validity of service ports
*/}}
{{- define "servicePortCheck" -}}
{{- $result := include "isPortValid" .port -}}
{{- if eq $result "false" -}}
{{- fail "Provide a valid value for port in service" -}}
{{- end -}}
{{- $result := include "isPortValid" .targetPort -}}
{{- if eq $result "false" -}}
{{- $nameCheck := include "isNameValid" .targetPort -}}
{{- if eq $nameCheck "false" -}}
{{- fail "Provide a valid value for targetPort in service" -}}
{{- end -}}
{{- end -}}

{{- $nodePortValue := .nodePort -}}
{{- if $nodePortValue -}}
{{- $result := include "isPortValid" .nodePort -}}
{{- if eq $result "false" -}}
{{- fail "Provide a valid value for nodePort in service" -}}
{{- end -}}
{{- end -}}

{{- $result := include "isNameValid" .name -}}
{{- if eq $result "false" -}}
{{- fail "Provide a valid value for name in service" -}}
{{- end -}}

{{- $result := .protocol -}}
{{- if $result -}}
{{- if not (or (eq $result "TCP") (eq $result "UDP") (eq $result "HTTP") (eq $result "SCTP") (eq $result "PROXY")) -}}
{{- fail "Provide a valid value for protocol in service. Valid values are TCP, UDP, HTTP, SCTP or PROXY" -}}
{{- end -}}
{{- end -}}

{{- end -}}

{{/*
A function to check for validity of service ports
*/}}
{{- define "servicePortRangeCheck" -}}

{{- $result := include "isPortRangeValid" .portRange -}}
{{- if eq $result "false" -}}
{{- fail "Provide a valid value for port range in service" -}}
{{- end -}}

{{- $result := include "isPortRangeValid" .targetPortRange -}}
{{- if eq $result "false" -}}
{{- fail "Provide a valid value for target port range in service" -}}
{{- end -}}

{{- if .nodePortRange -}}
{{- $result := include "isPortRangeValid" .nodePortRange -}}
{{- if eq $result "false" -}}
{{- fail "Provide a valid value for node port range in service" -}}
{{- end -}}
{{- end -}}

{{- $result := include "isNameValid" .name -}}
{{- if eq $result "false" -}}
{{- fail "Provide a valid value for name in service" -}}
{{- end -}}

{{- $result := .protocol -}}
{{- if $result -}}
{{- if not (or (eq $result "TCP") (eq $result "UDP") (eq $result "HTTP") (eq $result "SCTP") (eq $result "PROXY")) -}}
{{- fail "Provide a valid value for protocol in service. Valid values are TCP, UDP, HTTP, SCTP or PROXY" -}}
{{- end -}}
{{- end -}}

{{- end -}}

{{/*
A function to validate an email address
*/}}
{{- define "emailValidator" -}}
{{- $emailRegex := "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$" -}}
{{- $isValid := regexMatch $emailRegex . -}}
{{- if eq $isValid true -}}
	true
{{- else -}}
	false	
{{- end -}}
{{- end -}}

{{/*
A function to validate the user or group name and ID
*/}}
{{- define "userOrGroupNameIDValidator" -}}
{{- $isInteger := include "integerValidation" . -}}
{{- if eq $isInteger "true" -}}
	true
{{- else -}}
	{{- $userOrGroupNameRegex := "^[a-z][-a-z0-9]*$" -}}
	{{- $isValid := regexMatch $userOrGroupNameRegex . -}}
	{{- if eq $isValid true -}}
		true
	{{- else -}}
		false
	{{- end -}}				
{{- end -}}
{{- end -}}

{{/*
A function to validate arch
*/}}
{{- define "archValidator" -}}
{{- $archList := list "0 - Do not use" "1 - Least preferred" "2 - No Preference" "3 - Most preferred" -}}
{{- $isValid := has . $archList -}}
{{- if eq $isValid true -}}
	true
{{- else -}}
	false	
{{- end -}}
{{- end -}}

{{/*
Main function to test the input validations
*/}}

{{- define "as4Service.validateInput" -}}

{{- $isValid := .Values.license }}
{{- if not (eq $isValid true) }}
{{- fail "License must be accepted by setting license key to true" }}
{{- end }}

{{- $typeStr :=  .Values.licenseType | toString | lower -}}
{{- if not ( or (eq $typeStr "prod") (eq $typeStr "non-prod")) -}}
{{- fail "Configuration Error: Please provide a valid value for parameter licenseType. Value can be either prod or non-prod." -}}
{{- end -}}

{{- $result := include "integerValidation" .Values.as4catalog.replicaCount -}}
{{- if eq $result "false" -}}
{{- fail "Provide a valid value for .Values.as4catalog.replicaCount" -}}
{{- end -}}

{{- $result := include "mandatoryArgumentsCheck" .Values.image.repository -}}
{{- if eq $result "false" -}}
{{- fail ".Values.image.repository cannot be empty." -}}
{{- end -}}

{{- $result := include "mandatoryArgumentsCheck" .Values.image.tag -}}
{{- if eq $result "false" -}}
{{- fail ".Values.image.tag cannot be empty" -}}
{{- end -}}

{{- $result := include "mandatoryArgumentsCheck" .Values.image.pullPolicy -}}
{{- if eq $result "false" -}}
{{- fail ".Values.image.pullPolicy cannot be empty" -}}
{{- end -}}

{{- $isValid := .Values.persistence.enabled | toString -}}
{{- if not ( or (eq $isValid "false") (eq $isValid "true")) -}}
{{- fail "Provide a valid value for field Values.persistence.enabled. Value can be either true or false." -}}
{{- end -}}

{{- $dynamicProvisioning := .Values.persistence.useDynamicProvisioning | toString -}}
{{- if not ( or (eq $dynamicProvisioning "false") (eq $dynamicProvisioning "true")) -}}
{{- fail "Provide a valid value for field Values.persistence.useDynamicProvisioning. Value can be either true or false." -}}
{{- end -}}


{{- if .Values.security.supplementalGroups -}}
    {{- range .Values.security.supplementalGroups }}
    	{{- $isValid := include "userOrGroupNameIDValidator" . -}}
		{{- if eq $isValid "false" -}}
		{{- fail "Values.security.supplementalGroups is invalid. Either provide a numeric value for group ID or follow the pattern ^[a-z][-a-z0-9]*$ to provide valid group name in an array." -}}
		{{- end -}}
    {{- end }}
{{- end -}}

{{- if .Values.security.fsGroup -}}
{{- $isValid := include "userOrGroupNameIDValidator" .Values.security.fsGroup -}}
{{- if eq $isValid "false" -}}
{{- fail "Values.security.fsGroup is invalid. Either provide a numeric value for group ID or follow the pattern ^[a-z][-a-z0-9]*$ to provide valid group name." -}}
{{- end -}}
{{- end -}}

{{- if .Values.security.runAsUser -}}
{{- $isValid := include "userOrGroupNameIDValidator" .Values.security.runAsUser -}}
{{- if eq $isValid "false" -}}
{{- fail "Values.security.runAsUser is invalid. Either provide a numeric value for user ID or follow the pattern ^[a-z][-a-z0-9]*$ to provide valid user name." -}}
{{- end -}}
{{- end -}}

{{- $isIngressEnabled := .Values.ingress.enabled | toString -}}
{{- if not ( or (eq $isValid "false") (eq $isValid "true")) -}}
{{- fail "Provide a valid value for Values.ingress.enabled. Value can be either false or true." -}}
{{- end -}}

{{- if (.Values.ingress.enabled | default true) -}}
	{{- $result := include "mandatoryArgumentsCheck" .Values.as4informational.ingress.internal.host -}}
	{{- if eq $result "false" -}}
	{{- fail ".Values.as4informational.ingress.internal.host cannot be empty" -}}
	{{- end -}}
	
	
{{- end -}}

{{- $isValid := .Values.as4catalog.autoscaling.enabled | toString -}}
{{- if not ( or (eq $isValid "false") (eq $isValid "true")) -}}
{{- fail "Provide a valid value for Values.as4catalog.autoscaling.enabled. Value can be either false or true." -}}
{{- end -}}

{{- if eq $isValid "true" -}}
	{{- $isValid := include "integerValidation" .Values.as4catalog.autoscaling.minReplicas -}}
	{{- if eq $isValid "false" -}}
	{{- fail "Values.as4catalog.autoscaling.minReplicas is not valid." -}}
	{{- end -}}

	{{- $isValid := include "integerValidation" .Values.as4catalog.autoscaling.maxReplicas -}}
	{{- if eq $isValid "false" -}}
	{{- fail "Values.as4catalog.autoscaling.maxReplicas is not valid." -}}
	{{- end -}}

	{{- $isValid := include "integerValidation" .Values.as4catalog.autoscaling.targetCPUUtilizationPercentage -}}
	{{- if eq $isValid "false" -}}
	{{- fail "Values.as4catalog.autoscaling.targetCPUUtilizationPercentage is not valid." -}}
	{{- end -}}
{{- end -}}

{{- $enableAppLogOnConsole := .Values.logs.enableAppLogOnConsole | toString -}}
{{- if not ( or (eq $enableAppLogOnConsole "false") (eq $enableAppLogOnConsole "true")) -}}
{{- fail "Provide a valid value for Values.logs.enableAppLogOnConsole. Value can be either false or true." -}}
{{- end -}}

{{- $logsPVCEnabled := .Values.appLogsPVC.enabled | toString -}}
{{- if not ( or (eq $logsPVCEnabled "false") (eq $logsPVCEnabled "true")) -}}
{{- fail "Please provide correct value for .Values.appLogsPVC.enabled. Value can be either false or true." -}}
{{- end -}}

{{- $accessMode := .Values.appLogsPVC.accessMode -}}
{{- if not ( or (eq $accessMode "ReadWriteOnce") (eq $accessMode "ReadWriteOncePod") (eq $accessMode "ReadOnlyMany") (eq $accessMode "ReadWriteMany") ( not (empty .Values.appLogsPVC.preDefinedLogsPVCName))) -}}
{{- fail "Please specify Values.appLogsPVC.accessMode as one of these supported access modes - ReadWriteOnce | ReadOnlyMany | ReadWriteMany | ReadWriteOncePod" -}}
{{- end -}}

{{- $isValid := .Values.dataSetup.enabled | toString -}}
{{- if not ( or (eq $isValid "false") (eq $isValid "true")) -}}
{{- fail "Please provide value for Values.dataSetup.enabled. Value can be either false or true." -}}
{{- end -}}

{{- $isValid := .Values.dataSetup.logLevel -}}
{{- if not ( or (eq $isValid "SEVERE") (eq $isValid "WARNING") (eq $isValid "INFO") (eq $isValid "FINE") (eq $isValid "OFF")) -}}
{{- fail "Please specify logLevel as one of these supported values - SEVERE | WARNING | INFO | FINE | OFF " -}}
{{- end -}}

{{- $isValid := .Values.dbSetup.dbVendor -}}
{{- if not ( or (eq $isValid "DB2") (eq $isValid "Oracle") (eq $isValid "MSSQL") (eq $isValid "db2") (eq $isValid "oracle") (eq $isValid "mssql")) -}}
{{- fail "Please specify dbVendor as one of these supported databases - DB2 | Oracle | MSSQL" -}}
{{- end -}}

{{- $dbVendor := .Values.dbSetup.dbVendor -}}
{{- if or (eq $isValid "MSSQL") (eq $isValid "mssql") -}}

{{- $isValid := .Values.dbSetup.MSSQL_TRUST_SERVER_CERTIFICATE | toString -}}
{{- if not ( or (eq $isValid "false") (eq $isValid "true")) -}}
{{- fail "Please provide Value for MSSQL_TRUST_SERVER_CERTIFICATE. Value can be either false or true." -}}
{{- end -}}

{{- $isValid := include "mandatoryArgumentsCheck" .Values.dbSetup.MSSQL_ENCRYPT -}}
{{- if eq $isValid "false" -}}
{{- fail "Please specify the value for .Values.dbSetup.MSSQL_ENCRYPT." -}}
{{- end -}}

{{- end -}}

{{- $dbVendor := .Values.dbSetup.dbVendor -}}
{{- if or (eq $isValid "Oracle") (eq $isValid "oracle") -}}

{{- $isValid := .Values.dbSetup.useOracleServiceName | toString -}}
{{- if not ( or (eq $isValid "false") (eq $isValid "true")) -}}
{{- fail "Please provide Value for useOracleServiceName. Value can be either false or true." -}}
{{- end -}}
{{- end -}}

{{- $isValid := include "mandatoryArgumentsCheck" .Values.dbSetup.dbHost -}}
{{- if eq $isValid "false" -}}
{{- fail "Please specify the dbHost." -}}
{{- end -}}

{{- $isValid := include "isPortValid" .Values.dbSetup.dbPort -}}
{{- if eq $isValid "false" -}}
{{- fail "Please specify the dbPort correctly." -}}
{{- end -}}

{{- $isValid := include "mandatoryArgumentsCheck" .Values.dbSetup.identityDbData -}}
{{- if eq $isValid "false" -}}
{{- fail "Please specify the Identity DatabaseName in values.dbSetup.identityDbData" -}}
{{- end -}}

{{- $isValid := include "mandatoryArgumentsCheck" .Values.dbSetup.commsDbData -}}
{{- if eq $isValid "false" -}}
{{- fail "Please specify the Comms DatabaseName in values.dbSetup.commsDbData" -}}
{{- end -}}


{{- $isValid := include "mandatoryArgumentsCheck" .Values.dbSetup.infraDbData -}}
{{- if eq $isValid "false" -}}
{{- fail "Please specify the Infra DatabaseName in values.dbSetup.infraDbData" -}}
{{- end -}}


{{- $isValid := include "mandatoryArgumentsCheck" .Values.dbSetup.uiDbData -}}
{{- if eq $isValid "false" -}}
{{- fail "Please specify the UI DatabaseName in values.dbSetup.uiDbData" -}}
{{- end -}}


{{- $dbVendor := .Values.dbSetup.dbVendor -}}
{{- if (or (eq $dbVendor "DB2") (eq $dbVendor "db2") ) -}}

{{- $isValid := include "mandatoryArgumentsCheck" .Values.dbSetup.identitySchema -}}
{{- if eq $isValid "false" -}}
{{- fail "Please specify the Identity Schema name in values.dbSetup.identitySchema" -}}
{{- end -}}

{{- $isValid := include "mandatoryArgumentsCheck" .Values.dbSetup.commsSchema -}}
{{- if eq $isValid "false" -}}
{{- fail "Please specify the Comms Schema name in values.dbSetup.commsSchema" -}}
{{- end -}}


{{- $isValid := include "mandatoryArgumentsCheck" .Values.dbSetup.infraSchema -}}
{{- if eq $isValid "false" -}}
{{- fail "Please specify the Infra Schema name in values.dbSetup.infraSchema" -}}
{{- end -}}


{{- $isValid := include "mandatoryArgumentsCheck" .Values.dbSetup.uiSchema -}}
{{- if eq $isValid "false" -}}
{{- fail "Please specify the UI Schema name in values.dbSetup.uiSchema" -}}
{{- end -}}

{{- end -}}

{{- $isValid := include "mandatoryArgumentsCheck" .Values.dbSetup.dbSecret -}}
{{- if eq $isValid "false" -}}
{{- fail "Please specify the dbSecret." -}}
{{- end -}}

{{- $isValid := .Values.dbSetup.usessl | toString -}}
{{- if not ( or (eq $isValid "false") (eq $isValid "true")) -}}
{{- fail "Please provide Value for usessl. Value can be either false or true." -}}
{{- end -}}

{{- $isSSL := .Values.dbSetup.usessl | toString -}}
{{- $dbVendor := .Values.dbSetup.dbVendor -}}
{{- if (eq $isSSL "true") -}}
	{{- if not .Values.dbSetup.sslVersion -}}
        {{- fail "Please provide ssl Version to be used." -}}
        {{- end -}}
        {{- if not .Values.dbSetup.dbTruststore -}}
        {{- fail "Please provide the path of dbTruststore file." -}}
        {{- end -}}
        {{- if not .Values.dbSetup.dbTruststoreSecret -}}
        {{- fail "Please provide dbTruststoreSecret secret name." -}}
        {{- end -}}
{{- end -}}


{{- $isValid := include "mandatoryArgumentsCheck" .Values.mqSetup.mqHost -}}
{{- if eq $isValid "false" -}}
{{- fail "Please specify the MQ Host." -}}
{{- end -}}

{{- $isValid := include "mandatoryArgumentsCheck" .Values.mqSetup.mqPort -}}
{{- if eq $isValid "false" -}}
{{- fail "Please specify the MQ Port." -}}
{{- end -}}

{{- $isValid := include "mandatoryArgumentsCheck" .Values.mqSetup.mqServerChannel -}}
{{- if eq $isValid "false" -}}
{{- fail "Please specify the MQ Channel." -}}
{{- end -}}

{{- $isValid := include "mandatoryArgumentsCheck" .Values.mqSetup.mqServerQueueManager -}}
{{- if eq $isValid "false" -}}
{{- fail "Please specify the Queue Manager." -}}
{{- end -}}

{{- $isValid := include "mandatoryArgumentsCheck" .Values.mqSetup.mqSecret -}}
{{- if eq $isValid "false" -}}
{{- fail "Please specify the MQ Secret." -}}
{{- end -}}

{{- $isMQSSLEnabled := .Values.mqSetup.enableSsl | toString -}}
{{- if not ( or (eq $isMQSSLEnabled "false") (eq $isMQSSLEnabled "true")) -}}
{{- fail "Please provide Value for mqSetup.enableSsl. Value can be either false or true." -}}
{{- end -}}


{{- $isValid := include "mandatoryArgumentsCheck" .Values.wxsSetup.wxsSecret -}}
{{- if eq $isValid "false" -}}
{{- fail "Please specify the WXSSetup Secret." -}}
{{- end -}}

{{- $isValid := include "mandatoryArgumentsCheck" .Values.setupCfg.sslProtocol -}}
{{- if eq $isValid "false" -}}
{{- fail "Please specify the value for setupCfg.sslProtocol" -}}
{{- end -}}


# as4catalog validation
{{- $isValidLivenessInitialDelay := include "integerValidation" .Values.as4catalog.livenessProbe.initialDelaySeconds -}}
{{- if eq $isValidLivenessInitialDelay "false" -}}
  {{- fail "Values.as4catalog.livenessProbe.initialDelaySeconds is not valid." -}}
{{- end -}}

{{- $isValidLivenessTimeout := include "integerValidation" .Values.as4catalog.livenessProbe.timeoutSeconds -}}
{{- if eq $isValidLivenessTimeout "false" -}}
  {{- fail "Values.as4catalog.livenessProbe.timeoutSeconds is not valid." -}}
{{- end -}}

{{- $isValidLivenessPeriod := include "integerValidation" .Values.as4catalog.livenessProbe.periodSeconds -}}
{{- if eq $isValidLivenessPeriod "false" -}}
  {{- fail "Values.as4catalog.livenessProbe.periodSeconds is not valid." -}}
{{- end -}}

{{- $isValidReadinessInitialDelay := include "integerValidation" .Values.as4catalog.readinessProbe.initialDelaySeconds -}}
{{- if eq $isValidReadinessInitialDelay "false" -}}
  {{- fail "Values.as4catalog.readinessProbe.initialDelaySeconds is not valid." -}}
{{- end -}}

{{- $isValidReadinessTimeout := include "integerValidation" .Values.as4catalog.readinessProbe.timeoutSeconds -}}
{{- if eq $isValidReadinessTimeout "false" -}}
  {{- fail "Values.as4catalog.readinessProbe.timeoutSeconds is not valid." -}}
{{- end -}}

{{- $isValidReadinessPeriod := include "integerValidation" .Values.as4catalog.readinessProbe.periodSeconds -}}
{{- if eq $isValidReadinessPeriod "false" -}}
  {{- fail "Values.as4catalog.readinessProbe.periodSeconds is not valid." -}}
{{- end -}}

# as4operational validation
{{- include "backendServiceCheck" .Values.as4operational.backendService -}}
{{- $isValidOperationalLivenessInitialDelay := include "integerValidation" .Values.as4operational.livenessProbe.initialDelaySeconds -}}
{{- if eq $isValidOperationalLivenessInitialDelay "false" -}}
  {{- fail "Values.as4operational.livenessProbe.initialDelaySeconds is not valid." -}}
{{- end -}}

{{- $isValidOperationalLivenessTimeout := include "integerValidation" .Values.as4operational.livenessProbe.timeoutSeconds -}}
{{- if eq $isValidOperationalLivenessTimeout "false" -}}
  {{- fail "Values.as4operational.livenessProbe.timeoutSeconds is not valid." -}}
{{- end -}}

{{- $isValidOperationalLivenessPeriod := include "integerValidation" .Values.as4operational.livenessProbe.periodSeconds -}}
{{- if eq $isValidOperationalLivenessPeriod "false" -}}
  {{- fail "Values.as4operational.livenessProbe.periodSeconds is not valid." -}}
{{- end -}}

{{- $isValidOperationalReadinessInitialDelay := include "integerValidation" .Values.as4operational.readinessProbe.initialDelaySeconds -}}
{{- if eq $isValidOperationalReadinessInitialDelay "false" -}}
  {{- fail "Values.as4operational.readinessProbe.initialDelaySeconds is not valid." -}}
{{- end -}}

{{- $isValidOperationalReadinessTimeout := include "integerValidation" .Values.as4operational.readinessProbe.timeoutSeconds -}}
{{- if eq $isValidOperationalReadinessTimeout "false" -}}
  {{- fail "Values.as4operational.readinessProbe.timeoutSeconds is not valid." -}}
{{- end -}}

{{- $isValidOperationalReadinessPeriod := include "integerValidation" .Values.as4operational.readinessProbe.periodSeconds -}}
{{- if eq $isValidOperationalReadinessPeriod "false" -}}
  {{- fail "Values.as4operational.readinessProbe.periodSeconds is not valid." -}}
{{- end -}}

# as4container validation
{{- $isValidContainerLivenessInitialDelay := include "integerValidation" .Values.as4container.livenessProbe.initialDelaySeconds -}}
{{- if eq $isValidContainerLivenessInitialDelay "false" -}}
  {{- fail "Values.as4container.livenessProbe.initialDelaySeconds is not valid." -}}
{{- end -}}

{{- $isValidContainerLivenessTimeout := include "integerValidation" .Values.as4container.livenessProbe.timeoutSeconds -}}
{{- if eq $isValidContainerLivenessTimeout "false" -}}
  {{- fail "Values.as4container.livenessProbe.timeoutSeconds is not valid." -}}
{{- end -}}

{{- $isValidContainerLivenessPeriod := include "integerValidation" .Values.as4container.livenessProbe.periodSeconds -}}
{{- if eq $isValidContainerLivenessPeriod "false" -}}
  {{- fail "Values.as4container.livenessProbe.periodSeconds is not valid." -}}
{{- end -}}

{{- $isValidContainerReadinessInitialDelay := include "integerValidation" .Values.as4container.readinessProbe.initialDelaySeconds -}}
{{- if eq $isValidContainerReadinessInitialDelay "false" -}}
  {{- fail "Values.as4container.readinessProbe.initialDelaySeconds is not valid." -}}
{{- end -}}

{{- $isValidContainerReadinessTimeout := include "integerValidation" .Values.as4container.readinessProbe.timeoutSeconds -}}
{{- if eq $isValidContainerReadinessTimeout "false" -}}
  {{- fail "Values.as4container.readinessProbe.timeoutSeconds is not valid." -}}
{{- end -}}

{{- $isValidContainerReadinessPeriod := include "integerValidation" .Values.as4container.readinessProbe.periodSeconds -}}
{{- if eq $isValidContainerReadinessPeriod "false" -}}
  {{- fail "Values.as4container.readinessProbe.periodSeconds is not valid." -}}
{{- end -}}

# as4informational validation
{{- $isValidInformationalLivenessInitialDelay := include "integerValidation" .Values.as4informational.livenessProbe.initialDelaySeconds -}}
{{- if eq $isValidInformationalLivenessInitialDelay "false" -}}
  {{- fail "Values.as4informational.livenessProbe.initialDelaySeconds is not valid." -}}
{{- end -}}

{{- $isValidInformationalLivenessTimeout := include "integerValidation" .Values.as4informational.livenessProbe.timeoutSeconds -}}
{{- if eq $isValidInformationalLivenessTimeout "false" -}}
  {{- fail "Values.as4informational.livenessProbe.timeoutSeconds is not valid." -}}
{{- end -}}

{{- $isValidInformationalLivenessPeriod := include "integerValidation" .Values.as4informational.livenessProbe.periodSeconds -}}
{{- if eq $isValidInformationalLivenessPeriod "false" -}}
  {{- fail "Values.as4informational.livenessProbe.periodSeconds is not valid." -}}
{{- end -}}

{{- $isValidInformationalReadinessInitialDelay := include "integerValidation" .Values.as4informational.readinessProbe.initialDelaySeconds -}}
{{- if eq $isValidInformationalReadinessInitialDelay "false" -}}
  {{- fail "Values.as4informational.readinessProbe.initialDelaySeconds is not valid." -}}
{{- end -}}

{{- $isValidInformationalReadinessTimeout := include "integerValidation" .Values.as4informational.readinessProbe.timeoutSeconds -}}
{{- if eq $isValidInformationalReadinessTimeout "false" -}}
  {{- fail "Values.as4informational.readinessProbe.timeoutSeconds is not valid." -}}
{{- end -}}

{{- $isValidInformationalReadinessPeriod := include "integerValidation" .Values.as4informational.readinessProbe.periodSeconds -}}
{{- if eq $isValidInformationalReadinessPeriod "false" -}}
  {{- fail "Values.as4informational.readinessProbe.periodSeconds is not valid." -}}
{{- end -}}

{{- $isValidInformationalStartupInitialDelay := include "integerValidation" .Values.as4informational.startupProbe.initialDelaySeconds -}}
{{- if eq $isValidInformationalStartupInitialDelay "false" -}}
  {{- fail "Values.as4informational.startupProbe.initialDelaySeconds is not valid." -}}
{{- end -}}

{{- $isValidInformationalStartupTimeout := include "integerValidation" .Values.as4informational.startupProbe.timeoutSeconds -}}
{{- if eq $isValidInformationalStartupTimeout "false" -}}
  {{- fail "Values.as4informational.startupProbe.timeoutSeconds is not valid." -}}
{{- end -}}

{{- $isValidInformationalStartupPeriod := include "integerValidation" .Values.as4informational.startupProbe.periodSeconds -}}
{{- if eq $isValidInformationalStartupPeriod "false" -}}
  {{- fail "Values.as4informational.startupProbe.periodSeconds is not valid." -}}
{{- end -}}

{{- $isValidInformationalStartupFailureThreshold := include "integerValidation" .Values.as4informational.startupProbe.failureThreshold -}}
{{- if eq $isValidInformationalStartupFailureThreshold "false" -}}
  {{- fail "Values.as4informational.startupProbe.failureThreshold is not valid." -}}
{{- end -}}



{{- if and (.Values.resourcesInit.enabled) (.Values.appResourcesPVC.enabled) -}}
{{ fail "Only one of 'resourcesInit.enabled' or 'appResourcesPVC.enabled' can be true, not both." }}
{{- end -}}

{{- $isValid := .Values.resourcesInit.enabled | toString -}}
{{- if not ( or (eq $isValid "false") (eq $isValid "true")) -}}
{{- fail "Please provide value for Values.resourcesInit.enabled. Value can be either false or true." -}}
{{- end -}}
{{- if eq $isValid "true" -}}
	{{- $result := .Values.appResourcesPVC.enabled | toString -}}
	{{- if eq $result "true" -}}
	{{- fail "To configure and map application resources either .Values.appResourcesPVC.enabled or .Values.resourcesInit.enabled should be set to true but not both." -}}
	{{- end -}}

	{{- $result := include "mandatoryArgumentsCheck" .Values.resourcesInit.image.repository -}}
	{{- if eq $result "false" -}}
	{{- fail ".Values.resourcesInit.image.repository cannot be empty." -}}
	{{- end -}}

	{{- if not .Values.resourcesInit.image.digest -}}
	{{- $result := include "mandatoryArgumentsCheck" .Values.resourcesInit.image.tag -}}
	{{- if eq $result "false" -}}
	{{- fail "Please specify either .Values.resourcesInit.image.tag or .Values.resourcesInit.image.digest " -}}
	{{- end -}}
	{{- end -}}

	{{- $result := include "mandatoryArgumentsCheck" .Values.resourcesInit.image.pullPolicy -}}
	{{- if eq $result "false" -}}
	{{- fail ".Values.resourcesInit.image.pullPolicy cannot be empty." -}}
	{{- end -}}
	
{{- end -}}




{{/*
Starting Validation of as4catalog configuration properties.
*/}}

{{- $isValid := include "isPortValid" .Values.as4catalog.server.port -}}
{{- if eq $isValid "false" -}}
{{- fail "Provide a valid values for server port." -}}
{{- end -}}


{{- if (.Values.as4catalog.server.ssl.enabled ) -}}
{{- $isValid := include "mandatoryArgumentsCheck" .Values.as4catalog.server.ssl.keyStoreSecretName -}}
{{- if eq $isValid "false" -}}
{{- fail "Provide a value for keystore secret name." -}}
{{- end -}}
{{- $isValid := include "mandatoryArgumentsCheck" .Values.as4catalog.server.ssl.trustStoreSecretName -}}
{{- if eq $isValid "false" -}}
{{- fail "Provide a value for truststore secret name." -}}
{{- end -}}
{{- $keyStoreType := lower .Values.as4catalog.server.ssl.keyStoreType -}}
{{- if not ( or (eq $keyStoreType "pkcs12") (eq $keyStoreType "jks")) -}}
{{- fail "Please specify .Values.as4catalog.server.ssl.keyStoreType as one of the supported values - pkcs12|jks" -}}
{{- end -}}
{{- $trustStoreType := lower .Values.as4catalog.server.ssl.trustStoreType -}}
{{- if not ( or (eq $trustStoreType "pkcs12") (eq $trustStoreType "jks")) -}}
{{- fail "Please specify .Values.as4catalog.server.ssl.trustStoreType as one of the supported values - pkcs12|jks" -}}
{{- end -}}
{{- end -}}

{{- end -}}
