######################################################### {COPYRIGHT-TOP} ###
# IBM Confidential
# OCO Source Materials
# 5900-AEO
#
# Copyright IBM Corp. 2026
#
# The source code for this program is not published or otherwise
# divested of its trade secrets,
# irrespective of what has been deposited with the U.S Copyright Office.
######################################################### {COPYRIGHT-END} ###
{{/*
Expand the name of the chart.
*/}}
{{- define "ibm-text2sql.name" -}}
{{- default .Release.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "ibm-text2sql.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "ibm-text2sql.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "ibm-text2sql.labels" -}}
helm.sh/chart: {{ include "ibm-text2sql.chart" . }}
{{ include "ibm-text2sql.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "ibm-text2sql.selectorLabels" -}}
app.kubernetes.io/name: {{ include "ibm-text2sql.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Concatenate image registry with image name.
Usage: {{ include "ibm-text2sql.image" (dict "imageName" "text2sql" "context" .) }}
*/}}
{{- define "ibm-text2sql.image" -}}
{{- $image := index .context.Values.images .imageName -}}
{{- printf "%s/%s" .context.Values.images.registry $image -}}
{{- end -}}

{{/*
Lookup secret value by secret name and key
Usage: {{ include "ibm-text2sql.secretValue" (dict "secretName" "my-secret" "key" "password" "context" .) }}
*/}}
{{- define "ibm-text2sql.secretValue" -}}
{{- $secret := lookup "v1" "Secret" .context.Release.Namespace .secretName -}}
{{- if $secret -}}
{{- index $secret.data .key | b64dec -}}
{{- else -}}
{{- "" -}}
{{- end -}}
{{- end -}}

{{/*
Validate with custom error message
*/}}
{{- define "ibm-text2sql.requiredMsg" -}}
{{- if or (not .value) (eq .value "") -}}
{{- fail .message -}}
{{- end -}}
{{- .value -}}
{{- end -}}