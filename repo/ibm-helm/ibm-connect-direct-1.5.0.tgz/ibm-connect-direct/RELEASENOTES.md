# Breaking Changes

- None

# Whats new in Helm chart v1.5.0 for IBM Connect:Direct for UNIX v6.5.0.0

- Arbitrary User Support
- UBI minimal upgrade
- Security fixes

# Fixes

- For Application defect fixes, refer [fixlist.txt](./ibm_cloud_pak/fixlist.txt).

# Prerequisites

Please refer prerequisites section from [README.md](README.md)

# Documentation

Please refer to [README.md](README.md) provided with chart for detailed installation instruction.

# Version History

| Chart | Date         | Kubernetes Required | OpenShift Required | Image(s) Supported             | Details                             |
| ----- | ------------ | ------------------- | ------------------ | ------------------------------ | ----------------------------------- | 
| 1.5.0 | Oct 13, 2026 | >= 1.33             | >=4.18             | cdu:6.5.0.0-iFix000-2026-10-13 | C:D Unix 6.5.0.0-iFix000-2026-10-13 |

`Note: The images listed here are minimum supported container image for the respective helm chart version.`

