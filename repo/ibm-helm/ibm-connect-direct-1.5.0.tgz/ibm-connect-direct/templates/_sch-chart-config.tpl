{{- /*
Chart specific config file for SCH (Shared Configurable Helpers)
_sch-chart-config.tpl is a config file for the chart to specify additional
values and/or override values defined in the sch/_config.tpl file.

*/ -}}

{{- /*
"sch.chart.config.values" contains the chart specific values used to override or provide
additional configuration values used by the Shared Configurable Helpers.
*/ -}}
{{- define "ibm-connect-direct.sch.chart.config.values" -}}
sch:
  chart:
    appName: "ibm-connect-direct"
    metering:
    {{- if eq (toString .Values.licenseType | lower) "non-prod"  }}
      productName: "IBM Sterling Connect Direct Premium Ed Non Prod Certified Container"
      productID: "54f9be5388f94bd4a7fc1c56ca59a6bd"
    {{- else }}
      productName: "IBM Sterling Connect Direct Premium Ed Certified Container"
      productID: "0e99fe73c7ae4b799e11d00a9bbf0db0"
    {{- end }}
      productVersion: "6.5"
      productMetric: "VIRTUAL_PROCESSOR_CORE"
      productChargedContainers: "All"
    podSecurityContext:
      runAsNonRoot: true
      seccompProfile:
        type: "RuntimeDefault"
      supplementalGroups: 
{{- if .Values.storageSecurity.supplementalGroups }}
{{ toYaml .Values.storageSecurity.supplementalGroups | indent 8 }}
{{- else }}
      - 65534
{{- end }}

      {{- if eq (lower (toString .Values.spm.enabled)) "y" }}
      #fsGroup: null
      {{- else }}
      fsGroup: {{ toJson .Values.storageSecurity.fsGroup | default 45678 }}
      {{- end }}
      {{- if and (.Capabilities.APIVersions.Has "security.openshift.io/v1") (eq (lower (toString .Values.spm.enabled)) "y") }}
      # OpenShift - allow SCC to assign UID
      {{- else }}
      # OpenShift SPM supports custom runAsUser values and SCC-assigned runtime UIDs
      # If no runAsUser value is provided, the container runs in root user mode and 
      # Non-OCP clusters use UID 45678 by default.
      runAsUser: {{ ternary (toJson .Values.storageSecurity.runAsUser) "45678" (and (.Capabilities.APIVersions.Has "security.openshift.io/v1") (eq .Values.spm.enabled "y")) }}
      runAsGroup: 0
      {{- end }}
    containerSecurityContext:
      privileged: false
      {{- if eq (lower (toString .Values.spm.enabled)) "y" }}
      runAsUser: {{ ternary (toJson .Values.storageSecurity.runAsUser) "45678" (and (.Capabilities.APIVersions.Has "security.openshift.io/v1") (eq .Values.spm.enabled "y")) }}
      {{- end }}
      readOnlyRootFilesystem: false
      {{- if eq (toString .Values.spm.enabled | lower) "y" }}
      allowPrivilegeEscalation: false
      {{- else }}
      allowPrivilegeEscalation: true
      {{- end }}
      capabilities:
        drop: [ "ALL" ]
      {{- if eq (lower (toString .Values.spm.enabled)) "n" }}
        add: [ "CHOWN", "SETGID", "SETUID", "DAC_OVERRIDE", "FOWNER", "AUDIT_WRITE", "SYS_CHROOT" ]
      {{- end }}
{{- end -}}
