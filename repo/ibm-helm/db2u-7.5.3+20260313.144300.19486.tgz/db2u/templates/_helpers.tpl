{{/*
Return the list of namespaces the operator should watch:
- Always starts with tetheredNamespaces (if any)
- Adds instanceNamespace if set
- Prepends operatorNamespace if set
*/}}
{{- define "db2u.watchNamespaces" -}}
  {{- $watchNamespaces := default (list) .Values.global.tetheredNamespaces -}}

  {{- if .Values.global.instanceNamespace }}
    {{- $watchNamespaces = append $watchNamespaces .Values.global.instanceNamespace }}
  {{- end }}

  {{- if .Values.global.operatorNamespace }}
    {{- $watchNamespaces = prepend $watchNamespaces .Values.global.operatorNamespace }}
  {{- end }}

  {{- $watchNamespaces | toYaml }}
{{- end }}

{{/*
Return the db2u operator image reference with digest, based on global.arch.
Falls back gracefully if no digest is found.
*/}}
{{- define "db2u.operatorImage" -}}
  {{- $arch := toString (default "" .Values.global.arch) -}}
  {{- $imageName := printf "%s/%s" .Values.global.imagePullPrefix .Values.db2u.operatorImageName -}}
  {{- if and (eq $arch "amd64") (not (empty .Values.db2u.operatorImageDigest.amd64)) }}
    {{- printf "%s@%s" $imageName .Values.db2u.operatorImageDigest.amd64 -}}
  {{- else if and (eq $arch "ppc64le") (not (empty .Values.db2u.operatorImageDigest.ppc64le)) }}
    {{- printf "%s@%s" $imageName .Values.db2u.operatorImageDigest.ppc64le -}}
  {{- else if and (eq $arch "s390x") (not (empty .Values.db2u.operatorImageDigest.s390x)) }}
    {{- printf "%s@%s" $imageName .Values.db2u.operatorImageDigest.s390x -}}
  {{- else }}
    {{- $imageName -}}
  {{- end -}}
{{- end }}

{{/*
Return the db2uDay2 operator image reference with digest, based on global.arch.
Falls back gracefully if no digest is found.
*/}}
{{- define "db2uDay2.operatorImage" -}}
  {{- $arch := toString (default "" .Values.global.arch) -}}
  {{- $imageName := printf "%s/%s" .Values.global.imagePullPrefix .Values.db2u.day2.operatorImageName -}}
  {{- if and (eq $arch "amd64") (not (empty .Values.db2u.day2.operatorImageDigest.amd64)) }}
    {{- printf "%s@%s" $imageName .Values.db2u.day2.operatorImageDigest.amd64 -}}
  {{- else if and (eq $arch "ppc64le") (not (empty .Values.db2u.day2.operatorImageDigest.ppc64le)) }}
    {{- printf "%s@%s" $imageName .Values.db2u.day2.operatorImageDigest.ppc64le -}}
  {{- else if and (eq $arch "s390x") (not (empty .Values.db2u.day2.operatorImageDigest.s390x)) }}
    {{- printf "%s@%s" $imageName .Values.db2u.day2.operatorImageDigest.s390x -}}
  {{- else }}
    {{- $imageName -}}
  {{- end -}}
{{- end }}
